@extends('layouts.app')

@section('title', 'Retreat Management')

@section('content')
<div class="space-y-6">

    {{-- Header --}}
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
            <h1 class="text-3xl font-serif font-light text-slate-900">Retreat Blueprint Studio</h1>
            <p class="text-xs text-slate-500 mt-1">Deploy, modify, copy, or instantiate luxury holistic programming profiles.</p>
        </div>
        <a href="{{ route('retreats.create') }}"
           class="py-3 px-5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-md flex items-center gap-2 transition-all hover:scale-[1.01] glow-ai self-start">
            <i class="fa-solid fa-sparkles text-amber-300"></i>
            <span>Launch Guided Program Studio Wizard</span>
        </a>
    </div>

    {{-- Stats Strip --}}
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <x-stat-card label="Total Programs" :value="$stats['total']" icon="fa-spa" color="purple" />
        <x-stat-card label="Live Listings" :value="$stats['live']" icon="fa-circle-dot" color="wellness" />
        <x-stat-card label="Drafts" :value="$stats['draft']" icon="fa-pencil" color="amber" />
        <x-stat-card label="Upcoming" :value="$stats['upcoming']" icon="fa-calendar-arrow-up" color="blue" />
        <x-stat-card label="Avg Occupancy" :value="$stats['avg_occupancy'] . '%'" icon="fa-users" color="purple" />
    </div>

    {{-- Filters --}}
    <div class="glass-premium p-4 rounded-2xl border border-white" x-data="{ showFilters: false }">
        <div class="flex items-center gap-3 flex-wrap">
            {{-- Search --}}
            <div class="relative flex-1 min-w-48">
                <i class="fa-regular fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
                <input type="text"
                       name="search"
                       value="{{ request('search') }}"
                       placeholder="Search retreats..."
                       class="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-lavender-500/20 focus:border-lavender-500 outline-none"
                       hx-get="{{ route('retreats.index') }}"
                       hx-trigger="keyup changed delay:400ms"
                       hx-target="#retreats-grid"
                       hx-push-url="true"
                       hx-include="[name='status'],[name='category'],[name='sort']">
            </div>

            {{-- Status filter --}}
            <select name="status"
                    class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:border-lavender-500 outline-none"
                    onchange="this.form && this.form.submit()">
                <option value="" {{ !request('status') ? 'selected' : '' }}>All Status</option>
                <option value="live" {{ request('status') === 'live' ? 'selected' : '' }}>Live</option>
                <option value="draft" {{ request('status') === 'draft' ? 'selected' : '' }}>Draft</option>
            </select>

            {{-- Category filter --}}
            <select name="category"
                    class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:border-lavender-500 outline-none">
                <option value="">All Categories</option>
                @foreach($categories as $cat)
                <option value="{{ $cat->id }}" {{ request('category') == $cat->id ? 'selected' : '' }}>
                    {{ $cat->name }}
                </option>
                @endforeach
            </select>

            {{-- Sort --}}
            <select name="sort"
                    class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:border-lavender-500 outline-none">
                <option value="created_at">Newest</option>
                <option value="name">Name</option>
                <option value="price_per_person">Price</option>
                <option value="start_date_time">Start Date</option>
            </select>

            {{-- View toggle --}}
            <div class="ml-auto flex items-center gap-1 border border-slate-200 rounded-xl p-1 bg-white">
                <button class="p-1.5 rounded-lg bg-slate-900 text-white" title="Grid view">
                    <i class="fa-solid fa-grid-2 text-xs"></i>
                </button>
                <button class="p-1.5 rounded-lg text-slate-500 hover:text-slate-900" title="List view">
                    <i class="fa-solid fa-list text-xs"></i>
                </button>
            </div>
        </div>
    </div>

    {{-- Retreats Grid --}}
    <div id="retreats-grid">
        @if($retreats->isEmpty())
        <div class="glass-premium rounded-3xl border border-white p-16 text-center">
            <i class="fa-regular fa-spa text-4xl text-lavender-300 mb-4 block"></i>
            <h3 class="text-xl font-serif text-slate-900 mb-2">No retreats yet</h3>
            <p class="text-sm text-slate-500 mb-6">Launch your first wellness program and start accepting bookings worldwide.</p>
            <a href="{{ route('retreats.create') }}"
               class="inline-flex items-center gap-2 py-3 px-6 bg-slate-900 text-white rounded-xl text-sm font-semibold">
                <i class="fa-solid fa-sparkles text-amber-300"></i>
                Create Your First Retreat
            </a>
        </div>
        @else
        <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
            @foreach($retreats as $retreat)
            <x-retreat-card :retreat="$retreat" />
            @endforeach
        </div>

        {{-- Pagination --}}
        <div class="mt-6">
            {{ $retreats->links('components.pagination') }}
        </div>
        @endif
    </div>

</div>
@endsection
