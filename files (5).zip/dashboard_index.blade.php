@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="space-y-8">

    {{-- Page Header --}}
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
            <h1 class="text-3xl font-serif font-light text-slate-900">
                Good {{ now()->hour < 12 ? 'morning' : (now()->hour < 17 ? 'afternoon' : 'evening') }},
                <span class="font-semibold">{{ auth()->user()->first_name }}</span>
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                {{ auth()->user()->center->name }} ·
                <span class="text-{{ auth()->user()->center->is_verified ? 'emerald' : 'amber' }}-600 font-medium">
                    {{ auth()->user()->center->is_verified ? '✓ Verified Center' : 'Verification Pending' }}
                </span>
            </p>
        </div>
        <div class="flex items-center gap-3">
            <select id="period-select"
                    class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:ring-2 focus:ring-lavender-500/20 focus:border-lavender-500 outline-none"
                    onchange="window.location.href='?period=' + this.value">
                <option value="7" {{ $period == 7 ? 'selected' : '' }}>Last 7 days</option>
                <option value="30" {{ $period == 30 ? 'selected' : '' }}>Last 30 days</option>
                <option value="90" {{ $period == 90 ? 'selected' : '' }}>Last 90 days</option>
                <option value="365" {{ $period == 365 ? 'selected' : '' }}>Last year</option>
            </select>
            <a href="{{ route('retreats.create') }}"
               class="py-2.5 px-5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-md flex items-center gap-2 transition-all hover:scale-[1.01]">
                <i class="fa-solid fa-sparkles text-amber-300 text-xs"></i>
                <span>New Retreat</span>
            </a>
        </div>
    </div>

    {{-- KPI Stats Grid --}}
    <section class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <x-stat-card
            label="Total Bookings"
            :value="number_format($currentBookings)"
            :trend="$prevBookings > 0 ? round(($currentBookings - $prevBookings) / $prevBookings * 100, 1) : null"
            icon="fa-calendar-check"
            color="purple"
        />
        <x-stat-card
            label="Revenue"
            :value="'$' . number_format($currentRevenue, 0)"
            :trend="$prevRevenue > 0 ? round(($currentRevenue - $prevRevenue) / $prevRevenue * 100, 1) : null"
            icon="fa-circle-dollar-to-slot"
            color="wellness"
        />
        <x-stat-card
            label="Inquiries"
            :value="number_format($currentInquiries)"
            :trend="$prevInquiries > 0 ? round(($currentInquiries - $prevInquiries) / $prevInquiries * 100, 1) : null"
            icon="fa-messages"
            color="peach"
        />
        <x-stat-card
            label="Conversion Rate"
            :value="$conversionRate . '%'"
            icon="fa-arrow-trend-up"
            color="purple"
        />
    </section>

    {{-- Main 2-col content --}}
    <section class="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {{-- Revenue Chart --}}
        <div class="xl:col-span-2 glass-premium p-6 rounded-2xl border border-white shadow-sm">
            <div class="flex items-center justify-between mb-5">
                <div>
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-900">Revenue & Bookings Trend</h3>
                    <p class="text-[10px] text-slate-400 mt-0.5">Last {{ $period }} days · Live data</p>
                </div>
                <div class="flex items-center gap-3 text-[10px] text-slate-500">
                    <span class="flex items-center gap-1"><span class="h-2.5 w-2.5 rounded-full bg-lavender-500 inline-block"></span> Revenue</span>
                    <span class="flex items-center gap-1"><span class="h-2.5 w-2.5 rounded-full bg-emerald-500 inline-block"></span> Bookings</span>
                </div>
            </div>

            {{-- Chart canvas --}}
            <div id="revenue-chart" class="h-48 w-full" data-chart='@json($chartDays)'></div>
        </div>

        {{-- AI Insights --}}
        <div class="glass-premium p-6 rounded-2xl border border-white shadow-sm space-y-4">
            <div class="flex items-center gap-2 pb-3 border-b border-slate-100">
                <i class="fa-solid fa-wand-magic-sparkles text-lavender-500 text-sm animate-pulse"></i>
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-900">AI Insights</h3>
            </div>

            @forelse(auth()->user()->center->aiRecommendations->take(3) as $rec)
            <div class="p-3 rounded-xl border space-y-1.5
                {{ $rec->type === 'pricing' ? 'bg-purple-50/50 border-purple-100' : 'bg-emerald-50/50 border-emerald-100' }}">
                <span class="text-[8px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded font-mono
                    {{ $rec->type === 'pricing' ? 'bg-purple-100 text-purple-700' : 'bg-emerald-100 text-emerald-700' }}">
                    {{ ucfirst($rec->type) }} Insight
                </span>
                <p class="text-xs font-light text-slate-700 leading-relaxed">{{ Str::limit($rec->recommendation, 120) }}</p>
                <div class="flex items-center gap-2 pt-1">
                    <form method="POST" action="{{ route('ai.recommendations.apply', $rec) }}">
                        @csrf
                        <button class="text-[10px] font-semibold text-purple-600 hover:underline">Apply ↗</button>
                    </form>
                    <form method="POST" action="{{ route('ai.recommendations.dismiss', $rec) }}">
                        @csrf
                        <button class="text-[10px] text-slate-400 hover:text-slate-600">Dismiss</button>
                    </form>
                </div>
            </div>
            @empty
            <div class="text-center py-6 text-slate-400">
                <i class="fa-regular fa-robot text-2xl mb-2 block"></i>
                <p class="text-xs">AI insights will appear here</p>
            </div>
            @endforelse

            <a href="{{ route('ai.recommendations') }}" class="text-[10px] text-lavender-600 font-semibold hover:underline flex items-center gap-1">
                View all recommendations <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
    </section>

    {{-- Top Retreats + Recent Bookings --}}
    <section class="grid grid-cols-1 xl:grid-cols-2 gap-6">

        {{-- Top Performing Retreats --}}
        <div class="glass-premium p-6 rounded-2xl border border-white shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-900">Top Retreat Performance</h3>
                <a href="{{ route('analytics.index') }}" class="text-[10px] text-lavender-600 font-semibold hover:underline">Full Analytics →</a>
            </div>

            <div class="space-y-3">
                @forelse($topRetreats as $retreat)
                <div class="flex items-center gap-3 p-3 rounded-xl bg-white border border-slate-100 hover:border-lavender-200 transition-all">
                    <div class="h-10 w-10 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                        @if($retreat->thumbnail_image_url)
                        <img src="{{ $retreat->thumbnail_image_url }}" class="w-full h-full object-cover" alt="{{ $retreat->name }}">
                        @else
                        <div class="w-full h-full flex items-center justify-center">
                            <i class="fa-regular fa-spa text-slate-300"></i>
                        </div>
                        @endif
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-xs font-semibold text-slate-900 truncate">{{ $retreat->name }}</p>
                        <div class="flex items-center gap-3 mt-1">
                            <div class="w-20 h-1 bg-slate-100 rounded-full overflow-hidden">
                                <div class="h-full bg-emerald-500 rounded-full" style="width: {{ $retreat->occupancy_rate }}%"></div>
                            </div>
                            <span class="text-[10px] text-emerald-600 font-bold">{{ $retreat->occupancy_rate }}%</span>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-xs font-bold font-mono text-slate-900">${{ number_format($retreat->bookings_sum_pay_amount, 0) }}</p>
                        <p class="text-[10px] text-slate-400">{{ $retreat->bookings_count }} bookings</p>
                    </div>
                </div>
                @empty
                <div class="text-center py-8 text-slate-400">
                    <i class="fa-regular fa-spa text-2xl mb-2 block"></i>
                    <p class="text-xs">No retreat data yet</p>
                    <a href="{{ route('retreats.create') }}" class="text-lavender-600 font-semibold text-xs hover:underline mt-1 inline-block">Create your first retreat →</a>
                </div>
                @endforelse
            </div>
        </div>

        {{-- Recent Bookings --}}
        <div class="glass-premium p-6 rounded-2xl border border-white shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-900">Recent Bookings</h3>
                <a href="{{ route('bookings.index') }}" class="text-[10px] text-lavender-600 font-semibold hover:underline">View all →</a>
            </div>

            <div class="space-y-2">
                @forelse($recentBookings as $booking)
                <a href="{{ route('bookings.show', $booking) }}"
                   class="flex items-center gap-3 p-3 rounded-xl border border-slate-100 hover:border-lavender-200 hover:bg-lavender-50/30 transition-all">
                    <div class="h-8 w-8 rounded-full bg-gradient-to-tr from-lavender-500 to-peach-400 flex items-center justify-center text-white text-[10px] font-bold shrink-0">
                        {{ strtoupper(substr($booking->userInfo?->firstname ?? '?', 0, 1)) }}
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-xs font-semibold text-slate-900 truncate">{{ $booking->guest_name }}</p>
                        <p class="text-[10px] text-slate-400 truncate">{{ $booking->experience?->name }}</p>
                    </div>
                    <div class="text-right shrink-0">
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[9px] font-bold uppercase tracking-wider
                            bg-{{ $booking->stage_color }}-50 text-{{ $booking->stage_color }}-700 border border-{{ $booking->stage_color }}-200">
                            {{ $booking->stage_label }}
                        </span>
                        <p class="text-[10px] font-mono font-bold text-slate-900 mt-0.5">${{ number_format($booking->pay_amount, 0) }}</p>
                    </div>
                </a>
                @empty
                <div class="text-center py-8 text-slate-400">
                    <i class="fa-regular fa-calendar-check text-2xl mb-2 block"></i>
                    <p class="text-xs">No bookings yet</p>
                </div>
                @endforelse
            </div>
        </div>
    </section>

    {{-- Quick Links --}}
    <section class="grid grid-cols-2 md:grid-cols-4 gap-3">
        @php
        $quickLinks = [
            ['route' => 'bookings.check-ins', 'icon' => 'fa-door-open', 'label' => "Today's Check-ins", 'color' => 'emerald'],
            ['route' => 'inquiries.index', 'icon' => 'fa-messages', 'label' => 'Pending Inquiries', 'color' => 'amber'],
            ['route' => 'finance.payouts', 'icon' => 'fa-money-bill-transfer', 'label' => 'Payout Status', 'color' => 'purple'],
            ['route' => 'ai.recommendations', 'icon' => 'fa-wand-magic-sparkles', 'label' => 'AI Recommendations', 'color' => 'indigo'],
        ];
        @endphp

        @foreach($quickLinks as $link)
        <a href="{{ route($link['route']) }}"
           class="glass-premium p-4 rounded-2xl border border-white shadow-sm hover:shadow-md transition-all flex items-center gap-3 group">
            <div class="h-9 w-9 rounded-xl bg-{{ $link['color'] }}-100 flex items-center justify-center">
                <i class="fa-regular {{ $link['icon'] }} text-{{ $link['color'] }}-600 text-sm group-hover:scale-110 transition-transform"></i>
            </div>
            <span class="text-xs font-semibold text-slate-700">{{ $link['label'] }}</span>
        </a>
        @endforeach
    </section>

</div>
@endsection

@push('scripts')
<script>
// Lightweight chart using canvas
const chartData = document.getElementById('revenue-chart')?.dataset.chart;
if (chartData) {
    const data = JSON.parse(chartData);
    // Initialize chart (using your preferred charting library)
    // Example: Alpine.js + simple SVG chart, or Chart.js
    initRevenueChart('revenue-chart', data);
}

function initRevenueChart(containerId, data) {
    // Simple implementation — replace with Chart.js or ApexCharts as needed
    const container = document.getElementById(containerId);
    if (!container || !data.length) return;

    const maxRevenue = Math.max(...data.map(d => d.revenue));
    if (maxRevenue === 0) {
        container.innerHTML = '<div class="flex items-center justify-center h-full text-slate-300 text-xs">No revenue data for this period</div>';
        return;
    }

    const bars = data.slice(-30).map((d, i) => {
        const height = maxRevenue > 0 ? Math.max(4, (d.revenue / maxRevenue) * 100) : 0;
        return `<div class="flex-1 flex flex-col justify-end gap-0.5 group cursor-pointer relative"
                     title="${d.date}: $${d.revenue.toFixed(0)} (${d.bookings} bookings)">
                    <div class="w-full bg-gradient-to-t from-lavender-500 to-lavender-400 rounded-sm opacity-80 group-hover:opacity-100 transition-all"
                         style="height: ${height}%"></div>
                </div>`;
    }).join('');

    container.innerHTML = `<div class="flex items-end gap-1 h-full px-1">${bars}</div>`;
}
</script>
@endpush
