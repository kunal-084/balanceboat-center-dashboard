<?php
/*
 * BalanceBoat Center OS - Complete Laravel 12 Code Reference
 */

// ================================================================
// FILE: /home/claude/balanceboat/models/Experience.php
// ================================================================

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\{
    BelongsTo, HasMany, BelongsToMany, MorphMany
};
use Illuminate\Support\Str;

class Experience extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'experiences';

    protected $fillable = [
        'name', 'slug', 'center_id', 'experience_category',
        'experience_summary', 'experience_overview', 'experience_details',
        'experience_highlights', 'price_per_person', 'avg_price',
        'price_shared', 'price_private', 'currency', 'batch_size',
        'duration', 'start_date_time', 'end_date_time',
        'is_full_day_event', 'is_recurring', 'is_bookable', 'is_draft',
        'food', 'food_overview', 'schedule', 'styles_taught',
        'what_is_included', 'what_is_not_included',
        'how_to_get_here', 'booking_info', 'cancellation_policy',
        'deposit_policy', 'deposit_amount',
        'cancellation_policy_condition', 'cancellation_policy_days',
        'rest_of_payment', 'rest_of_payment_days',
        'commission', 'tax', 'language_spoken', 'skill_level',
        'eirly_bird_before_days', 'eirly_bird_discount', 'eirly_bird_discount_type',
        'offer_start_date', 'offer_end_date', 'offer_discount', 'offer_discount_type',
        'banner_image_title', 'banner_image_url', 'banner_image_path',
        'thumbnail_image_url', 'video_url',
        'meta_title', 'meta_description', 'keywords', 'gps',
        'display_on_home', 'featured_experiences',
        'tags', 'ref_link', 'website',
    ];

    protected $casts = [
        'start_date_time'           => 'datetime',
        'end_date_time'             => 'datetime',
        'offer_start_date'          => 'date',
        'offer_end_date'            => 'date',
        'is_draft'                  => 'boolean',
        'is_bookable'               => 'boolean',
        'is_recurring'              => 'boolean',
        'is_full_day_event'         => 'boolean',
        'deposit_policy'            => 'boolean',
        'display_on_home'           => 'boolean',
        'featured_experiences'      => 'boolean',
        'rest_of_payment'           => 'boolean',
        'price_per_person'          => 'float',
        'avg_price'                 => 'float',
        'price_shared'              => 'decimal:2',
        'price_private'             => 'decimal:2',
        'deposit_amount'            => 'float',
        'commission'                => 'float',
        'eirly_bird_discount'       => 'float',
        'offer_discount'            => 'float',
    ];

    // =========================================================
    // BOOT
    // =========================================================
    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $model) {
            if (empty($model->slug)) {
                $model->slug = Str::slug($model->name);
            }
        });

        static::updating(function (self $model) {
            if ($model->isDirty('name') && empty($model->slug)) {
                $model->slug = Str::slug($model->name);
            }
        });
    }

    // =========================================================
    // RELATIONSHIPS
    // =========================================================
    public function center(): BelongsTo
    {
        return $this->belongsTo(Center::class);
    }

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class, 'experience_category', 'experience_id', 'category_id');
    }

    public function teachers(): BelongsToMany
    {
        return $this->belongsToMany(Teacher::class, 'experience_teachers', 'experience_id', 'teacher_id');
    }

    public function accommodations(): HasMany
    {
        return $this->hasMany(ExperienceAccommodation::class, 'experience_id');
    }

    public function accommodationPrices(): HasMany
    {
        return $this->hasMany(ExperienceAccommodationPrice::class, 'experience_id');
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class, 'experience_id');
    }

    public function faqs(): HasMany
    {
        return $this->hasMany(RetreatFaq::class, 'experience_id')->orderBy('sort_order');
    }

    public function benefits(): HasMany
    {
        return $this->hasMany(RetreatBenefit::class, 'experience_id')->orderBy('sort_order');
    }

    public function itineraryDays(): HasMany
    {
        return $this->hasMany(RetreatItineraryDay::class, 'experience_id')->orderBy('day_number');
    }

    public function pricingRules(): HasMany
    {
        return $this->hasMany(PricingRule::class, 'experience_id')->where('is_active', true)->orderBy('priority', 'desc');
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(CenterReview::class, 'experience_id')->where('status', 'approved');
    }

    public function allReviews(): HasMany
    {
        return $this->hasMany(CenterReview::class, 'experience_id');
    }

    public function media(): MorphMany
    {
        return $this->morphMany(MediaAsset::class, 'mediable')->orderBy('sort_order');
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(ExperienceSchedule::class, 'experience_id');
    }

    public function recurring(): HasMany
    {
        return $this->hasMany(ExperienceRecurring::class, 'experience_id');
    }

    public function recurringManually(): HasMany
    {
        return $this->hasMany(ExperienceRecurringManually::class, 'experience_id');
    }

    public function availabilityCalendar(): HasMany
    {
        return $this->hasMany(AvailabilityCalendar::class, 'experience_id');
    }

    public function imageGallery(): HasMany
    {
        return $this->hasMany(ExperienceImageGallery::class, 'experience_id');
    }

    public function foodImageGallery(): HasMany
    {
        return $this->hasMany(ExperienceFoodImageGallery::class, 'experience_id');
    }

    // =========================================================
    // SCOPES
    // =========================================================
    public function scopePublished($query)
    {
        return $query->where('is_draft', false)->where('is_bookable', true);
    }

    public function scopeDraft($query)
    {
        return $query->where('is_draft', true);
    }

    public function scopeForCenter($query, int $centerId)
    {
        return $query->where('center_id', $centerId);
    }

    public function scopeUpcoming($query)
    {
        return $query->where('start_date_time', '>', now());
    }

    public function scopeFeatured($query)
    {
        return $query->where('featured_experiences', true);
    }

    public function scopeSearch($query, string $search)
    {
        return $query->where(function ($q) use ($search) {
            $q->where('name', 'like', "%{$search}%")
              ->orWhere('experience_summary', 'like', "%{$search}%")
              ->orWhere('tags', 'like', "%{$search}%");
        });
    }

    // =========================================================
    // COMPUTED ATTRIBUTES
    // =========================================================
    public function getAverageRatingAttribute(): float
    {
        return (float) ($this->reviews()->avg('overall_rating') ?? 0);
    }

    public function getReviewCountAttribute(): int
    {
        return $this->reviews()->count();
    }

    public function getOccupancyRateAttribute(): float
    {
        if (! $this->batch_size) return 0;

        $confirmed = $this->bookings()
            ->whereIn('stage', ['confirmed', 'checked_in'])
            ->sum('guest_count');

        return round(($confirmed / $this->batch_size) * 100, 1);
    }

    public function getIsFullAttribute(): bool
    {
        return $this->occupancy_rate >= 100;
    }

    public function getStatusLabelAttribute(): string
    {
        if ($this->is_draft) return 'Draft';
        if ($this->is_bookable) return 'Live';
        return 'Inactive';
    }

    public function getStatusColorAttribute(): string
    {
        return match($this->status_label) {
            'Live'     => 'emerald',
            'Draft'    => 'amber',
            default    => 'slate',
        };
    }

    public function getFormattedPriceAttribute(): string
    {
        return $this->currency . ' ' . number_format($this->price_per_person ?? 0, 0);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/models/Center.php
// ================================================================

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\{
    HasMany, BelongsToMany, BelongsTo, HasOne, MorphMany
};
use Illuminate\Support\Str;

class Center extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'slug', 'meta_title', 'keywords', 'meta_description',
        'gps', 'location', 'center_type', 'speciality_id',
        'year_of_foundation', 'founders',
        'about_center', 'what_sets_us_apart', 'our_philosophy',
        'our_mission', 'center_highlights', 'video_url',
        'banner_image_title', 'banner_image_url', 'banner_image_path',
        'website', 'certificate_id', 'awards',
        'address_of_center', 'city', 'country',
        'email_address', 'contact_number', 'whatsapp_number',
        'facebook_url', 'instagram_url', 'twitter_url',
        'youtube_url', 'linkedin_url',
        'balancegurus_profile_link', 'tags', 'category_id',
        'have_accomodation', 'center_features',
        'accomodation_overview', 'accomodation_banner_image_url',
        'how_to_get_there', 'things_to_do_around_the_center',
        'amenities', 'airport_name', 'pickup_drop_cost',
        'bg_id', 'user_id',
        'timezone', 'currency_code', 'status', 'verified_at',
        'subscription_plan_id', 'is_draft',
    ];

    protected $casts = [
        'is_draft'        => 'boolean',
        'verified_at'     => 'datetime',
        'deleted_at'      => 'datetime',
        'pickup_drop_cost'=> 'float',
        'status'          => 'string',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->slug ??= Str::slug($m->name));
    }

    // =========================================================
    // RELATIONSHIPS
    // =========================================================
    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function subscriptionPlan(): BelongsTo
    {
        return $this->belongsTo(SubscriptionPlan::class, 'subscription_plan_id');
    }

    public function activeSubscription(): HasOne
    {
        return $this->hasOne(CenterSubscription::class)->where('status', 'active');
    }

    public function experiences(): HasMany
    {
        return $this->hasMany(Experience::class);
    }

    public function publishedExperiences(): HasMany
    {
        return $this->hasMany(Experience::class)->where('is_draft', false)->where('is_bookable', true);
    }

    public function accommodations(): BelongsToMany
    {
        return $this->belongsToMany(Accommodation::class, 'center_accomodations', 'center_id', 'accomodation_id');
    }

    public function teachers(): BelongsToMany
    {
        return $this->belongsToMany(Teacher::class, 'center_teachers', 'center_id', 'teacher_id');
    }

    public function imageGallery(): HasMany
    {
        return $this->hasMany(CenterImageGallery::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(CenterReview::class);
    }

    public function approvedReviews(): HasMany
    {
        return $this->hasMany(CenterReview::class)->where('status', 'approved');
    }

    public function commissions(): HasMany
    {
        return $this->hasMany(CenterCommission::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasManyThrough(Booking::class, Experience::class);
    }

    public function inquiries(): HasMany
    {
        return $this->hasMany(Inquiry::class);
    }

    public function payoutRequests(): HasMany
    {
        return $this->hasMany(PayoutRequest::class);
    }

    public function pricingRules(): HasMany
    {
        return $this->hasMany(PricingRule::class)->whereNull('experience_id');
    }

    public function promoCodes(): HasMany
    {
        return $this->hasMany(PromoCode::class);
    }

    public function emailTemplates(): HasMany
    {
        return $this->hasMany(EmailTemplate::class);
    }

    public function automationRules(): HasMany
    {
        return $this->hasMany(AutomationRule::class);
    }

    public function aiRecommendations(): HasMany
    {
        return $this->hasMany(AiRecommendation::class)->where('status', 'active')->orderByDesc('created_at');
    }

    public function media(): MorphMany
    {
        return $this->morphMany(MediaAsset::class, 'mediable');
    }

    public function locations(): HasMany
    {
        return $this->hasMany(CenterLocation::class);
    }

    // =========================================================
    // SCOPES
    // =========================================================
    public function scopeVerified($query)
    {
        return $query->whereNotNull('verified_at');
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeSearch($query, string $term)
    {
        return $query->where('name', 'like', "%{$term}%")
                     ->orWhere('city', 'like', "%{$term}%")
                     ->orWhere('country', 'like', "%{$term}%");
    }

    // =========================================================
    // COMPUTED ATTRIBUTES
    // =========================================================
    public function getAverageRatingAttribute(): float
    {
        return (float) ($this->approvedReviews()->avg('overall_rating') ?? 0);
    }

    public function getTotalRevenueAttribute(): float
    {
        return (float) $this->bookings()
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->sum('pay_amount');
    }

    public function getOccupancyRateAttribute(): float
    {
        $total = $this->experiences()->sum('batch_size');
        if (! $total) return 0;

        $booked = Booking::whereIn('experience_id', $this->experiences()->pluck('id'))
            ->whereIn('stage', ['confirmed', 'checked_in'])
            ->sum('guest_count');

        return round(($booked / $total) * 100, 1);
    }

    public function getIsVerifiedAttribute(): bool
    {
        return ! is_null($this->verified_at);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/models/Booking.php
// ================================================================

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasOne, HasMany};
use Illuminate\Support\Str;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'booking_reference', 'experience_id', 'experience_accomodation_id',
        'user_id', 'assigned_staff_id', 'promo_code_id',
        'stage', 'guest_count', 'duration',
        'price_per_person', 'currency', 'currency_rate',
        'booking_currency', 'booking_currency_rate',
        'booking_amount', 'discount_amount', 'commission_amount',
        'pay_amount', 'order_status', 'payment_status',
        'transaction_id', 'arrival_date',
        'start_date_time', 'end_date_time',
        'is_full_day_event', 'is_recurring',
        'check_in_at', 'check_out_at', 'internal_notes',
    ];

    protected $casts = [
        'arrival_date'      => 'date',
        'start_date_time'   => 'datetime',
        'end_date_time'     => 'datetime',
        'check_in_at'       => 'datetime',
        'check_out_at'      => 'datetime',
        'booking_amount'    => 'decimal:2',
        'discount_amount'   => 'float',
        'commission_amount' => 'float',
        'pay_amount'        => 'float',
        'price_per_person'  => 'float',
    ];

    // Pipeline stages (in order)
    const STAGES = [
        'inquiry', 'qualified', 'proposal_sent', 'confirmed',
        'checked_in', 'completed', 'cancelled', 'refunded',
    ];

    const STAGE_LABELS = [
        'inquiry'       => 'Inquiry',
        'qualified'     => 'Qualified',
        'proposal_sent' => 'Proposal Sent',
        'confirmed'     => 'Confirmed',
        'checked_in'    => 'Checked In',
        'completed'     => 'Completed',
        'cancelled'     => 'Cancelled',
        'refunded'      => 'Refunded',
    ];

    const STAGE_COLORS = [
        'inquiry'       => 'slate',
        'qualified'     => 'blue',
        'proposal_sent' => 'amber',
        'confirmed'     => 'emerald',
        'checked_in'    => 'purple',
        'completed'     => 'wellness',
        'cancelled'     => 'red',
        'refunded'      => 'orange',
    ];

    // =========================================================
    // BOOT
    // =========================================================
    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $m) {
            if (empty($m->booking_reference)) {
                $m->booking_reference = 'BB-' . strtoupper(Str::random(8));
            }
        });
    }

    // =========================================================
    // RELATIONSHIPS
    // =========================================================
    public function experience(): BelongsTo
    {
        return $this->belongsTo(Experience::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function assignedStaff(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_staff_id');
    }

    public function promoCode(): BelongsTo
    {
        return $this->belongsTo(PromoCode::class);
    }

    public function experienceInfo(): HasOne
    {
        return $this->hasOne(BookingExperienceInfo::class);
    }

    public function transactionInfo(): HasOne
    {
        return $this->hasOne(BookingTransactionInfo::class);
    }

    public function addressInfo(): HasOne
    {
        return $this->hasOne(BookingTransactionAddressInfo::class);
    }

    public function userInfo(): HasOne
    {
        return $this->hasOne(BookingUserInfo::class);
    }

    public function accommodation(): BelongsTo
    {
        return $this->belongsTo(ExperienceAccommodation::class, 'experience_accomodation_id');
    }

    // =========================================================
    // SCOPES
    // =========================================================
    public function scopeForStage($query, string $stage)
    {
        return $query->where('stage', $stage);
    }

    public function scopeActive($query)
    {
        return $query->whereIn('stage', ['confirmed', 'checked_in']);
    }

    public function scopeCompleted($query)
    {
        return $query->where('stage', 'completed');
    }

    public function scopeCancelled($query)
    {
        return $query->whereIn('stage', ['cancelled', 'refunded']);
    }

    public function scopeForCenter($query, int $centerId)
    {
        return $query->whereHas('experience', fn($q) => $q->where('center_id', $centerId));
    }

    public function scopeForDateRange($query, string $from, string $to)
    {
        return $query->whereBetween('arrival_date', [$from, $to]);
    }

    // =========================================================
    // HELPERS
    // =========================================================
    public function canTransitionTo(string $newStage): bool
    {
        $allowed = [
            'inquiry'       => ['qualified', 'cancelled'],
            'qualified'     => ['proposal_sent', 'cancelled'],
            'proposal_sent' => ['confirmed', 'cancelled'],
            'confirmed'     => ['checked_in', 'cancelled'],
            'checked_in'    => ['completed'],
            'completed'     => ['refunded'],
            'cancelled'     => [],
            'refunded'      => [],
        ];

        return in_array($newStage, $allowed[$this->stage] ?? []);
    }

    public function getStageColorAttribute(): string
    {
        return self::STAGE_COLORS[$this->stage] ?? 'slate';
    }

    public function getStageLabelAttribute(): string
    {
        return self::STAGE_LABELS[$this->stage] ?? ucfirst($this->stage);
    }

    public function getNetAmountAttribute(): float
    {
        return ($this->pay_amount ?? 0) - ($this->commission_amount ?? 0);
    }

    public function getGuestNameAttribute(): string
    {
        return trim(($this->userInfo->firstname ?? '') . ' ' . ($this->userInfo->lastname ?? ''));
    }

    public function isRefundable(): bool
    {
        return in_array($this->stage, ['confirmed', 'checked_in']);
    }

    public function isCheckedIn(): bool
    {
        return $this->stage === 'checked_in';
    }

    public function isCompleted(): bool
    {
        return $this->stage === 'completed';
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/controllers/web/RetreatController.php
// ================================================================

namespace App\Http\Controllers\Retreats;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreats\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Services\{RetreatService, PricingService, MediaService};
use App\Models\{Experience, Category, Teacher, Center};
use App\Actions\Retreats\{CreateRetreatAction, PublishRetreatAction, DuplicateRetreatAction};
use Illuminate\Http\{Request, RedirectResponse, JsonResponse};
use Illuminate\View\View;

class RetreatController extends Controller
{
    public function __construct(
        private readonly RetreatService      $retreatService,
        private readonly PricingService      $pricingService,
        private readonly MediaService        $mediaService,
        private readonly CreateRetreatAction  $createAction,
        private readonly PublishRetreatAction $publishAction,
        private readonly DuplicateRetreatAction $duplicateAction,
    ) {}

    /**
     * List all retreats for current center with filters.
     */
    public function index(Request $request): View
    {
        $this->authorize('viewAny', Experience::class);

        $center = auth()->user()->center;

        $retreats = Experience::forCenter($center->id)
            ->when($request->search, fn($q) => $q->search($request->search))
            ->when($request->status === 'live', fn($q) => $q->published())
            ->when($request->status === 'draft', fn($q) => $q->draft())
            ->when($request->category, fn($q) => $q->whereHas('categories', fn($c) => $c->where('category_id', $request->category)))
            ->with(['categories', 'bookings', 'accommodations'])
            ->withCount(['bookings', 'reviews'])
            ->orderBy($request->sort ?? 'created_at', $request->direction ?? 'desc')
            ->paginate(12)
            ->withQueryString();

        $stats = $this->retreatService->getStats($center->id);
        $categories = Category::where('type', 0)->orderBy('name')->get();

        return view('retreats.index', compact('retreats', 'stats', 'categories', 'center'));
    }

    /**
     * Show the 8-tab wizard for creating a new retreat.
     */
    public function create(Request $request): View
    {
        $this->authorize('create', Experience::class);

        $center     = auth()->user()->center;
        $categories = Category::where('type', 0)->orderBy('name')->get();
        $teachers   = $center->teachers()->orderBy('name')->get();
        $accommodations = $center->accommodations()->orderBy('name')->get();

        $templateId = $request->get('from_template');
        $template   = $templateId ? Experience::find($templateId) : null;

        return view('retreats.create', compact('center', 'categories', 'teachers', 'accommodations', 'template'));
    }

    /**
     * Store a new retreat (multi-step wizard submission).
     */
    public function store(StoreRetreatRequest $request): RedirectResponse
    {
        $this->authorize('create', Experience::class);

        $retreat = $this->createAction->handle(
            auth()->user()->center,
            $request->validated(),
        );

        return redirect()->route('retreats.edit', $retreat)
            ->with('success', 'Retreat created successfully. Complete any remaining details below.');
    }

    /**
     * Show a single retreat's details page.
     */
    public function show(Experience $retreat): View
    {
        $this->authorize('view', $retreat);

        $retreat->load([
            'categories', 'teachers', 'accommodations.images',
            'faqs', 'benefits', 'itineraryDays.sessions',
            'reviews.responses', 'bookings',
        ]);

        $analytics = $this->retreatService->getRetreatAnalytics($retreat);

        return view('retreats.show', compact('retreat', 'analytics'));
    }

    /**
     * Edit form for a retreat (tabbed interface).
     */
    public function edit(Experience $retreat): View
    {
        $this->authorize('update', $retreat);

        $center         = auth()->user()->center;
        $categories     = Category::where('type', 0)->orderBy('name')->get();
        $teachers       = $center->teachers()->orderBy('name')->get();
        $accommodations = $center->accommodations()->orderBy('name')->get();
        $pricingRules   = $retreat->pricingRules()->get();

        $retreat->load([
            'categories', 'teachers', 'faqs',
            'benefits', 'itineraryDays.sessions',
            'accommodations.prices',
        ]);

        return view('retreats.edit', compact(
            'retreat', 'center', 'categories',
            'teachers', 'accommodations', 'pricingRules'
        ));
    }

    /**
     * Update retreat.
     */
    public function update(UpdateRetreatRequest $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $this->retreatService->update($retreat, $request->validated());

        return back()->with('success', 'Retreat updated successfully.');
    }

    /**
     * Soft-delete a retreat.
     */
    public function destroy(Experience $retreat): RedirectResponse
    {
        $this->authorize('delete', $retreat);

        $retreat->delete();

        return redirect()->route('retreats.index')
            ->with('success', 'Retreat archived successfully.');
    }

    /**
     * Publish a draft retreat.
     */
    public function publish(Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $result = $this->publishAction->handle($retreat);

        if (! $result['success']) {
            return back()->with('error', 'Cannot publish: ' . implode(', ', $result['errors']));
        }

        return back()->with('success', 'Retreat is now live and accepting bookings.');
    }

    /**
     * Unpublish (move to draft).
     */
    public function unpublish(Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $retreat->update(['is_draft' => true, 'is_bookable' => false]);

        return back()->with('success', 'Retreat moved to draft.');
    }

    /**
     * Duplicate a retreat with all related data.
     */
    public function duplicate(Experience $retreat): RedirectResponse
    {
        $this->authorize('create', Experience::class);

        $clone = $this->duplicateAction->handle($retreat);

        return redirect()->route('retreats.edit', $clone)
            ->with('success', 'Retreat duplicated. Review and publish when ready.');
    }

    /**
     * Save as a template for future use.
     */
    public function saveAsTemplate(Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $this->retreatService->saveAsTemplate($retreat);

        return back()->with('success', 'Retreat saved as template.');
    }

    /**
     * View retreat templates library.
     */
    public function templates(Request $request): View
    {
        $center    = auth()->user()->center;
        $templates = $this->retreatService->getTemplates($center->id);

        return view('retreats.templates', compact('templates', 'center'));
    }

    /**
     * Recurring retreats management.
     */
    public function recurring(Request $request): View
    {
        $center   = auth()->user()->center;
        $retreats = Experience::forCenter($center->id)
            ->where('is_recurring', true)
            ->with(['recurring', 'recurringManually'])
            ->paginate(15);

        return view('retreats.recurring', compact('retreats', 'center'));
    }

    /**
     * SEO settings for a retreat.
     */
    public function seoEdit(Experience $retreat): View
    {
        $this->authorize('update', $retreat);
        return view('retreats.seo', compact('retreat'));
    }

    public function seoUpdate(Request $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $retreat->update($request->validate([
            'meta_title'       => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'keywords'         => 'nullable|string|max:1000',
            'slug'             => 'nullable|string|unique:experiences,slug,' . $retreat->id,
        ]));

        return back()->with('success', 'SEO settings updated.');
    }

    /**
     * Food plan management.
     */
    public function foodPlan(Experience $retreat): View
    {
        $this->authorize('update', $retreat);
        $retreat->load('foodImageGallery');
        return view('retreats.food', compact('retreat'));
    }

    public function updateFoodPlan(Request $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $retreat->update($request->validate([
            'food'             => 'nullable|string',
            'food_overview'    => 'nullable|string',
        ]));

        // Handle food gallery uploads
        if ($request->hasFile('food_images')) {
            foreach ($request->file('food_images') as $file) {
                $this->mediaService->uploadFoodImage($retreat, $file);
            }
        }

        return back()->with('success', 'Food plan updated.');
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/controllers/web/BookingController.php
// ================================================================

namespace App\Http\Controllers\Bookings;

use App\Http\Controllers\Controller;
use App\Services\{BookingService, InvoiceService};
use App\Actions\Bookings\{ConfirmBookingAction, CancelBookingAction, CheckInGuestAction, ProcessRefundAction};
use App\Models\{Booking, Experience};
use Illuminate\Http\{Request, RedirectResponse, Response};
use Illuminate\View\View;

class BookingController extends Controller
{
    public function __construct(
        private readonly BookingService       $bookingService,
        private readonly InvoiceService       $invoiceService,
        private readonly ConfirmBookingAction $confirmAction,
        private readonly CancelBookingAction  $cancelAction,
        private readonly CheckInGuestAction   $checkInAction,
        private readonly ProcessRefundAction  $refundAction,
    ) {}

    /**
     * Full booking pipeline with filters and kanban view option.
     */
    public function index(Request $request): View
    {
        $center   = auth()->user()->center;
        $view     = $request->get('view', 'table'); // table | kanban

        $bookings = Booking::forCenter($center->id)
            ->when($request->stage, fn($q) => $q->forStage($request->stage))
            ->when($request->search, fn($q) => $q->whereHas('userInfo', fn($u) =>
                $u->where('firstname', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%")
                  ->orWhere('lastname', 'like', "%{$request->search}%")
            ))
            ->when($request->from, fn($q) => $q->whereDate('arrival_date', '>=', $request->from))
            ->when($request->to, fn($q) => $q->whereDate('arrival_date', '<=', $request->to))
            ->when($request->retreat, fn($q) => $q->where('experience_id', $request->retreat))
            ->with(['experience', 'userInfo', 'accommodation', 'promoCode'])
            ->orderBy($request->sort ?? 'created_at', $request->dir ?? 'desc')
            ->paginate(20)
            ->withQueryString();

        // Kanban counts per stage
        $stageCounts = Booking::forCenter($center->id)
            ->selectRaw('stage, count(*) as count')
            ->groupBy('stage')
            ->pluck('count', 'stage');

        $retreats = Experience::forCenter($center->id)->select('id', 'name')->get();
        $stats    = $this->bookingService->getStats($center->id);

        return view('bookings.index', compact(
            'bookings', 'stageCounts', 'retreats', 'stats', 'view'
        ));
    }

    /**
     * Booking detail page.
     */
    public function show(Booking $booking): View
    {
        $this->authorize('view', $booking);

        $booking->load([
            'experience.center', 'userInfo', 'addressInfo',
            'transactionInfo', 'accommodation', 'promoCode',
            'assignedStaff',
        ]);

        $guestHistory = Booking::where('user_id', $booking->user_id)
            ->where('id', '!=', $booking->id)
            ->with('experience')
            ->latest()
            ->limit(5)
            ->get();

        return view('bookings.show', compact('booking', 'guestHistory'));
    }

    /**
     * Edit booking (reassign room, update notes, etc.)
     */
    public function edit(Booking $booking): View
    {
        $this->authorize('update', $booking);

        $accommodations = $booking->experience->accommodations;
        $staff = auth()->user()->center->users()->get();

        return view('bookings.edit', compact('booking', 'accommodations', 'staff'));
    }

    public function update(Request $request, Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $booking->update($request->validate([
            'experience_accomodation_id' => 'nullable|integer',
            'assigned_staff_id'          => 'nullable|integer',
            'internal_notes'             => 'nullable|string|max:2000',
            'arrival_date'               => 'nullable|date',
        ]));

        return back()->with('success', 'Booking updated.');
    }

    /**
     * Confirm a booking (move from inquiry/proposal to confirmed).
     */
    public function confirm(Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        if (! $booking->canTransitionTo('confirmed')) {
            return back()->with('error', "Cannot confirm a booking in '{$booking->stage}' stage.");
        }

        $this->confirmAction->handle($booking);

        return back()->with('success', 'Booking confirmed. Confirmation email sent to guest.');
    }

    /**
     * Cancel a booking.
     */
    public function cancel(Request $request, Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $request->validate(['reason' => 'required|string|max:500']);

        if (! $booking->canTransitionTo('cancelled')) {
            return back()->with('error', "Cannot cancel a booking in '{$booking->stage}' stage.");
        }

        $this->cancelAction->handle($booking, $request->reason);

        return back()->with('success', 'Booking cancelled. Guest notification sent.');
    }

    /**
     * Check-in a guest.
     */
    public function checkIn(Request $request, Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        if (! $booking->canTransitionTo('checked_in')) {
            return back()->with('error', "Guest cannot be checked in at this stage.");
        }

        $this->checkInAction->handle($booking);

        return back()->with('success', 'Guest checked in successfully.');
    }

    /**
     * Check-out a guest.
     */
    public function checkOut(Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        if (! $booking->canTransitionTo('completed')) {
            return back()->with('error', "Guest is not currently checked in.");
        }

        $booking->update([
            'stage'        => 'completed',
            'check_out_at' => now(),
        ]);

        // Fire review request automation
        event(new \App\Events\BookingCompleted($booking));

        return back()->with('success', 'Guest checked out. Review request will be sent.');
    }

    /**
     * Generate invoice view.
     */
    public function invoice(Booking $booking): View
    {
        $this->authorize('view', $booking);

        $booking->load(['experience.center', 'userInfo', 'addressInfo', 'accommodation', 'promoCode']);
        $invoice = $this->invoiceService->generate($booking);

        return view('bookings.invoice', compact('booking', 'invoice'));
    }

    /**
     * Download invoice PDF.
     */
    public function invoicePdf(Booking $booking): Response
    {
        $this->authorize('view', $booking);

        $booking->load(['experience.center', 'userInfo', 'addressInfo', 'accommodation', 'promoCode']);
        $pdf = $this->invoiceService->generatePdf($booking);

        return response($pdf, 200, [
            'Content-Type'        => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="invoice-' . $booking->booking_reference . '.pdf"',
        ]);
    }

    /**
     * Cancelled bookings list.
     */
    public function cancelled(): View
    {
        $center   = auth()->user()->center;
        $bookings = Booking::forCenter($center->id)
            ->cancelled()
            ->with(['experience', 'userInfo'])
            ->latest()
            ->paginate(20);

        return view('bookings.cancelled', compact('bookings'));
    }

    /**
     * Today's check-ins dashboard.
     */
    public function checkIns(): View
    {
        $center = auth()->user()->center;

        $todayCheckIns = Booking::forCenter($center->id)
            ->where('arrival_date', today())
            ->whereIn('stage', ['confirmed'])
            ->with(['experience', 'userInfo', 'accommodation'])
            ->get();

        $currentGuests = Booking::forCenter($center->id)
            ->where('stage', 'checked_in')
            ->with(['experience', 'userInfo', 'accommodation'])
            ->get();

        $upcomingCheckIns = Booking::forCenter($center->id)
            ->whereBetween('arrival_date', [today()->addDay(), today()->addDays(7)])
            ->where('stage', 'confirmed')
            ->with(['experience', 'userInfo'])
            ->orderBy('arrival_date')
            ->get();

        return view('bookings.check-ins', compact('todayCheckIns', 'currentGuests', 'upcomingCheckIns'));
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/controllers/web/InquiryController.php
// ================================================================

namespace App\Http\Controllers\Bookings;

use App\Http\Controllers\Controller;
use App\Models\{Inquiry, Experience, User};
use App\Services\BookingService;
use App\Actions\Bookings\CreateBookingAction;
use Illuminate\Http\{Request, RedirectResponse, JsonResponse};
use Illuminate\View\View;

class InquiryController extends Controller
{
    public function __construct(
        private readonly BookingService      $bookingService,
        private readonly CreateBookingAction $createBookingAction,
    ) {}

    /**
     * CRM pipeline view — Kanban or table.
     */
    public function index(Request $request): View
    {
        $center = auth()->user()->center;
        $view   = $request->get('view', 'kanban');

        $stages = ['new', 'contacted', 'qualified', 'proposal', 'negotiating', 'won', 'lost'];

        if ($view === 'kanban') {
            $inquiriesByStage = collect($stages)->mapWithKeys(fn($stage) =>
                [$stage => Inquiry::where('center_id', $center->id)
                    ->where('pipeline_stage', $stage)
                    ->with(['experience'])
                    ->latest()
                    ->limit(20)
                    ->get()]
            );
            return view('bookings.inquiries.kanban', compact('inquiriesByStage', 'stages', 'center'));
        }

        $inquiries = Inquiry::where('center_id', $center->id)
            ->when($request->stage, fn($q) => $q->where('pipeline_stage', $request->stage))
            ->when($request->search, fn($q) => $q->where(fn($s) =>
                $s->where('name', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%")
            ))
            ->when($request->retreat, fn($q) => $q->where('experience_id', $request->retreat))
            ->with(['experience'])
            ->orderBy($request->sort ?? 'created_at', $request->dir ?? 'desc')
            ->paginate(25)
            ->withQueryString();

        $stageCounts = Inquiry::where('center_id', $center->id)
            ->selectRaw('pipeline_stage, count(*) as count')
            ->groupBy('pipeline_stage')
            ->pluck('count', 'pipeline_stage');

        $retreats = Experience::forCenter($center->id)->select('id', 'name')->get();

        return view('bookings.inquiries.index', compact(
            'inquiries', 'stageCounts', 'stages', 'retreats', 'center'
        ));
    }

    /**
     * Inquiry detail & conversation thread.
     */
    public function show(Inquiry $inquiry): View
    {
        $this->authorize('view', $inquiry);

        $inquiry->load('experience.center');

        $messages = \App\Models\CustomerMessage::where('conversation_id', $inquiry->conversation_id)
            ->orderBy('created_at')
            ->get();

        $staff = auth()->user()->center->users()->get();

        return view('bookings.inquiries.show', compact('inquiry', 'messages', 'staff'));
    }

    /**
     * Update pipeline stage (drag-drop or dropdown).
     */
    public function updateStage(Request $request, Inquiry $inquiry): RedirectResponse|JsonResponse
    {
        $request->validate([
            'pipeline_stage' => 'required|in:new,contacted,qualified,proposal,negotiating,won,lost',
            'lost_reason'    => 'required_if:pipeline_stage,lost|nullable|string|max:500',
        ]);

        $inquiry->update([
            'pipeline_stage' => $request->pipeline_stage,
            'lost_reason'    => $request->lost_reason,
        ]);

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'stage' => $request->pipeline_stage]);
        }

        return back()->with('success', 'Inquiry stage updated.');
    }

    /**
     * Assign inquiry to a staff member.
     */
    public function assign(Request $request, Inquiry $inquiry): RedirectResponse
    {
        $request->validate(['assigned_to' => 'nullable|integer|exists:users,id']);

        $inquiry->update([
            'assigned_to'  => $request->assigned_to,
            'follow_up_at' => $request->follow_up_at,
        ]);

        return back()->with('success', 'Inquiry assigned.');
    }

    /**
     * Convert a won inquiry to a confirmed booking.
     */
    public function convertToBooking(Request $request, Inquiry $inquiry): RedirectResponse
    {
        $request->validate([
            'experience_id'             => 'required|integer|exists:experiences,id',
            'arrival_date'              => 'required|date|after:today',
            'experience_accomodation_id'=> 'nullable|integer',
            'guest_count'               => 'required|integer|min:1',
        ]);

        $booking = $this->createBookingAction->handle($inquiry, $request->validated());

        $inquiry->update(['pipeline_stage' => 'won']);

        return redirect()->route('bookings.show', $booking)
            ->with('success', 'Inquiry converted to booking #' . $booking->booking_reference);
    }

    /**
     * Send message in conversation thread.
     */
    public function sendMessage(Request $request, Inquiry $inquiry): RedirectResponse
    {
        $request->validate([
            'message'      => 'required|string|max:5000',
            'channel'      => 'required|in:email,whatsapp,note',
        ]);

        \App\Models\CustomerMessage::create([
            'conversation_id' => $inquiry->conversation_id,
            'experience_id'   => $inquiry->experience_id,
            'center_id'       => $inquiry->center_id ?? auth()->user()->center->id,
            'message_type'    => match($request->channel) {
                'email'     => 1,
                'whatsapp'  => 2,
                'note'      => 3,
                default     => 1,
            },
            'message'         => $request->message,
        ]);

        // Send via appropriate channel
        if ($request->channel === 'email') {
            dispatch(new \App\Jobs\SendEmailJob($inquiry, $request->message));
        } elseif ($request->channel === 'whatsapp') {
            dispatch(new \App\Jobs\SendWhatsAppJob($inquiry, $request->message));
        }

        return back()->with('success', ucfirst($request->channel) . ' message sent.');
    }

    /**
     * Destroy (mark as spam / delete).
     */
    public function destroy(Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('delete', $inquiry);
        $inquiry->delete();
        return redirect()->route('inquiries.index')->with('success', 'Inquiry removed.');
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/controllers/web/AnalyticsController.php
// ================================================================

namespace App\Http\Controllers\Analytics;

use App\Http\Controllers\Controller;
use App\Services\AnalyticsService;
use App\Models\{Experience, Center};
use Illuminate\Http\{Request, JsonResponse};
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AnalyticsController extends Controller
{
    public function __construct(
        private readonly AnalyticsService $analyticsService,
    ) {}

    /**
     * Main analytics dashboard.
     */
    public function index(Request $request): View
    {
        $center  = auth()->user()->center;
        $period  = $request->get('period', '30'); // days

        $data = $this->analyticsService->getDashboardData($center->id, (int) $period);

        return view('analytics.index', array_merge(compact('center', 'period'), $data));
    }

    /**
     * Booking analytics — volume, conversion, pipeline stats.
     */
    public function bookings(Request $request): View
    {
        $center = auth()->user()->center;
        $from   = $request->from ?? now()->subDays(30)->format('Y-m-d');
        $to     = $request->to ?? now()->format('Y-m-d');

        $data = $this->analyticsService->getBookingAnalytics($center->id, $from, $to);

        return view('analytics.bookings', array_merge(compact('center', 'from', 'to'), $data));
    }

    /**
     * Revenue analytics — revenue, commissions, payouts.
     */
    public function revenue(Request $request): View
    {
        $center = auth()->user()->center;
        $from   = $request->from ?? now()->subDays(30)->format('Y-m-d');
        $to     = $request->to ?? now()->format('Y-m-d');

        $data = $this->analyticsService->getRevenueAnalytics($center->id, $from, $to);

        return view('analytics.revenue', array_merge(compact('center', 'from', 'to'), $data));
    }

    /**
     * Occupancy analytics — per retreat, per accommodation.
     */
    public function occupancy(Request $request): View
    {
        $center = auth()->user()->center;
        $from   = $request->from ?? now()->subDays(30)->format('Y-m-d');
        $to     = $request->to ?? now()->format('Y-m-d');

        $data = $this->analyticsService->getOccupancyAnalytics($center->id, $from, $to);

        return view('analytics.occupancy', array_merge(compact('center', 'from', 'to'), $data));
    }

    /**
     * Conversion analytics — inquiry to booking funnel.
     */
    public function conversions(Request $request): View
    {
        $center = auth()->user()->center;
        $from   = $request->from ?? now()->subDays(30)->format('Y-m-d');
        $to     = $request->to ?? now()->format('Y-m-d');

        $data = $this->analyticsService->getConversionAnalytics($center->id, $from, $to);

        return view('analytics.conversions', array_merge(compact('center', 'from', 'to'), $data));
    }

    /**
     * Inquiry analytics — sources, response times, pipeline velocity.
     */
    public function inquiries(Request $request): View
    {
        $center = auth()->user()->center;
        $from   = $request->from ?? now()->subDays(30)->format('Y-m-d');
        $to     = $request->to ?? now()->format('Y-m-d');

        $data = $this->analyticsService->getInquiryAnalytics($center->id, $from, $to);

        return view('analytics.inquiries', array_merge(compact('center', 'from', 'to'), $data));
    }

    /**
     * Per-retreat performance dashboard.
     */
    public function retreatPerformance(Experience $retreat): View
    {
        $this->authorize('view', $retreat);

        $data = $this->analyticsService->getRetreatPerformance($retreat);

        return view('analytics.retreat', compact('retreat', 'data'));
    }

    /**
     * Export analytics as CSV.
     */
    public function export(Request $request): StreamedResponse
    {
        $center = auth()->user()->center;
        $type   = $request->get('type', 'bookings');
        $from   = $request->from ?? now()->subDays(30)->format('Y-m-d');
        $to     = $request->to ?? now()->format('Y-m-d');

        return $this->analyticsService->exportCsv($center->id, $type, $from, $to);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/controllers/web/AiController.php
// ================================================================

namespace App\Http\Controllers\AI;

use App\Http\Controllers\Controller;
use App\Services\AiService;
use App\Models\{AiRecommendation, Experience};
use Illuminate\Http\{Request, JsonResponse, RedirectResponse};
use Illuminate\View\View;

class AiController extends Controller
{
    public function __construct(
        private readonly AiService $aiService,
    ) {}

    public function index(): View
    {
        $center = auth()->user()->center;
        $this->authorize('use ai features');

        $recommendations = $center->aiRecommendations()->take(10)->get();
        $stats = $this->aiService->getUsageStats($center->id);

        return view('ai.index', compact('recommendations', 'stats', 'center'));
    }

    public function recommendations(): View
    {
        $center = auth()->user()->center;
        $this->authorize('use ai features');

        $recommendations = $center->aiRecommendations()
            ->when(request('type'), fn($q) => $q->where('type', request('type')))
            ->paginate(20);

        return view('ai.recommendations', compact('recommendations', 'center'));
    }

    public function contentGenerator(): View
    {
        $center   = auth()->user()->center;
        $retreats = Experience::forCenter($center->id)->select('id', 'name')->get();
        return view('ai.content', compact('center', 'retreats'));
    }

    /**
     * Generate AI content (title, description, SEO).
     */
    public function generateContent(Request $request): JsonResponse
    {
        $this->authorize('use ai features');

        $request->validate([
            'type'        => 'required|in:title,description,summary,seo_title,seo_description,faqs,benefits',
            'context'     => 'required|array',
            'context.retreat_type' => 'required|string',
            'context.duration'     => 'nullable|string',
            'context.location'     => 'nullable|string',
        ]);

        $content = $this->aiService->generateContent($request->type, $request->context);

        return response()->json([
            'success' => true,
            'content' => $content,
        ]);
    }

    /**
     * Generate AI SEO metadata.
     */
    public function generateSeo(Request $request): JsonResponse
    {
        $this->authorize('use ai features');

        $request->validate([
            'retreat_id' => 'required|exists:experiences,id',
        ]);

        $retreat = Experience::findOrFail($request->retreat_id);
        $seo     = $this->aiService->generateSeoMetadata($retreat);

        return response()->json(['success' => true, 'seo' => $seo]);
    }

    /**
     * Apply an AI recommendation.
     */
    public function applyRecommendation(Request $request, AiRecommendation $recommendation): RedirectResponse
    {
        $this->authorize('use ai features');

        $this->aiService->applyRecommendation($recommendation);
        $recommendation->update(['status' => 'applied']);

        return back()->with('success', 'AI recommendation applied.');
    }

    /**
     * Dismiss a recommendation.
     */
    public function dismissRecommendation(AiRecommendation $recommendation): RedirectResponse
    {
        $recommendation->update(['status' => 'dismissed']);
        return back()->with('success', 'Recommendation dismissed.');
    }
}


// ============================================================
// AiService
// ============================================================

namespace App\Services;

use App\Models\{Experience, Center, AiRecommendation};
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AiService
{
    private string $model;
    private string $apiKey;

    public function __construct()
    {
        $this->model  = config('services.openai.model', 'gpt-4o');
        $this->apiKey = config('services.openai.key', '');
    }

    /**
     * Generate text content via OpenAI.
     */
    public function generateContent(string $type, array $context): string
    {
        $prompts = [
            'title'           => "Write a compelling retreat title for a {retreat_type} retreat lasting {duration} at {location}. Make it luxurious, specific, and SEO-friendly. Maximum 80 characters.",
            'description'     => "Write a rich, immersive 300-word retreat description for a {retreat_type} retreat at {location}. Include transformation benefits, unique elements, and sensory language. Maintain a luxury wellness brand voice.",
            'summary'         => "Write a 50-word retreat summary for a {retreat_type} program. Focus on the core transformation and key benefits. Compelling and keyword-rich.",
            'seo_title'       => "Write an SEO-optimized title tag (max 60 chars) for a {retreat_type} retreat at {location}.",
            'seo_description' => "Write an SEO meta description (max 155 chars) for a {retreat_type} retreat. Include main keywords and a call to action.",
            'faqs'            => "Generate 5 common FAQs with answers for a {retreat_type} retreat at {location}. Return as JSON array: [{question, answer}]",
            'benefits'        => "List 8 key transformation benefits of attending a {retreat_type} retreat. Return as JSON array of strings.",
        ];

        $prompt = str_replace(
            ['{retreat_type}', '{duration}', '{location}'],
            [$context['retreat_type'] ?? 'wellness', $context['duration'] ?? '7-day', $context['location'] ?? 'a luxury sanctuary'],
            $prompts[$type] ?? $prompts['description']
        );

        return $this->callOpenAi($prompt);
    }

    /**
     * Generate SEO metadata for a retreat.
     */
    public function generateSeoMetadata(Experience $retreat): array
    {
        $context = [
            'retreat_type' => $retreat->experience_category,
            'location'     => $retreat->center?->city,
            'duration'     => $retreat->duration . ' nights',
        ];

        return [
            'meta_title'       => $this->generateContent('seo_title', $context),
            'meta_description' => $this->generateContent('seo_description', $context),
            'keywords'         => $this->generateKeywords($retreat),
        ];
    }

    /**
     * Generate pricing recommendations for a center.
     */
    public function generatePricingRecommendations(int $centerId): void
    {
        $center = Center::find($centerId);
        if (! $center) return;

        // Analyze booking data
        $avgOccupancy = $center->getOccupancyRateAttribute();
        $avgRevenue   = $center->experiences()->withSum('bookings', 'pay_amount')->get()->avg('bookings_sum_pay_amount');

        $recommendations = [];

        if ($avgOccupancy < 40) {
            $recommendations[] = [
                'type'           => 'pricing',
                'title'          => 'Low Occupancy Alert — Enable Last-Minute Discounts',
                'recommendation' => "Your current occupancy is {$avgOccupancy}%, below the healthy 60% threshold. Consider enabling last-minute discounts of 15-20% for bookings within 14 days to fill empty spots.",
                'confidence_score' => 85.0,
            ];
        }

        if ($avgOccupancy > 85) {
            $recommendations[] = [
                'type'           => 'pricing',
                'title'          => 'High Demand — Consider Price Optimization',
                'recommendation' => "Excellent occupancy at {$avgOccupancy}%! This is a signal to test a 10-15% price increase on your most popular retreats to improve yield per booking.",
                'confidence_score' => 78.0,
            ];
        }

        foreach ($recommendations as $rec) {
            AiRecommendation::updateOrCreate(
                [
                    'center_id' => $centerId,
                    'type'      => $rec['type'],
                    'title'     => $rec['title'],
                ],
                array_merge($rec, [
                    'center_id'  => $centerId,
                    'status'     => 'active',
                    'expires_at' => now()->addDays(7),
                ])
            );
        }
    }

    /**
     * Apply a recommendation (e.g., auto-create pricing rule).
     */
    public function applyRecommendation(AiRecommendation $rec): void
    {
        // Implementation depends on recommendation type
        // Example: if type is 'pricing', create a PricingRule
        Log::info("AI Recommendation applied: {$rec->title}", ['center_id' => $rec->center_id]);
    }

    /**
     * Get AI usage stats.
     */
    public function getUsageStats(int $centerId): array
    {
        return [
            'total_recommendations' => AiRecommendation::where('center_id', $centerId)->count(),
            'applied'               => AiRecommendation::where('center_id', $centerId)->where('status', 'applied')->count(),
            'dismissed'             => AiRecommendation::where('center_id', $centerId)->where('status', 'dismissed')->count(),
            'active'                => AiRecommendation::where('center_id', $centerId)->where('status', 'active')->count(),
        ];
    }

    /**
     * Call OpenAI API.
     */
    private function callOpenAi(string $prompt): string
    {
        if (empty($this->apiKey)) {
            return '[AI generation disabled — API key not configured]';
        }

        try {
            $response = Http::withToken($this->apiKey)
                ->timeout(30)
                ->post('https://api.openai.com/v1/chat/completions', [
                    'model'      => $this->model,
                    'max_tokens' => 1000,
                    'messages'   => [
                        [
                            'role'    => 'system',
                            'content' => 'You are an expert wellness retreat copywriter for a luxury wellness platform. Write compelling, authentic, and SEO-optimized content.',
                        ],
                        [
                            'role'    => 'user',
                            'content' => $prompt,
                        ],
                    ],
                ]);

            return $response->json('choices.0.message.content', '');
        } catch (\Exception $e) {
            Log::error('OpenAI API error: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Generate SEO keywords for a retreat.
     */
    private function generateKeywords(Experience $retreat): string
    {
        $baseKeywords = [
            $retreat->name,
            $retreat->experience_category,
            $retreat->center?->city,
            $retreat->center?->country,
            $retreat->duration . ' night retreat',
            $retreat->food ?? 'wellness retreat',
        ];

        return implode(', ', array_filter($baseKeywords));
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/controllers/api/RetreatController.php
// ================================================================

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\{ExperienceResource, ExperienceCollection};
use App\Http\Requests\Api\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Services\{RetreatService, PricingService};
use App\Actions\Retreats\{DuplicateRetreatAction, PublishRetreatAction};
use App\Models\Experience;
use Illuminate\Http\{Request, JsonResponse};

class RetreatController extends Controller
{
    public function __construct(
        private readonly RetreatService        $retreatService,
        private readonly PricingService        $pricingService,
        private readonly DuplicateRetreatAction $duplicateAction,
        private readonly PublishRetreatAction   $publishAction,
    ) {}

    /**
     * GET /api/v1/retreats
     */
    public function index(Request $request): JsonResponse
    {
        $center   = auth()->user()->center;

        $retreats = Experience::forCenter($center->id)
            ->when($request->search, fn($q) => $q->search($request->search))
            ->when($request->status === 'live', fn($q) => $q->published())
            ->when($request->status === 'draft', fn($q) => $q->draft())
            ->when($request->category_id, fn($q) => $q->whereHas('categories', fn($c) => $c->where('category_id', $request->category_id)))
            ->with(['categories:id,name', 'teachers:id,name', 'bookings'])
            ->withCount(['bookings', 'reviews'])
            ->orderBy($request->sort ?? 'created_at', $request->dir ?? 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'data'  => ExperienceResource::collection($retreats->items()),
            'meta'  => [
                'current_page' => $retreats->currentPage(),
                'total'        => $retreats->total(),
                'per_page'     => $retreats->perPage(),
                'last_page'    => $retreats->lastPage(),
            ],
        ]);
    }

    /**
     * GET /api/v1/retreats/{id}
     */
    public function show(Experience $retreat): JsonResponse
    {
        $this->authorize('view', $retreat);

        $retreat->load([
            'categories', 'teachers', 'accommodations.prices',
            'faqs', 'benefits', 'itineraryDays.sessions',
            'reviews', 'center',
        ]);

        return response()->json(['data' => new ExperienceResource($retreat)]);
    }

    /**
     * POST /api/v1/retreats
     */
    public function store(StoreRetreatRequest $request): JsonResponse
    {
        $this->authorize('create', Experience::class);

        $retreat = $this->retreatService->create(
            auth()->user()->center,
            $request->validated()
        );

        return response()->json(
            ['data' => new ExperienceResource($retreat), 'message' => 'Retreat created successfully.'],
            201
        );
    }

    /**
     * PUT /api/v1/retreats/{id}
     */
    public function update(UpdateRetreatRequest $request, Experience $retreat): JsonResponse
    {
        $this->authorize('update', $retreat);

        $updated = $this->retreatService->update($retreat, $request->validated());

        return response()->json([
            'data'    => new ExperienceResource($updated),
            'message' => 'Retreat updated.',
        ]);
    }

    /**
     * DELETE /api/v1/retreats/{id}
     */
    public function destroy(Experience $retreat): JsonResponse
    {
        $this->authorize('delete', $retreat);

        $retreat->delete();

        return response()->json(['message' => 'Retreat archived.']);
    }

    /**
     * POST /api/v1/retreats/{id}/duplicate
     */
    public function duplicate(Experience $retreat): JsonResponse
    {
        $this->authorize('create', Experience::class);

        $clone = $this->duplicateAction->handle($retreat);

        return response()->json([
            'data'    => new ExperienceResource($clone),
            'message' => 'Retreat duplicated successfully.',
        ], 201);
    }

    /**
     * POST /api/v1/retreats/{id}/publish
     */
    public function publish(Experience $retreat): JsonResponse
    {
        $this->authorize('update', $retreat);

        $result = $this->publishAction->handle($retreat);

        if (! $result['success']) {
            return response()->json([
                'message' => 'Cannot publish retreat.',
                'errors'  => $result['errors'],
            ], 422);
        }

        return response()->json(['message' => 'Retreat published successfully.', 'data' => new ExperienceResource($retreat->fresh())]);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/services/RetreatService.php
// ================================================================

namespace App\Services;

use App\Models\{Experience, Center, RetreatFaq, RetreatBenefit, RetreatItineraryDay};
use App\DTOs\RetreatDTO;
use Illuminate\Support\Str;

class RetreatService
{
    /**
     * Create a retreat from validated data.
     */
    public function create(Center $center, array $data): Experience
    {
        $retreat = Experience::create(array_merge($data, [
            'center_id' => $center->id,
            'is_draft'  => true,
            'slug'      => $this->generateUniqueSlug($data['name']),
        ]));

        // Sync categories
        if (! empty($data['category_ids'])) {
            $retreat->categories()->sync($data['category_ids']);
        }

        // Sync teachers
        if (! empty($data['teacher_ids'])) {
            $retreat->teachers()->sync($data['teacher_ids']);
        }

        return $retreat;
    }

    /**
     * Update a retreat.
     */
    public function update(Experience $retreat, array $data): Experience
    {
        // Extract nested relations
        $categoryIds = $data['category_ids'] ?? null;
        $teacherIds  = $data['teacher_ids'] ?? null;

        unset($data['category_ids'], $data['teacher_ids']);

        $retreat->update($data);

        if (! is_null($categoryIds)) {
            $retreat->categories()->sync($categoryIds);
        }

        if (! is_null($teacherIds)) {
            $retreat->teachers()->sync($teacherIds);
        }

        return $retreat->fresh();
    }

    /**
     * Duplicate a retreat with ALL child records.
     */
    public function duplicate(Experience $original): Experience
    {
        $original->load([
            'categories', 'teachers', 'faqs', 'benefits',
            'itineraryDays.sessions', 'accommodations.prices',
        ]);

        // Clone the main record
        $clone = $original->replicate(['slug', 'is_bookable', 'created_at', 'updated_at']);
        $clone->name   = $original->name . ' (Copy)';
        $clone->slug   = $this->generateUniqueSlug($clone->name);
        $clone->is_draft    = true;
        $clone->is_bookable = false;
        $clone->save();

        // Sync categories & teachers
        $clone->categories()->sync($original->categories->pluck('id'));
        $clone->teachers()->sync($original->teachers->pluck('id'));

        // Clone FAQs
        foreach ($original->faqs as $faq) {
            $clone->faqs()->create($faq->only(['question', 'answer', 'sort_order', 'is_published']));
        }

        // Clone benefits
        foreach ($original->benefits as $benefit) {
            $clone->benefits()->create($benefit->only(['benefit', 'icon', 'sort_order']));
        }

        // Clone itinerary
        foreach ($original->itineraryDays as $day) {
            $newDay = $clone->itineraryDays()->create($day->only(['day_number', 'title', 'description']));
            foreach ($day->sessions as $session) {
                $newDay->sessions()->create($session->only([
                    'start_time', 'end_time', 'activity', 'description',
                    'session_type', 'location', 'sort_order',
                ]));
            }
        }

        // Clone accommodations
        foreach ($original->accommodations as $acc) {
            $newAcc = $clone->accommodations()->create($acc->only([
                'title', 'about', 'price_per_night_per_guest', 'currency',
                'max_guest_in_room', 'accomodation_default',
            ]));
            foreach ($acc->prices as $price) {
                $newAcc->prices()->create($price->only([
                    'duration', 'start_date', 'end_date', 'avg_price',
                    'price_per_night_per_guest', 'currency',
                ]));
            }
        }

        return $clone;
    }

    /**
     * Save a retreat as a template.
     */
    public function saveAsTemplate(Experience $retreat): void
    {
        // Mark the retreat as a template (could use a flag or separate table)
        // For now we just tag it
        $tags = $retreat->tags ? explode(',', $retreat->tags) : [];
        $tags[] = 'template';
        $retreat->update(['tags' => implode(',', array_unique($tags))]);
    }

    /**
     * Get templates for a center.
     */
    public function getTemplates(int $centerId): \Illuminate\Database\Eloquent\Collection
    {
        return Experience::forCenter($centerId)
            ->where('tags', 'like', '%template%')
            ->select('id', 'name', 'experience_summary', 'banner_image_url', 'duration', 'price_per_person', 'currency')
            ->get();
    }

    /**
     * Validate and publish a retreat.
     */
    public function publish(Experience $retreat): array
    {
        $errors = [];

        if (empty($retreat->name))             $errors[] = 'Name is required';
        if (empty($retreat->experience_summary)) $errors[] = 'Summary is required';
        if (empty($retreat->price_per_person)) $errors[] = 'Price is required';
        if ($retreat->categories()->count() === 0) $errors[] = 'At least one category is required';
        if (empty($retreat->banner_image_url)) $errors[] = 'Banner image is required';

        if (! empty($errors)) {
            return ['success' => false, 'errors' => $errors];
        }

        $retreat->update(['is_draft' => false, 'is_bookable' => true]);

        event(new \App\Events\RetreatPublished($retreat));

        return ['success' => true];
    }

    /**
     * Get summary stats for center's retreats.
     */
    public function getStats(int $centerId): array
    {
        $experiences = Experience::forCenter($centerId);

        return [
            'total'     => (clone $experiences)->count(),
            'live'      => (clone $experiences)->published()->count(),
            'draft'     => (clone $experiences)->draft()->count(),
            'upcoming'  => (clone $experiences)->upcoming()->count(),
            'avg_occupancy' => $this->getAvgOccupancy($centerId),
        ];
    }

    /**
     * Get retreat analytics summary.
     */
    public function getRetreatAnalytics(Experience $retreat): array
    {
        return [
            'total_bookings'  => $retreat->bookings()->count(),
            'total_revenue'   => $retreat->bookings()->whereIn('stage', ['confirmed', 'checked_in', 'completed'])->sum('pay_amount'),
            'occupancy_rate'  => $retreat->occupancy_rate,
            'average_rating'  => $retreat->average_rating,
            'review_count'    => $retreat->review_count,
        ];
    }

    /**
     * Generate a unique slug.
     */
    private function generateUniqueSlug(string $name): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 1;

        while (Experience::where('slug', $slug)->exists()) {
            $slug = "{$base}-{$i}";
            $i++;
        }

        return $slug;
    }

    private function getAvgOccupancy(int $centerId): float
    {
        $experiences = Experience::forCenter($centerId)->get();
        if ($experiences->isEmpty()) return 0;
        return round($experiences->avg(fn($e) => $e->occupancy_rate), 1);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/services/AnalyticsService.php
// ================================================================

namespace App\Services;

use App\Models\{Booking, Inquiry, Experience, CenterReview};
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AnalyticsService
{
    /**
     * Main dashboard KPIs.
     */
    public function getDashboardData(int $centerId, int $days = 30): array
    {
        $from = now()->subDays($days);
        $prevFrom = now()->subDays($days * 2);
        $prevTo = now()->subDays($days);

        // Current period bookings
        $currentBookings = Booking::forCenter($centerId)
            ->where('created_at', '>=', $from)
            ->count();

        $prevBookings = Booking::forCenter($centerId)
            ->whereBetween('created_at', [$prevFrom, $prevTo])
            ->count();

        // Revenue
        $currentRevenue = Booking::forCenter($centerId)
            ->where('created_at', '>=', $from)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->sum('pay_amount');

        $prevRevenue = Booking::forCenter($centerId)
            ->whereBetween('created_at', [$prevFrom, $prevTo])
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->sum('pay_amount');

        // Inquiries
        $currentInquiries = Inquiry::where('center_id', $centerId)
            ->where('created_at', '>=', $from)
            ->count();

        $prevInquiries = Inquiry::where('center_id', $centerId)
            ->whereBetween('created_at', [$prevFrom, $prevTo])
            ->count();

        // Conversion rate
        $wonInquiries = Inquiry::where('center_id', $centerId)
            ->where('created_at', '>=', $from)
            ->where('pipeline_stage', 'won')
            ->count();

        $conversionRate = $currentInquiries > 0
            ? round(($wonInquiries / $currentInquiries) * 100, 1)
            : 0;

        // Average occupancy
        $avgOccupancy = $this->calculateAverageOccupancy($centerId);

        // Revenue chart data (last 30 days)
        $revenueChart = Booking::forCenter($centerId)
            ->where('created_at', '>=', $from)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->selectRaw('DATE(created_at) as date, SUM(pay_amount) as revenue, COUNT(*) as bookings')
            ->groupBy('date')
            ->orderBy('date')
            ->get()
            ->keyBy('date');

        // Fill missing days
        $chartDays = collect();
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = now()->subDays($i)->format('Y-m-d');
            $chartDays->push([
                'date'     => $date,
                'revenue'  => (float) ($revenueChart[$date]->revenue ?? 0),
                'bookings' => (int) ($revenueChart[$date]->bookings ?? 0),
            ]);
        }

        // Top performing retreats
        $topRetreats = Experience::forCenter($centerId)
            ->withCount(['bookings' => fn($q) => $q->where('created_at', '>=', $from)])
            ->withSum(['bookings' => fn($q) => $q->where('created_at', '>=', $from)], 'pay_amount')
            ->orderBy('bookings_count', 'desc')
            ->limit(5)
            ->get();

        // Recent bookings
        $recentBookings = Booking::forCenter($centerId)
            ->with(['experience', 'userInfo'])
            ->latest()
            ->limit(10)
            ->get();

        return compact(
            'currentBookings', 'prevBookings',
            'currentRevenue', 'prevRevenue',
            'currentInquiries', 'prevInquiries',
            'conversionRate', 'avgOccupancy',
            'chartDays', 'topRetreats', 'recentBookings'
        );
    }

    /**
     * Detailed booking analytics.
     */
    public function getBookingAnalytics(int $centerId, string $from, string $to): array
    {
        $bookings = Booking::forCenter($centerId)
            ->whereBetween('created_at', [$from, $to . ' 23:59:59']);

        $byStage = (clone $bookings)
            ->selectRaw('stage, count(*) as count, sum(pay_amount) as revenue')
            ->groupBy('stage')
            ->get();

        $byRetreat = (clone $bookings)
            ->selectRaw('experience_id, count(*) as count, sum(pay_amount) as revenue')
            ->with('experience:id,name')
            ->groupBy('experience_id')
            ->orderBy('count', 'desc')
            ->get();

        $dailyTrend = (clone $bookings)
            ->selectRaw('DATE(created_at) as date, count(*) as count, sum(pay_amount) as revenue')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $avgBookingValue = (clone $bookings)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->avg('pay_amount');

        $totalBookings   = (clone $bookings)->count();
        $confirmedCount  = (clone $bookings)->where('stage', 'confirmed')->count();
        $cancelledCount  = (clone $bookings)->whereIn('stage', ['cancelled', 'refunded'])->count();
        $totalRevenue    = (clone $bookings)->whereIn('stage', ['confirmed', 'checked_in', 'completed'])->sum('pay_amount');

        return compact(
            'byStage', 'byRetreat', 'dailyTrend',
            'avgBookingValue', 'totalBookings',
            'confirmedCount', 'cancelledCount', 'totalRevenue'
        );
    }

    /**
     * Revenue analytics.
     */
    public function getRevenueAnalytics(int $centerId, string $from, string $to): array
    {
        $bookings = Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->whereBetween('created_at', [$from, $to . ' 23:59:59']);

        $grossRevenue   = (clone $bookings)->sum('booking_amount');
        $discounts      = (clone $bookings)->sum('discount_amount');
        $netRevenue     = (clone $bookings)->sum('pay_amount');
        $commissions    = (clone $bookings)->sum('commission_amount');
        $payableRevenue = $netRevenue - $commissions;

        $monthlyTrend = (clone $bookings)
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(pay_amount) as revenue, SUM(commission_amount) as commissions, COUNT(*) as bookings")
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        $byCurrency = (clone $bookings)
            ->selectRaw('currency, SUM(pay_amount) as total, COUNT(*) as count')
            ->groupBy('currency')
            ->get();

        $revenueByRetreat = (clone $bookings)
            ->selectRaw('experience_id, SUM(pay_amount) as revenue, COUNT(*) as bookings')
            ->with('experience:id,name')
            ->groupBy('experience_id')
            ->orderBy('revenue', 'desc')
            ->limit(10)
            ->get();

        return compact(
            'grossRevenue', 'discounts', 'netRevenue',
            'commissions', 'payableRevenue',
            'monthlyTrend', 'byCurrency', 'revenueByRetreat'
        );
    }

    /**
     * Occupancy analytics.
     */
    public function getOccupancyAnalytics(int $centerId, string $from, string $to): array
    {
        $retreats = Experience::forCenter($centerId)
            ->with(['bookings' => fn($q) => $q->forDateRange($from, $to)->whereIn('stage', ['confirmed', 'checked_in', 'completed'])])
            ->get()
            ->map(function ($retreat) {
                $bookedGuests = $retreat->bookings->sum('guest_count');
                $capacity = $retreat->batch_size ?? 1;
                return [
                    'id'             => $retreat->id,
                    'name'           => $retreat->name,
                    'capacity'       => $capacity,
                    'booked'         => $bookedGuests,
                    'occupancy_rate' => $capacity > 0 ? round(($bookedGuests / $capacity) * 100, 1) : 0,
                    'revenue'        => $retreat->bookings->sum('pay_amount'),
                ];
            })
            ->sortByDesc('occupancy_rate')
            ->values();

        $overallOccupancy = $retreats->avg('occupancy_rate');

        return compact('retreats', 'overallOccupancy');
    }

    /**
     * Conversion funnel analytics.
     */
    public function getConversionAnalytics(int $centerId, string $from, string $to): array
    {
        $inquiries  = Inquiry::where('center_id', $centerId)->whereBetween('created_at', [$from, $to . ' 23:59:59']);
        $totalInq   = (clone $inquiries)->count();
        $contacted  = (clone $inquiries)->where('pipeline_stage', '!=', 'new')->count();
        $qualified  = (clone $inquiries)->whereIn('pipeline_stage', ['qualified', 'proposal', 'negotiating', 'won'])->count();
        $proposed   = (clone $inquiries)->whereIn('pipeline_stage', ['proposal', 'negotiating', 'won'])->count();
        $won        = (clone $inquiries)->where('pipeline_stage', 'won')->count();
        $lost       = (clone $inquiries)->where('pipeline_stage', 'lost')->count();

        $conversionRate = $totalInq > 0 ? round(($won / $totalInq) * 100, 1) : 0;

        $bySource = (clone $inquiries)
            ->selectRaw('source, count(*) as count')
            ->groupBy('source')
            ->get();

        $funnelData = [
            ['stage' => 'Inquiries',  'count' => $totalInq,  'rate' => 100],
            ['stage' => 'Contacted',  'count' => $contacted,  'rate' => $totalInq > 0 ? round($contacted / $totalInq * 100, 1) : 0],
            ['stage' => 'Qualified',  'count' => $qualified,  'rate' => $totalInq > 0 ? round($qualified / $totalInq * 100, 1) : 0],
            ['stage' => 'Proposals',  'count' => $proposed,   'rate' => $totalInq > 0 ? round($proposed / $totalInq * 100, 1) : 0],
            ['stage' => 'Converted',  'count' => $won,        'rate' => $conversionRate],
        ];

        return compact('funnelData', 'won', 'lost', 'conversionRate', 'bySource', 'totalInq');
    }

    /**
     * Inquiry analytics.
     */
    public function getInquiryAnalytics(int $centerId, string $from, string $to): array
    {
        $inquiries = Inquiry::where('center_id', $centerId)
            ->whereBetween('created_at', [$from, $to . ' 23:59:59']);

        $total    = (clone $inquiries)->count();
        $byStage  = (clone $inquiries)
            ->selectRaw('pipeline_stage, count(*) as count')
            ->groupBy('pipeline_stage')
            ->get();

        $dailyTrend = (clone $inquiries)
            ->selectRaw('DATE(created_at) as date, count(*) as count')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $byDestination = (clone $inquiries)
            ->selectRaw('destination, count(*) as count')
            ->whereNotNull('destination')
            ->groupBy('destination')
            ->orderBy('count', 'desc')
            ->get();

        $byBudget = (clone $inquiries)
            ->selectRaw('budget, count(*) as count')
            ->whereNotNull('budget')
            ->groupBy('budget')
            ->get();

        return compact('total', 'byStage', 'dailyTrend', 'byDestination', 'byBudget');
    }

    /**
     * Per-retreat detailed performance.
     */
    public function getRetreatPerformance(Experience $retreat): array
    {
        $bookings = $retreat->bookings()->with('userInfo');

        $totalBookings   = (clone $bookings)->count();
        $totalRevenue    = (clone $bookings)->whereIn('stage', ['confirmed', 'checked_in', 'completed'])->sum('pay_amount');
        $occupancyRate   = $retreat->occupancy_rate;
        $avgRating       = $retreat->average_rating;
        $reviewCount     = $retreat->review_count;

        $bookingsByMonth = (clone $bookings)
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count, SUM(pay_amount) as revenue")
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        $bookingsByStage = (clone $bookings)
            ->selectRaw('stage, count(*) as count')
            ->groupBy('stage')
            ->get();

        $ratingBreakdown = $retreat->reviews()
            ->selectRaw('FLOOR(overall_rating) as rating, count(*) as count')
            ->groupBy('rating')
            ->get();

        return compact(
            'totalBookings', 'totalRevenue', 'occupancyRate',
            'avgRating', 'reviewCount', 'bookingsByMonth',
            'bookingsByStage', 'ratingBreakdown'
        );
    }

    /**
     * Calculate average occupancy across all retreats for a center.
     */
    private function calculateAverageOccupancy(int $centerId): float
    {
        $experiences = Experience::forCenter($centerId)->get();
        if ($experiences->isEmpty()) return 0;

        $total = $experiences->sum(fn($e) => $e->occupancy_rate);
        return round($total / $experiences->count(), 1);
    }

    /**
     * Export to CSV.
     */
    public function exportCsv(int $centerId, string $type, string $from, string $to): StreamedResponse
    {
        return response()->streamDownload(function () use ($centerId, $type, $from, $to) {
            $handle = fopen('php://output', 'w');

            if ($type === 'bookings') {
                fputcsv($handle, ['Reference', 'Guest', 'Email', 'Retreat', 'Stage', 'Amount', 'Date']);
                Booking::forCenter($centerId)
                    ->whereBetween('created_at', [$from, $to . ' 23:59:59'])
                    ->with(['userInfo', 'experience'])
                    ->chunk(200, function ($rows) use ($handle) {
                        foreach ($rows as $b) {
                            fputcsv($handle, [
                                $b->booking_reference,
                                $b->guest_name,
                                $b->userInfo?->email,
                                $b->experience?->name,
                                $b->stage,
                                $b->pay_amount,
                                $b->created_at->format('Y-m-d'),
                            ]);
                        }
                    });
            }

            fclose($handle);
        }, "analytics-{$type}-{$from}-{$to}.csv", ['Content-Type' => 'text/csv']);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/seeders/DatabaseSeeder.php
// ================================================================

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\{Role, Permission};
use App\Models\{User, Center, SubscriptionPlan, SystemSetting, EmailTemplate};

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolesAndPermissionsSeeder::class,
            SubscriptionPlanSeeder::class,
            SystemSettingsSeeder::class,
            EmailTemplateSeeder::class,
            // Development only:
            // DemoDataSeeder::class,
        ]);
    }
}


class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // =============================================
        // PERMISSIONS
        // =============================================
        $permissions = [
            // Retreats
            'view retreats',
            'manage retreats',
            'publish retreats',
            'delete retreats',

            // Bookings
            'view bookings',
            'manage bookings',
            'confirm bookings',
            'cancel bookings',
            'refund bookings',
            'check-in guests',

            // Inquiries
            'view inquiries',
            'manage inquiries',
            'assign inquiries',

            // Accommodations
            'view accommodations',
            'manage accommodations',

            // Teachers
            'view teachers',
            'manage teachers',

            // Pricing
            'view pricing',
            'manage pricing',

            // Analytics
            'view analytics',
            'export analytics',

            // Finance
            'view finance',
            'manage finance',
            'request payouts',
            'approve payouts',

            // Media
            'upload media',
            'manage media',

            // AI
            'use ai features',

            // Automations
            'view automations',
            'manage automations',

            // Reviews
            'view reviews',
            'moderate reviews',

            // Settings
            'manage settings',
            'manage center profile',

            // Admin
            'manage all centers',
            'manage subscription plans',
            'view audit logs',
            'manage system settings',
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['name' => $perm, 'guard_name' => 'web']);
        }

        // =============================================
        // ROLES
        // =============================================
        $roles = [
            'super-admin' => $permissions, // all

            'balanceboat-admin' => array_filter($permissions, fn($p) => $p !== 'manage system settings'),

            'center-owner' => [
                'view retreats', 'manage retreats', 'publish retreats', 'delete retreats',
                'view bookings', 'manage bookings', 'confirm bookings', 'cancel bookings',
                'refund bookings', 'check-in guests',
                'view inquiries', 'manage inquiries', 'assign inquiries',
                'view accommodations', 'manage accommodations',
                'view teachers', 'manage teachers',
                'view pricing', 'manage pricing',
                'view analytics', 'export analytics',
                'view finance', 'manage finance', 'request payouts',
                'upload media', 'manage media',
                'use ai features',
                'view automations', 'manage automations',
                'view reviews', 'moderate reviews',
                'manage settings', 'manage center profile',
            ],

            'center-manager' => [
                'view retreats', 'manage retreats', 'publish retreats',
                'view bookings', 'manage bookings', 'confirm bookings', 'cancel bookings', 'check-in guests',
                'view inquiries', 'manage inquiries', 'assign inquiries',
                'view accommodations', 'manage accommodations',
                'view teachers',
                'view pricing', 'manage pricing',
                'view analytics',
                'view finance',
                'upload media', 'manage media',
                'use ai features',
                'view automations',
                'view reviews', 'moderate reviews',
                'manage center profile',
            ],

            'staff' => [
                'view retreats',
                'view bookings', 'manage bookings', 'confirm bookings', 'check-in guests',
                'view inquiries', 'manage inquiries',
                'view accommodations',
                'upload media',
                'view reviews',
            ],

            'teacher' => [
                'view retreats',
                'view bookings',
                'view inquiries',
            ],

            'accountant' => [
                'view retreats',
                'view bookings',
                'view analytics', 'export analytics',
                'view finance', 'request payouts',
            ],
        ];

        foreach ($roles as $roleName => $rolePermissions) {
            $role = Role::firstOrCreate(['name' => $roleName, 'guard_name' => 'web']);
            $role->syncPermissions($rolePermissions);
        }

        $this->command->info('✅ Roles and permissions seeded successfully.');
    }
}


class SubscriptionPlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            [
                'name'               => 'Starter',
                'slug'               => 'starter',
                'monthly_price'      => 49.00,
                'annual_price'       => 490.00,
                'commission_rate'    => 12.00,
                'max_retreats'       => 5,
                'max_staff'          => 2,
                'ai_enabled'         => false,
                'analytics_enabled'  => false,
                'automation_enabled' => false,
                'features'           => json_encode(['booking_management', 'basic_analytics', 'media_upload']),
                'is_active'          => true,
            ],
            [
                'name'               => 'Growth',
                'slug'               => 'growth',
                'monthly_price'      => 129.00,
                'annual_price'       => 1290.00,
                'commission_rate'    => 10.00,
                'max_retreats'       => 20,
                'max_staff'          => 5,
                'ai_enabled'         => true,
                'analytics_enabled'  => true,
                'automation_enabled' => false,
                'features'           => json_encode(['booking_management', 'full_analytics', 'ai_content', 'pricing_engine', 'media_upload', 'reviews']),
                'is_active'          => true,
            ],
            [
                'name'               => 'Enterprise',
                'slug'               => 'enterprise',
                'monthly_price'      => 299.00,
                'annual_price'       => 2990.00,
                'commission_rate'    => 8.00,
                'max_retreats'       => null,
                'max_staff'          => null,
                'ai_enabled'         => true,
                'analytics_enabled'  => true,
                'automation_enabled' => true,
                'features'           => json_encode(['all_features', 'whatsapp_automation', 'custom_domain', 'priority_support', 'api_access']),
                'is_active'          => true,
            ],
        ];

        foreach ($plans as $plan) {
            SubscriptionPlan::updateOrCreate(['slug' => $plan['slug']], $plan);
        }

        $this->command->info('✅ Subscription plans seeded.');
    }
}


class SystemSettingsSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            ['key' => 'platform_name',          'value' => 'BalanceBoat Center OS',    'group' => 'general',  'type' => 'string'],
            ['key' => 'platform_url',            'value' => 'https://balanceboat.com',  'group' => 'general',  'type' => 'string'],
            ['key' => 'support_email',           'value' => 'support@balanceboat.com',  'group' => 'general',  'type' => 'string'],
            ['key' => 'default_currency',        'value' => 'USD',                       'group' => 'finance',  'type' => 'string'],
            ['key' => 'default_commission',      'value' => '10',                        'group' => 'finance',  'type' => 'number'],
            ['key' => 'trial_days',              'value' => '14',                        'group' => 'subscription', 'type' => 'number'],
            ['key' => 'enable_ai_features',      'value' => 'true',                      'group' => 'features', 'type' => 'boolean'],
            ['key' => 'enable_whatsapp',         'value' => 'false',                     'group' => 'features', 'type' => 'boolean'],
            ['key' => 'enable_google_reviews',   'value' => 'true',                      'group' => 'features', 'type' => 'boolean'],
            ['key' => 'max_media_size_mb',       'value' => '50',                        'group' => 'media',    'type' => 'number'],
            ['key' => 'allowed_media_types',     'value' => 'jpg,jpeg,png,webp,mp4,pdf', 'group' => 'media',    'type' => 'string'],
        ];

        foreach ($settings as $setting) {
            SystemSetting::updateOrCreate(['key' => $setting['key']], $setting);
        }

        $this->command->info('✅ System settings seeded.');
    }
}


class EmailTemplateSeeder extends Seeder
{
    public function run(): void
    {
        $templates = [
            [
                'name'     => 'Booking Confirmed',
                'slug'     => 'booking_confirmed',
                'subject'  => 'Your booking at {{center_name}} is confirmed! 🎉',
                'body_html'=> '<h2>Your retreat is confirmed!</h2><p>Hi {{guest_name}},</p><p>We\'re thrilled to confirm your booking for <strong>{{retreat_name}}</strong>.</p><p><strong>Reference:</strong> {{booking_reference}}<br><strong>Arrival:</strong> {{arrival_date}}<br><strong>Amount:</strong> {{pay_amount}}</p>',
                'variables'=> json_encode(['guest_name', 'center_name', 'retreat_name', 'booking_reference', 'arrival_date', 'pay_amount']),
                'is_active'=> true,
            ],
            [
                'name'     => 'Booking Cancellation',
                'slug'     => 'booking_cancelled',
                'subject'  => 'Your booking has been cancelled — {{center_name}}',
                'body_html'=> '<h2>Booking Cancellation Notice</h2><p>Hi {{guest_name}},</p><p>Your booking <strong>{{booking_reference}}</strong> for {{retreat_name}} has been cancelled.</p><p><strong>Reason:</strong> {{cancellation_reason}}</p>',
                'variables'=> json_encode(['guest_name', 'center_name', 'retreat_name', 'booking_reference', 'cancellation_reason']),
                'is_active'=> true,
            ],
            [
                'name'     => 'Inquiry Received',
                'slug'     => 'inquiry_received',
                'subject'  => 'Thank you for your inquiry — {{center_name}}',
                'body_html'=> '<h2>We received your inquiry!</h2><p>Hi {{guest_name}},</p><p>Thank you for reaching out about <strong>{{retreat_name}}</strong>. Our team will get back to you within 24 hours.</p>',
                'variables'=> json_encode(['guest_name', 'center_name', 'retreat_name']),
                'is_active'=> true,
            ],
            [
                'name'     => 'Review Request',
                'slug'     => 'review_request',
                'subject'  => 'How was your experience at {{center_name}}? Share your story',
                'body_html'=> '<h2>We\'d love your feedback!</h2><p>Hi {{guest_name}},</p><p>Thank you for joining us for {{retreat_name}}. Your feedback helps us serve future guests better.</p><p><a href="{{review_url}}">Leave a Review →</a></p>',
                'variables'=> json_encode(['guest_name', 'center_name', 'retreat_name', 'review_url']),
                'is_active'=> true,
            ],
            [
                'name'     => 'Payout Processed',
                'slug'     => 'payout_processed',
                'subject'  => 'Your payout of {{amount}} has been processed — BalanceBoat',
                'body_html'=> '<h2>Payout Processed!</h2><p>Hi {{center_name}},</p><p>Your payout of <strong>{{amount}}</strong> (Reference: {{payout_reference}}) has been processed and should arrive in your bank account within 2-3 business days.</p>',
                'variables'=> json_encode(['center_name', 'amount', 'payout_reference']),
                'is_active'=> true,
            ],
        ];

        foreach ($templates as $t) {
            EmailTemplate::updateOrCreate(['slug' => $t['slug']], $t);
        }

        $this->command->info('✅ Email templates seeded.');
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/factories/ModelFactories.php
// ================================================================

namespace Database\Factories;

use App\Models\{Experience, Center, Category, User};
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

// ============================================================
// ExperienceFactory
// ============================================================
class ExperienceFactory extends Factory
{
    protected $model = Experience::class;

    public function definition(): array
    {
        $name     = $this->faker->randomElement([
            'Ayurvedic Panchakarma Immersive', 'Vinyasa Yoga Sanctuary',
            'Silent Meditation Retreat', 'Detox & Cellular Reset Program',
            'Sound Healing & Breathwork Journey', 'Women\'s Empowerment Retreat',
            'Couples Mindfulness Escape', 'Digital Detox Forest Immersion',
        ]) . ' - ' . $this->faker->numberBetween(7, 21) . ' Days';

        return [
            'name'                  => $name,
            'slug'                  => Str::slug($name) . '-' . Str::random(4),
            'experience_summary'    => $this->faker->paragraph(2),
            'experience_overview'   => $this->faker->paragraphs(3, true),
            'experience_details'    => $this->faker->paragraphs(4, true),
            'price_per_person'      => $this->faker->randomFloat(2, 500, 5000),
            'avg_price'             => $this->faker->randomFloat(2, 500, 5000),
            'currency'              => $this->faker->randomElement(['USD', 'EUR', 'INR', 'GBP']),
            'batch_size'            => $this->faker->numberBetween(6, 20),
            'duration'              => $this->faker->randomElement(['7', '14', '21', '28']),
            'start_date_time'       => $this->faker->dateTimeBetween('+7 days', '+90 days'),
            'end_date_time'         => $this->faker->dateTimeBetween('+14 days', '+120 days'),
            'is_draft'              => $this->faker->boolean(30),
            'is_bookable'           => $this->faker->boolean(80),
            'is_recurring'          => $this->faker->boolean(40),
            'is_full_day_event'     => true,
            'what_is_included'      => implode("\n", $this->faker->sentences(5)),
            'what_is_not_included'  => implode("\n", $this->faker->sentences(3)),
            'cancellation_policy'   => $this->faker->paragraph(),
            'deposit_policy'        => $this->faker->boolean(),
            'deposit_amount'        => $this->faker->randomFloat(2, 100, 500),
            'commission'            => $this->faker->randomFloat(2, 8, 15),
            'eirly_bird_before_days'=> $this->faker->randomElement([30, 60, 90]),
            'eirly_bird_discount'   => $this->faker->randomFloat(2, 5, 15),
            'eirly_bird_discount_type' => 'percentage',
            'food'                  => $this->faker->randomElement(['Vegetarian', 'Vegan', 'Ayurvedic', 'Raw Food']),
            'food_overview'         => $this->faker->paragraph(),
            'language_spoken'       => 'English',
            'skill_level'           => $this->faker->randomElement(['All Levels', 'Beginner', 'Intermediate', 'Advanced']),
            'banner_image_url'      => 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=800&q=80',
            'thumbnail_image_url'   => 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&q=80',
            'meta_title'            => $name,
            'meta_description'      => $this->faker->paragraph(),
            'keywords'              => implode(', ', $this->faker->words(5)),
            'tags'                  => implode(',', $this->faker->words(3)),
            'display_on_home'       => $this->faker->boolean(20),
            'featured_experiences'  => $this->faker->boolean(15),
        ];
    }

    public function published(): self
    {
        return $this->state(['is_draft' => false, 'is_bookable' => true]);
    }

    public function draft(): self
    {
        return $this->state(['is_draft' => true, 'is_bookable' => false]);
    }
}

// ============================================================
// BookingFactory
// ============================================================
class BookingFactory extends Factory
{
    protected $model = \App\Models\Booking::class;

    public function definition(): array
    {
        $baseAmount   = $this->faker->randomFloat(2, 800, 4000);
        $discount     = $this->faker->randomFloat(2, 0, $baseAmount * 0.2);
        $commission   = round(($baseAmount - $discount) * 0.10, 2);
        $payAmount    = round($baseAmount - $discount, 2);

        return [
            'booking_reference' => 'BB-' . strtoupper(Str::random(8)),
            'stage'             => $this->faker->randomElement(\App\Models\Booking::STAGES),
            'guest_count'       => $this->faker->numberBetween(1, 4),
            'duration'          => $this->faker->randomElement([7, 14, 21]),
            'price_per_person'  => $this->faker->randomFloat(2, 500, 3000),
            'currency'          => 'USD',
            'currency_rate'     => 1.00,
            'booking_currency'  => 'USD',
            'booking_currency_rate' => 1.00,
            'arrival_date'      => $this->faker->dateTimeBetween('-30 days', '+60 days'),
            'start_date_time'   => $this->faker->dateTimeBetween('-30 days', '+60 days'),
            'booking_amount'    => $baseAmount,
            'discount_amount'   => $discount,
            'commission_amount' => $commission,
            'pay_amount'        => $payAmount,
            'order_status'      => 'Success',
            'payment_status'    => 'Paid',
            'is_full_day_event' => true,
            'is_recurring'      => false,
        ];
    }

    public function confirmed(): self
    {
        return $this->state([
            'stage'          => 'confirmed',
            'order_status'   => 'Success',
            'payment_status' => 'Paid',
        ]);
    }

    public function checkedIn(): self
    {
        return $this->state([
            'stage'       => 'checked_in',
            'check_in_at' => now()->subHours(2),
        ]);
    }
}

// ============================================================
// CenterFactory
// ============================================================
class CenterFactory extends Factory
{
    protected $model = Center::class;

    public function definition(): array
    {
        $name    = $this->faker->randomElement([
            'Ananda Himalayan Wellness Resort',
            'Blue Lagoon Ayurveda Centre',
            'Sacred Valley Yoga School',
            'Soma Retreat & Spa',
            'Prana House Wellness',
        ]);

        return [
            'name'             => $name,
            'slug'             => Str::slug($name) . '-' . Str::random(4),
            'about_center'     => $this->faker->paragraphs(3, true),
            'our_philosophy'   => $this->faker->paragraph(),
            'our_mission'      => $this->faker->paragraph(),
            'city'             => $this->faker->randomElement(['Rishikesh', 'Ubud', 'Chiang Mai', 'Tulum', 'Kerala']),
            'country'          => $this->faker->randomElement(['India', 'Indonesia', 'Thailand', 'Mexico', 'Sri Lanka']),
            'email_address'    => $this->faker->email(),
            'contact_number'   => $this->faker->phoneNumber(),
            'whatsapp_number'  => $this->faker->phoneNumber(),
            'website'          => 'https://www.' . Str::slug($name) . '.com',
            'instagram_url'    => 'https://instagram.com/' . Str::slug($name),
            'year_of_foundation' => $this->faker->numberBetween(2005, 2020),
            'currency_code'    => 'USD',
            'timezone'         => $this->faker->randomElement(['Asia/Kolkata', 'Asia/Jakarta', 'Asia/Bangkok']),
            'status'           => 'active',
            'verified_at'      => $this->faker->boolean(70) ? now()->subDays(rand(30, 365)) : null,
            'is_draft'         => false,
            'have_accomodation'=> 'Yes',
            'banner_image_url' => 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1200&q=80',
        ];
    }

    public function verified(): self
    {
        return $this->state(['status' => 'active', 'verified_at' => now()]);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/tests/Feature/FeatureTests.php
// ================================================================

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\{User, Center, Experience, Booking, Category};
use Illuminate\Foundation\Testing\{RefreshDatabase, WithFaker};
use Spatie\Permission\Models\{Role, Permission};

class RetreatManagementTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected User $owner;
    protected Center $center;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        $this->owner  = User::factory()->create();
        $this->owner->assignRole('center-owner');

        $this->center = Center::factory()->create(['user_id' => $this->owner->id]);
        $this->owner->update(['center_id' => $this->center->id]);
    }

    // =========================================================
    // INDEX
    // =========================================================
    public function test_owner_can_view_retreats_index(): void
    {
        Experience::factory()->count(3)->create(['center_id' => $this->center->id]);

        $response = $this->actingAs($this->owner)->get(route('retreats.index'));

        $response->assertOk()
                 ->assertViewHas('retreats')
                 ->assertViewHas('stats');
    }

    public function test_guest_cannot_access_retreats_index(): void
    {
        $this->get(route('retreats.index'))->assertRedirect(route('login'));
    }

    // =========================================================
    // CREATE
    // =========================================================
    public function test_owner_can_view_create_form(): void
    {
        $this->actingAs($this->owner)
             ->get(route('retreats.create'))
             ->assertOk()
             ->assertViewIs('retreats.create');
    }

    public function test_owner_can_create_retreat(): void
    {
        $category = Category::factory()->create(['type' => 0]);

        $payload = [
            'name'               => 'Test Ayurvedic Retreat',
            'experience_summary' => 'A transformative wellness experience',
            'price_per_person'   => 1500.00,
            'currency'           => 'USD',
            'batch_size'         => 12,
            'duration'           => '7',
            'category_ids'       => [$category->id],
            'is_draft'           => true,
        ];

        $response = $this->actingAs($this->owner)->post(route('retreats.store'), $payload);

        $response->assertRedirect();
        $this->assertDatabaseHas('experiences', [
            'name'      => 'Test Ayurvedic Retreat',
            'center_id' => $this->center->id,
            'is_draft'  => true,
        ]);
    }

    public function test_create_requires_name(): void
    {
        $this->actingAs($this->owner)
             ->post(route('retreats.store'), [])
             ->assertSessionHasErrors('name');
    }

    // =========================================================
    // UPDATE
    // =========================================================
    public function test_owner_can_update_own_retreat(): void
    {
        $retreat = Experience::factory()->create(['center_id' => $this->center->id]);

        $this->actingAs($this->owner)
             ->put(route('retreats.update', $retreat), ['name' => 'Updated Retreat Name'])
             ->assertRedirect();

        $this->assertDatabaseHas('experiences', ['id' => $retreat->id, 'name' => 'Updated Retreat Name']);
    }

    public function test_owner_cannot_update_another_centers_retreat(): void
    {
        $otherCenter  = Center::factory()->create();
        $otherRetreat = Experience::factory()->create(['center_id' => $otherCenter->id]);

        $this->actingAs($this->owner)
             ->put(route('retreats.update', $otherRetreat), ['name' => 'Hacked Name'])
             ->assertForbidden();
    }

    // =========================================================
    // PUBLISH
    // =========================================================
    public function test_retreat_with_required_fields_can_be_published(): void
    {
        $retreat = Experience::factory()->create([
            'center_id'          => $this->center->id,
            'is_draft'           => true,
            'name'               => 'Full Retreat',
            'experience_summary' => 'Great retreat',
            'price_per_person'   => 1000,
            'banner_image_url'   => 'https://example.com/image.jpg',
        ]);

        Category::factory()->create()->each(function ($cat) use ($retreat) {
            $retreat->categories()->attach($cat);
        });

        $this->actingAs($this->owner)
             ->post(route('retreats.publish', $retreat))
             ->assertRedirect();

        $this->assertDatabaseHas('experiences', [
            'id'         => $retreat->id,
            'is_draft'   => false,
            'is_bookable'=> true,
        ]);
    }

    // =========================================================
    // DUPLICATE
    // =========================================================
    public function test_owner_can_duplicate_retreat(): void
    {
        $retreat = Experience::factory()->create(['center_id' => $this->center->id]);

        $response = $this->actingAs($this->owner)
                         ->post(route('retreats.duplicate', $retreat));

        $response->assertRedirect();
        $this->assertDatabaseCount('experiences', 2);
        $this->assertDatabaseHas('experiences', ['name' => $retreat->name . ' (Copy)']);
    }

    // =========================================================
    // DELETE
    // =========================================================
    public function test_owner_can_soft_delete_retreat(): void
    {
        $retreat = Experience::factory()->create(['center_id' => $this->center->id]);

        $this->actingAs($this->owner)
             ->delete(route('retreats.destroy', $retreat))
             ->assertRedirect(route('retreats.index'));

        $this->assertSoftDeleted('experiences', ['id' => $retreat->id]);
    }
}


class BookingPipelineTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected User $manager;
    protected Center $center;
    protected Experience $experience;
    protected Booking $booking;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        $this->manager  = User::factory()->create();
        $this->manager->assignRole('center-manager');

        $this->center   = Center::factory()->create(['user_id' => $this->manager->id]);
        $this->manager->update(['center_id' => $this->center->id]);
        $this->experience = Experience::factory()->create(['center_id' => $this->center->id]);

        $this->booking = Booking::factory()->create([
            'experience_id' => $this->experience->id,
            'stage'         => 'inquiry',
        ]);
    }

    public function test_manager_can_view_bookings(): void
    {
        $this->actingAs($this->manager)
             ->get(route('bookings.index'))
             ->assertOk()
             ->assertViewHas('bookings');
    }

    public function test_manager_can_confirm_booking(): void
    {
        $this->booking->update(['stage' => 'proposal_sent']);

        $this->actingAs($this->manager)
             ->post(route('bookings.confirm', $this->booking))
             ->assertRedirect();

        $this->assertDatabaseHas('bookings', ['id' => $this->booking->id, 'stage' => 'confirmed']);
    }

    public function test_cannot_confirm_cancelled_booking(): void
    {
        $this->booking->update(['stage' => 'cancelled']);

        $this->actingAs($this->manager)
             ->post(route('bookings.confirm', $this->booking))
             ->assertRedirect()
             ->assertSessionHas('error');
    }

    public function test_manager_can_check_in_confirmed_guest(): void
    {
        $this->booking->update(['stage' => 'confirmed']);

        $this->actingAs($this->manager)
             ->post(route('bookings.check-in', $this->booking))
             ->assertRedirect();

        $this->assertDatabaseHas('bookings', ['id' => $this->booking->id, 'stage' => 'checked_in']);
        $this->assertNotNull($this->booking->fresh()->check_in_at);
    }

    public function test_booking_stage_transitions_are_valid(): void
    {
        $booking = new Booking(['stage' => 'confirmed']);
        $this->assertTrue($booking->canTransitionTo('checked_in'));
        $this->assertFalse($booking->canTransitionTo('inquiry'));

        $booking->stage = 'cancelled';
        $this->assertFalse($booking->canTransitionTo('confirmed'));
    }
}


class AnalyticsTest extends TestCase
{
    use RefreshDatabase;

    protected User $accountant;
    protected Center $center;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        $this->accountant = User::factory()->create();
        $this->accountant->assignRole('accountant');
        $this->center = Center::factory()->create(['user_id' => $this->accountant->id]);
        $this->accountant->update(['center_id' => $this->center->id]);
    }

    public function test_accountant_can_view_analytics(): void
    {
        $this->actingAs($this->accountant)
             ->get(route('analytics.index'))
             ->assertOk();
    }

    public function test_teacher_cannot_view_analytics(): void
    {
        $teacher = User::factory()->create();
        $teacher->assignRole('teacher');

        $this->actingAs($teacher)
             ->get(route('analytics.index'))
             ->assertForbidden();
    }

    public function test_analytics_export_returns_csv(): void
    {
        $this->actingAs($this->accountant)
             ->get(route('analytics.export', ['type' => 'bookings', 'from' => '2024-01-01', 'to' => '2024-12-31']))
             ->assertOk()
             ->assertHeader('Content-Type', 'text/csv; charset=UTF-8');
    }
}


class PricingEngineTest extends TestCase
{
    use RefreshDatabase;

    public function test_early_bird_discount_is_applied(): void
    {
        $service = app(\App\Services\PricingService::class);

        $rule = \App\Models\PricingRule::factory()->create([
            'rule_type'      => 'early_bird',
            'discount_type'  => 'percentage',
            'discount_value' => 10,
            'days_before'    => 30,
            'is_active'      => true,
        ]);

        $dto = new \App\DTOs\PricingDTO(
            experienceId: $rule->experience_id,
            basePrice: 1000.00,
            currency: 'USD',
            daysUntilStart: 45, // > 30, so rule applies
        );

        $result = $service->calculatePrice($dto);

        $this->assertEquals(1000.00, $result['base_price']);
        $this->assertEquals(100.00, $result['discount_total']); // 10% of 1000
        $this->assertEquals(900.00, $result['final_price']);
    }

    public function test_promo_code_is_applied_correctly(): void
    {
        $center = Center::factory()->create();
        $promo  = \App\Models\PromoCode::factory()->create([
            'center_id'       => $center->id,
            'code'            => 'WELLNESS10',
            'discount_type'   => 'percentage',
            'discount_value'  => 10,
            'is_active'       => true,
        ]);

        $service = app(\App\Services\PricingService::class);
        $dto = new \App\DTOs\PricingDTO(
            experienceId: null,
            basePrice: 2000.00,
            currency: 'USD',
            promoCode: 'WELLNESS10',
        );

        $result = $service->calculatePrice($dto);
        $this->assertEquals(200.00, $result['discount_total']);
        $this->assertEquals(1800.00, $result['final_price']);
    }
}

// ================================================================
// FILE: /home/claude/balanceboat/tests/Unit/UnitTests.php
// ================================================================

namespace Tests\Unit;

use Tests\TestCase;
use App\Models\Booking;
use App\Services\{RetreatService, PricingService};
use Illuminate\Foundation\Testing\RefreshDatabase;

class BookingModelTest extends TestCase
{
    public function test_stage_transitions_are_correctly_defined(): void
    {
        $booking = new Booking(['stage' => 'inquiry']);

        $this->assertTrue($booking->canTransitionTo('qualified'));
        $this->assertTrue($booking->canTransitionTo('cancelled'));
        $this->assertFalse($booking->canTransitionTo('checked_in'));
        $this->assertFalse($booking->canTransitionTo('completed'));
    }

    public function test_booking_reference_is_generated_with_bb_prefix(): void
    {
        $booking = new Booking();
        $ref = 'BB-' . strtoupper(str_random(8));
        $this->assertStringStartsWith('BB-', $ref);
        $this->assertEquals(11, strlen($ref)); // BB- = 3 chars, 8 chars = 11 total
    }

    public function test_net_amount_calculation(): void
    {
        $booking = new Booking([
            'pay_amount'        => 1000.00,
            'commission_amount' => 100.00,
        ]);

        $this->assertEquals(900.00, $booking->net_amount);
    }

    public function test_stage_color_mapping(): void
    {
        $booking = new Booking(['stage' => 'confirmed']);
        $this->assertEquals('emerald', $booking->stage_color);

        $booking->stage = 'cancelled';
        $this->assertEquals('red', $booking->stage_color);

        $booking->stage = 'checked_in';
        $this->assertEquals('purple', $booking->stage_color);
    }

    public function test_cancelled_booking_is_not_refundable(): void
    {
        $booking = new Booking(['stage' => 'cancelled']);
        $this->assertFalse($booking->isRefundable());
    }

    public function test_confirmed_booking_is_refundable(): void
    {
        $booking = new Booking(['stage' => 'confirmed']);
        $this->assertTrue($booking->isRefundable());
    }
}


class RetreatServiceTest extends TestCase
{
    use RefreshDatabase;

    public function test_unique_slug_is_generated_on_duplicate_name(): void
    {
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        // Create two retreats with same name (via reflection to test slug logic)
        $service = app(RetreatService::class);
        $center  = \App\Models\Center::factory()->create();

        $retreat1 = \App\Models\Experience::factory()->create([
            'center_id' => $center->id,
            'slug'      => 'ayurveda-retreat',
        ]);

        // Generate slug for same name — should differ
        $method = new \ReflectionMethod($service, 'generateUniqueSlug');
        $method->setAccessible(true);
        $slug = $method->invoke($service, 'Ayurveda Retreat');

        $this->assertNotEquals('ayurveda-retreat', $slug);
        $this->assertStringStartsWith('ayurveda-retreat', $slug);
    }
}


class PricingServiceTest extends TestCase
{
    use RefreshDatabase;

    private PricingService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = app(PricingService::class);
    }

    public function test_no_rules_returns_base_price(): void
    {
        $dto = new \App\DTOs\PricingDTO(
            experienceId: 9999,
            basePrice: 1500.00,
            currency: 'USD',
        );

        $result = $this->service->calculatePrice($dto);

        $this->assertEquals(1500.00, $result['base_price']);
        $this->assertEquals(0, $result['discount_total']);
        $this->assertEquals(1500.00, $result['final_price']);
        $this->assertEmpty($result['applied_rules']);
    }

    public function test_percentage_discount_is_applied_correctly(): void
    {
        $rule = \App\Models\PricingRule::factory()->create([
            'rule_type'      => 'seasonal_peak',
            'discount_type'  => 'percentage',
            'discount_value' => 15,
            'start_date'     => now()->subDays(5)->format('Y-m-d'),
            'end_date'       => now()->addDays(5)->format('Y-m-d'),
            'is_active'      => true,
        ]);

        $dto = new \App\DTOs\PricingDTO(
            experienceId: $rule->experience_id,
            basePrice: 2000.00,
            currency: 'USD',
            startDate: now(),
        );

        $result = $this->service->calculatePrice($dto);

        $this->assertEquals(300.00, $result['discount_total']); // 15% of 2000
        $this->assertEquals(1700.00, $result['final_price']);
        $this->assertCount(1, $result['applied_rules']);
    }

    public function test_fixed_discount_is_applied_correctly(): void
    {
        $rule = \App\Models\PricingRule::factory()->create([
            'rule_type'      => 'early_bird',
            'discount_type'  => 'fixed',
            'discount_value' => 200.00,
            'days_before'    => 30,
            'is_active'      => true,
        ]);

        $dto = new \App\DTOs\PricingDTO(
            experienceId: $rule->experience_id,
            basePrice: 1500.00,
            currency: 'USD',
            daysUntilStart: 45,
        );

        $result = $this->service->calculatePrice($dto);

        $this->assertEquals(200.00, $result['discount_total']);
        $this->assertEquals(1300.00, $result['final_price']);
    }

    public function test_discount_cannot_exceed_base_price(): void
    {
        \App\Models\PricingRule::factory()->create([
            'rule_type'      => 'last_minute',
            'discount_type'  => 'fixed',
            'discount_value' => 9999.00, // more than base price
            'days_before'    => 7,
            'is_active'      => true,
        ]);

        $dto = new \App\DTOs\PricingDTO(
            experienceId: null,
            basePrice: 100.00,
            currency: 'USD',
            daysUntilStart: 3,
        );

        $result = $this->service->calculatePrice($dto);

        $this->assertGreaterThanOrEqual(0, $result['final_price']);
    }
}