@extends('layouts.app')

@section('title', 'Bookings Registry')

@section('content')
<div class="space-y-6" x-data="{ view: '{{ $view }}' }">

    {{-- Header --}}
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
            <h1 class="text-3xl font-serif font-light text-slate-900">Bookings Registry Ledger</h1>
            <p class="text-xs text-slate-500 mt-1">Track, manage, and process all guest bookings and pipeline stages.</p>
        </div>
        <div class="flex items-center gap-2">
            {{-- View Toggle --}}
            <div class="flex items-center border border-slate-200 rounded-xl p-1 bg-white">
                <button @click="view='table'; window.location.href='?view=table'"
                        :class="view==='table' ? 'bg-slate-900 text-white' : 'text-slate-500'"
                        class="px-3 py-1.5 rounded-lg text-xs font-medium transition-all">
                    <i class="fa-solid fa-table mr-1"></i> Table
                </button>
                <button @click="view='kanban'; window.location.href='?view=kanban'"
                        :class="view==='kanban' ? 'bg-slate-900 text-white' : 'text-slate-500'"
                        class="px-3 py-1.5 rounded-lg text-xs font-medium transition-all">
                    <i class="fa-solid fa-columns mr-1"></i> Pipeline
                </button>
            </div>
            <a href="{{ route('bookings.check-ins') }}"
               class="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-all">
                <i class="fa-solid fa-door-open"></i>
                <span>Today's Check-ins</span>
            </a>
        </div>
    </div>

    {{-- KPI Stats --}}
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <x-stat-card label="Active Bookings" :value="$stats['active'] ?? 0" icon="fa-calendar-check" color="emerald" />
        <x-stat-card label="Pending Confirm" :value="$stats['pending'] ?? 0" icon="fa-clock" color="amber" />
        <x-stat-card label="Checked In" :value="$stats['checked_in'] ?? 0" icon="fa-door-open" color="purple" />
        <x-stat-card label="This Month Revenue" :value="'$' . number_format($stats['month_revenue'] ?? 0, 0)" icon="fa-dollar-sign" color="wellness" />
    </div>

    {{-- Pipeline Stage Bar --}}
    <div class="glass-premium p-4 rounded-2xl border border-white">
        <div class="flex items-center gap-2 overflow-x-auto pb-1">
            <a href="{{ route('bookings.index') }}"
               class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all
                      {{ !request('stage') ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:border-lavender-300' }}">
                <span>All</span>
                <span class="text-[10px] font-mono">{{ $bookings->total() }}</span>
            </a>
            @foreach(\App\Models\Booking::STAGES as $stage)
            <a href="{{ route('bookings.index', array_merge(request()->query(), ['stage' => $stage])) }}"
               class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all
                      {{ request('stage') === $stage ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:border-lavender-300' }}">
                <span>{{ \App\Models\Booking::STAGE_LABELS[$stage] }}</span>
                <span class="text-[10px] font-mono">{{ $stageCounts[$stage] ?? 0 }}</span>
            </a>
            @endforeach
        </div>
    </div>

    {{-- Filters --}}
    <form method="GET" action="{{ route('bookings.index') }}" class="flex items-center gap-3 flex-wrap">
        <input type="hidden" name="view" value="{{ $view }}">
        <input type="hidden" name="stage" value="{{ request('stage') }}">

        <div class="relative flex-1 min-w-48">
            <i class="fa-regular fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Search by guest name or email..."
                   class="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-lavender-500/20 focus:border-lavender-500 outline-none">
        </div>

        <select name="retreat" class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:border-lavender-500 outline-none">
            <option value="">All Retreats</option>
            @foreach($retreats as $r)
            <option value="{{ $r->id }}" {{ request('retreat') == $r->id ? 'selected' : '' }}>{{ $r->name }}</option>
            @endforeach
        </select>

        <input type="date" name="from" value="{{ request('from') }}"
               class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:border-lavender-500 outline-none">
        <input type="date" name="to" value="{{ request('to') }}"
               class="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:border-lavender-500 outline-none">

        <button type="submit" class="py-2 px-4 bg-lavender-600 text-white rounded-xl text-xs font-semibold hover:bg-lavender-700 transition-all">
            Filter
        </button>
        <a href="{{ route('bookings.index') }}" class="py-2 px-3 text-xs text-slate-500 hover:text-slate-800">Clear</a>

        {{-- Export --}}
        <a href="{{ route('analytics.export', ['type' => 'bookings', 'from' => request('from', now()->subDays(30)->format('Y-m-d')), 'to' => request('to', now()->format('Y-m-d'))]) }}"
           class="ml-auto py-2 px-3 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-50 flex items-center gap-1">
            <i class="fa-regular fa-download"></i> Export
        </a>
    </form>

    {{-- Bookings Table --}}
    @if($view === 'table')
    <div class="glass-premium rounded-2xl border border-white overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="border-b border-slate-100 bg-slate-50/50">
                        <th class="text-left px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Reference</th>
                        <th class="text-left px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Guest</th>
                        <th class="text-left px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Retreat</th>
                        <th class="text-left px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Arrival</th>
                        <th class="text-left px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Stage</th>
                        <th class="text-right px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Amount</th>
                        <th class="text-center px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($bookings as $booking)
                    <tr class="hover:bg-lavender-50/20 transition-colors">
                        <td class="px-5 py-3.5">
                            <a href="{{ route('bookings.show', $booking) }}"
                               class="font-mono text-xs font-bold text-lavender-700 hover:underline">
                                {{ $booking->booking_reference }}
                            </a>
                        </td>
                        <td class="px-5 py-3.5">
                            <div class="flex items-center gap-2">
                                <div class="h-7 w-7 rounded-full bg-gradient-to-tr from-lavender-400 to-peach-400 flex items-center justify-center text-white text-[10px] font-bold shrink-0">
                                    {{ strtoupper(substr($booking->userInfo?->firstname ?? '?', 0, 1)) }}
                                </div>
                                <div>
                                    <p class="text-xs font-semibold text-slate-900">{{ $booking->guest_name }}</p>
                                    <p class="text-[10px] text-slate-400">{{ $booking->userInfo?->email }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-5 py-3.5">
                            <p class="text-xs text-slate-700 font-medium max-w-[160px] truncate">
                                {{ $booking->experience?->name ?? '—' }}
                            </p>
                        </td>
                        <td class="px-5 py-3.5">
                            <p class="text-xs text-slate-700">
                                {{ $booking->arrival_date?->format('d M Y') ?? '—' }}
                            </p>
                        </td>
                        <td class="px-5 py-3.5">
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[9px] font-bold uppercase tracking-wider
                                bg-{{ $booking->stage_color }}-50 text-{{ $booking->stage_color }}-700 border border-{{ $booking->stage_color }}-200">
                                @if(in_array($booking->stage, ['confirmed', 'checked_in']))
                                <span class="h-1 w-1 rounded-full bg-{{ $booking->stage_color }}-500 animate-pulse"></span>
                                @endif
                                {{ $booking->stage_label }}
                            </span>
                        </td>
                        <td class="px-5 py-3.5 text-right">
                            <p class="text-xs font-bold font-mono text-slate-900">${{ number_format($booking->pay_amount, 0) }}</p>
                            @if($booking->discount_amount > 0)
                            <p class="text-[10px] text-emerald-600">-${{ number_format($booking->discount_amount, 0) }}</p>
                            @endif
                        </td>
                        <td class="px-5 py-3.5">
                            <div class="flex items-center justify-center gap-1" x-data="{ open: false }" @click.outside="open=false">
                                <a href="{{ route('bookings.show', $booking) }}"
                                   class="p-1.5 text-slate-400 hover:text-lavender-600 hover:bg-lavender-50 rounded-lg transition-all" title="View">
                                    <i class="fa-regular fa-eye text-xs"></i>
                                </a>

                                @if($booking->canTransitionTo('confirmed'))
                                <form method="POST" action="{{ route('bookings.confirm', $booking) }}">
                                    @csrf
                                    <button class="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all" title="Confirm">
                                        <i class="fa-regular fa-circle-check text-xs"></i>
                                    </button>
                                </form>
                                @endif

                                @if($booking->canTransitionTo('checked_in'))
                                <form method="POST" action="{{ route('bookings.check-in', $booking) }}">
                                    @csrf
                                    <button class="p-1.5 text-slate-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-all" title="Check In">
                                        <i class="fa-regular fa-door-open text-xs"></i>
                                    </button>
                                </form>
                                @endif

                                <a href="{{ route('bookings.invoice', $booking) }}"
                                   class="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all" title="Invoice">
                                    <i class="fa-regular fa-file-invoice text-xs"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-12 text-slate-400">
                            <i class="fa-regular fa-calendar-xmark text-2xl mb-2 block"></i>
                            <p class="text-sm">No bookings found matching your filters</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($bookings->hasPages())
        <div class="px-5 py-4 border-t border-slate-100">
            {{ $bookings->links('components.pagination') }}
        </div>
        @endif
    </div>
    @endif

</div>
@endsection
