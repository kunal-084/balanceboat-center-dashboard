<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    Auth\LoginController,
    Auth\OtpController,
    Auth\MfaController,
    Onboarding\OnboardingController,
    Dashboard\DashboardController,
    Centers\CenterController,
    Centers\CenterMediaController,
    Centers\CenterReviewController,
    Retreats\RetreatController,
    Retreats\RetreatItineraryController,
    Retreats\RetreatFaqController,
    Retreats\RetreatScheduleController,
    Accommodations\AccommodationController,
    Accommodations\AvailabilityController,
    Bookings\BookingController,
    Bookings\InquiryController,
    Bookings\RefundController,
    Pricing\PricingRuleController,
    Pricing\PromoCodeController,
    Teachers\TeacherController,
    Finance\FinanceController,
    Finance\PayoutController,
    Analytics\AnalyticsController,
    AI\AiController,
    Automation\AutomationController,
    Media\MediaController,
    Settings\SettingsController,
};

// ============================================================
// PUBLIC AUTH ROUTES
// ============================================================
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLogin'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
    Route::get('/login/otp', [OtpController::class, 'showOtpForm'])->name('login.otp');
    Route::post('/login/otp/send', [OtpController::class, 'sendOtp'])->name('login.otp.send');
    Route::post('/login/otp/verify', [OtpController::class, 'verifyOtp'])->name('login.otp.verify');
    Route::get('/login/google', [LoginController::class, 'redirectToGoogle'])->name('login.google');
    Route::get('/login/google/callback', [LoginController::class, 'handleGoogleCallback'])->name('login.google.callback');
    Route::get('/forgot-password', [LoginController::class, 'showForgotPassword'])->name('password.request');
    Route::post('/forgot-password', [LoginController::class, 'sendResetLink'])->name('password.email');
    Route::get('/reset-password/{token}', [LoginController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [LoginController::class, 'resetPassword'])->name('password.update');
});

Route::post('/logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth');

// ============================================================
// ONBOARDING (auth, not yet onboarded)
// ============================================================
Route::middleware(['auth', 'onboarding.incomplete'])->group(function () {
    Route::get('/onboarding', [OnboardingController::class, 'index'])->name('onboarding.index');
    Route::post('/onboarding/step/{step}', [OnboardingController::class, 'saveStep'])->name('onboarding.step');
    Route::post('/onboarding/complete', [OnboardingController::class, 'complete'])->name('onboarding.complete');
});

// ============================================================
// AUTHENTICATED APPLICATION ROUTES
// ============================================================
Route::middleware(['auth', 'onboarding.complete', 'audit.log'])->group(function () {

    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');
    Route::get('/dashboard/widgets/{widget}', [DashboardController::class, 'widget'])->name('dashboard.widget');

    // ========================================================
    // CENTER MANAGEMENT
    // ========================================================
    Route::prefix('center')->name('center.')->group(function () {
        Route::get('/', [CenterController::class, 'show'])->name('show');
        Route::get('/edit', [CenterController::class, 'edit'])->name('edit');
        Route::put('/', [CenterController::class, 'update'])->name('update');

        Route::get('/locations', [CenterController::class, 'locations'])->name('locations');
        Route::post('/locations', [CenterController::class, 'storeLocation'])->name('locations.store');
        Route::delete('/locations/{location}', [CenterController::class, 'destroyLocation'])->name('locations.destroy');

        Route::get('/certifications', [CenterController::class, 'certifications'])->name('certifications');
        Route::post('/certifications', [CenterController::class, 'attachCertification'])->name('certifications.attach');
        Route::delete('/certifications/{cert}', [CenterController::class, 'detachCertification'])->name('certifications.detach');

        Route::get('/amenities', [CenterController::class, 'amenities'])->name('amenities');
        Route::post('/amenities', [CenterController::class, 'syncAmenities'])->name('amenities.sync');

        Route::get('/team', [CenterController::class, 'team'])->name('team');
        Route::post('/team/invite', [CenterController::class, 'inviteTeamMember'])->name('team.invite');
        Route::delete('/team/{user}', [CenterController::class, 'removeTeamMember'])->name('team.remove');

        Route::get('/seo', [CenterController::class, 'seoSettings'])->name('seo');
        Route::put('/seo', [CenterController::class, 'updateSeo'])->name('seo.update');

        Route::resource('reviews', CenterReviewController::class)->only(['index', 'show', 'update', 'destroy']);
        Route::post('reviews/{review}/respond', [CenterReviewController::class, 'respond'])->name('reviews.respond');
        Route::post('reviews/{review}/approve', [CenterReviewController::class, 'approve'])->name('reviews.approve');

        Route::get('/media', [CenterMediaController::class, 'index'])->name('media.index');
        Route::post('/media', [CenterMediaController::class, 'store'])->name('media.store');
        Route::delete('/media/{media}', [CenterMediaController::class, 'destroy'])->name('media.destroy');
        Route::put('/media/reorder', [CenterMediaController::class, 'reorder'])->name('media.reorder');
    });

    // ========================================================
    // RETREAT (EXPERIENCE) MANAGEMENT
    // ========================================================
    Route::prefix('retreats')->name('retreats.')->group(function () {
        Route::get('/', [RetreatController::class, 'index'])->name('index');
        Route::get('/create', [RetreatController::class, 'create'])->name('create');
        Route::post('/', [RetreatController::class, 'store'])->name('store');
        Route::get('/templates', [RetreatController::class, 'templates'])->name('templates');
        Route::get('/recurring', [RetreatController::class, 'recurring'])->name('recurring');

        Route::prefix('{retreat}')->group(function () {
            Route::get('/', [RetreatController::class, 'show'])->name('show');
            Route::get('/edit', [RetreatController::class, 'edit'])->name('edit');
            Route::put('/', [RetreatController::class, 'update'])->name('update');
            Route::delete('/', [RetreatController::class, 'destroy'])->name('destroy');

            Route::post('/publish', [RetreatController::class, 'publish'])->name('publish');
            Route::post('/unpublish', [RetreatController::class, 'unpublish'])->name('unpublish');
            Route::post('/duplicate', [RetreatController::class, 'duplicate'])->name('duplicate');
            Route::post('/save-as-template', [RetreatController::class, 'saveAsTemplate'])->name('save-as-template');

            Route::get('/availability', [RetreatScheduleController::class, 'availability'])->name('availability');
            Route::put('/availability', [RetreatScheduleController::class, 'updateAvailability'])->name('availability.update');

            Route::resource('faqs', RetreatFaqController::class)->except(['show']);
            Route::put('faqs/reorder', [RetreatFaqController::class, 'reorder'])->name('faqs.reorder');

            Route::resource('itinerary', RetreatItineraryController::class)->except(['show']);
            Route::resource('itinerary.sessions', RetreatItineraryController::class . '@sessions')->except(['show']);

            Route::get('/seo', [RetreatController::class, 'seoEdit'])->name('seo');
            Route::put('/seo', [RetreatController::class, 'seoUpdate'])->name('seo.update');

            Route::get('/food', [RetreatController::class, 'foodPlan'])->name('food');
            Route::put('/food', [RetreatController::class, 'updateFoodPlan'])->name('food.update');

            Route::get('/reviews', [CenterReviewController::class, 'retreatReviews'])->name('reviews');

            Route::get('/media', [MediaController::class, 'forRetreat'])->name('media');
            Route::post('/media', [MediaController::class, 'uploadForRetreat'])->name('media.upload');
        });
    });

    // ========================================================
    // ACCOMMODATIONS
    // ========================================================
    Route::resource('accommodations', AccommodationController::class);
    Route::prefix('accommodations/{accommodation}')->name('accommodations.')->group(function () {
        Route::get('/inventory', [AccommodationController::class, 'inventory'])->name('inventory');
        Route::get('/pricing', [AccommodationController::class, 'pricing'])->name('pricing');
        Route::put('/pricing', [AccommodationController::class, 'updatePricing'])->name('pricing.update');
        Route::get('/calendar', [AvailabilityController::class, 'show'])->name('calendar');
        Route::put('/calendar', [AvailabilityController::class, 'update'])->name('calendar.update');
        Route::post('/calendar/block', [AvailabilityController::class, 'blockDates'])->name('calendar.block');
        Route::post('/calendar/unblock', [AvailabilityController::class, 'unblockDates'])->name('calendar.unblock');
        Route::get('/media', [MediaController::class, 'forAccommodation'])->name('media');
    });

    // ========================================================
    // BOOKINGS
    // ========================================================
    Route::prefix('bookings')->name('bookings.')->group(function () {
        Route::get('/', [BookingController::class, 'index'])->name('index');
        Route::get('/{booking}', [BookingController::class, 'show'])->name('show');
        Route::get('/{booking}/edit', [BookingController::class, 'edit'])->name('edit');
        Route::put('/{booking}', [BookingController::class, 'update'])->name('update');
        Route::post('/{booking}/confirm', [BookingController::class, 'confirm'])->name('confirm');
        Route::post('/{booking}/cancel', [BookingController::class, 'cancel'])->name('cancel');
        Route::post('/{booking}/check-in', [BookingController::class, 'checkIn'])->name('check-in');
        Route::post('/{booking}/check-out', [BookingController::class, 'checkOut'])->name('check-out');
        Route::get('/{booking}/invoice', [BookingController::class, 'invoice'])->name('invoice');
        Route::get('/{booking}/invoice/pdf', [BookingController::class, 'invoicePdf'])->name('invoice.pdf');
        Route::get('/cancelled', [BookingController::class, 'cancelled'])->name('cancelled');
        Route::get('/check-ins', [BookingController::class, 'checkIns'])->name('check-ins');
        Route::post('/{booking}/refund', [RefundController::class, 'process'])->name('refund');
    });

    // ========================================================
    // INQUIRY PIPELINE (CRM)
    // ========================================================
    Route::resource('inquiries', InquiryController::class);
    Route::prefix('inquiries/{inquiry}')->name('inquiries.')->group(function () {
        Route::put('/stage', [InquiryController::class, 'updateStage'])->name('stage');
        Route::put('/assign', [InquiryController::class, 'assign'])->name('assign');
        Route::post('/convert', [InquiryController::class, 'convertToBooking'])->name('convert');
        Route::post('/message', [InquiryController::class, 'sendMessage'])->name('message');
    });

    // ========================================================
    // GUESTS
    // ========================================================
    Route::prefix('guests')->name('guests.')->group(function () {
        Route::get('/', fn() => view('guests.index'))->name('index');
        Route::get('/{user}', fn($user) => view('guests.show', ['user' => $user]))->name('show');
        Route::get('/{user}/bookings', fn($user) => view('guests.bookings', ['user' => $user]))->name('bookings');
    });

    // ========================================================
    // PRICING ENGINE
    // ========================================================
    Route::prefix('pricing')->name('pricing.')->group(function () {
        Route::get('/seasonal', [PricingRuleController::class, 'seasonal'])->name('seasonal');
        Route::get('/dynamic', [PricingRuleController::class, 'dynamic'])->name('dynamic');
        Route::get('/early-bird', [PricingRuleController::class, 'earlyBird'])->name('early-bird');
        Route::get('/last-minute', [PricingRuleController::class, 'lastMinute'])->name('last-minute');
        Route::get('/parity', [PricingRuleController::class, 'parity'])->name('parity');
        Route::resource('rules', PricingRuleController::class);
    });

    // Promo Codes
    Route::resource('coupons', PromoCodeController::class);
    Route::post('coupons/{coupon}/toggle', [PromoCodeController::class, 'toggleActive'])->name('coupons.toggle');

    // ========================================================
    // TEACHER MANAGEMENT
    // ========================================================
    Route::resource('teachers', TeacherController::class);
    Route::prefix('teachers/{teacher}')->name('teachers.')->group(function () {
        Route::get('/availability', [TeacherController::class, 'availability'])->name('availability');
        Route::put('/availability', [TeacherController::class, 'updateAvailability'])->name('availability.update');
        Route::get('/retreats', [TeacherController::class, 'retreats'])->name('retreats');
        Route::get('/certifications', [TeacherController::class, 'certifications'])->name('certifications');
    });

    // ========================================================
    // FINANCE
    // ========================================================
    Route::prefix('finance')->name('finance.')->group(function () {
        Route::get('/', [FinanceController::class, 'index'])->name('index');
        Route::get('/revenue', [FinanceController::class, 'revenue'])->name('revenue');
        Route::get('/commissions', [FinanceController::class, 'commissions'])->name('commissions');
        Route::get('/tax', [FinanceController::class, 'tax'])->name('tax');
        Route::get('/invoices', [FinanceController::class, 'invoices'])->name('invoices');
        Route::get('/bank-details', [FinanceController::class, 'bankDetails'])->name('bank-details');
        Route::put('/bank-details', [FinanceController::class, 'updateBankDetails'])->name('bank-details.update');
        Route::resource('payouts', PayoutController::class)->only(['index', 'create', 'store', 'show']);
        Route::put('payouts/{payout}/cancel', [PayoutController::class, 'cancel'])->name('payouts.cancel');
    });

    // ========================================================
    // ANALYTICS
    // ========================================================
    Route::prefix('analytics')->name('analytics.')->group(function () {
        Route::get('/', [AnalyticsController::class, 'index'])->name('index');
        Route::get('/bookings', [AnalyticsController::class, 'bookings'])->name('bookings');
        Route::get('/revenue', [AnalyticsController::class, 'revenue'])->name('revenue');
        Route::get('/occupancy', [AnalyticsController::class, 'occupancy'])->name('occupancy');
        Route::get('/conversions', [AnalyticsController::class, 'conversions'])->name('conversions');
        Route::get('/inquiries', [AnalyticsController::class, 'inquiries'])->name('inquiries');
        Route::get('/retreats/{retreat}', [AnalyticsController::class, 'retreatPerformance'])->name('retreat');
        Route::get('/export', [AnalyticsController::class, 'export'])->name('export');
    });

    // ========================================================
    // AI MODULES
    // ========================================================
    Route::prefix('ai')->name('ai.')->group(function () {
        Route::get('/', [AiController::class, 'index'])->name('index');
        Route::get('/recommendations', [AiController::class, 'recommendations'])->name('recommendations');
        Route::get('/content', [AiController::class, 'contentGenerator'])->name('content');
        Route::post('/content/generate', [AiController::class, 'generateContent'])->name('content.generate');
        Route::get('/seo', [AiController::class, 'seoGenerator'])->name('seo');
        Route::post('/seo/generate', [AiController::class, 'generateSeo'])->name('seo.generate');
        Route::post('/recommendations/{recommendation}/apply', [AiController::class, 'applyRecommendation'])->name('recommendations.apply');
        Route::post('/recommendations/{recommendation}/dismiss', [AiController::class, 'dismissRecommendation'])->name('recommendations.dismiss');
    });

    // ========================================================
    // AUTOMATION
    // ========================================================
    Route::prefix('automations')->name('automations.')->group(function () {
        Route::get('/', [AutomationController::class, 'index'])->name('index');
        Route::resource('rules', AutomationController::class);
        Route::post('rules/{rule}/toggle', [AutomationController::class, 'toggleActive'])->name('rules.toggle');
        Route::get('/logs', [AutomationController::class, 'logs'])->name('logs');
        Route::get('/email-templates', [AutomationController::class, 'emailTemplates'])->name('email-templates.index');
        Route::resource('email-templates', AutomationController::class . '@emailTemplates');
        Route::get('/whatsapp-templates', [AutomationController::class, 'whatsappTemplates'])->name('whatsapp-templates.index');
    });

    // ========================================================
    // MEDIA LIBRARY
    // ========================================================
    Route::prefix('media')->name('media.')->group(function () {
        Route::get('/', [MediaController::class, 'index'])->name('index');
        Route::post('/upload', [MediaController::class, 'upload'])->name('upload');
        Route::delete('/{media}', [MediaController::class, 'destroy'])->name('destroy');
        Route::put('/reorder', [MediaController::class, 'reorder'])->name('reorder');
        Route::put('/{media}', [MediaController::class, 'update'])->name('update');
        Route::get('/folders', [MediaController::class, 'folders'])->name('folders');
        Route::post('/folders', [MediaController::class, 'createFolder'])->name('folders.create');
    });

    // ========================================================
    // SETTINGS
    // ========================================================
    Route::prefix('settings')->name('settings.')->group(function () {
        Route::get('/', [SettingsController::class, 'index'])->name('index');
        Route::get('/notifications', [SettingsController::class, 'notifications'])->name('notifications');
        Route::put('/notifications', [SettingsController::class, 'updateNotifications'])->name('notifications.update');
        Route::get('/subscription', [SettingsController::class, 'subscription'])->name('subscription');
        Route::get('/security', [SettingsController::class, 'security'])->name('security');
        Route::post('/security/enable-mfa', [SettingsController::class, 'enableMfa'])->name('security.mfa');
        Route::get('/profile', [SettingsController::class, 'profile'])->name('profile');
        Route::put('/profile', [SettingsController::class, 'updateProfile'])->name('profile.update');
        Route::put('/password', [SettingsController::class, 'updatePassword'])->name('password.update');
    });

    // ========================================================
    // SUPER ADMIN / BB ADMIN ONLY
    // ========================================================
    Route::middleware('role:super-admin|balanceboat-admin')->prefix('admin')->name('admin.')->group(function () {
        Route::get('/centers', fn() => view('admin.centers.index'))->name('centers.index');
        Route::get('/centers/{center}', fn($center) => view('admin.centers.show', compact('center')))->name('centers.show');
        Route::put('/centers/{center}/verify', fn($center) => back())->name('centers.verify');
        Route::put('/centers/{center}/suspend', fn($center) => back())->name('centers.suspend');
        Route::get('/audit-logs', fn() => view('admin.audit-logs'))->name('audit-logs');
        Route::get('/system-settings', [SettingsController::class, 'systemSettings'])->name('system-settings');
        Route::put('/system-settings', [SettingsController::class, 'updateSystemSettings'])->name('system-settings.update');
        Route::get('/subscriptions', fn() => view('admin.subscriptions'))->name('subscriptions');
        Route::resource('subscription-plans', SettingsController::class . '@subscriptionPlans');
    });
});
