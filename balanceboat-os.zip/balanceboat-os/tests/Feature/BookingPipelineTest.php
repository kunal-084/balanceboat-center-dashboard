<?php

// ============================================================
// tests/Feature/BookingPipelineTest.php
// ============================================================

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Center;
use App\Models\Booking;
use App\Models\Experience;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;

class BookingPipelineTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected User $centerOwner;
    protected Center $center;
    protected Experience $retreat;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        $this->centerOwner = User::factory()->create();
        $this->centerOwner->assignRole('center-owner');

        $this->center = Center::factory()->create();
        $this->centerOwner->update(['center_id' => $this->center->id]);

        $this->retreat = Experience::factory()->create([
            'center_id' => $this->center->id,
            'status'    => 'published',
        ]);
    }

    public function test_booking_can_be_created(): void
    {
        $this->actingAs($this->centerOwner);

        $response = $this->postJson('/api/v1/bookings', [
            'experience_id'  => $this->retreat->id,
            'guest_name'     => 'Jane Doe',
            'guest_email'    => 'jane@example.com',
            'guest_phone'    => '+1234567890',
            'checkin_date'   => now()->addDays(10)->format('Y-m-d'),
            'checkout_date'  => now()->addDays(17)->format('Y-m-d'),
            'adults'         => 1,
        ]);

        $response->assertStatus(201)
            ->assertJsonStructure(['data' => ['id', 'booking_reference', 'status']]);

        $this->assertDatabaseHas('bookings', [
            'guest_email' => 'jane@example.com',
            'status'      => 'pending',
        ]);
    }

    public function test_booking_transitions_from_pending_to_confirmed(): void
    {
        $this->actingAs($this->centerOwner);

        $booking = Booking::factory()->create([
            'center_id'     => $this->center->id,
            'experience_id' => $this->retreat->id,
            'status'        => 'pending',
        ]);

        $response = $this->postJson("/api/v1/bookings/{$booking->id}/confirm");

        $response->assertStatus(200);
        $this->assertDatabaseHas('bookings', ['id' => $booking->id, 'status' => 'confirmed']);
    }

    public function test_booking_transitions_from_confirmed_to_checked_in(): void
    {
        $this->actingAs($this->centerOwner);

        $booking = Booking::factory()->confirmed()->create([
            'center_id'     => $this->center->id,
            'experience_id' => $this->retreat->id,
        ]);

        $response = $this->postJson("/api/v1/bookings/{$booking->id}/check-in");

        $response->assertStatus(200);
        $this->assertDatabaseHas('bookings', ['id' => $booking->id, 'status' => 'checked_in']);
    }

    public function test_booking_transitions_from_checked_in_to_completed(): void
    {
        $this->actingAs($this->centerOwner);

        $booking = Booking::factory()->create([
            'center_id'     => $this->center->id,
            'experience_id' => $this->retreat->id,
            'status'        => 'checked_in',
        ]);

        $response = $this->postJson("/api/v1/bookings/{$booking->id}/check-out");

        $response->assertStatus(200);
        $this->assertDatabaseHas('bookings', ['id' => $booking->id, 'status' => 'completed']);
    }

    public function test_booking_can_be_cancelled_from_pending(): void
    {
        $this->actingAs($this->centerOwner);

        $booking = Booking::factory()->pending()->create([
            'center_id'     => $this->center->id,
            'experience_id' => $this->retreat->id,
        ]);

        $response = $this->postJson("/api/v1/bookings/{$booking->id}/cancel", [
            'reason' => 'Guest request',
        ]);

        $response->assertStatus(200);
        $this->assertDatabaseHas('bookings', ['id' => $booking->id, 'status' => 'cancelled']);
    }

    public function test_invalid_status_transition_is_rejected(): void
    {
        $this->actingAs($this->centerOwner);

        $booking = Booking::factory()->completed()->create([
            'center_id'     => $this->center->id,
            'experience_id' => $this->retreat->id,
        ]);

        // Cannot confirm a completed booking
        $response = $this->postJson("/api/v1/bookings/{$booking->id}/confirm");

        $response->assertStatus(422);
    }

    public function test_staff_cannot_refund_booking(): void
    {
        $staff = User::factory()->create(['center_id' => $this->center->id]);
        $staff->assignRole('staff');
        $this->actingAs($staff);

        $booking = Booking::factory()->completed()->create([
            'center_id'     => $this->center->id,
            'experience_id' => $this->retreat->id,
        ]);

        $response = $this->postJson("/api/v1/bookings/{$booking->id}/cancel", ['reason' => 'test']);

        $response->assertStatus(403);
    }

    public function test_booking_reference_is_unique(): void
    {
        $booking1 = Booking::factory()->create(['center_id' => $this->center->id, 'experience_id' => $this->retreat->id]);
        $booking2 = Booking::factory()->create(['center_id' => $this->center->id, 'experience_id' => $this->retreat->id]);

        $this->assertNotEquals($booking1->booking_reference, $booking2->booking_reference);
    }

    public function test_unauthenticated_user_cannot_access_bookings(): void
    {
        $response = $this->getJson('/api/v1/bookings');
        $response->assertStatus(401);
    }
}
