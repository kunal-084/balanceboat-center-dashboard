<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Center;
use App\Models\Experience;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;

class RetreatCrudTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected User $centerOwner;
    protected Center $center;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        $this->centerOwner = User::factory()->create();
        $this->centerOwner->assignRole('center-owner');

        $this->center = Center::factory()->create();
        $this->centerOwner->update(['center_id' => $this->center->id]);
    }

    public function test_center_owner_can_create_retreat(): void
    {
        $this->actingAs($this->centerOwner);

        $response = $this->postJson('/api/v1/experiences', [
            'title'              => 'Test Yoga Retreat',
            'short_description'  => 'A transformational yoga experience.',
            'description'        => 'Full description of the retreat program.',
            'duration_days'      => 7,
            'duration_nights'    => 6,
            'base_price'         => 999.00,
            'currency'           => 'USD',
            'min_participants'   => 2,
            'max_participants'   => 20,
        ]);

        $response->assertStatus(201)
            ->assertJsonStructure(['data' => ['id', 'title', 'slug', 'status']]);

        $this->assertDatabaseHas('experiences', [
            'title'     => 'Test Yoga Retreat',
            'center_id' => $this->center->id,
            'status'    => 'draft',
        ]);
    }

    public function test_retreat_can_be_published(): void
    {
        $this->actingAs($this->centerOwner);

        $retreat = Experience::factory()->create([
            'center_id' => $this->center->id,
            'status'    => 'draft',
        ]);

        $response = $this->postJson("/api/v1/experiences/{$retreat->id}/publish");

        $response->assertStatus(200);
        $this->assertDatabaseHas('experiences', ['id' => $retreat->id, 'status' => 'published']);
    }

    public function test_retreat_can_be_unpublished(): void
    {
        $this->actingAs($this->centerOwner);

        $retreat = Experience::factory()->published()->create([
            'center_id' => $this->center->id,
        ]);

        $response = $this->postJson("/api/v1/experiences/{$retreat->id}/unpublish");

        $response->assertStatus(200);
        $this->assertDatabaseHas('experiences', ['id' => $retreat->id, 'status' => 'draft']);
    }

    public function test_retreat_can_be_duplicated(): void
    {
        $this->actingAs($this->centerOwner);

        $retreat = Experience::factory()->published()->create([
            'center_id' => $this->center->id,
            'title'     => 'Original Retreat',
        ]);

        $response = $this->postJson("/api/v1/experiences/{$retreat->id}/duplicate");

        $response->assertStatus(201);
        $this->assertDatabaseHas('experiences', ['title' => 'Copy of Original Retreat', 'status' => 'draft']);
    }

    public function test_retreat_can_be_updated(): void
    {
        $this->actingAs($this->centerOwner);

        $retreat = Experience::factory()->create(['center_id' => $this->center->id]);

        $response = $this->putJson("/api/v1/experiences/{$retreat->id}", [
            'title'      => 'Updated Title',
            'base_price' => 1499.00,
        ]);

        $response->assertStatus(200);
        $this->assertDatabaseHas('experiences', ['id' => $retreat->id, 'title' => 'Updated Title']);
    }

    public function test_retreat_can_be_deleted_when_draft(): void
    {
        $this->actingAs($this->centerOwner);

        $retreat = Experience::factory()->draft()->create(['center_id' => $this->center->id]);

        $response = $this->deleteJson("/api/v1/experiences/{$retreat->id}");

        $response->assertStatus(200);
        $this->assertSoftDeleted('experiences', ['id' => $retreat->id]);
    }

    public function test_teacher_cannot_create_retreat(): void
    {
        $teacher = User::factory()->create(['center_id' => $this->center->id]);
        $teacher->assignRole('teacher');
        $this->actingAs($teacher);

        $response = $this->postJson('/api/v1/experiences', [
            'title'      => 'Unauthorized Retreat',
            'base_price' => 500,
        ]);

        $response->assertStatus(403);
    }

    public function test_center_owner_cannot_access_another_centers_retreat(): void
    {
        $otherCenter  = Center::factory()->create();
        $otherRetreat = Experience::factory()->create(['center_id' => $otherCenter->id]);

        $this->actingAs($this->centerOwner);

        $response = $this->putJson("/api/v1/experiences/{$otherRetreat->id}", [
            'title' => 'Hacked Title',
        ]);

        $response->assertStatus(403);
    }

    public function test_retreat_slug_is_auto_generated(): void
    {
        $this->actingAs($this->centerOwner);

        $response = $this->postJson('/api/v1/experiences', [
            'title'       => 'My Unique Retreat Title',
            'description' => 'Full desc',
            'base_price'  => 500,
            'duration_days' => 5,
        ]);

        $response->assertStatus(201);
        $data = $response->json('data');
        $this->assertStringStartsWith('my-unique-retreat-title', $data['slug']);
    }

    public function test_published_retreat_appears_in_public_listing(): void
    {
        $retreat = Experience::factory()->published()->create(['center_id' => $this->center->id]);

        $response = $this->getJson('/api/v1/experiences');

        $response->assertStatus(200);
        $ids = collect($response->json('data'))->pluck('id')->toArray();
        $this->assertContains($retreat->id, $ids);
    }

    public function test_draft_retreat_does_not_appear_in_public_listing(): void
    {
        $retreat = Experience::factory()->draft()->create(['center_id' => $this->center->id]);

        $response = $this->getJson('/api/v1/experiences');

        $response->assertStatus(200);
        $ids = collect($response->json('data'))->pluck('id')->toArray();
        $this->assertNotContains($retreat->id, $ids);
    }
}
