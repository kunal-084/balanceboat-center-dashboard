<?php

// ============================================================
// tests/Feature/PricingEngineTest.php
// ============================================================

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Center;
use App\Models\Experience;
use App\Models\PricingRule;
use App\Models\PromoCode;
use App\Services\PricingService;
use Illuminate\Foundation\Testing\RefreshDatabase;

class PricingEngineTest extends TestCase
{
    use RefreshDatabase;

    protected User $centerOwner;
    protected Center $center;
    protected Experience $retreat;
    protected PricingService $pricingService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        $this->pricingService = app(PricingService::class);

        $this->centerOwner = User::factory()->create();
        $this->centerOwner->assignRole('center-owner');

        $this->center = Center::factory()->create(['commission_rate' => 10]);
        $this->centerOwner->update(['center_id' => $this->center->id]);

        $this->retreat = Experience::factory()->published()->create([
            'center_id'  => $this->center->id,
            'base_price' => 1000.00,
            'currency'   => 'USD',
        ]);
    }

    public function test_base_price_is_returned_when_no_rules_apply(): void
    {
        $pricing = $this->pricingService->calculatePrice([
            'experience_id' => $this->retreat->id,
            'checkin_date'  => now()->addDays(30)->format('Y-m-d'),
            'checkout_date' => now()->addDays(37)->format('Y-m-d'),
            'guests'        => 1,
        ]);

        $this->assertEquals(1000.00, $pricing->base_price);
        $this->assertEquals(1000.00, $pricing->final_price);
        $this->assertEquals(0, $pricing->discount_amount);
    }

    public function test_percentage_discount_rule_applies_correctly(): void
    {
        PricingRule::create([
            'center_id'        => $this->center->id,
            'experience_id'    => $this->retreat->id,
            'name'             => 'Early Bird 20%',
            'type'             => 'early_bird',
            'discount_type'    => 'percentage',
            'discount_value'   => 20,
            'days_before_start' => 60,
            'is_active'        => true,
            'priority'         => 1,
        ]);

        $pricing = $this->pricingService->calculatePrice([
            'experience_id' => $this->retreat->id,
            'checkin_date'  => now()->addDays(90)->format('Y-m-d'),
            'checkout_date' => now()->addDays(97)->format('Y-m-d'),
            'guests'        => 1,
        ]);

        $this->assertEquals(200.00, $pricing->discount_amount);
        $this->assertEquals(800.00, $pricing->final_price);
    }

    public function test_fixed_discount_rule_applies_correctly(): void
    {
        PricingRule::create([
            'center_id'      => $this->center->id,
            'experience_id'  => $this->retreat->id,
            'name'           => 'Weekend Special',
            'type'           => 'seasonal',
            'discount_type'  => 'fixed',
            'discount_value' => 150,
            'is_active'      => true,
            'priority'       => 1,
        ]);

        $pricing = $this->pricingService->calculatePrice([
            'experience_id' => $this->retreat->id,
            'checkin_date'  => now()->addDays(14)->format('Y-m-d'),
            'checkout_date' => now()->addDays(21)->format('Y-m-d'),
            'guests'        => 1,
        ]);

        $this->assertEquals(150.00, $pricing->discount_amount);
        $this->assertEquals(850.00, $pricing->final_price);
    }

    public function test_valid_promo_code_applies_correctly(): void
    {
        $promo = PromoCode::create([
            'center_id'       => $this->center->id,
            'code'            => 'WELLNESS25',
            'discount_type'   => 'percentage',
            'discount_value'  => 25,
            'min_booking_amount' => 500,
            'max_uses'        => 100,
            'used_count'      => 0,
            'is_active'       => true,
            'expires_at'      => now()->addDays(30),
        ]);

        $pricing = $this->pricingService->calculatePrice([
            'experience_id' => $this->retreat->id,
            'checkin_date'  => now()->addDays(14)->format('Y-m-d'),
            'checkout_date' => now()->addDays(21)->format('Y-m-d'),
            'guests'        => 1,
            'promo_code'    => 'WELLNESS25',
        ]);

        $this->assertEquals(250.00, $pricing->promo_discount);
        $this->assertEquals(750.00, $pricing->final_price);
    }

    public function test_expired_promo_code_is_rejected(): void
    {
        PromoCode::create([
            'center_id'      => $this->center->id,
            'code'           => 'EXPIRED10',
            'discount_type'  => 'percentage',
            'discount_value' => 10,
            'is_active'      => true,
            'expires_at'     => now()->subDay(),
        ]);

        $this->expectException(\InvalidArgumentException::class);

        $this->pricingService->validatePromoCode('EXPIRED10', 1000);
    }

    public function test_inactive_promo_code_is_rejected(): void
    {
        PromoCode::create([
            'center_id'      => $this->center->id,
            'code'           => 'INACTIVE10',
            'discount_type'  => 'percentage',
            'discount_value' => 10,
            'is_active'      => false,
            'expires_at'     => now()->addDays(30),
        ]);

        $this->expectException(\InvalidArgumentException::class);

        $this->pricingService->validatePromoCode('INACTIVE10', 1000);
    }

    public function test_promo_code_minimum_amount_is_enforced(): void
    {
        PromoCode::create([
            'center_id'          => $this->center->id,
            'code'               => 'MIN500',
            'discount_type'      => 'percentage',
            'discount_value'     => 20,
            'min_booking_amount' => 500,
            'is_active'          => true,
            'expires_at'         => now()->addDays(30),
        ]);

        $this->expectException(\InvalidArgumentException::class);

        $this->pricingService->validatePromoCode('MIN500', 300);
    }

    public function test_price_does_not_go_below_zero(): void
    {
        PricingRule::create([
            'center_id'      => $this->center->id,
            'experience_id'  => $this->retreat->id,
            'name'           => 'Huge Discount',
            'type'           => 'promotional',
            'discount_type'  => 'fixed',
            'discount_value' => 9999,
            'is_active'      => true,
            'priority'       => 1,
        ]);

        $pricing = $this->pricingService->calculatePrice([
            'experience_id' => $this->retreat->id,
            'checkin_date'  => now()->addDays(7)->format('Y-m-d'),
            'checkout_date' => now()->addDays(14)->format('Y-m-d'),
            'guests'        => 1,
        ]);

        $this->assertGreaterThanOrEqual(0, $pricing->final_price);
    }

    public function test_pricing_api_endpoint_returns_correct_structure(): void
    {
        $response = $this->postJson('/api/v1/pricing/calculate', [
            'experience_id' => $this->retreat->id,
            'checkin_date'  => now()->addDays(14)->format('Y-m-d'),
            'checkout_date' => now()->addDays(21)->format('Y-m-d'),
            'guests'        => 2,
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'base_price',
                    'discount_amount',
                    'final_price',
                    'currency',
                    'applied_rules',
                ],
            ]);
    }
}
