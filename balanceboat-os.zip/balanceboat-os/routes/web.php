<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Web\DashboardController;
use App\Http\Controllers\Web\RetreatController;
use App\Http\Controllers\Web\BookingController;
use App\Http\Controllers\Web\InquiryController;
use App\Http\Controllers\Web\TeacherController;
use App\Http\Controllers\Web\PricingController;
use App\Http\Controllers\Web\AnalyticsController;
use App\Http\Controllers\Web\FinanceController;
use App\Http\Controllers\Web\MediaController;
use App\Http\Controllers\Web\AiController;
use App\Http\Controllers\Web\AutomationController;
use App\Http\Controllers\Web\ReviewController;
use App\Http\Controllers\Web\SettingsController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\OtpController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\SocialAuthController;

/*
|--------------------------------------------------------------------------
| Authentication Routes
|--------------------------------------------------------------------------
*/

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLogin'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

    Route::get('/login/otp', [OtpController::class, 'showOtpForm'])->name('login.otp');
    Route::post('/login/otp/send', [OtpController::class, 'sendOtp'])->name('login.otp.send');
    Route::post('/login/otp/verify', [OtpController::class, 'verifyOtp'])->name('login.otp.verify');

    Route::get('/forgot-password', [ForgotPasswordController::class, 'showForm'])->name('password.request');
    Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLink'])->name('password.email');
    Route::get('/reset-password/{token}', [ForgotPasswordController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [ForgotPasswordController::class, 'resetPassword'])->name('password.update');

    Route::get('/auth/google', [SocialAuthController::class, 'redirectToGoogle'])->name('auth.google');
    Route::get('/auth/google/callback', [SocialAuthController::class, 'handleGoogleCallback'])->name('auth.google.callback');
});

Route::post('/logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth');

/*
|--------------------------------------------------------------------------
| Onboarding Routes
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'onboarding.incomplete'])->prefix('onboarding')->name('onboarding.')->group(function () {
    Route::get('/', [\App\Http\Controllers\Web\OnboardingController::class, 'index'])->name('index');
    Route::get('/step/{step}', [\App\Http\Controllers\Web\OnboardingController::class, 'showStep'])->name('step');
    Route::post('/step/{step}', [\App\Http\Controllers\Web\OnboardingController::class, 'saveStep'])->name('step.save');
    Route::post('/complete', [\App\Http\Controllers\Web\OnboardingController::class, 'complete'])->name('complete');
});

/*
|--------------------------------------------------------------------------
| Application Routes (Authenticated)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified', 'onboarding.complete'])->group(function () {

    /*
    |------------------------------------------------------------------
    | Dashboard
    |------------------------------------------------------------------
    */
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.alt');
    Route::get('/dashboard/kpis', [DashboardController::class, 'kpis'])->name('dashboard.kpis');
    Route::get('/dashboard/charts', [DashboardController::class, 'charts'])->name('dashboard.charts');
    Route::get('/dashboard/activity', [DashboardController::class, 'recentActivity'])->name('dashboard.activity');

    /*
    |------------------------------------------------------------------
    | Retreat Management
    |------------------------------------------------------------------
    */
    Route::prefix('retreats')->name('retreats.')->group(function () {
        Route::get('/', [RetreatController::class, 'index'])->name('index');
        Route::get('/create', [RetreatController::class, 'create'])->name('create');
        Route::post('/', [RetreatController::class, 'store'])->name('store');
        Route::get('/{experience}', [RetreatController::class, 'show'])->name('show');
        Route::get('/{experience}/edit', [RetreatController::class, 'edit'])->name('edit');
        Route::put('/{experience}', [RetreatController::class, 'update'])->name('update');
        Route::delete('/{experience}', [RetreatController::class, 'destroy'])->name('destroy');

        // Retreat Lifecycle
        Route::post('/{experience}/publish', [RetreatController::class, 'publish'])->name('publish');
        Route::post('/{experience}/unpublish', [RetreatController::class, 'unpublish'])->name('unpublish');
        Route::post('/{experience}/archive', [RetreatController::class, 'archive'])->name('archive');
        Route::post('/{experience}/duplicate', [RetreatController::class, 'duplicate'])->name('duplicate');

        // Availability & Scheduling
        Route::get('/{experience}/availability', [RetreatController::class, 'availability'])->name('availability');
        Route::post('/{experience}/availability/block', [RetreatController::class, 'blockDates'])->name('availability.block');
        Route::delete('/{experience}/availability/{date}', [RetreatController::class, 'unblockDate'])->name('availability.unblock');
        Route::post('/{experience}/schedules', [RetreatController::class, 'storeSchedule'])->name('schedules.store');
        Route::delete('/{experience}/schedules/{schedule}', [RetreatController::class, 'destroySchedule'])->name('schedules.destroy');

        // Itinerary
        Route::post('/{experience}/itinerary/days', [RetreatController::class, 'storeDayItinerary'])->name('itinerary.day.store');
        Route::put('/{experience}/itinerary/days/{day}', [RetreatController::class, 'updateDayItinerary'])->name('itinerary.day.update');
        Route::delete('/{experience}/itinerary/days/{day}', [RetreatController::class, 'destroyDayItinerary'])->name('itinerary.day.destroy');
        Route::post('/{experience}/itinerary/days/{day}/sessions', [RetreatController::class, 'storeSession'])->name('itinerary.session.store');
        Route::put('/{experience}/itinerary/sessions/{session}', [RetreatController::class, 'updateSession'])->name('itinerary.session.update');
        Route::delete('/{experience}/itinerary/sessions/{session}', [RetreatController::class, 'destroySession'])->name('itinerary.session.destroy');

        // Media
        Route::post('/{experience}/media', [RetreatController::class, 'uploadMedia'])->name('media.upload');
        Route::delete('/{experience}/media/{media}', [RetreatController::class, 'deleteMedia'])->name('media.destroy');
        Route::post('/{experience}/media/reorder', [RetreatController::class, 'reorderMedia'])->name('media.reorder');
    });

    /*
    |------------------------------------------------------------------
    | Booking Management
    |------------------------------------------------------------------
    */
    Route::prefix('bookings')->name('bookings.')->group(function () {
        Route::get('/', [BookingController::class, 'index'])->name('index');
        Route::get('/create', [BookingController::class, 'create'])->name('create');
        Route::post('/', [BookingController::class, 'store'])->name('store');
        Route::get('/{booking}', [BookingController::class, 'show'])->name('show');
        Route::get('/{booking}/edit', [BookingController::class, 'edit'])->name('edit');
        Route::put('/{booking}', [BookingController::class, 'update'])->name('update');
        Route::delete('/{booking}', [BookingController::class, 'destroy'])->name('destroy');

        // Pipeline Actions
        Route::post('/{booking}/confirm', [BookingController::class, 'confirm'])->name('confirm');
        Route::post('/{booking}/check-in', [BookingController::class, 'checkIn'])->name('check-in');
        Route::post('/{booking}/check-out', [BookingController::class, 'checkOut'])->name('check-out');
        Route::post('/{booking}/cancel', [BookingController::class, 'cancel'])->name('cancel');
        Route::post('/{booking}/refund', [BookingController::class, 'refund'])->name('refund');
        Route::post('/{booking}/assign', [BookingController::class, 'assignStaff'])->name('assign');

        // Notes & Communication
        Route::post('/{booking}/notes', [BookingController::class, 'addNote'])->name('notes.store');
        Route::get('/{booking}/invoice', [BookingController::class, 'downloadInvoice'])->name('invoice');
    });

    /*
    |------------------------------------------------------------------
    | Inquiry Pipeline
    |------------------------------------------------------------------
    */
    Route::prefix('inquiries')->name('inquiries.')->group(function () {
        Route::get('/', [InquiryController::class, 'index'])->name('index');
        Route::get('/{inquiry}', [InquiryController::class, 'show'])->name('show');
        Route::put('/{inquiry}', [InquiryController::class, 'update'])->name('update');
        Route::delete('/{inquiry}', [InquiryController::class, 'destroy'])->name('destroy');

        Route::post('/{inquiry}/qualify', [InquiryController::class, 'qualify'])->name('qualify');
        Route::post('/{inquiry}/disqualify', [InquiryController::class, 'disqualify'])->name('disqualify');
        Route::post('/{inquiry}/convert', [InquiryController::class, 'convertToBooking'])->name('convert');
        Route::post('/{inquiry}/reply', [InquiryController::class, 'reply'])->name('reply');
        Route::post('/{inquiry}/assign', [InquiryController::class, 'assign'])->name('assign');
    });

    /*
    |------------------------------------------------------------------
    | Teacher Management
    |------------------------------------------------------------------
    */
    Route::resource('teachers', TeacherController::class);
    Route::prefix('teachers')->name('teachers.')->group(function () {
        Route::post('/{teacher}/toggle-featured', [TeacherController::class, 'toggleFeatured'])->name('toggle-featured');
        Route::get('/{teacher}/retreats', [TeacherController::class, 'retreats'])->name('retreats');
    });

    /*
    |------------------------------------------------------------------
    | Pricing Engine
    |------------------------------------------------------------------
    */
    Route::prefix('pricing')->name('pricing.')->group(function () {
        Route::get('/', [PricingController::class, 'index'])->name('index');

        // Pricing Rules
        Route::get('/rules', [PricingController::class, 'rules'])->name('rules');
        Route::post('/rules', [PricingController::class, 'storeRule'])->name('rules.store');
        Route::put('/rules/{rule}', [PricingController::class, 'updateRule'])->name('rules.update');
        Route::delete('/rules/{rule}', [PricingController::class, 'destroyRule'])->name('rules.destroy');
        Route::post('/rules/{rule}/toggle', [PricingController::class, 'toggleRule'])->name('rules.toggle');

        // Promo Codes
        Route::get('/promo-codes', [PricingController::class, 'promoCodes'])->name('promo-codes');
        Route::post('/promo-codes', [PricingController::class, 'storePromoCode'])->name('promo-codes.store');
        Route::put('/promo-codes/{promoCode}', [PricingController::class, 'updatePromoCode'])->name('promo-codes.update');
        Route::delete('/promo-codes/{promoCode}', [PricingController::class, 'destroyPromoCode'])->name('promo-codes.destroy');
        Route::post('/promo-codes/{promoCode}/toggle', [PricingController::class, 'togglePromoCode'])->name('promo-codes.toggle');

        // Calculator
        Route::post('/calculate', [PricingController::class, 'calculatePrice'])->name('calculate');
    });

    /*
    |------------------------------------------------------------------
    | Analytics
    |------------------------------------------------------------------
    */
    Route::prefix('analytics')->name('analytics.')->group(function () {
        Route::get('/', [AnalyticsController::class, 'index'])->name('index');
        Route::get('/revenue', [AnalyticsController::class, 'revenue'])->name('revenue');
        Route::get('/bookings', [AnalyticsController::class, 'bookings'])->name('bookings');
        Route::get('/occupancy', [AnalyticsController::class, 'occupancy'])->name('occupancy');
        Route::get('/conversion', [AnalyticsController::class, 'conversion'])->name('conversion');
        Route::get('/retreats', [AnalyticsController::class, 'retreats'])->name('retreats');
        Route::get('/export', [AnalyticsController::class, 'export'])->name('export');
    });

    /*
    |------------------------------------------------------------------
    | Finance
    |------------------------------------------------------------------
    */
    Route::prefix('finance')->name('finance.')->group(function () {
        Route::get('/', [FinanceController::class, 'index'])->name('index');
        Route::get('/revenue', [FinanceController::class, 'revenue'])->name('revenue');
        Route::get('/commissions', [FinanceController::class, 'commissions'])->name('commissions');
        Route::get('/payouts', [FinanceController::class, 'payouts'])->name('payouts');
        Route::post('/payouts', [FinanceController::class, 'requestPayout'])->name('payouts.request');
        Route::get('/payouts/{payout}', [FinanceController::class, 'showPayout'])->name('payouts.show');
        Route::get('/invoices', [FinanceController::class, 'invoices'])->name('invoices');
        Route::get('/invoices/{booking}', [FinanceController::class, 'downloadInvoice'])->name('invoices.download');
        Route::get('/tax-report', [FinanceController::class, 'taxReport'])->name('tax-report');
        Route::get('/export', [FinanceController::class, 'export'])->name('export');
    });

    /*
    |------------------------------------------------------------------
    | Media Library
    |------------------------------------------------------------------
    */
    Route::prefix('media')->name('media.')->group(function () {
        Route::get('/', [MediaController::class, 'index'])->name('index');
        Route::post('/upload', [MediaController::class, 'upload'])->name('upload');
        Route::delete('/{media}', [MediaController::class, 'destroy'])->name('destroy');
        Route::post('/reorder', [MediaController::class, 'reorder'])->name('reorder');
        Route::put('/{media}', [MediaController::class, 'update'])->name('update');

        // Folders
        Route::post('/folders', [MediaController::class, 'createFolder'])->name('folders.store');
        Route::put('/folders/{folder}', [MediaController::class, 'updateFolder'])->name('folders.update');
        Route::delete('/folders/{folder}', [MediaController::class, 'destroyFolder'])->name('folders.destroy');
        Route::post('/folders/{folder}/move', [MediaController::class, 'moveToFolder'])->name('folders.move');
    });

    /*
    |------------------------------------------------------------------
    | AI Studio
    |------------------------------------------------------------------
    */
    Route::prefix('ai')->name('ai.')->group(function () {
        Route::get('/', [AiController::class, 'index'])->name('index');
        Route::post('/generate-content', [AiController::class, 'generateContent'])->name('generate-content');
        Route::post('/generate-seo', [AiController::class, 'generateSeo'])->name('generate-seo');
        Route::post('/pricing-recommendations', [AiController::class, 'pricingRecommendations'])->name('pricing-recommendations');
        Route::post('/recommendations/{recommendation}/apply', [AiController::class, 'applyRecommendation'])->name('recommendations.apply');
        Route::post('/recommendations/{recommendation}/dismiss', [AiController::class, 'dismissRecommendation'])->name('recommendations.dismiss');
        Route::get('/recommendations', [AiController::class, 'recommendations'])->name('recommendations');
    });

    /*
    |------------------------------------------------------------------
    | Automation Rules
    |------------------------------------------------------------------
    */
    Route::prefix('automations')->name('automations.')->group(function () {
        Route::get('/', [AutomationController::class, 'index'])->name('index');
        Route::post('/', [AutomationController::class, 'store'])->name('store');
        Route::get('/{rule}', [AutomationController::class, 'show'])->name('show');
        Route::put('/{rule}', [AutomationController::class, 'update'])->name('update');
        Route::delete('/{rule}', [AutomationController::class, 'destroy'])->name('destroy');
        Route::post('/{rule}/toggle', [AutomationController::class, 'toggle'])->name('toggle');
        Route::get('/{rule}/executions', [AutomationController::class, 'executions'])->name('executions');
    });

    /*
    |------------------------------------------------------------------
    | Reviews
    |------------------------------------------------------------------
    */
    Route::prefix('reviews')->name('reviews.')->group(function () {
        Route::get('/', [ReviewController::class, 'index'])->name('index');
        Route::get('/{review}', [ReviewController::class, 'show'])->name('show');
        Route::post('/{review}/approve', [ReviewController::class, 'approve'])->name('approve');
        Route::post('/{review}/reject', [ReviewController::class, 'reject'])->name('reject');
        Route::post('/{review}/respond', [ReviewController::class, 'respond'])->name('respond');
    });

    /*
    |------------------------------------------------------------------
    | Settings
    |------------------------------------------------------------------
    */
    Route::prefix('settings')->name('settings.')->group(function () {
        Route::get('/', fn() => redirect()->route('settings.center-profile'))->name('index');

        Route::get('/center-profile', [SettingsController::class, 'centerProfile'])->name('center-profile');
        Route::put('/center-profile', [SettingsController::class, 'updateCenterProfile'])->name('center-profile.update');

        Route::get('/team', [SettingsController::class, 'team'])->name('team');
        Route::post('/team', [SettingsController::class, 'inviteTeamMember'])->name('team.invite');
        Route::put('/team/{user}', [SettingsController::class, 'updateTeamMember'])->name('team.update');
        Route::delete('/team/{user}', [SettingsController::class, 'removeTeamMember'])->name('team.destroy');

        Route::get('/email-templates', [SettingsController::class, 'emailTemplates'])->name('email-templates');
        Route::post('/email-templates', [SettingsController::class, 'storeEmailTemplate'])->name('email-templates.store');
        Route::put('/email-templates/{template}', [SettingsController::class, 'updateEmailTemplate'])->name('email-templates.update');
        Route::delete('/email-templates/{template}', [SettingsController::class, 'destroyEmailTemplate'])->name('email-templates.destroy');

        Route::get('/preferences', [SettingsController::class, 'preferences'])->name('preferences');
        Route::put('/preferences', [SettingsController::class, 'updatePreferences'])->name('preferences.update');

        Route::get('/subscription', [SettingsController::class, 'subscription'])->name('subscription');
        Route::post('/subscription/upgrade', [SettingsController::class, 'upgradeSubscription'])->name('subscription.upgrade');
        Route::post('/subscription/cancel', [SettingsController::class, 'cancelSubscription'])->name('subscription.cancel');

        Route::get('/security', [SettingsController::class, 'security'])->name('security');
        Route::put('/security/password', [SettingsController::class, 'updatePassword'])->name('security.password');
        Route::post('/security/mfa/enable', [SettingsController::class, 'enableMfa'])->name('security.mfa.enable');
        Route::post('/security/mfa/disable', [SettingsController::class, 'disableMfa'])->name('security.mfa.disable');
    });

    /*
    |------------------------------------------------------------------
    | Notifications (AJAX)
    |------------------------------------------------------------------
    */
    Route::prefix('notifications')->name('notifications.')->group(function () {
        Route::get('/', [\App\Http\Controllers\Web\NotificationController::class, 'index'])->name('index');
        Route::post('/{notification}/read', [\App\Http\Controllers\Web\NotificationController::class, 'markRead'])->name('read');
        Route::post('/read-all', [\App\Http\Controllers\Web\NotificationController::class, 'markAllRead'])->name('read-all');
    });

});

/*
|--------------------------------------------------------------------------
| Super Admin / BalanceBoat Admin Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:super-admin|balanceboat-admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [\App\Http\Controllers\Admin\AdminDashboardController::class, 'index'])->name('dashboard');
    Route::resource('centers', \App\Http\Controllers\Admin\AdminCenterController::class);
    Route::resource('plans', \App\Http\Controllers\Admin\AdminPlanController::class);
    Route::resource('users', \App\Http\Controllers\Admin\AdminUserController::class);
    Route::get('/audit-logs', [\App\Http\Controllers\Admin\AdminAuditController::class, 'index'])->name('audit-logs');
    Route::get('/system-settings', [\App\Http\Controllers\Admin\AdminSettingsController::class, 'index'])->name('system-settings');
    Route::put('/system-settings', [\App\Http\Controllers\Admin\AdminSettingsController::class, 'update'])->name('system-settings.update');
});
