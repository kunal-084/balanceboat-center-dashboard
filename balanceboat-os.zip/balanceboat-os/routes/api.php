<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ApiExperienceController;
use App\Http\Controllers\Api\ApiBookingController;
use App\Http\Controllers\Api\ApiPricingController;
use App\Http\Controllers\Api\ApiAnalyticsController;
use App\Http\Controllers\Api\ApiMediaController;
use App\Http\Controllers\Api\ApiCenterController;
use App\Http\Controllers\Api\ApiTeacherController;
use App\Http\Controllers\Api\ApiAccommodationController;
use App\Http\Controllers\Api\ApiAuthController;

/*
|--------------------------------------------------------------------------
| API Routes — v1
|--------------------------------------------------------------------------
| Prefix:    /api/v1
| Auth:      Laravel Sanctum
| Rate Limit: 60 requests/minute
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->name('api.v1.')->group(function () {

    /*
    |------------------------------------------------------------------
    | Public Endpoints (no auth required)
    |------------------------------------------------------------------
    */
    Route::middleware('throttle:60,1')->group(function () {
        // Auth
        Route::post('/auth/login', [ApiAuthController::class, 'login'])->name('auth.login');
        Route::post('/auth/register', [ApiAuthController::class, 'register'])->name('auth.register');
        Route::post('/auth/forgot-password', [ApiAuthController::class, 'forgotPassword'])->name('auth.forgot-password');
        Route::post('/auth/otp/send', [ApiAuthController::class, 'sendOtp'])->name('auth.otp.send');
        Route::post('/auth/otp/verify', [ApiAuthController::class, 'verifyOtp'])->name('auth.otp.verify');

        // Public Catalog Endpoints
        Route::get('/experiences', [ApiExperienceController::class, 'index'])->name('experiences.index');
        Route::get('/experiences/{experience}', [ApiExperienceController::class, 'show'])->name('experiences.show');
        Route::get('/centers/{center}/experiences', [ApiExperienceController::class, 'byCenter'])->name('experiences.by-center');
        Route::get('/centers/{center}', [ApiCenterController::class, 'show'])->name('centers.show');
        Route::get('/categories', [\App\Http\Controllers\Api\ApiCategoryController::class, 'index'])->name('categories.index');
        Route::get('/teachers', [ApiTeacherController::class, 'index'])->name('teachers.index');
        Route::get('/teachers/{teacher}', [ApiTeacherController::class, 'show'])->name('teachers.show');

        // Pricing check
        Route::post('/pricing/calculate', [ApiPricingController::class, 'calculate'])->name('pricing.calculate');
        Route::post('/pricing/validate-promo', [ApiPricingController::class, 'validatePromoCode'])->name('pricing.validate-promo');

        // Availability
        Route::get('/experiences/{experience}/availability', [ApiExperienceController::class, 'availability'])->name('experiences.availability');
        Route::get('/accommodations/{accommodation}/availability', [ApiAccommodationController::class, 'availability'])->name('accommodations.availability');
    });

    /*
    |------------------------------------------------------------------
    | Authenticated Endpoints
    |------------------------------------------------------------------
    */
    Route::middleware(['auth:sanctum', 'throttle:120,1'])->group(function () {

        // Auth Management
        Route::post('/auth/logout', [ApiAuthController::class, 'logout'])->name('auth.logout');
        Route::get('/auth/me', [ApiAuthController::class, 'me'])->name('auth.me');
        Route::put('/auth/profile', [ApiAuthController::class, 'updateProfile'])->name('auth.profile.update');
        Route::post('/auth/token/refresh', [ApiAuthController::class, 'refreshToken'])->name('auth.token.refresh');

        // Bookings
        Route::prefix('bookings')->name('bookings.')->group(function () {
            Route::get('/', [ApiBookingController::class, 'index'])->name('index');
            Route::post('/', [ApiBookingController::class, 'store'])->name('store');
            Route::get('/{booking}', [ApiBookingController::class, 'show'])->name('show');
            Route::put('/{booking}', [ApiBookingController::class, 'update'])->name('update');
            Route::delete('/{booking}', [ApiBookingController::class, 'destroy'])->name('destroy');
            Route::post('/{booking}/confirm', [ApiBookingController::class, 'confirm'])->name('confirm');
            Route::post('/{booking}/check-in', [ApiBookingController::class, 'checkIn'])->name('check-in');
            Route::post('/{booking}/check-out', [ApiBookingController::class, 'checkOut'])->name('check-out');
            Route::post('/{booking}/cancel', [ApiBookingController::class, 'cancel'])->name('cancel');
        });

        // Centers (center admin only)
        Route::prefix('centers')->name('centers.')->group(function () {
            Route::get('/', [ApiCenterController::class, 'index'])->name('index');
            Route::post('/', [ApiCenterController::class, 'store'])->name('store');
            Route::put('/{center}', [ApiCenterController::class, 'update'])->name('update');
            Route::delete('/{center}', [ApiCenterController::class, 'destroy'])->name('destroy');
            Route::post('/{center}/media', [ApiMediaController::class, 'uploadForCenter'])->name('media.upload');
        });

        // Experiences CRUD (authenticated)
        Route::prefix('experiences')->name('experiences.')->group(function () {
            Route::post('/', [ApiExperienceController::class, 'store'])->name('store');
            Route::put('/{experience}', [ApiExperienceController::class, 'update'])->name('update');
            Route::delete('/{experience}', [ApiExperienceController::class, 'destroy'])->name('destroy');
            Route::post('/{experience}/publish', [ApiExperienceController::class, 'publish'])->name('publish');
            Route::post('/{experience}/unpublish', [ApiExperienceController::class, 'unpublish'])->name('unpublish');
            Route::post('/{experience}/duplicate', [ApiExperienceController::class, 'duplicate'])->name('duplicate');
        });

        // Accommodations
        Route::prefix('accommodations')->name('accommodations.')->group(function () {
            Route::get('/', [ApiAccommodationController::class, 'index'])->name('index');
            Route::post('/', [ApiAccommodationController::class, 'store'])->name('store');
            Route::get('/{accommodation}', [ApiAccommodationController::class, 'show'])->name('show');
            Route::put('/{accommodation}', [ApiAccommodationController::class, 'update'])->name('update');
            Route::delete('/{accommodation}', [ApiAccommodationController::class, 'destroy'])->name('destroy');
        });

        // Analytics (center-scoped)
        Route::prefix('analytics')->name('analytics.')->group(function () {
            Route::get('/kpis', [ApiAnalyticsController::class, 'kpis'])->name('kpis');
            Route::get('/revenue', [ApiAnalyticsController::class, 'revenue'])->name('revenue');
            Route::get('/occupancy', [ApiAnalyticsController::class, 'occupancy'])->name('occupancy');
            Route::get('/top-retreats', [ApiAnalyticsController::class, 'topRetreats'])->name('top-retreats');
            Route::get('/conversion-funnel', [ApiAnalyticsController::class, 'conversionFunnel'])->name('conversion-funnel');
            Route::get('/booking-trend', [ApiAnalyticsController::class, 'bookingTrend'])->name('booking-trend');
        });

        // Media
        Route::prefix('media')->name('media.')->group(function () {
            Route::get('/', [ApiMediaController::class, 'index'])->name('index');
            Route::post('/upload', [ApiMediaController::class, 'upload'])->name('upload');
            Route::delete('/{media}', [ApiMediaController::class, 'destroy'])->name('destroy');
            Route::post('/reorder', [ApiMediaController::class, 'reorder'])->name('reorder');
        });

        // Pricing Rules
        Route::prefix('pricing')->name('pricing.')->group(function () {
            Route::get('/rules', [ApiPricingController::class, 'rules'])->name('rules');
            Route::post('/rules', [ApiPricingController::class, 'storeRule'])->name('rules.store');
            Route::put('/rules/{rule}', [ApiPricingController::class, 'updateRule'])->name('rules.update');
            Route::delete('/rules/{rule}', [ApiPricingController::class, 'destroyRule'])->name('rules.destroy');
        });

        // Notifications
        Route::get('/notifications', [\App\Http\Controllers\Api\ApiNotificationController::class, 'index'])->name('notifications.index');
        Route::post('/notifications/{notification}/read', [\App\Http\Controllers\Api\ApiNotificationController::class, 'markRead'])->name('notifications.read');
        Route::post('/notifications/read-all', [\App\Http\Controllers\Api\ApiNotificationController::class, 'markAllRead'])->name('notifications.read-all');
    });

    /*
    |------------------------------------------------------------------
    | Admin Endpoints (super-admin / balanceboat-admin)
    |------------------------------------------------------------------
    */
    Route::middleware(['auth:sanctum', 'role:super-admin|balanceboat-admin', 'throttle:60,1'])
        ->prefix('admin')
        ->name('admin.')
        ->group(function () {
            Route::get('/centers', [\App\Http\Controllers\Api\Admin\ApiAdminCenterController::class, 'index'])->name('centers.index');
            Route::put('/centers/{center}', [\App\Http\Controllers\Api\Admin\ApiAdminCenterController::class, 'update'])->name('centers.update');
            Route::get('/users', [\App\Http\Controllers\Api\Admin\ApiAdminUserController::class, 'index'])->name('users.index');
            Route::get('/audit-logs', [\App\Http\Controllers\Api\Admin\ApiAdminAuditController::class, 'index'])->name('audit-logs');
            Route::get('/analytics/platform', [\App\Http\Controllers\Api\Admin\ApiAdminAnalyticsController::class, 'platform'])->name('analytics.platform');
        });
});
