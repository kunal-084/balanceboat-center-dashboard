#!/usr/bin/env bash
################################################################################
# BalanceBoat Center OS — Zero-Downtime Deployment Script
#
# Usage:  ./devops/deploy.sh [--branch=main] [--skip-migrations]
# Prereq: git, composer, npm, php8.3, supervisorctl, certbot (on server)
################################################################################

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
APP_DIR="/var/www/balanceboat-os"
RELEASES_DIR="${APP_DIR}/releases"
SHARED_DIR="${APP_DIR}/shared"
CURRENT_LINK="${APP_DIR}/current"
REPO_URL="git@github.com:your-org/balanceboat-os.git"
BRANCH="${BRANCH:-main}"
KEEP_RELEASES=5

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RELEASE_DIR="${RELEASES_DIR}/${TIMESTAMP}"

# Parse args
SKIP_MIGRATIONS=0
for arg in "$@"; do
    case $arg in
        --skip-migrations) SKIP_MIGRATIONS=1 ;;
        --branch=*)        BRANCH="${arg#*=}"  ;;
    esac
done

log() { echo -e "\033[1;36m[$(date '+%H:%M:%S')] $*\033[0m"; }
err() { echo -e "\033[1;31m[ERROR] $*\033[0m" >&2; exit 1; }
ok()  { echo -e "\033[1;32m[OK] $*\033[0m"; }

# ── Pre-flight ────────────────────────────────────────────────────────────────
log "🚀 Starting deployment — branch: ${BRANCH}"
[[ -d "$SHARED_DIR" ]] || err "Shared dir missing. Run server setup first."

# ── 1. Clone release ─────────────────────────────────────────────────────────
log "📦 Cloning repo..."
git clone \
    --depth 1 \
    --branch "${BRANCH}" \
    "${REPO_URL}" \
    "${RELEASE_DIR}"
ok "Cloned to ${RELEASE_DIR}"

# ── 2. Link shared files/dirs ─────────────────────────────────────────────────
log "🔗 Linking shared resources..."
ln -sfn "${SHARED_DIR}/.env"             "${RELEASE_DIR}/.env"
ln -sfn "${SHARED_DIR}/storage"          "${RELEASE_DIR}/storage"
ln -sfn "${SHARED_DIR}/public/uploads"   "${RELEASE_DIR}/public/uploads"
ok "Shared links created"

# ── 3. PHP Dependencies ───────────────────────────────────────────────────────
log "📚 Installing Composer dependencies..."
cd "${RELEASE_DIR}"
composer install \
    --no-interaction \
    --no-dev \
    --optimize-autoloader \
    --prefer-dist \
    2>&1 | tail -5
ok "Composer done"

# ── 4. Node / Assets ─────────────────────────────────────────────────────────
log "🎨 Building frontend assets..."
npm ci --silent
npm run build
ok "Assets built"

# ── 5. Artisan: pre-deployment ───────────────────────────────────────────────
log "⚙️  Running pre-deployment commands..."
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
ok "Caches warmed"

# ── 6. Maintenance Mode (atomic) ─────────────────────────────────────────────
log "🔒 Enabling maintenance mode..."
if [[ -L "$CURRENT_LINK" ]]; then
    php "${CURRENT_LINK}/artisan" down \
        --secret="$(openssl rand -hex 16)" \
        --render="errors::503" \
        --refresh=15 \
        2>/dev/null || true
fi

# ── 7. Migrations ────────────────────────────────────────────────────────────
if [[ "$SKIP_MIGRATIONS" -eq 0 ]]; then
    log "🗄️  Running migrations..."
    php artisan migrate --force --no-interaction
    ok "Migrations done"
else
    log "⚠️  Skipping migrations (--skip-migrations flag set)"
fi

# ── 8. Symlink new release ────────────────────────────────────────────────────
log "🔄 Switching release..."
ln -sfn "${RELEASE_DIR}" "${CURRENT_LINK}"
ok "Current → ${RELEASE_DIR}"

# ── 9. Clear old caches ───────────────────────────────────────────────────────
log "🧹 Clearing application caches..."
php artisan cache:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache

# ── 10. Restart queue workers ────────────────────────────────────────────────
log "🔁 Restarting queue workers..."
php artisan queue:restart
supervisorctl restart balanceboat:*
ok "Queue workers restarted"

# ── 11. Disable maintenance mode ─────────────────────────────────────────────
log "🟢 Taking app out of maintenance mode..."
php artisan up
ok "App is live!"

# ── 12. Clean up old releases ────────────────────────────────────────────────
log "🗑️  Cleaning up old releases (keeping ${KEEP_RELEASES})..."
ls -dt "${RELEASES_DIR}"/*/ \
    | tail -n "+$((KEEP_RELEASES + 1))" \
    | xargs rm -rf 2>/dev/null || true
ok "Cleanup done"

# ── 13. Health check ─────────────────────────────────────────────────────────
log "❤️  Running health check..."
sleep 2
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "https://your-domain.com/up" || echo 0)

if [[ "$HTTP_STATUS" == "200" ]]; then
    ok "Health check passed (HTTP ${HTTP_STATUS})"
else
    err "Health check FAILED (HTTP ${HTTP_STATUS}). Consider rolling back."
fi

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo "╔═══════════════════════════════════════════╗"
echo "║  ✅ Deployment complete: ${TIMESTAMP}  ║"
echo "╚═══════════════════════════════════════════╝"
echo ""

# ── Rollback helper (printed for reference) ───────────────────────────────────
PREVIOUS=$(ls -dt "${RELEASES_DIR}"/*/  | sed -n '2p' | tr -d '/')
log "💡 To rollback: ln -sfn ${PREVIOUS} ${CURRENT_LINK} && php artisan queue:restart"
