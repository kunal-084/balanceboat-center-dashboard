import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'resources/js/app.js',
            ],
            refresh: [
                'resources/views/**',
                'routes/**',
            ],
        }),
    ],

    build: {
        chunkSizeWarningLimit: 1000,
        rollupOptions: {
            output: {
                manualChunks: {
                    alpine: ['alpinejs', '@alpinejs/collapse', '@alpinejs/focus', '@alpinejs/persist'],
                    charts: ['chart.js'],
                    datepicker: ['flatpickr'],
                    select: ['tom-select'],
                },
            },
        },
    },

    optimizeDeps: {
        include: ['alpinejs', 'chart.js', 'flatpickr'],
    },
});
