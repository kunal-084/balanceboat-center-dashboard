<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('retreat_faqs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('experience_id');
            $table->text('question');
            $table->longText('answer');
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_published')->default(true);
            $table->timestamps();

            $table->foreign('experience_id')->references('id')->on('experiences')->onDelete('cascade');
            $table->index(['experience_id', 'is_published', 'sort_order'], 'idx_faq_exp');
        });

        Schema::create('retreat_benefits', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('experience_id');
            $table->string('benefit', 500);
            $table->string('icon', 100)->nullable()->comment('FontAwesome class');
            $table->string('category', 50)->nullable()->comment('physical, mental, spiritual, social');
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();

            $table->foreign('experience_id')->references('id')->on('experiences')->onDelete('cascade');
            $table->index(['experience_id', 'sort_order'], 'idx_benefit_exp_sort');
        });

        Schema::create('retreat_itinerary_days', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('experience_id');
            $table->unsignedSmallInteger('day_number');
            $table->string('title', 255)->nullable();
            $table->text('description')->nullable();
            $table->string('theme', 100)->nullable()->comment('Arrival, Detox, Integration, etc.');
            $table->timestamps();

            $table->foreign('experience_id')->references('id')->on('experiences')->onDelete('cascade');
            $table->unique(['experience_id', 'day_number'], 'uq_itinerary_day');
        });

        Schema::create('retreat_itinerary_sessions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('day_id');
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->string('activity', 255);
            $table->text('description')->nullable();
            $table->enum('session_type', [
                'yoga', 'meditation', 'breathwork', 'therapy', 'consultation',
                'meal', 'breakfast', 'lunch', 'dinner',
                'excursion', 'lecture', 'workshop', 'free_time', 'arrival', 'departure', 'other',
            ])->default('other');
            $table->string('location', 200)->nullable()->comment('Yoga Shala, Dining Hall, etc.');
            $table->string('facilitator', 200)->nullable();
            $table->boolean('is_optional')->default(false);
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();

            $table->foreign('day_id')->references('id')->on('retreat_itinerary_days')->onDelete('cascade');
            $table->index(['day_id', 'sort_order'], 'idx_session_day_sort');
        });

        Schema::create('center_reviews', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->unsignedBigInteger('experience_id')->nullable()->index();
            $table->unsignedBigInteger('booking_id')->nullable()->unique();
            $table->unsignedInteger('user_id')->nullable()->index();
            $table->string('reviewer_name', 200)->nullable();
            $table->string('reviewer_email', 200)->nullable();
            $table->string('reviewer_country', 100)->nullable();
            $table->decimal('overall_rating', 3, 1);
            $table->decimal('accommodation_rating', 3, 1)->nullable();
            $table->decimal('food_rating', 3, 1)->nullable();
            $table->decimal('teacher_rating', 3, 1)->nullable();
            $table->decimal('value_rating', 3, 1)->nullable();
            $table->decimal('cleanliness_rating', 3, 1)->nullable();
            $table->string('title', 300)->nullable();
            $table->longText('body')->nullable();
            $table->enum('status', ['pending', 'approved', 'rejected', 'flagged'])
                  ->default('pending')->index();
            $table->string('rejection_reason', 500)->nullable();
            $table->enum('source', ['platform', 'google', 'trustpilot', 'manual'])
                  ->default('platform')->index();
            $table->string('external_id', 200)->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->unsignedInteger('approved_by')->nullable();
            $table->boolean('is_verified_guest')->default(false);
            $table->boolean('is_featured')->default(false);
            $table->timestamps();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->foreign('experience_id')->references('id')->on('experiences')->onDelete('set null');
            $table->index(['center_id', 'status', 'overall_rating'], 'idx_review_center_status');
        });

        Schema::create('review_responses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('review_id')->unique();
            $table->unsignedInteger('responded_by');
            $table->longText('response');
            $table->timestamp('responded_at')->nullable();
            $table->timestamps();

            $table->foreign('review_id')->references('id')->on('center_reviews')->onDelete('cascade');
        });

        Schema::create('seo_metadata', function (Blueprint $table) {
            $table->id();
            $table->string('seoable_type', 200)->index();
            $table->unsignedBigInteger('seoable_id')->index();
            $table->string('title', 160)->nullable();
            $table->text('description')->nullable();
            $table->text('keywords')->nullable();
            $table->string('og_title', 200)->nullable();
            $table->text('og_description')->nullable();
            $table->string('og_image', 500)->nullable();
            $table->string('twitter_title', 200)->nullable();
            $table->text('twitter_description')->nullable();
            $table->string('twitter_image', 500)->nullable();
            $table->string('canonical_url', 500)->nullable();
            $table->enum('robots', ['index,follow', 'noindex,nofollow', 'noindex,follow', 'index,nofollow'])
                  ->default('index,follow');
            $table->json('schema_org')->nullable()->comment('JSON-LD structured data');
            $table->timestamps();

            $table->unique(['seoable_type', 'seoable_id'], 'uq_seo_morphs');
        });

        Schema::create('payout_requests', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->string('reference', 30)->unique();
            $table->decimal('gross_amount', 14, 2);
            $table->decimal('commission_deducted', 14, 2)->default(0);
            $table->decimal('tax_deducted', 14, 2)->default(0);
            $table->decimal('net_payout', 14, 2);
            $table->string('currency', 10)->default('USD');
            $table->enum('status', ['pending', 'processing', 'completed', 'failed', 'cancelled'])
                  ->default('pending')->index();
            $table->enum('payment_method', ['bank_transfer', 'paypal', 'wise', 'stripe', 'other'])
                  ->default('bank_transfer');
            $table->json('bank_details')->nullable();
            $table->string('transaction_reference', 200)->nullable();
            $table->text('admin_notes')->nullable();
            $table->unsignedInteger('processed_by')->nullable();
            $table->timestamp('requested_at')->nullable();
            $table->timestamp('processed_at')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->date('period_from')->nullable();
            $table->date('period_to')->nullable();
            $table->json('included_booking_ids')->nullable();
            $table->timestamps();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->index(['center_id', 'status', 'created_at'], 'idx_payout_center_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payout_requests');
        Schema::dropIfExists('seo_metadata');
        Schema::dropIfExists('review_responses');
        Schema::dropIfExists('center_reviews');
        Schema::dropIfExists('retreat_itinerary_sessions');
        Schema::dropIfExists('retreat_itinerary_days');
        Schema::dropIfExists('retreat_benefits');
        Schema::dropIfExists('retreat_faqs');
    }
};
