<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Extend bookings
        Schema::table('bookings', function (Blueprint $table) {
            $table->string('booking_reference', 20)->nullable()->unique()->after('id');
            $table->enum('stage', [
                'inquiry', 'qualified', 'proposal_sent', 'confirmed',
                'checked_in', 'completed', 'cancelled', 'refunded',
            ])->default('inquiry')->after('order_status')->index();
            $table->unsignedSmallInteger('guest_count')->default(1)->after('stage');
            $table->unsignedBigInteger('assigned_staff_id')->nullable()->after('user_id');
            $table->unsignedBigInteger('promo_code_id')->nullable()->after('assigned_staff_id');
            $table->timestamp('check_in_at')->nullable()->after('promo_code_id');
            $table->timestamp('check_out_at')->nullable()->after('check_in_at');
            $table->text('internal_notes')->nullable()->after('check_out_at');
            $table->string('cancellation_reason', 500)->nullable()->after('internal_notes');
            $table->timestamp('cancelled_at')->nullable()->after('cancellation_reason');
            $table->timestamp('deleted_at')->nullable()->after('updated_at');

            $table->index(['stage', 'arrival_date'], 'idx_booking_stage_date');
            $table->index(['experience_id', 'stage'], 'idx_booking_exp_stage');
        });

        // Extend inquiries
        Schema::table('inquiries', function (Blueprint $table) {
            $table->enum('pipeline_stage', [
                'new', 'contacted', 'qualified', 'proposal',
                'negotiating', 'won', 'lost',
            ])->default('new')->after('note')->index();
            $table->unsignedInteger('assigned_to')->nullable()->after('pipeline_stage');
            $table->unsignedBigInteger('center_id')->nullable()->after('assigned_to');
            $table->unsignedBigInteger('converted_booking_id')->nullable()->after('center_id');
            $table->timestamp('follow_up_at')->nullable()->after('converted_booking_id')->index();
            $table->string('lost_reason', 500)->nullable()->after('follow_up_at');
            $table->timestamp('last_contacted_at')->nullable()->after('lost_reason');
            $table->unsignedTinyInteger('contact_attempts')->default(0)->after('last_contacted_at');
            $table->unsignedSmallInteger('group_size')->nullable()->after('contact_attempts');
            $table->string('utm_source', 100)->nullable()->after('source');
            $table->string('utm_medium', 100)->nullable()->after('utm_source');
            $table->string('utm_campaign', 200)->nullable()->after('utm_medium');
            $table->timestamp('deleted_at')->nullable()->after('updated_at');

            $table->index(['pipeline_stage', 'center_id'], 'idx_inquiry_pipeline_center');
        });

        // Extend teachers
        Schema::table('teachers', function (Blueprint $table) {
            $table->unsignedInteger('user_id')->nullable()->after('id')->unique();
            $table->decimal('hourly_rate', 10, 2)->nullable()->after('currently_working_with');
            $table->string('rate_currency', 10)->default('USD')->after('hourly_rate');
            $table->json('languages')->nullable()->after('rate_currency');
            $table->string('nationality', 100)->nullable()->after('languages');
            $table->string('website_url', 250)->nullable()->after('nationality');
            $table->string('instagram_url', 250)->nullable()->after('website_url');
            $table->string('facebook_url', 250)->nullable()->after('instagram_url');
            $table->string('youtube_url', 250)->nullable()->after('facebook_url');
            $table->enum('status', ['active', 'inactive', 'pending', 'suspended'])
                  ->default('active')->after('youtube_url')->index();
            $table->boolean('is_featured')->default(false)->after('status')->index();
            $table->boolean('is_verified')->default(false)->after('is_featured');
            $table->timestamp('verified_at')->nullable()->after('is_verified');
            $table->decimal('average_rating', 3, 1)->nullable()->after('verified_at');
            $table->unsignedInteger('total_reviews')->default(0)->after('average_rating');
            $table->timestamp('deleted_at')->nullable()->after('updated_at');
        });

        // Extend experiences
        Schema::table('experiences', function (Blueprint $table) {
            $table->enum('publish_status', ['draft', 'published', 'archived', 'paused'])
                  ->default('draft')->after('is_draft')->index();
            $table->unsignedSmallInteger('duration_nights')->nullable()->after('duration');
            $table->string('skill_level_normalized', 50)->nullable()->after('skill_level')
                  ->comment('all_levels, beginner, intermediate, advanced');
            $table->boolean('is_featured')->default(false)->after('featured_experiences')->index();
            $table->decimal('average_rating', 3, 1)->nullable()->after('is_featured');
            $table->unsignedInteger('review_count')->default(0)->after('average_rating');
            $table->unsignedInteger('view_count')->default(0)->after('review_count');
            $table->unsignedInteger('booking_count')->default(0)->after('view_count');
            $table->timestamp('published_at')->nullable()->after('booking_count');
            $table->timestamp('deleted_at')->nullable()->after('updated_at');

            $table->index(['center_id', 'publish_status'], 'idx_exp_center_status');
            $table->index(['publish_status', 'is_featured'], 'idx_exp_status_featured');
        });
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn([
                'booking_reference', 'stage', 'guest_count', 'assigned_staff_id',
                'promo_code_id', 'check_in_at', 'check_out_at',
                'internal_notes', 'cancellation_reason', 'cancelled_at', 'deleted_at',
            ]);
        });

        Schema::table('inquiries', function (Blueprint $table) {
            $table->dropColumn([
                'pipeline_stage', 'assigned_to', 'center_id', 'converted_booking_id',
                'follow_up_at', 'lost_reason', 'last_contacted_at', 'contact_attempts',
                'group_size', 'utm_source', 'utm_medium', 'utm_campaign', 'deleted_at',
            ]);
        });

        Schema::table('teachers', function (Blueprint $table) {
            $table->dropColumn([
                'user_id', 'hourly_rate', 'rate_currency', 'languages', 'nationality',
                'website_url', 'instagram_url', 'facebook_url', 'youtube_url',
                'status', 'is_featured', 'is_verified', 'verified_at',
                'average_rating', 'total_reviews', 'deleted_at',
            ]);
        });

        Schema::table('experiences', function (Blueprint $table) {
            $table->dropColumn([
                'publish_status', 'duration_nights', 'skill_level_normalized',
                'is_featured', 'average_rating', 'review_count',
                'view_count', 'booking_count', 'published_at', 'deleted_at',
            ]);
        });
    }
};
