<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_plans', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('slug', 120)->unique();
            $table->text('description')->nullable();
            $table->decimal('monthly_price', 10, 2)->default(0);
            $table->decimal('annual_price', 10, 2)->default(0);
            $table->decimal('commission_rate', 5, 2)->default(10.00)
                  ->comment('Platform commission percentage on bookings');
            $table->unsignedSmallInteger('max_retreats')->nullable()
                  ->comment('NULL = unlimited');
            $table->unsignedSmallInteger('max_staff')->nullable();
            $table->unsignedSmallInteger('max_accommodations')->nullable();
            $table->boolean('ai_enabled')->default(false);
            $table->boolean('analytics_enabled')->default(false);
            $table->boolean('automation_enabled')->default(false);
            $table->boolean('whatsapp_enabled')->default(false);
            $table->boolean('api_access')->default(false);
            $table->boolean('custom_domain')->default(false);
            $table->boolean('priority_support')->default(false);
            $table->json('features')->nullable()->comment('Array of feature keys included');
            $table->unsignedSmallInteger('trial_days')->default(14);
            $table->boolean('is_active')->default(true)->index();
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();

            $table->index(['is_active', 'sort_order'], 'idx_plans_active_sort');
        });

        Schema::create('center_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id');
            $table->unsignedBigInteger('plan_id');
            $table->enum('status', ['trialing', 'active', 'past_due', 'cancelled', 'expired'])
                  ->default('trialing')->index();
            $table->enum('billing_cycle', ['monthly', 'annual'])->default('monthly');
            $table->timestamp('trial_ends_at')->nullable();
            $table->timestamp('current_period_start')->nullable();
            $table->timestamp('current_period_end')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->string('stripe_subscription_id', 255)->nullable()->unique();
            $table->string('stripe_customer_id', 255)->nullable();
            $table->decimal('amount_paid', 10, 2)->nullable();
            $table->string('currency', 10)->default('USD');
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->foreign('plan_id')->references('id')->on('subscription_plans')->onDelete('restrict');
            $table->index(['center_id', 'status'], 'idx_sub_center_status');
        });

        Schema::create('system_settings', function (Blueprint $table) {
            $table->id();
            $table->string('key', 200)->unique();
            $table->longText('value')->nullable();
            $table->string('group', 50)->default('general')->index();
            $table->enum('type', ['string', 'boolean', 'integer', 'float', 'json', 'array'])
                  ->default('string');
            $table->string('label', 200)->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_public')->default(false)
                  ->comment('Can be exposed to frontend');
            $table->timestamps();
        });

        Schema::create('user_preferences', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id')->unique();
            $table->string('timezone', 100)->default('UTC');
            $table->string('locale', 10)->default('en');
            $table->string('currency', 10)->default('USD');
            $table->string('date_format', 30)->default('Y-m-d');
            $table->boolean('email_notifications')->default(true);
            $table->boolean('whatsapp_notifications')->default(false);
            $table->boolean('sms_notifications')->default(false);
            $table->boolean('browser_notifications')->default(true);
            $table->json('notification_types')->nullable()
                  ->comment('Which notification types are enabled');
            $table->json('dashboard_widgets')->nullable()
                  ->comment('Widget layout preferences');
            $table->json('table_columns')->nullable()
                  ->comment('Visible columns per table');
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });

        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id')->nullable();
            $table->string('user_name', 200)->nullable()->comment('Snapshot of user name');
            $table->string('user_email', 200)->nullable()->comment('Snapshot of user email');
            $table->string('event', 50)->index()
                  ->comment('created, updated, deleted, login, logout, export, import, published');
            $table->string('auditable_type', 200)->index();
            $table->unsignedBigInteger('auditable_id')->index();
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->string('url', 2000)->nullable();
            $table->string('http_method', 10)->nullable();
            $table->unsignedBigInteger('center_id')->nullable()->index();
            $table->text('tags')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['user_id', 'created_at'], 'idx_audit_user_date');
            $table->index(['auditable_type', 'auditable_id'], 'idx_audit_morphs');
            $table->index(['center_id', 'created_at'], 'idx_audit_center_date');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('user_preferences');
        Schema::dropIfExists('system_settings');
        Schema::dropIfExists('center_subscriptions');
        Schema::dropIfExists('subscription_plans');
    }
};
