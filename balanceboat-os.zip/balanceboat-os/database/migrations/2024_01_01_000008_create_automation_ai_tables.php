<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('email_templates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->nullable()->index();
            $table->string('name', 200);
            $table->string('slug', 220)->index();
            $table->string('subject', 500);
            $table->longText('body_html');
            $table->longText('body_text')->nullable();
            $table->json('variables')->nullable();
            $table->string('category', 100)->default('transactional');
            $table->boolean('is_active')->default(true)->index();
            $table->boolean('is_system')->default(false);
            $table->timestamps();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
        });

        Schema::create('whatsapp_templates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->nullable()->index();
            $table->string('name', 200);
            $table->string('slug', 220)->index();
            $table->string('whatsapp_template_name', 200)->nullable();
            $table->string('language_code', 10)->default('en');
            $table->longText('body');
            $table->json('variables')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->boolean('is_approved')->default(false)->index();
            $table->timestamps();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
        });

        Schema::create('automation_rules', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->string('name', 200);
            $table->text('description')->nullable();
            $table->string('trigger_event', 200)->index();
            $table->json('trigger_conditions')->nullable();
            $table->enum('action_type', ['email', 'whatsapp', 'sms', 'webhook', 'internal_task']);
            $table->unsignedBigInteger('email_template_id')->nullable();
            $table->unsignedBigInteger('whatsapp_template_id')->nullable();
            $table->json('action_config')->nullable();
            $table->string('delay_unit', 20)->default('hours');
            $table->unsignedSmallInteger('delay_value')->default(0);
            $table->boolean('is_active')->default(true)->index();
            $table->unsignedInteger('execution_count')->default(0);
            $table->timestamp('last_executed_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->foreign('email_template_id')->references('id')->on('email_templates')->onDelete('set null');
            $table->index(['center_id', 'trigger_event', 'is_active'], 'idx_auto_trigger');
        });

        Schema::create('automation_executions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('automation_rule_id');
            $table->string('trigger_event', 200);
            $table->json('trigger_data')->nullable();
            $table->enum('status', ['pending', 'running', 'completed', 'failed', 'skipped'])
                  ->default('pending')->index();
            $table->text('error_message')->nullable();
            $table->json('result_data')->nullable();
            $table->timestamp('scheduled_at')->nullable();
            $table->timestamp('executed_at')->nullable();
            $table->timestamps();

            $table->foreign('automation_rule_id')->references('id')->on('automation_rules')->onDelete('cascade');
            $table->index(['automation_rule_id', 'status', 'scheduled_at'], 'idx_exec_rule_status');
        });

        Schema::create('ai_recommendations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->unsignedBigInteger('experience_id')->nullable()->index();
            $table->enum('type', [
                'pricing', 'content', 'seo', 'occupancy',
                'demand_forecast', 'early_bird', 'last_minute', 'marketing', 'operational',
            ])->index();
            $table->string('title', 300);
            $table->longText('recommendation');
            $table->decimal('confidence_score', 5, 2)->nullable();
            $table->decimal('estimated_impact_pct', 5, 2)->nullable();
            $table->json('supporting_data')->nullable();
            $table->json('action_payload')->nullable();
            $table->enum('status', ['active', 'applied', 'dismissed', 'expired'])
                  ->default('active')->index();
            $table->timestamp('applied_at')->nullable();
            $table->unsignedInteger('applied_by')->nullable();
            $table->timestamp('dismissed_at')->nullable();
            $table->unsignedInteger('dismissed_by')->nullable();
            $table->timestamp('expires_at')->nullable()->index();
            $table->string('ai_model', 100)->nullable();
            $table->timestamps();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->index(['center_id', 'type', 'status'], 'idx_ai_rec_center_type');
        });

        Schema::create('notifications', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type');
            $table->morphs('notifiable');
            $table->text('data');
            $table->timestamp('read_at')->nullable();
            $table->timestamps();

            $table->index(['notifiable_type', 'notifiable_id', 'read_at'], 'idx_notif_morphs_read');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('ai_recommendations');
        Schema::dropIfExists('automation_executions');
        Schema::dropIfExists('automation_rules');
        Schema::dropIfExists('whatsapp_templates');
        Schema::dropIfExists('email_templates');
    }
};
