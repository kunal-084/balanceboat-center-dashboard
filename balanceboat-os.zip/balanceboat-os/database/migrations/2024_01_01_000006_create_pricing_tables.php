<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pricing_rules', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->unsignedBigInteger('experience_id')->nullable()->index()
                  ->comment('NULL = applies to all center retreats');
            $table->unsignedBigInteger('accommodation_id')->nullable()->index();
            $table->string('name', 200);
            $table->text('description')->nullable();
            $table->enum('rule_type', [
                'early_bird',
                'last_minute',
                'seasonal_peak',
                'seasonal_off',
                'occupancy_based',
                'duration_based',
                'group_discount',
                'repeat_guest',
                'custom',
            ])->index();
            $table->enum('discount_type', ['percentage', 'fixed'])->default('percentage');
            $table->decimal('discount_value', 10, 2);
            $table->decimal('min_price_cap', 10, 2)->nullable()
                  ->comment('Price cannot drop below this after discount');
            $table->unsignedSmallInteger('days_before')->nullable()
                  ->comment('For early_bird / last_minute');
            $table->unsignedTinyInteger('occupancy_threshold_pct')->nullable()
                  ->comment('For occupancy_based: trigger when occupancy >= this %');
            $table->unsignedSmallInteger('min_duration_nights')->nullable()
                  ->comment('For duration_based');
            $table->unsignedTinyInteger('min_group_size')->nullable()
                  ->comment('For group_discount');
            $table->date('start_date')->nullable()->index();
            $table->date('end_date')->nullable()->index();
            $table->unsignedTinyInteger('priority')->default(0)
                  ->comment('Higher = applied first when stacking');
            $table->boolean('is_stackable')->default(false)
                  ->comment('Can combine with other discounts?');
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->foreign('experience_id')->references('id')->on('experiences')->onDelete('cascade');
            $table->index(['experience_id', 'rule_type', 'is_active', 'priority'], 'idx_pricing_rule_full');
        });

        Schema::create('promo_codes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->unsignedInteger('created_by')->nullable();
            $table->string('code', 50)->unique()->index();
            $table->string('description', 255)->nullable();
            $table->enum('discount_type', ['percentage', 'fixed'])->default('percentage');
            $table->decimal('discount_value', 10, 2);
            $table->decimal('min_booking_amount', 12, 2)->nullable();
            $table->decimal('max_discount_cap', 12, 2)->nullable();
            $table->unsignedInteger('max_uses')->nullable()->comment('NULL = unlimited');
            $table->unsignedTinyInteger('max_uses_per_user')->default(1);
            $table->unsignedInteger('used_count')->default(0);
            $table->date('valid_from')->nullable()->index();
            $table->date('valid_until')->nullable()->index();
            $table->boolean('applies_to_all')->default(true);
            $table->json('applicable_experience_ids')->nullable();
            $table->json('applicable_category_ids')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->index(['center_id', 'is_active', 'valid_until'], 'idx_promo_center');
        });

        Schema::create('coupon_redemptions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('promo_code_id');
            $table->unsignedBigInteger('booking_id');
            $table->unsignedInteger('user_id')->nullable();
            $table->decimal('original_amount', 12, 2);
            $table->decimal('discount_applied', 12, 2);
            $table->decimal('final_amount', 12, 2);
            $table->timestamps();

            $table->foreign('promo_code_id')->references('id')->on('promo_codes')->onDelete('cascade');
            $table->foreign('booking_id')->references('id')->on('bookings')->onDelete('cascade');
            $table->unique(['promo_code_id', 'booking_id'], 'uq_promo_booking');
            $table->index(['user_id', 'promo_code_id'], 'idx_user_promo');
        });

        Schema::create('availability_calendar', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('experience_id')->nullable()->index();
            $table->unsignedBigInteger('accommodation_id')->nullable()->index();
            $table->date('calendar_date')->index();
            $table->unsignedSmallInteger('total_units')->default(0);
            $table->unsignedSmallInteger('available_units')->default(0);
            $table->unsignedSmallInteger('booked_units')->default(0);
            $table->unsignedSmallInteger('blocked_units')->default(0);
            $table->enum('status', ['open', 'closed', 'blocked', 'sold_out'])->default('open')->index();
            $table->decimal('override_price', 12, 2)->nullable()
                  ->comment('Override price for specific date');
            $table->string('block_reason', 255)->nullable();
            $table->timestamps();

            $table->foreign('experience_id')->references('id')->on('experiences')->onDelete('cascade');
            $table->index(['experience_id', 'calendar_date', 'status'], 'idx_cal_exp_date');
            $table->index(['accommodation_id', 'calendar_date'], 'idx_cal_acc_date');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('availability_calendar');
        Schema::dropIfExists('coupon_redemptions');
        Schema::dropIfExists('promo_codes');
        Schema::dropIfExists('pricing_rules');
    }
};
