<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('centers', function (Blueprint $table) {
            $table->string('timezone', 100)->nullable()->after('country');
            $table->string('currency_code', 10)->default('USD')->after('timezone');
            $table->enum('status', ['pending', 'active', 'suspended', 'archived'])
                  ->default('pending')->after('is_draft')->index();
            $table->timestamp('verified_at')->nullable()->after('status');
            $table->unsignedBigInteger('subscription_plan_id')->nullable()->after('user_id');
            $table->timestamp('trial_ends_at')->nullable()->after('subscription_plan_id');
            $table->string('twitter_url', 250)->nullable()->after('instagram_url');
            $table->string('youtube_url', 250)->nullable()->after('twitter_url');
            $table->string('linkedin_url', 250)->nullable()->after('youtube_url');
            $table->string('tiktok_url', 250)->nullable()->after('linkedin_url');
            $table->json('operating_hours')->nullable()->comment('JSON: {mon:{open:09:00,close:18:00}}');
            $table->string('tax_id', 100)->nullable();
            $table->string('registration_number', 100)->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('state', 100)->nullable();
            $table->string('postal_code', 20)->nullable();
            $table->unsignedSmallInteger('number_of_staff')->default(0);
            $table->boolean('is_featured')->default(false)->index();

            $table->index(['status', 'is_draft'], 'idx_centers_status');
            $table->index(['country', 'city'], 'idx_centers_location');
            $table->index(['latitude', 'longitude'], 'idx_centers_geo');
        });
    }

    public function down(): void
    {
        Schema::table('centers', function (Blueprint $table) {
            $table->dropColumn([
                'timezone', 'currency_code', 'status', 'verified_at',
                'subscription_plan_id', 'trial_ends_at',
                'twitter_url', 'youtube_url', 'linkedin_url', 'tiktok_url',
                'operating_hours', 'tax_id', 'registration_number',
                'latitude', 'longitude', 'state', 'postal_code',
                'number_of_staff', 'is_featured',
            ]);
        });
    }
};
