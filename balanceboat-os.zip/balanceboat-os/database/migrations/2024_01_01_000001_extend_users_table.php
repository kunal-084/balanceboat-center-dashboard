<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->unsignedBigInteger('center_id')->nullable()->after('id');
            $table->string('center_role', 50)->nullable()->after('center_id')
                  ->comment('owner, manager, staff, teacher, accountant');
            $table->boolean('is_active')->default(true)->after('remember_token');
            $table->boolean('email_verified')->default(false)->after('is_active');
            $table->timestamp('email_verified_at')->nullable()->after('email_verified');
            $table->string('two_factor_secret', 255)->nullable()->after('email_verified_at');
            $table->text('two_factor_recovery_codes')->nullable()->after('two_factor_secret');
            $table->boolean('two_factor_enabled')->default(false)->after('two_factor_recovery_codes');
            $table->string('timezone', 100)->default('UTC')->after('two_factor_enabled');
            $table->string('locale', 10)->default('en')->after('timezone');
            $table->timestamp('last_login_at')->nullable()->after('locale');
            $table->string('last_login_ip', 45)->nullable()->after('last_login_at');
            $table->timestamp('deleted_at')->nullable()->after('updated_at');

            $table->index(['center_id', 'center_role'], 'idx_users_center');
            $table->index(['is_active', 'email_verified'], 'idx_users_status');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'center_id', 'center_role', 'is_active', 'email_verified',
                'email_verified_at', 'two_factor_secret', 'two_factor_recovery_codes',
                'two_factor_enabled', 'timezone', 'locale',
                'last_login_at', 'last_login_ip', 'deleted_at',
            ]);
        });
    }
};
