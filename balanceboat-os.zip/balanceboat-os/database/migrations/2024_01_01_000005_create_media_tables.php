<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('media_folders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->unsignedBigInteger('parent_id')->nullable()->index();
            $table->string('name', 200);
            $table->string('slug', 220);
            $table->text('description')->nullable();
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->foreign('parent_id')->references('id')->on('media_folders')->onDelete('set null');
            $table->unique(['center_id', 'parent_id', 'slug'], 'uq_folder_slug');
        });

        Schema::create('media_assets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('center_id')->index();
            $table->unsignedBigInteger('folder_id')->nullable()->index();
            $table->unsignedInteger('uploaded_by')->nullable();
            $table->string('mediable_type', 200)->nullable()->index();
            $table->unsignedBigInteger('mediable_id')->nullable()->index();
            $table->string('collection', 100)->default('default')
                  ->comment('gallery, featured, food, avatar, document');
            $table->string('filename', 255);
            $table->string('original_filename', 255)->nullable();
            $table->string('disk', 30)->default('s3');
            $table->string('path', 1000);
            $table->string('url', 1000)->nullable();
            $table->string('cdn_url', 1000)->nullable();
            $table->string('mime_type', 100);
            $table->enum('media_type', ['image', 'video', 'document', 'audio', 'other'])
                  ->default('image')->index();
            $table->unsignedBigInteger('size_bytes')->default(0);
            $table->unsignedSmallInteger('width')->nullable();
            $table->unsignedSmallInteger('height')->nullable();
            $table->unsignedInteger('duration_seconds')->nullable()->comment('For videos/audio');
            $table->string('alt_text', 500)->nullable();
            $table->string('caption', 1000)->nullable();
            $table->string('category', 100)->nullable()
                  ->comment('exterior, interior, food, therapy, yoga_hall, garden, pool, spa');
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_featured')->default(false)->index();
            $table->json('metadata')->nullable()->comment('EXIF, thumbnails, variants');
            $table->json('thumbnails')->nullable()->comment('Thumbnail URLs at different sizes');
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('center_id')->references('id')->on('centers')->onDelete('cascade');
            $table->foreign('folder_id')->references('id')->on('media_folders')->onDelete('set null');
            $table->index(['mediable_type', 'mediable_id', 'collection'], 'idx_media_morphs');
            $table->index(['center_id', 'media_type', 'collection'], 'idx_media_center_type');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('media_assets');
        Schema::dropIfExists('media_folders');
    }
};
