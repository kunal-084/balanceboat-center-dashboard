<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\EmailTemplate;

class EmailTemplateSeeder extends Seeder
{
    public function run(): void
    {
        $templates = [
            // ---- Booking Templates ----
            [
                'name'       => 'Booking Confirmed',
                'slug'       => 'booking-confirmed',
                'category'   => 'booking',
                'subject'    => 'Your booking is confirmed — {{retreat_name}}',
                'body_html'  => $this->bookingConfirmedHtml(),
                'body_text'  => $this->bookingConfirmedText(),
                'variables'  => ['guest_name', 'booking_reference', 'retreat_name', 'retreat_start_date', 'retreat_end_date', 'total_amount', 'currency', 'center_name', 'accommodation_name'],
                'is_active'  => true,
                'is_system'  => true,
            ],
            [
                'name'       => 'Booking Cancelled',
                'slug'       => 'booking-cancelled',
                'category'   => 'booking',
                'subject'    => 'Booking Cancellation — {{retreat_name}} ({{booking_reference}})',
                'body_html'  => $this->bookingCancelledHtml(),
                'body_text'  => 'Dear {{guest_name}}, your booking {{booking_reference}} for {{retreat_name}} has been cancelled. Refund: {{refund_amount}} {{currency}} within 5-7 business days.',
                'variables'  => ['guest_name', 'booking_reference', 'retreat_name', 'refund_amount', 'currency'],
                'is_active'  => true,
                'is_system'  => true,
            ],
            [
                'name'       => 'Check-In Reminder',
                'slug'       => 'check-in-reminder',
                'category'   => 'booking',
                'subject'    => 'Your retreat begins tomorrow — {{retreat_name}}',
                'body_html'  => $this->checkInReminderHtml(),
                'body_text'  => 'Dear {{guest_name}}, your retreat {{retreat_name}} begins tomorrow. Check-in at {{center_name}} at {{checkin_time}}. We\'re excited to welcome you.',
                'variables'  => ['guest_name', 'retreat_name', 'center_name', 'checkin_time', 'center_address'],
                'is_active'  => true,
                'is_system'  => false,
            ],
            [
                'name'       => 'Review Request',
                'slug'       => 'review-request',
                'category'   => 'review',
                'subject'    => 'How was your experience at {{center_name}}?',
                'body_html'  => $this->reviewRequestHtml(),
                'body_text'  => 'Dear {{guest_name}}, we hope you had a wonderful stay. Please take a moment to share your experience: {{review_link}}',
                'variables'  => ['guest_name', 'retreat_name', 'center_name', 'review_link'],
                'is_active'  => true,
                'is_system'  => false,
            ],
            [
                'name'       => 'Inquiry Received (Center)',
                'slug'       => 'inquiry-received-center',
                'category'   => 'inquiry',
                'subject'    => 'New inquiry received from {{inquiry_name}}',
                'body_html'  => $this->inquiryReceivedCenterHtml(),
                'body_text'  => 'You received a new inquiry from {{inquiry_name}} ({{inquiry_email}}) regarding {{retreat_name}}. Message: {{inquiry_message}}',
                'variables'  => ['inquiry_name', 'inquiry_email', 'retreat_name', 'inquiry_message', 'dashboard_link'],
                'is_active'  => true,
                'is_system'  => true,
            ],
            [
                'name'       => 'Inquiry Received (Guest)',
                'slug'       => 'inquiry-received-guest',
                'category'   => 'inquiry',
                'subject'    => 'We received your inquiry — {{retreat_name}}',
                'body_html'  => $this->inquiryReceivedGuestHtml(),
                'body_text'  => 'Dear {{inquiry_name}}, thank you for your interest in {{retreat_name}} at {{center_name}}. We\'ll be in touch within 24 hours.',
                'variables'  => ['inquiry_name', 'retreat_name', 'center_name'],
                'is_active'  => true,
                'is_system'  => true,
            ],
            [
                'name'       => 'Team Invitation',
                'slug'       => 'team-invitation',
                'category'   => 'auth',
                'subject'    => 'You\'ve been invited to join {{center_name}} on {{platform_name}}',
                'body_html'  => $this->teamInvitationHtml(),
                'body_text'  => 'You\'ve been invited to join {{center_name}} on {{platform_name}} as {{role}}. Accept invitation: {{invitation_link}}',
                'variables'  => ['invitee_name', 'center_name', 'inviter_name', 'role', 'invitation_link', 'platform_name'],
                'is_active'  => true,
                'is_system'  => true,
            ],
            [
                'name'       => 'Password Reset',
                'slug'       => 'password-reset',
                'category'   => 'auth',
                'subject'    => 'Reset your {{platform_name}} password',
                'body_html'  => $this->passwordResetHtml(),
                'body_text'  => 'Hi {{user_name}}, click to reset your password: {{reset_link}} (expires in 60 minutes)',
                'variables'  => ['user_name', 'reset_link', 'platform_name'],
                'is_active'  => true,
                'is_system'  => true,
            ],
            [
                'name'       => 'Payout Processed',
                'slug'       => 'payout-processed',
                'category'   => 'finance',
                'subject'    => 'Payout of {{amount}} {{currency}} has been processed',
                'body_html'  => $this->payoutProcessedHtml(),
                'body_text'  => 'Hi {{user_name}}, your payout of {{amount}} {{currency}} has been processed and should arrive within 3-5 business days.',
                'variables'  => ['user_name', 'amount', 'currency', 'period', 'bank_last4'],
                'is_active'  => true,
                'is_system'  => true,
            ],
        ];

        foreach ($templates as $template) {
            EmailTemplate::updateOrCreate(
                ['slug' => $template['slug']],
                $template
            );
        }

        $this->command->info('✅ Email templates seeded.');
    }

    private function bookingConfirmedHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body { font-family: 'Georgia', serif; background: #f5f3ff; margin: 0; padding: 0; }
  .wrapper { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; overflow: hidden; }
  .header { background: linear-gradient(135deg, #8b5cf6, #7c3aed); padding: 40px 32px; text-align: center; }
  .header h1 { color: #fff; font-size: 26px; margin: 0; }
  .header p { color: rgba(255,255,255,0.85); margin: 8px 0 0; }
  .body { padding: 32px; }
  .detail-card { background: #f9f8ff; border-left: 4px solid #8b5cf6; border-radius: 8px; padding: 20px 24px; margin: 24px 0; }
  .detail-card h3 { color: #7c3aed; margin: 0 0 12px; font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; }
  .detail-row { display: flex; justify-content: space-between; margin: 8px 0; font-size: 15px; }
  .detail-label { color: #6b7280; }
  .detail-value { color: #111827; font-weight: 600; }
  .btn { display: block; width: max-content; margin: 24px auto; padding: 14px 32px; background: #8b5cf6; color: #fff; text-decoration: none; border-radius: 8px; font-size: 15px; }
  .footer { background: #f9f8ff; padding: 20px 32px; text-align: center; font-size: 13px; color: #9ca3af; }
</style>
</head>
<body>
<div class="wrapper">
  <div class="header">
    <h1>Booking Confirmed ✨</h1>
    <p>Your wellness journey is booked and awaiting you</p>
  </div>
  <div class="body">
    <p>Dear <strong>{{guest_name}}</strong>,</p>
    <p>Wonderful news! Your booking for <strong>{{retreat_name}}</strong> at <strong>{{center_name}}</strong> has been confirmed.</p>
    <div class="detail-card">
      <h3>Booking Details</h3>
      <div class="detail-row"><span class="detail-label">Booking Reference</span><span class="detail-value">{{booking_reference}}</span></div>
      <div class="detail-row"><span class="detail-label">Retreat</span><span class="detail-value">{{retreat_name}}</span></div>
      <div class="detail-row"><span class="detail-label">Check-in</span><span class="detail-value">{{retreat_start_date}}</span></div>
      <div class="detail-row"><span class="detail-label">Check-out</span><span class="detail-value">{{retreat_end_date}}</span></div>
      <div class="detail-row"><span class="detail-label">Accommodation</span><span class="detail-value">{{accommodation_name}}</span></div>
      <div class="detail-row"><span class="detail-label">Total Paid</span><span class="detail-value">{{currency}} {{total_amount}}</span></div>
    </div>
    <p>Please save your booking reference <strong>{{booking_reference}}</strong> for any correspondence.</p>
    <a class="btn" href="{{platform_url}}">View Your Booking</a>
    <p>We look forward to welcoming you. ✨</p>
    <p>Warm regards,<br><strong>{{center_name}} Team</strong></p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}} · {{support_email}}</div>
</div>
</body>
</html>
HTML;
    }

    private function bookingConfirmedText(): string
    {
        return "Dear {{guest_name}},\n\nYour booking for {{retreat_name}} at {{center_name}} is confirmed.\n\nBooking Reference: {{booking_reference}}\nCheck-in: {{retreat_start_date}}\nCheck-out: {{retreat_end_date}}\nTotal: {{currency}} {{total_amount}}\n\nWarm regards,\n{{center_name}} Team";
    }

    private function bookingCancelledHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f5f3ff;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#f59e0b,#d97706);padding:40px 32px;text-align:center}
.header h1{color:#fff;font-size:24px;margin:0}
.body{padding:32px}
.detail-card{background:#fffbeb;border-left:4px solid #f59e0b;border-radius:8px;padding:20px;margin:24px 0}
.footer{background:#f9f8ff;padding:20px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>Booking Cancelled</h1></div>
  <div class="body">
    <p>Dear <strong>{{guest_name}}</strong>,</p>
    <p>Your booking <strong>{{booking_reference}}</strong> for <strong>{{retreat_name}}</strong> has been cancelled.</p>
    <div class="detail-card">
      <p><strong>Refund Amount:</strong> {{currency}} {{refund_amount}}</p>
      <p>Refunds are processed within 5–7 business days.</p>
    </div>
    <p>We hope to welcome you on a future retreat.</p>
    <p>Warm regards,<br>{{center_name}} Team</p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function checkInReminderHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f0fdf4;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#22c55e,#16a34a);padding:40px 32px;text-align:center}
.header h1{color:#fff;font-size:24px;margin:0}
.body{padding:32px}
.highlight{background:#f0fdf4;border-radius:8px;padding:20px;margin:24px 0;border-left:4px solid #22c55e}
.footer{background:#f9f8ff;padding:20px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>Your Retreat Begins Tomorrow 🌿</h1></div>
  <div class="body">
    <p>Dear <strong>{{guest_name}}</strong>,</p>
    <p>We're thrilled to welcome you to <strong>{{retreat_name}}</strong> tomorrow.</p>
    <div class="highlight">
      <p><strong>Check-in:</strong> {{checkin_time}}</p>
      <p><strong>Location:</strong> {{center_name}}</p>
      <p><strong>Address:</strong> {{center_address}}</p>
    </div>
    <p>Please bring a valid photo ID and your booking reference <strong>{{booking_reference}}</strong>.</p>
    <p>With love and wellness,<br>{{center_name}} Team</p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function reviewRequestHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#fff7ed;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#fb923c,#f97316);padding:40px 32px;text-align:center}
.header h1{color:#fff;font-size:24px;margin:0}
.body{padding:32px;text-align:center}
.stars{font-size:40px;margin:16px 0;letter-spacing:4px}
.btn{display:inline-block;padding:14px 36px;background:#fb923c;color:#fff;text-decoration:none;border-radius:8px;font-size:16px;margin:16px 0}
.footer{background:#f9f8ff;padding:20px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>How Was Your Experience? 💫</h1></div>
  <div class="body">
    <p>Dear <strong>{{guest_name}}</strong>,</p>
    <p>Thank you for joining <strong>{{retreat_name}}</strong> at <strong>{{center_name}}</strong>. We hope it was a transformative experience.</p>
    <div class="stars">⭐⭐⭐⭐⭐</div>
    <p>Your feedback helps us grow and helps others find their path to wellness.</p>
    <a class="btn" href="{{review_link}}">Share Your Experience</a>
    <p>With gratitude,<br>{{center_name}} Team</p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function inquiryReceivedCenterHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f5f3ff;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:#7c3aed;padding:32px;text-align:center}
.header h1{color:#fff;font-size:22px;margin:0}
.body{padding:32px}
.msg-box{background:#f9f8ff;border-radius:8px;padding:20px;margin:20px 0;font-style:italic;color:#374151}
.btn{display:inline-block;padding:12px 28px;background:#8b5cf6;color:#fff;text-decoration:none;border-radius:8px}
.footer{background:#f9f8ff;padding:16px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>New Inquiry Received</h1></div>
  <div class="body">
    <p><strong>From:</strong> {{inquiry_name}} ({{inquiry_email}})</p>
    <p><strong>Retreat:</strong> {{retreat_name}}</p>
    <p><strong>Message:</strong></p>
    <div class="msg-box">{{inquiry_message}}</div>
    <a class="btn" href="{{dashboard_link}}">View in Dashboard</a>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function inquiryReceivedGuestHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f5f3ff;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#8b5cf6,#7c3aed);padding:40px 32px;text-align:center}
.header h1{color:#fff;font-size:24px;margin:0}
.body{padding:32px}
.footer{background:#f9f8ff;padding:16px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>We've Received Your Inquiry 🙏</h1></div>
  <div class="body">
    <p>Dear <strong>{{inquiry_name}}</strong>,</p>
    <p>Thank you for your interest in <strong>{{retreat_name}}</strong> at <strong>{{center_name}}</strong>.</p>
    <p>Our team will review your inquiry and get back to you within <strong>24 hours</strong>.</p>
    <p>Warm regards,<br>{{center_name}} Team</p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function teamInvitationHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f5f3ff;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#8b5cf6,#7c3aed);padding:40px 32px;text-align:center}
.header h1{color:#fff;font-size:24px;margin:0}
.body{padding:32px;text-align:center}
.btn{display:inline-block;padding:14px 36px;background:#8b5cf6;color:#fff;text-decoration:none;border-radius:8px;font-size:16px;margin:16px 0}
.footer{background:#f9f8ff;padding:16px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>You're Invited to {{center_name}} 🌿</h1></div>
  <div class="body">
    <p><strong>{{inviter_name}}</strong> has invited you to join <strong>{{center_name}}</strong> on <strong>{{platform_name}}</strong> as <strong>{{role}}</strong>.</p>
    <a class="btn" href="{{invitation_link}}">Accept Invitation</a>
    <p><small>This invitation expires in 48 hours.</small></p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function passwordResetHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f5f3ff;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:#7c3aed;padding:32px;text-align:center}
.header h1{color:#fff;font-size:22px;margin:0}
.body{padding:32px;text-align:center}
.btn{display:inline-block;padding:14px 36px;background:#8b5cf6;color:#fff;text-decoration:none;border-radius:8px;font-size:16px;margin:16px 0}
.footer{background:#f9f8ff;padding:16px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>Password Reset Request</h1></div>
  <div class="body">
    <p>Hi <strong>{{user_name}}</strong>,</p>
    <p>We received a request to reset your password for your <strong>{{platform_name}}</strong> account.</p>
    <a class="btn" href="{{reset_link}}">Reset Password</a>
    <p><small>This link expires in 60 minutes. If you didn't request this, please ignore this email.</small></p>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }

    private function payoutProcessedHtml(): string
    {
        return <<<'HTML'
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Georgia,serif;background:#f0fdf4;margin:0;padding:0}
.wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden}
.header{background:linear-gradient(135deg,#22c55e,#16a34a);padding:40px 32px;text-align:center}
.header h1{color:#fff;font-size:24px;margin:0}
.body{padding:32px}
.amount{font-size:40px;font-weight:700;color:#16a34a;text-align:center;margin:20px 0}
.detail-card{background:#f0fdf4;border-radius:8px;padding:20px;margin:20px 0}
.footer{background:#f9f8ff;padding:16px 32px;text-align:center;font-size:13px;color:#9ca3af}
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>Payout Processed 💚</h1></div>
  <div class="body">
    <p>Hi <strong>{{user_name}}</strong>,</p>
    <p>Your payout has been processed successfully.</p>
    <div class="amount">{{currency}} {{amount}}</div>
    <div class="detail-card">
      <p><strong>Period:</strong> {{period}}</p>
      <p><strong>Bank Account:</strong> ••••{{bank_last4}}</p>
      <p><strong>ETA:</strong> 3–5 business days</p>
    </div>
  </div>
  <div class="footer">© {{current_year}} {{platform_name}}</div>
</div>
</body></html>
HTML;
    }
}
