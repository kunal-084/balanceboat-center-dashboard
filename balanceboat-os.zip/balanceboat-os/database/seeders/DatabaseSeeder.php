<?php

// ============================================================
// database/seeders/DatabaseSeeder.php
// ============================================================

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolesAndPermissionsSeeder::class,
            SubscriptionPlanSeeder::class,
            SystemSettingsSeeder::class,
            EmailTemplateSeeder::class,
            WhatsAppTemplateSeeder::class,
            CategorySeeder::class,
            CurrencySeeder::class,
        ]);
    }
}
