<?php

// ============================================================
// database/seeders/SubscriptionPlanSeeder.php
// ============================================================

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SubscriptionPlan;

class SubscriptionPlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            [
                'name'                => 'Starter',
                'slug'                => 'starter',
                'description'         => 'Perfect for solo practitioners and small retreat centers.',
                'price_monthly'       => 29.00,
                'price_yearly'        => 290.00,
                'currency'            => 'USD',
                'trial_days'          => 14,
                'is_active'           => true,
                'features'            => [
                    'max_retreats'       => 5,
                    'max_accommodations' => 5,
                    'max_team_members'   => 2,
                    'media_storage_gb'   => 5,
                    'ai_credits'         => 50,
                    'analytics'          => 'basic',
                    'automation'         => false,
                    'whatsapp'           => false,
                    'api_access'         => false,
                    'priority_support'   => false,
                ],
            ],
            [
                'name'                => 'Growth',
                'slug'                => 'growth',
                'description'         => 'For growing wellness centers with multiple retreat programs.',
                'price_monthly'       => 89.00,
                'price_yearly'        => 890.00,
                'currency'            => 'USD',
                'trial_days'          => 14,
                'is_active'           => true,
                'is_popular'          => true,
                'features'            => [
                    'max_retreats'       => 25,
                    'max_accommodations' => 20,
                    'max_team_members'   => 10,
                    'media_storage_gb'   => 25,
                    'ai_credits'         => 300,
                    'analytics'          => 'advanced',
                    'automation'         => true,
                    'whatsapp'           => true,
                    'api_access'         => false,
                    'priority_support'   => false,
                ],
            ],
            [
                'name'                => 'Enterprise',
                'slug'                => 'enterprise',
                'description'         => 'Full platform for established retreat centers and resort chains.',
                'price_monthly'       => 249.00,
                'price_yearly'        => 2490.00,
                'currency'            => 'USD',
                'trial_days'          => 30,
                'is_active'           => true,
                'features'            => [
                    'max_retreats'       => -1,   // unlimited
                    'max_accommodations' => -1,
                    'max_team_members'   => -1,
                    'media_storage_gb'   => 200,
                    'ai_credits'         => -1,   // unlimited
                    'analytics'          => 'enterprise',
                    'automation'         => true,
                    'whatsapp'           => true,
                    'api_access'         => true,
                    'priority_support'   => true,
                    'custom_domain'      => true,
                    'dedicated_manager'  => true,
                ],
            ],
        ];

        foreach ($plans as $planData) {
            SubscriptionPlan::updateOrCreate(
                ['slug' => $planData['slug']],
                $planData
            );
        }

        $this->command->info('✅ Subscription plans seeded.');
    }
}
