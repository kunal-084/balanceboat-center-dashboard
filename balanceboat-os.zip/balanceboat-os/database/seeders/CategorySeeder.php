<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Yoga & Meditation',    'color' => '#8b5cf6', 'icon' => '🧘'],
            ['name' => 'Ayurveda',             'color' => '#22c55e', 'icon' => '🌿'],
            ['name' => 'Detox & Cleanse',      'color' => '#06b6d4', 'icon' => '💧'],
            ['name' => 'Mindfulness',          'color' => '#f59e0b', 'icon' => '🍃'],
            ['name' => 'Sound Healing',        'color' => '#ec4899', 'icon' => '🎵'],
            ['name' => 'Nature & Adventure',   'color' => '#16a34a', 'icon' => '🏔️'],
            ['name' => 'Spiritual & Healing',  'color' => '#7c3aed', 'icon' => '✨'],
            ['name' => 'Fitness & Wellness',   'color' => '#ef4444', 'icon' => '💪'],
            ['name' => 'Nutrition & Diet',     'color' => '#84cc16', 'icon' => '🥗'],
            ['name' => 'Art Therapy',          'color' => '#f97316', 'icon' => '🎨'],
            ['name' => 'Dance & Movement',     'color' => '#db2777', 'icon' => '💃'],
            ['name' => 'Surf & Wellness',      'color' => '#0ea5e9', 'icon' => '🏄'],
            ['name' => 'Qigong & Tai Chi',     'color' => '#65a30d', 'icon' => '☯️'],
            ['name' => 'Plant Medicine',       'color' => '#16a34a', 'icon' => '🌱'],
            ['name' => 'Cold Therapy',         'color' => '#0284c7', 'icon' => '❄️'],
        ];

        foreach ($categories as $cat) {
            DB::table('category')->updateOrInsert(
                ['name' => $cat['name']],
                [
                    'name'       => $cat['name'],
                    'slug'       => Str::slug($cat['name']),
                    'color'      => $cat['color'],
                    'icon'       => $cat['icon'],
                    'is_active'  => 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }

        $this->command->info('✅ Categories seeded.');
    }
}
