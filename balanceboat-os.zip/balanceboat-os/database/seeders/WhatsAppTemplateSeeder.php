<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class WhatsAppTemplateSeeder extends Seeder
{
    public function run(): void
    {
        $templates = [
            [
                'name'             => 'Booking Confirmed',
                'slug'             => 'booking-confirmed',
                'wa_template_name' => 'booking_confirmed',
                'language_code'    => 'en_US',
                'category'         => 'TRANSACTIONAL',
                'header_text'      => 'Booking Confirmed ✨',
                'body_text'        => 'Dear {{1}}, your booking for *{{2}}* is confirmed! 🎉\n\n📋 Booking Ref: *{{3}}*\n📅 Check-in: {{4}}\n🏡 Location: {{5}}\n\nWe look forward to welcoming you!',
                'is_active'        => true,
                'is_system'        => true,
            ],
            [
                'name'             => 'Retreat Reminder 24h',
                'slug'             => 'retreat-reminder-24h',
                'wa_template_name' => 'retreat_reminder_24h',
                'language_code'    => 'en_US',
                'category'         => 'TRANSACTIONAL',
                'header_text'      => 'Your Retreat Begins Tomorrow 🌿',
                'body_text'        => 'Hello {{1}}! Your retreat *{{2}}* starts tomorrow at {{3}}.\n\n📍 Location: {{4}}\n\nBring comfortable clothes and an open heart. See you soon! 🙏',
                'is_active'        => true,
                'is_system'        => false,
            ],
            [
                'name'             => 'Review Request',
                'slug'             => 'review-request',
                'wa_template_name' => 'review_request',
                'language_code'    => 'en_US',
                'category'         => 'MARKETING',
                'header_text'      => 'Share Your Experience 💫',
                'body_text'        => 'Dear {{1}}, thank you for joining *{{2}}*!\n\nWe\'d love to hear about your experience. Your feedback helps other wellness seekers find their path. 🌟\n\n👉 {{3}}',
                'is_active'        => true,
                'is_system'        => false,
            ],
            [
                'name'             => 'Inquiry Response',
                'slug'             => 'inquiry-response',
                'wa_template_name' => 'inquiry_response',
                'language_code'    => 'en_US',
                'category'         => 'TRANSACTIONAL',
                'header_text'      => 'We Received Your Inquiry 🙏',
                'body_text'        => 'Hello {{1}}, thank you for your interest in *{{2}}* at *{{3}}*.\n\nOur team will get back to you within 24 hours with more details.\n\nNamaste 🙏',
                'is_active'        => true,
                'is_system'        => true,
            ],
            [
                'name'             => 'Booking Cancelled',
                'slug'             => 'booking-cancelled',
                'wa_template_name' => 'booking_cancelled',
                'language_code'    => 'en_US',
                'category'         => 'TRANSACTIONAL',
                'header_text'      => 'Booking Cancellation',
                'body_text'        => 'Hello {{1}}, your booking *{{2}}* for *{{3}}* has been cancelled.\n\nRefund: *{{4}} {{5}}* will be processed in 5-7 business days.\n\nWe hope to see you on a future retreat. 🌿',
                'is_active'        => true,
                'is_system'        => true,
            ],
        ];

        foreach ($templates as $template) {
            DB::table('whatsapp_templates')->updateOrInsert(
                ['slug' => $template['slug']],
                array_merge($template, [
                    'created_at' => now(),
                    'updated_at' => now(),
                ])
            );
        }

        $this->command->info('✅ WhatsApp templates seeded.');
    }
}
