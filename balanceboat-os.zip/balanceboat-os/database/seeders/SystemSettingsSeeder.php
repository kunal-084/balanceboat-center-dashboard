<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SystemSetting;

class SystemSettingsSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            // Platform Identity
            ['key' => 'platform.name',             'value' => 'BalanceBoat', 'type' => 'string', 'group' => 'platform', 'is_public' => true],
            ['key' => 'platform.tagline',           'value' => 'Wellness Center Management OS', 'type' => 'string', 'group' => 'platform', 'is_public' => true],
            ['key' => 'platform.support_email',     'value' => 'support@balanceboat.com', 'type' => 'string', 'group' => 'platform', 'is_public' => true],
            ['key' => 'platform.support_phone',     'value' => '', 'type' => 'string', 'group' => 'platform', 'is_public' => false],
            ['key' => 'platform.logo_url',          'value' => '', 'type' => 'string', 'group' => 'platform', 'is_public' => true],
            ['key' => 'platform.favicon_url',       'value' => '', 'type' => 'string', 'group' => 'platform', 'is_public' => true],

            // Commission
            ['key' => 'billing.default_commission_rate', 'value' => '10', 'type' => 'float', 'group' => 'billing', 'is_public' => false],
            ['key' => 'billing.payment_gateway',    'value' => 'stripe', 'type' => 'string', 'group' => 'billing', 'is_public' => false],
            ['key' => 'billing.stripe_public_key',  'value' => '', 'type' => 'string', 'group' => 'billing', 'is_public' => true],
            ['key' => 'billing.currency_default',   'value' => 'USD', 'type' => 'string', 'group' => 'billing', 'is_public' => true],
            ['key' => 'billing.tax_rate',           'value' => '0', 'type' => 'float', 'group' => 'billing', 'is_public' => false],

            // Booking & Inquiries
            ['key' => 'bookings.auto_confirm',       'value' => '0', 'type' => 'boolean', 'group' => 'bookings', 'is_public' => false],
            ['key' => 'bookings.hold_duration_hours','value' => '24', 'type' => 'integer', 'group' => 'bookings', 'is_public' => false],
            ['key' => 'bookings.cancellation_window_hours', 'value' => '48', 'type' => 'integer', 'group' => 'bookings', 'is_public' => true],
            ['key' => 'inquiries.auto_reply',        'value' => '1', 'type' => 'boolean', 'group' => 'inquiries', 'is_public' => false],
            ['key' => 'inquiries.sla_hours',         'value' => '24', 'type' => 'integer', 'group' => 'inquiries', 'is_public' => false],

            // AI
            ['key' => 'ai.provider',                'value' => 'openai', 'type' => 'string', 'group' => 'ai', 'is_public' => false],
            ['key' => 'ai.openai_model',            'value' => 'gpt-4o', 'type' => 'string', 'group' => 'ai', 'is_public' => false],
            ['key' => 'ai.credits_per_generation',  'value' => '1', 'type' => 'integer', 'group' => 'ai', 'is_public' => false],

            // Media
            ['key' => 'media.max_image_size_mb',    'value' => '10', 'type' => 'integer', 'group' => 'media', 'is_public' => true],
            ['key' => 'media.auto_thumbnails',       'value' => '1', 'type' => 'boolean', 'group' => 'media', 'is_public' => false],
            ['key' => 'media.cdn_enabled',           'value' => '0', 'type' => 'boolean', 'group' => 'media', 'is_public' => false],

            // Security
            ['key' => 'security.mfa_required',       'value' => '0', 'type' => 'boolean', 'group' => 'security', 'is_public' => false],
            ['key' => 'security.session_timeout_min','value' => '120', 'type' => 'integer', 'group' => 'security', 'is_public' => false],
            ['key' => 'security.rate_limit_per_min', 'value' => '60', 'type' => 'integer', 'group' => 'security', 'is_public' => false],
            ['key' => 'security.audit_log_retention_days', 'value' => '365', 'type' => 'integer', 'group' => 'security', 'is_public' => false],

            // Onboarding
            ['key' => 'onboarding.welcome_video_url','value' => '', 'type' => 'string', 'group' => 'onboarding', 'is_public' => false],
            ['key' => 'onboarding.skip_allowed',    'value' => '0', 'type' => 'boolean', 'group' => 'onboarding', 'is_public' => false],

            // Analytics
            ['key' => 'analytics.ga_measurement_id','value' => '', 'type' => 'string', 'group' => 'analytics', 'is_public' => true],
            ['key' => 'analytics.gtm_container_id', 'value' => '', 'type' => 'string', 'group' => 'analytics', 'is_public' => true],
            ['key' => 'analytics.fb_pixel_id',      'value' => '', 'type' => 'string', 'group' => 'analytics', 'is_public' => true],

            // Localization
            ['key' => 'localization.timezone',       'value' => 'UTC', 'type' => 'string', 'group' => 'localization', 'is_public' => true],
            ['key' => 'localization.date_format',    'value' => 'D, d M Y', 'type' => 'string', 'group' => 'localization', 'is_public' => true],
            ['key' => 'localization.time_format',    'value' => 'g:i A', 'type' => 'string', 'group' => 'localization', 'is_public' => true],
        ];

        foreach ($settings as $setting) {
            SystemSetting::updateOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }

        $this->command->info('✅ System settings seeded.');
    }
}
