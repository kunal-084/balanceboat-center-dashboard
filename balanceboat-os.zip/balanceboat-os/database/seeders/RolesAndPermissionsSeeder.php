<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        // ----------------------------------------------------------------
        // PERMISSIONS — grouped by resource
        // ----------------------------------------------------------------

        $permissions = [
            // Centers
            'centers.view',       'centers.create',       'centers.edit',       'centers.delete',
            'centers.manage-all',

            // Retreats / Experiences
            'retreats.view',      'retreats.create',      'retreats.edit',      'retreats.delete',
            'retreats.publish',   'retreats.duplicate',   'retreats.archive',
            'retreats.manage-all',

            // Bookings
            'bookings.view',      'bookings.create',      'bookings.edit',      'bookings.delete',
            'bookings.confirm',   'bookings.cancel',      'bookings.check-in',  'bookings.check-out',
            'bookings.refund',    'bookings.assign-staff',
            'bookings.manage-all',

            // Inquiries
            'inquiries.view',     'inquiries.reply',      'inquiries.qualify',  'inquiries.convert',
            'inquiries.delete',

            // Teachers
            'teachers.view',      'teachers.create',      'teachers.edit',      'teachers.delete',

            // Accommodations
            'accommodations.view',      'accommodations.create',
            'accommodations.edit',      'accommodations.delete',

            // Pricing
            'pricing.view',       'pricing.manage',
            'promo-codes.view',   'promo-codes.manage',

            // Media
            'media.view',         'media.upload',         'media.delete',       'media.reorder',

            // Analytics
            'analytics.view',     'analytics.export',

            // Finance
            'finance.view',       'finance.manage',       'finance.payouts',
            'invoices.view',      'invoices.download',    'tax-reports.view',

            // AI
            'ai.view',            'ai.generate',          'ai.apply-recommendations',

            // Automations
            'automations.view',   'automations.manage',

            // Reviews
            'reviews.view',       'reviews.moderate',     'reviews.respond',

            // Settings
            'settings.view',      'settings.general',     'settings.team',
            'settings.billing',   'settings.security',    'settings.email-templates',

            // Subscriptions
            'subscriptions.view', 'subscriptions.manage',

            // Audit
            'audit-logs.view',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission, 'guard_name' => 'web']);
        }

        // ----------------------------------------------------------------
        // ROLES & PERMISSION ASSIGNMENTS
        // ----------------------------------------------------------------

        // 1. Super Admin — all permissions (handled by Gate::before in AuthServiceProvider)
        $superAdmin = Role::firstOrCreate(['name' => 'super-admin', 'guard_name' => 'web']);
        $superAdmin->syncPermissions(Permission::all());

        // 2. BalanceBoat Admin — platform management without billing
        $bbAdmin = Role::firstOrCreate(['name' => 'balanceboat-admin', 'guard_name' => 'web']);
        $bbAdmin->syncPermissions([
            'centers.view', 'centers.create', 'centers.edit', 'centers.manage-all',
            'retreats.view', 'retreats.manage-all',
            'bookings.view', 'bookings.manage-all',
            'inquiries.view',
            'teachers.view', 'teachers.create', 'teachers.edit',
            'accommodations.view',
            'pricing.view', 'pricing.manage', 'promo-codes.view', 'promo-codes.manage',
            'media.view', 'media.upload', 'media.delete',
            'analytics.view', 'analytics.export',
            'finance.view', 'finance.manage', 'finance.payouts',
            'invoices.view', 'invoices.download', 'tax-reports.view',
            'ai.view', 'ai.generate', 'ai.apply-recommendations',
            'automations.view', 'automations.manage',
            'reviews.view', 'reviews.moderate', 'reviews.respond',
            'settings.view', 'settings.general', 'settings.team', 'settings.email-templates',
            'subscriptions.view', 'subscriptions.manage',
            'audit-logs.view',
        ]);

        // 3. Center Owner — full center control
        $centerOwner = Role::firstOrCreate(['name' => 'center-owner', 'guard_name' => 'web']);
        $centerOwner->syncPermissions([
            'centers.view', 'centers.edit',
            'retreats.view', 'retreats.create', 'retreats.edit', 'retreats.delete',
            'retreats.publish', 'retreats.duplicate', 'retreats.archive',
            'bookings.view', 'bookings.create', 'bookings.edit',
            'bookings.confirm', 'bookings.cancel', 'bookings.check-in', 'bookings.check-out',
            'bookings.refund', 'bookings.assign-staff',
            'inquiries.view', 'inquiries.reply', 'inquiries.qualify',
            'inquiries.convert', 'inquiries.delete',
            'teachers.view', 'teachers.create', 'teachers.edit', 'teachers.delete',
            'accommodations.view', 'accommodations.create', 'accommodations.edit', 'accommodations.delete',
            'pricing.view', 'pricing.manage',
            'promo-codes.view', 'promo-codes.manage',
            'media.view', 'media.upload', 'media.delete', 'media.reorder',
            'analytics.view', 'analytics.export',
            'finance.view', 'finance.manage', 'finance.payouts',
            'invoices.view', 'invoices.download', 'tax-reports.view',
            'ai.view', 'ai.generate', 'ai.apply-recommendations',
            'automations.view', 'automations.manage',
            'reviews.view', 'reviews.moderate', 'reviews.respond',
            'settings.view', 'settings.general', 'settings.team',
            'settings.billing', 'settings.security', 'settings.email-templates',
            'subscriptions.view',
            'audit-logs.view',
        ]);

        // 4. Center Manager — operational management, no billing
        $centerManager = Role::firstOrCreate(['name' => 'center-manager', 'guard_name' => 'web']);
        $centerManager->syncPermissions([
            'centers.view',
            'retreats.view', 'retreats.create', 'retreats.edit',
            'retreats.publish', 'retreats.duplicate',
            'bookings.view', 'bookings.create', 'bookings.edit',
            'bookings.confirm', 'bookings.cancel', 'bookings.check-in', 'bookings.check-out',
            'bookings.assign-staff',
            'inquiries.view', 'inquiries.reply', 'inquiries.qualify', 'inquiries.convert',
            'teachers.view', 'teachers.create', 'teachers.edit',
            'accommodations.view', 'accommodations.edit',
            'pricing.view', 'pricing.manage',
            'promo-codes.view', 'promo-codes.manage',
            'media.view', 'media.upload', 'media.delete', 'media.reorder',
            'analytics.view', 'analytics.export',
            'finance.view',
            'invoices.view', 'invoices.download',
            'ai.view', 'ai.generate',
            'automations.view', 'automations.manage',
            'reviews.view', 'reviews.moderate', 'reviews.respond',
            'settings.view', 'settings.general', 'settings.email-templates',
        ]);

        // 5. Staff — front desk operations
        $staff = Role::firstOrCreate(['name' => 'staff', 'guard_name' => 'web']);
        $staff->syncPermissions([
            'centers.view',
            'retreats.view',
            'bookings.view', 'bookings.create', 'bookings.edit',
            'bookings.confirm', 'bookings.check-in', 'bookings.check-out',
            'inquiries.view', 'inquiries.reply',
            'teachers.view',
            'accommodations.view',
            'media.view', 'media.upload',
            'analytics.view',
            'invoices.view', 'invoices.download',
            'reviews.view',
            'settings.view',
        ]);

        // 6. Teacher — profile and retreat assignment only
        $teacher = Role::firstOrCreate(['name' => 'teacher', 'guard_name' => 'web']);
        $teacher->syncPermissions([
            'retreats.view',
            'bookings.view',
            'media.view', 'media.upload',
            'settings.view',
        ]);

        // 7. Accountant — finance-only access
        $accountant = Role::firstOrCreate(['name' => 'accountant', 'guard_name' => 'web']);
        $accountant->syncPermissions([
            'bookings.view',
            'analytics.view', 'analytics.export',
            'finance.view', 'finance.manage', 'finance.payouts',
            'invoices.view', 'invoices.download',
            'tax-reports.view',
            'settings.view',
        ]);

        $this->command->info('✅ Roles and permissions seeded successfully.');
    }
}
