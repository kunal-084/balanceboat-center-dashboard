<?php

// ============================================================
// database/factories/BookingFactory.php
// ============================================================

namespace Database\Factories;

use App\Models\Booking;
use App\Models\Experience;
use App\Models\Center;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class BookingFactory extends Factory
{
    protected $model = Booking::class;

    public function definition(): array
    {
        $startDate  = $this->faker->dateTimeBetween('-6 months', '+3 months');
        $nights     = $this->faker->numberBetween(2, 14);
        $endDate    = (clone $startDate)->modify("+{$nights} days");
        $basePrice  = $this->faker->randomFloat(2, 299, 2999);
        $guests     = $this->faker->numberBetween(1, 3);
        $total      = $basePrice * $guests;
        $statuses   = ['pending', 'confirmed', 'confirmed', 'confirmed', 'checked_in', 'completed', 'cancelled'];

        return [
            'booking_reference'  => 'BB-' . strtoupper(Str::random(8)),
            'experience_id'      => Experience::factory(),
            'center_id'          => fn(array $attrs) => Experience::find($attrs['experience_id'])?->center_id ?? Center::factory(),
            'guest_name'         => $this->faker->name(),
            'guest_email'        => $this->faker->safeEmail(),
            'guest_phone'        => $this->faker->phoneNumber(),
            'guest_country'      => $this->faker->countryCode(),
            'status'             => $this->faker->randomElement($statuses),
            'checkin_date'       => $startDate->format('Y-m-d'),
            'checkout_date'      => $endDate->format('Y-m-d'),
            'adults'             => $guests,
            'children'           => 0,
            'base_price'         => $basePrice,
            'discount_amount'    => 0,
            'total_amount'       => $total,
            'paid_amount'        => $total,
            'currency'           => 'USD',
            'payment_status'     => 'paid',
            'payment_method'     => $this->faker->randomElement(['stripe', 'bank_transfer', 'cash']),
            'special_requests'   => $this->faker->boolean(30) ? $this->faker->sentence() : null,
            'notes'              => null,
            'booked_at'          => $this->faker->dateTimeBetween('-6 months', 'now'),
        ];
    }

    public function confirmed(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'confirmed', 'payment_status' => 'paid']);
    }

    public function pending(): static
    {
        return $this->state(fn(array $attrs) => [
            'status'         => 'pending',
            'payment_status' => 'pending',
            'paid_amount'    => 0,
        ]);
    }

    public function completed(): static
    {
        return $this->state(fn(array $attrs) => [
            'status'         => 'completed',
            'payment_status' => 'paid',
        ]);
    }

    public function cancelled(): static
    {
        return $this->state(fn(array $attrs) => [
            'status'         => 'cancelled',
            'payment_status' => 'refunded',
        ]);
    }
}
