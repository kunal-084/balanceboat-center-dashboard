<?php

// ============================================================
// database/factories/CenterFactory.php
// ============================================================

namespace Database\Factories;

use App\Models\Center;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class CenterFactory extends Factory
{
    protected $model = Center::class;

    public function definition(): array
    {
        $centerNames = [
            'Ananda Wellness Retreat', 'Shanti Yoga Village', 'The Healing Grove',
            'Bodhi Tree Sanctuary', 'Om Retreat Center', 'The Zen Garden',
            'Sacred Space Wellness', 'Lotus Bloom Retreat', 'Prana Flow Center',
            'Moksha Mountain Retreat', 'Pure Life Wellness', 'Sattva Sanctuary',
        ];

        $name = $this->faker->randomElement($centerNames) . ' ' . $this->faker->city();

        return [
            'name'              => $name,
            'slug'              => Str::slug($name) . '-' . $this->faker->randomNumber(4),
            'tagline'           => $this->faker->sentence(8),
            'description'       => $this->faker->paragraphs(3, true),
            'email'             => $this->faker->companyEmail(),
            'phone'             => $this->faker->phoneNumber(),
            'website'           => 'https://' . Str::slug($name) . '.com',
            'country'           => $this->faker->randomElement(['IN', 'US', 'ES', 'TH', 'ID', 'PT', 'MX']),
            'state'             => $this->faker->state(),
            'city'              => $this->faker->city(),
            'address'           => $this->faker->streetAddress(),
            'latitude'          => $this->faker->latitude(-30, 60),
            'longitude'         => $this->faker->longitude(-20, 150),
            'is_active'         => true,
            'is_verified'       => $this->faker->boolean(70),
            'is_featured'       => $this->faker->boolean(20),
            'commission_rate'   => $this->faker->randomFloat(2, 5, 20),
            'rating'            => $this->faker->randomFloat(1, 3.5, 5.0),
            'total_reviews'     => $this->faker->numberBetween(0, 250),
            'total_bookings'    => $this->faker->numberBetween(0, 1000),
            'meta_title'        => $name,
            'meta_description'  => $this->faker->sentence(20),
            'created_at'        => now()->subDays($this->faker->numberBetween(30, 730)),
        ];
    }

    public function verified(): static
    {
        return $this->state(fn(array $attrs) => ['is_verified' => true, 'is_active' => true]);
    }

    public function featured(): static
    {
        return $this->state(fn(array $attrs) => ['is_featured' => true]);
    }
}
