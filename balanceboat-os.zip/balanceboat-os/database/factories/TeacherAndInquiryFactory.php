<?php

// ============================================================
// database/factories/TeacherFactory.php
// ============================================================

namespace Database\Factories;

use App\Models\Teacher;
use App\Models\Center;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class TeacherFactory extends Factory
{
    protected $model = Teacher::class;

    public function definition(): array
    {
        $name = $this->faker->name();

        $specializations = [
            'Hatha Yoga', 'Vinyasa Flow', 'Ashtanga Yoga', 'Yin Yoga',
            'Ayurvedic Medicine', 'Sound Healing', 'Vipassana Meditation',
            'Breathwork & Pranayama', 'Trauma-Informed Yoga', 'Restorative Yoga',
        ];

        return [
            'center_id'           => Center::factory(),
            'name'                => $name,
            'slug'                => Str::slug($name) . '-' . $this->faker->randomNumber(4),
            'email'               => $this->faker->safeEmail(),
            'phone'               => $this->faker->phoneNumber(),
            'bio'                 => $this->faker->paragraphs(3, true),
            'short_bio'           => $this->faker->paragraph(2),
            'specialization'      => $this->faker->randomElement($specializations),
            'years_of_experience' => $this->faker->numberBetween(1, 30),
            'nationality'         => $this->faker->country(),
            'languages'           => json_encode(['English', $this->faker->randomElement(['Hindi', 'Spanish', 'French', 'German'])]),
            'is_active'           => true,
            'is_featured'         => $this->faker->boolean(25),
            'rating'              => $this->faker->randomFloat(1, 3.5, 5.0),
            'total_reviews'       => $this->faker->numberBetween(0, 100),
            'instagram_url'       => 'https://instagram.com/' . Str::slug($name),
            'website_url'         => null,
            'created_at'          => now()->subDays($this->faker->numberBetween(30, 365)),
        ];
    }

    public function featured(): static
    {
        return $this->state(fn(array $attrs) => ['is_featured' => true]);
    }
}


// ============================================================
// database/factories/InquiryFactory.php
// ============================================================

namespace Database\Factories;

use App\Models\Inquiry;
use App\Models\Experience;
use App\Models\Center;
use Illuminate\Database\Eloquent\Factories\Factory;

class InquiryFactory extends Factory
{
    protected $model = Inquiry::class;

    public function definition(): array
    {
        $statuses = ['new', 'new', 'contacted', 'qualified', 'converted', 'lost'];

        return [
            'center_id'          => Center::factory(),
            'experience_id'      => null,
            'name'               => $this->faker->name(),
            'email'              => $this->faker->safeEmail(),
            'phone'              => $this->faker->phoneNumber(),
            'country'            => $this->faker->country(),
            'message'            => $this->faker->paragraphs(2, true),
            'preferred_dates'    => now()->addDays($this->faker->numberBetween(7, 90))->format('Y-m-d'),
            'group_size'         => $this->faker->numberBetween(1, 6),
            'budget'             => $this->faker->randomElement([null, '500-1000', '1000-2000', '2000-5000', '5000+']),
            'status'             => $this->faker->randomElement($statuses),
            'source'             => $this->faker->randomElement(['website', 'google', 'instagram', 'referral', 'direct']),
            'assigned_to'        => null,
            'notes'              => null,
            'created_at'         => $this->faker->dateTimeBetween('-90 days', 'now'),
        ];
    }

    public function new(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'new']);
    }

    public function qualified(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'qualified']);
    }

    public function converted(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'converted']);
    }
}
