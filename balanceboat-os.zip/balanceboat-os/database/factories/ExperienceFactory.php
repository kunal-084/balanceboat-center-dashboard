<?php

// ============================================================
// database/factories/ExperienceFactory.php
// ============================================================

namespace Database\Factories;

use App\Models\Experience;
use App\Models\Center;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ExperienceFactory extends Factory
{
    protected $model = Experience::class;

    public function definition(): array
    {
        $titles = [
            '7-Day Transformational Yoga & Meditation Retreat',
            '5-Day Ayurveda Detox & Renewal Program',
            '10-Day Vipassana Silent Meditation Retreat',
            '3-Day Sound Healing & Breathwork Immersion',
            '14-Day Yoga Teacher Training (200H RYT)',
            '4-Day Nature Therapy & Forest Bathing Retreat',
            '6-Day Raw Food & Yoga Detox Program',
            '5-Day Surf & Yoga Adventure Retreat',
            '21-Day Deep Healing Ayurveda Panchakarma',
            '2-Day Weekend Mindfulness & Stress Relief Retreat',
        ];

        $title    = $this->faker->randomElement($titles);
        $duration = $this->faker->randomElement([2, 3, 4, 5, 7, 10, 14, 21]);

        return [
            'center_id'         => Center::factory(),
            'title'             => $title,
            'slug'              => Str::slug($title) . '-' . $this->faker->unique()->randomNumber(4),
            'short_description' => $this->faker->paragraph(2),
            'description'       => $this->faker->paragraphs(5, true),
            'duration_days'     => $duration,
            'duration_nights'   => $duration - 1,
            'min_participants'  => $this->faker->numberBetween(1, 5),
            'max_participants'  => $this->faker->numberBetween(8, 30),
            'current_bookings'  => 0,
            'base_price'        => $this->faker->randomFloat(2, 299, 4999),
            'currency'          => 'USD',
            'status'            => $this->faker->randomElement(['draft', 'published', 'published', 'published']),
            'difficulty_level'  => $this->faker->randomElement(['beginner', 'intermediate', 'advanced', 'all_levels']),
            'food_included'     => $this->faker->boolean(80),
            'accommodation_included' => $this->faker->boolean(75),
            'cancellation_policy' => $this->faker->paragraph(2),
            'what_to_bring'     => $this->faker->paragraph(2),
            'is_featured'       => $this->faker->boolean(20),
            'meta_title'        => $title,
            'meta_description'  => $this->faker->sentence(20),
            'published_at'      => now()->subDays($this->faker->numberBetween(1, 180)),
            'created_at'        => now()->subDays($this->faker->numberBetween(10, 365)),
        ];
    }

    public function published(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'published']);
    }

    public function draft(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'draft']);
    }

    public function featured(): static
    {
        return $this->state(fn(array $attrs) => ['is_featured' => true, 'status' => 'published']);
    }
}
