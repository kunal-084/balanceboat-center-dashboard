<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

// ─────────────────────────────────────────────────────────────────────────────
// ExperiencePolicy
// ─────────────────────────────────────────────────────────────────────────────

class ExperiencePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id;
    }

    public function create(User $user): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function update(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function delete(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function publish(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function duplicate(User $user, Experience $experience): bool
    {
        return $this->view($user, $experience) && $this->create($user);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// BookingPolicy
// ─────────────────────────────────────────────────────────────────────────────

class BookingPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'staff', 'accountant']);
    }

    public function view(User $user, Booking $booking): bool
    {
        if ($user->hasRole('super-admin')) return true;
        $centerIds = $booking->experience?->center_id;
        return $centerIds === $user->center_id;
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function update(User $user, Booking $booking): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $booking->experience?->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function cancel(User $user, Booking $booking): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $booking->experience?->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function checkIn(User $user, Booking $booking): bool
    {
        return $this->update($user, $booking);
    }

    public function checkOut(User $user, Booking $booking): bool
    {
        return $this->update($user, $booking);
    }

    public function delete(User $user, Booking $booking): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner']);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CenterPolicy
// ─────────────────────────────────────────────────────────────────────────────

class CenterPolicy
{
    public function view(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id;
    }

    public function update(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function manageSubscription(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id && $user->hasRole('center-owner');
    }

    public function viewFinance(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'accountant']);
    }

    public function manageStaff(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id && $user->hasRole('center-owner');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TeacherPolicy
// ─────────────────────────────────────────────────────────────────────────────

class TeacherPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, Teacher $teacher): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $teacher->centers()->where('centers.id', $user->center_id)->exists();
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function update(User $user, Teacher $teacher): bool
    {
        if ($user->hasRole('super-admin')) return true;
        // Teacher can edit own profile
        if ($user->hasRole('teacher') && $teacher->user_id === $user->id) return true;
        return $teacher->centers()->where('centers.id', $user->center_id)->exists()
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function delete(User $user, Teacher $teacher): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $teacher->centers()->where('centers.id', $user->center_id)->exists()
            && $user->hasRole('center-owner');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MediaPolicy
// ─────────────────────────────────────────────────────────────────────────────

class MediaPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, MediaAsset $asset): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $asset->center_id === $user->center_id;
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function update(User $user, MediaAsset $asset): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $asset->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function delete(User $user, MediaAsset $asset): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $asset->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// InquiryPolicy
// ─────────────────────────────────────────────────────────────────────────────

class InquiryPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, Inquiry $inquiry): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $inquiry->center_id === $user->center_id
            || $inquiry->experience?->center_id === $user->center_id;
    }

    public function update(User $user, Inquiry $inquiry): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return ($inquiry->center_id === $user->center_id || $inquiry->experience?->center_id === $user->center_id)
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function delete(User $user, Inquiry $inquiry): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return ($inquiry->center_id === $user->center_id)
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PromoCodePolicy
// ─────────────────────────────────────────────────────────────────────────────

class PromoCodePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'accountant']);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function update(User $user, PromoCode $promo): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $promo->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function delete(User $user, PromoCode $promo): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $promo->center_id === $user->center_id && $user->hasRole('center-owner');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ReviewPolicy
// ─────────────────────────────────────────────────────────────────────────────

class ReviewPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function approve(User $user, CenterReview $review): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $review->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function respond(User $user, CenterReview $review): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $review->center_id === $user->center_id;
    }

    public function delete(User $user, CenterReview $review): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin']);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AutomationPolicy
// ─────────────────────────────────────────────────────────────────────────────

class AutomationPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function create(User $user): bool
    {
        if (! $user->center?->canUseFeature('automation')) return false;
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function update(User $user, AutomationRule $rule): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $rule->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function delete(User $user, AutomationRule $rule): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $rule->center_id === $user->center_id && $user->hasRole('center-owner');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PayoutPolicy
// ─────────────────────────────────────────────────────────────────────────────

class PayoutPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'accountant']);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'accountant']);
    }

    public function process(User $user, PayoutRequest $payout): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin']);
    }
}
