<?php

namespace App\Listeners;

use App\Events\PayoutRequested;
use App\Services\EmailService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Notification;

class SendPayoutRequestNotification implements ShouldQueue
{
    use InteractsWithQueue;

    public string $queue = 'notifications';

    public function __construct(private EmailService $emailService) {}

    public function handle(PayoutRequested $event): void
    {
        $center = $event->center;
        $owner  = $center->owner;

        // Notify the center owner
        $owner->notify(new \App\Notifications\PayoutRequestedNotification(
            center:   $center,
            amount:   $event->amount,
            currency: $event->currency,
        ));

        // Notify platform admin
        $adminEmail = config('app.admin_email');
        if ($adminEmail) {
            $this->emailService->sendRaw(
                to:      $adminEmail,
                subject: "Payout Request: {$center->name} — {$event->currency} {$event->amount}",
                body:    view('emails.admin.payout-request', [
                    'center'   => $center,
                    'amount'   => $event->amount,
                    'currency' => $event->currency,
                    'notes'    => $event->notes,
                ])->render(),
            );
        }
    }

    public function failed(PayoutRequested $event, \Throwable $e): void
    {
        \Log::error('SendPayoutRequestNotification failed', [
            'center_id' => $event->center->id,
            'error'     => $e->getMessage(),
        ]);
    }
}
