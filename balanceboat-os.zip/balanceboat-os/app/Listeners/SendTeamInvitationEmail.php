<?php

namespace App\Listeners;

use App\Events\TeamMemberInvited;
use App\Models\TeamInvitation;
use App\Services\EmailService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Str;

class SendTeamInvitationEmail implements ShouldQueue
{
    use InteractsWithQueue;

    public string $queue = 'notifications';

    public function __construct(private EmailService $emailService) {}

    public function handle(TeamMemberInvited $event): void
    {
        $token = Str::random(64);

        // Persist invitation token (expires in 7 days)
        TeamInvitation::updateOrCreate(
            ['email'     => $event->email, 'center_id' => $event->center->id],
            [
                'role'       => $event->role,
                'token'      => hash('sha256', $token),
                'expires_at' => now()->addDays(7),
            ]
        );

        $acceptUrl = route('invitations.accept', [
            'token'  => $token,
            'center' => $event->center->id,
        ]);

        $this->emailService->sendRaw(
            to:      $event->email,
            subject: "You're invited to join {$event->center->name} on BalanceBoat",
            body:    view('emails.team-invitation', [
                'center'    => $event->center,
                'role'      => $event->role,
                'acceptUrl' => $acceptUrl,
            ])->render(),
        );
    }

    public function failed(TeamMemberInvited $event, \Throwable $e): void
    {
        \Log::warning('SendTeamInvitationEmail failed', [
            'email'     => $event->email,
            'center_id' => $event->center->id,
            'error'     => $e->getMessage(),
        ]);
    }
}
