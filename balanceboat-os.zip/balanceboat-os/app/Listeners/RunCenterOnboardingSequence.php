<?php

namespace App\Listeners;

use App\Events\CenterOnboarded;
use App\Services\EmailService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class RunCenterOnboardingSequence implements ShouldQueue
{
    use InteractsWithQueue;

    public string $queue = 'automations';

    public function __construct(private EmailService $emailService) {}

    public function handle(CenterOnboarded $event): void
    {
        $center = $event->center;
        $owner  = $center->owner;

        // 1. Immediate welcome email
        $this->emailService->sendRaw(
            to:      $owner->email,
            subject: "Welcome to BalanceBoat, {$owner->first_name}! 🌿",
            body:    view('emails.onboarding.welcome', [
                'user'   => $owner,
                'center' => $center,
            ])->render(),
        );

        // 2. Schedule drip emails via jobs (Day 1, Day 3, Day 7)
        \App\Jobs\SendOnboardingDripEmail::dispatch($owner, $center, 'tips_day1')
            ->delay(now()->addDay());

        \App\Jobs\SendOnboardingDripEmail::dispatch($owner, $center, 'tips_day3')
            ->delay(now()->addDays(3));

        \App\Jobs\SendOnboardingDripEmail::dispatch($owner, $center, 'tips_day7')
            ->delay(now()->addDays(7));

        // 3. Set up default automation rules for the center
        $this->bootstrapDefaultAutomations($center);
    }

    private function bootstrapDefaultAutomations(\App\Models\Center $center): void
    {
        $defaults = [
            [
                'name'    => 'Welcome Reply to Inquiry',
                'trigger' => 'inquiry.received',
                'actions' => [['type' => 'send_email', 'template' => 'inquiry_auto_reply']],
                'delay_minutes' => 0,
                'is_active' => true,
            ],
            [
                'name'    => 'Booking Confirmation Email',
                'trigger' => 'booking.confirmed',
                'actions' => [['type' => 'send_email', 'template' => 'booking_confirmed']],
                'delay_minutes' => 0,
                'is_active' => true,
            ],
            [
                'name'    => '7-Day Pre-Retreat Reminder',
                'trigger' => 'retreat.starts_in_7_days',
                'actions' => [['type' => 'send_email', 'template' => 'retreat_reminder_7d']],
                'delay_minutes' => 0,
                'is_active' => true,
            ],
        ];

        foreach ($defaults as $rule) {
            $center->automationRules()->firstOrCreate(
                ['trigger' => $rule['trigger'], 'center_id' => $center->id],
                $rule
            );
        }
    }

    public function failed(CenterOnboarded $event, \Throwable $e): void
    {
        \Log::error('RunCenterOnboardingSequence failed', [
            'center_id' => $event->center->id,
            'error'     => $e->getMessage(),
        ]);
    }
}
