<?php
// ============================================================
// RETREAT (EXPERIENCE) REQUESTS
// ============================================================

namespace App\Http\Requests\Retreat;

use Illuminate\Foundation\Http\FormRequest;

class StoreRetreatRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', \App\Models\Experience::class);
    }

    public function rules(): array
    {
        return [
            'name'                          => ['required', 'string', 'max:200'],
            'slug'                          => ['nullable', 'string', 'max:220', 'unique:experiences,slug'],
            'experience_category'           => ['nullable', 'string', 'max:255'],
            'category_ids'                  => ['nullable', 'array'],
            'category_ids.*'                => ['integer', 'exists:category,id'],
            'teacher_ids'                   => ['nullable', 'array'],
            'teacher_ids.*'                 => ['integer', 'exists:teachers,id'],
            'price_per_person'              => ['required', 'numeric', 'min:0'],
            'currency'                      => ['required', 'string', 'size:3'],
            'avg_price'                     => ['nullable', 'numeric', 'min:0'],
            'price_shared'                  => ['nullable', 'numeric', 'min:0'],
            'price_private'                 => ['nullable', 'numeric', 'min:0'],
            'batch_size'                    => ['nullable', 'integer', 'min:1', 'max:500'],
            'duration'                      => ['nullable', 'string', 'max:100'],
            'duration_nights'               => ['nullable', 'integer', 'min:1', 'max:365'],
            'start_date_time'               => ['nullable', 'date'],
            'end_date_time'                 => ['nullable', 'date', 'after_or_equal:start_date_time'],
            'is_full_day_event'             => ['boolean'],
            'is_recurring'                  => ['boolean'],
            'experience_summary'            => ['nullable', 'string', 'max:2000'],
            'experience_overview'           => ['nullable', 'string'],
            'experience_details'            => ['nullable', 'string'],
            'experience_highlights'         => ['nullable', 'string'],
            'language_spoken'               => ['nullable', 'string', 'max:100'],
            'skill_level'                   => ['nullable', 'string', 'max:100'],
            'food'                          => ['nullable', 'string', 'max:100'],
            'food_overview'                 => ['nullable', 'string'],
            'schedule'                      => ['nullable', 'string'],
            'styles_taught'                 => ['nullable', 'string', 'max:255'],
            'area'                          => ['nullable', 'string', 'max:255'],
            'atmosphere'                    => ['nullable', 'string', 'max:255'],
            'what_is_included'              => ['nullable', 'string'],
            'what_is_not_included'          => ['nullable', 'string'],
            'how_to_get_here'               => ['nullable', 'string'],
            'booking_info'                  => ['nullable', 'string'],
            'cancellation_policy'           => ['nullable', 'string'],
            'deposit_policy'                => ['boolean'],
            'deposit_amount'                => ['nullable', 'numeric', 'min:0', 'required_if:deposit_policy,true'],
            'cancellation_policy_condition' => ['boolean'],
            'cancellation_policy_days'      => ['nullable', 'integer', 'min:1', 'required_if:cancellation_policy_condition,true'],
            'rest_of_payment'               => ['boolean'],
            'rest_of_payment_days'          => ['nullable', 'integer', 'min:1'],
            'commission'                    => ['nullable', 'numeric', 'min:0', 'max:100'],
            'tax'                           => ['nullable', 'string', 'max:100'],
            'is_bookable'                   => ['boolean'],
            'is_draft'                      => ['boolean'],
            'display_on_home'               => ['boolean'],
            'featured_experiences'          => ['boolean'],
            'luxury_retreats'               => ['boolean'],
            'weekend_retreats'              => ['boolean'],
            'couple_retreats'               => ['boolean'],
            'budget_retreats'               => ['boolean'],
            'eirly_bird_before_days'        => ['nullable', 'integer', 'min:1', 'max:365'],
            'eirly_bird_discount'           => ['nullable', 'numeric', 'min:0', 'max:100'],
            'eirly_bird_discount_type'      => ['nullable', 'in:percentage,fixed'],
            'offer_start_date'              => ['nullable', 'date'],
            'offer_end_date'                => ['nullable', 'date', 'after_or_equal:offer_start_date'],
            'offer_discount'                => ['nullable', 'numeric', 'min:0', 'max:100'],
            'offer_discount_type'           => ['nullable', 'in:percentage,fixed'],
            'meta_title'                    => ['nullable', 'string', 'max:160'],
            'meta_description'              => ['nullable', 'string', 'max:320'],
            'keywords'                      => ['nullable', 'string'],
            'tags'                          => ['nullable', 'string', 'max:500'],
            'video_url'                     => ['nullable', 'url', 'max:500'],
            'website'                       => ['nullable', 'url', 'max:250'],
            'ref_link'                      => ['nullable', 'url', 'max:250'],
        ];
    }

    public function messages(): array
    {
        return [
            'deposit_amount.required_if'         => 'Deposit amount is required when deposit policy is enabled.',
            'cancellation_policy_days.required_if'=> 'Cancellation days is required when cancellation policy is enabled.',
            'end_date_time.after_or_equal'        => 'End date must be after or equal to start date.',
        ];
    }
}

class UpdateRetreatRequest extends StoreRetreatRequest
{
    public function authorize(): bool
    {
        $experience = $this->route('retreat');
        return $this->user()->can('update', $experience);
    }

    public function rules(): array
    {
        $experienceId = $this->route('retreat')?->id;
        $rules        = parent::rules();

        $rules['name']                = ['sometimes', 'string', 'max:200'];
        $rules['price_per_person']    = ['sometimes', 'numeric', 'min:0'];
        $rules['currency']            = ['sometimes', 'string', 'size:3'];
        $rules['slug']                = ['nullable', 'string', 'max:220', "unique:experiences,slug,{$experienceId}"];

        return $rules;
    }
}

// ============================================================
// BOOKING REQUESTS
// ============================================================

namespace App\Http\Requests\Booking;

use Illuminate\Foundation\Http\FormRequest;

class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'experience_id'            => ['required', 'integer', 'exists:experiences,id'],
            'experience_accomodation_id'=> ['nullable', 'integer', 'exists:experience_accomodations,id'],
            'guest_count'              => ['required', 'integer', 'min:1', 'max:50'],
            'arrival_date'             => ['required', 'date', 'after_or_equal:today'],
            'start_date_time'          => ['nullable', 'date'],
            'end_date_time'            => ['nullable', 'date', 'after_or_equal:start_date_time'],
            'currency'                 => ['nullable', 'string', 'size:3'],
            'promo_code'               => ['nullable', 'string', 'max:50'],
            'guest_info'               => ['required', 'array'],
            'guest_info.firstname'     => ['required', 'string', 'max:100'],
            'guest_info.lastname'      => ['required', 'string', 'max:100'],
            'guest_info.email'         => ['required', 'email', 'max:191'],
            'guest_info.phone'         => ['required', 'string', 'max:30'],
            'guest_info.message'       => ['nullable', 'string', 'max:2000'],
            'billing_name'             => ['nullable', 'string', 'max:100'],
            'billing_address'          => ['nullable', 'string', 'max:150'],
            'billing_city'             => ['nullable', 'string', 'max:30'],
            'billing_country'          => ['nullable', 'string', 'max:20'],
            'billing_zip'              => ['nullable', 'string', 'max:10'],
            'billing_email'            => ['nullable', 'email', 'max:100'],
            'billing_tel'              => ['nullable', 'string', 'max:20'],
        ];
    }
}

class UpdateBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('booking'));
    }

    public function rules(): array
    {
        return [
            'stage'              => ['sometimes', 'in:inquiry,qualified,proposal_sent,confirmed,checked_in,completed,cancelled,refunded'],
            'assigned_staff_id'  => ['nullable', 'integer', 'exists:users,id'],
            'internal_notes'     => ['nullable', 'string', 'max:5000'],
            'cancellation_reason'=> ['nullable', 'string', 'max:500'],
            'arrival_date'       => ['sometimes', 'date'],
            'guest_count'        => ['sometimes', 'integer', 'min:1'],
        ];
    }
}

class CancelBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('cancel', $this->route('booking'));
    }

    public function rules(): array
    {
        return [
            'reason'         => ['required', 'string', 'min:10', 'max:500'],
            'process_refund' => ['boolean'],
            'refund_amount'  => ['nullable', 'numeric', 'min:0.01', 'required_if:process_refund,true'],
        ];
    }
}

// ============================================================
// TEACHER REQUESTS
// ============================================================

namespace App\Http\Requests\Teacher;

use Illuminate\Foundation\Http\FormRequest;

class StoreTeacherRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', \App\Models\Teacher::class);
    }

    public function rules(): array
    {
        return [
            'name'               => ['required', 'string', 'max:200'],
            'slug'               => ['nullable', 'string', 'max:220', 'unique:teachers,slug'],
            'short_description'  => ['nullable', 'string', 'max:500'],
            'complete_bio'       => ['nullable', 'string'],
            'currently_working_with' => ['nullable', 'string'],
            'expertise_id'       => ['nullable', 'string'],
            'certificate_id'     => ['nullable', 'string'],
            'teaching_since'     => ['nullable', 'integer', 'min:1950', 'max:' . date('Y')],
            'languages'          => ['nullable', 'array'],
            'languages.*'        => ['string', 'max:50'],
            'nationality'        => ['nullable', 'string', 'max:100'],
            'hourly_rate'        => ['nullable', 'numeric', 'min:0'],
            'rate_currency'      => ['nullable', 'string', 'size:3'],
            'website_url'        => ['nullable', 'url', 'max:250'],
            'instagram_url'      => ['nullable', 'url', 'max:250'],
            'facebook_url'       => ['nullable', 'url', 'max:250'],
            'youtube_url'        => ['nullable', 'url', 'max:250'],
            'status'             => ['nullable', 'in:active,inactive,pending,suspended'],
            'is_featured'        => ['boolean'],
            'meta_title'         => ['nullable', 'string', 'max:255'],
            'meta_description'   => ['nullable', 'string', 'max:320'],
            'keywords'           => ['nullable', 'string'],
        ];
    }
}

class UpdateTeacherRequest extends StoreTeacherRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('teacher'));
    }

    public function rules(): array
    {
        $teacherId = $this->route('teacher')?->id;
        $rules     = parent::rules();
        $rules['name']  = ['sometimes', 'string', 'max:200'];
        $rules['slug']  = ['nullable', 'string', 'max:220', "unique:teachers,slug,{$teacherId}"];
        return $rules;
    }
}

// ============================================================
// ACCOMMODATION REQUESTS
// ============================================================

namespace App\Http\Requests\Accommodation;

use Illuminate\Foundation\Http\FormRequest;

class StoreAccommodationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', \App\Models\Accomodation::class);
    }

    public function rules(): array
    {
        return [
            'name'                    => ['required', 'string', 'max:200'],
            'description'             => ['nullable', 'string'],
            'max_guest_in_room'       => ['nullable', 'integer', 'min:1', 'max:20'],
            'banner_image_title'      => ['nullable', 'string', 'max:255'],
            'banner_image_url'        => ['nullable', 'string', 'max:500'],
            'banner_image_path'       => ['nullable', 'string', 'max:500'],
        ];
    }
}

class UpdateAccommodationRequest extends StoreAccommodationRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('accommodation'));
    }

    public function rules(): array
    {
        $rules = parent::rules();
        $rules['name'] = ['sometimes', 'string', 'max:200'];
        return $rules;
    }
}

// ============================================================
// INQUIRY REQUESTS
// ============================================================

namespace App\Http\Requests\Inquiry;

use Illuminate\Foundation\Http\FormRequest;

class StoreInquiryRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'         => ['required', 'string', 'max:191'],
            'lastname'     => ['nullable', 'string', 'max:191'],
            'email'        => ['required', 'email', 'max:191'],
            'country_code' => ['nullable', 'integer'],
            'phone'        => ['nullable', 'string', 'max:20'],
            'whatsapp'     => ['boolean'],
            'message'      => ['nullable', 'string', 'max:5000'],
            'retreat_type' => ['nullable', 'string', 'max:255'],
            'destination'  => ['nullable', 'string', 'max:255'],
            'budget'       => ['nullable', 'string', 'max:255'],
            'timeline'     => ['nullable', 'string', 'max:255'],
            'experience_id'=> ['nullable', 'integer', 'exists:experiences,id'],
            'source'       => ['nullable', 'string', 'max:100'],
            'ref_url'      => ['nullable', 'url', 'max:500'],
            'group_size'   => ['nullable', 'integer', 'min:1', 'max:500'],
        ];
    }
}

class UpdateInquiryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('inquiry'));
    }

    public function rules(): array
    {
        return [
            'pipeline_stage'  => ['sometimes', 'in:new,contacted,qualified,proposal,negotiating,won,lost'],
            'assigned_to'     => ['nullable', 'integer', 'exists:users,id'],
            'note'            => ['nullable', 'string', 'max:5000'],
            'follow_up_at'    => ['nullable', 'date'],
            'lost_reason'     => ['nullable', 'string', 'max:500'],
        ];
    }
}

// ============================================================
// PROMO CODE REQUESTS
// ============================================================

namespace App\Http\Requests\PromoCode;

use Illuminate\Foundation\Http\FormRequest;

class StorePromoCodeRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'code'                       => ['required', 'string', 'max:50', 'unique:promo_codes,code', 'regex:/^[A-Z0-9\-_]+$/'],
            'description'                => ['nullable', 'string', 'max:255'],
            'discount_type'              => ['required', 'in:percentage,fixed'],
            'discount_value'             => ['required', 'numeric', 'min:0.01'],
            'min_booking_amount'         => ['nullable', 'numeric', 'min:0'],
            'max_discount_cap'           => ['nullable', 'numeric', 'min:0'],
            'max_uses'                   => ['nullable', 'integer', 'min:1'],
            'max_uses_per_user'          => ['required', 'integer', 'min:1', 'max:100'],
            'valid_from'                 => ['nullable', 'date'],
            'valid_until'                => ['nullable', 'date', 'after_or_equal:valid_from'],
            'applies_to_all'             => ['boolean'],
            'applicable_experience_ids'  => ['nullable', 'array', 'required_if:applies_to_all,false'],
            'applicable_experience_ids.*'=> ['integer', 'exists:experiences,id'],
            'is_active'                  => ['boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'code.regex' => 'Code must contain only uppercase letters, numbers, hyphens, or underscores.',
            'applicable_experience_ids.required_if' => 'Please select at least one retreat when not applying to all.',
        ];
    }
}

class UpdatePromoCodeRequest extends StorePromoCodeRequest
{
    public function rules(): array
    {
        $id    = $this->route('promo_code')?->id;
        $rules = parent::rules();
        $rules['code'] = ['sometimes', 'string', 'max:50', "unique:promo_codes,code,{$id}", 'regex:/^[A-Z0-9\-_]+$/'];
        $rules['discount_type']  = ['sometimes', 'in:percentage,fixed'];
        $rules['discount_value'] = ['sometimes', 'numeric', 'min:0.01'];
        return $rules;
    }
}

// ============================================================
// PRICING RULE REQUESTS
// ============================================================

namespace App\Http\Requests\Pricing;

use Illuminate\Foundation\Http\FormRequest;

class StorePricingRuleRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'                    => ['required', 'string', 'max:200'],
            'description'             => ['nullable', 'string', 'max:500'],
            'experience_id'           => ['nullable', 'integer', 'exists:experiences,id'],
            'rule_type'               => ['required', 'in:early_bird,last_minute,seasonal_peak,seasonal_off,occupancy_based,duration_based,group_discount,repeat_guest,custom'],
            'discount_type'           => ['required', 'in:percentage,fixed'],
            'discount_value'          => ['required', 'numeric', 'min:0.01'],
            'min_price_cap'           => ['nullable', 'numeric', 'min:0'],
            'days_before'             => ['nullable', 'integer', 'min:1', 'required_if:rule_type,early_bird', 'required_if:rule_type,last_minute'],
            'occupancy_threshold_pct' => ['nullable', 'integer', 'min:1', 'max:100', 'required_if:rule_type,occupancy_based'],
            'min_duration_nights'     => ['nullable', 'integer', 'min:1', 'required_if:rule_type,duration_based'],
            'min_group_size'          => ['nullable', 'integer', 'min:2', 'required_if:rule_type,group_discount'],
            'start_date'              => ['nullable', 'date', 'required_if:rule_type,seasonal_peak', 'required_if:rule_type,seasonal_off'],
            'end_date'                => ['nullable', 'date', 'after_or_equal:start_date'],
            'priority'                => ['integer', 'min:0', 'max:100'],
            'is_stackable'            => ['boolean'],
            'is_active'               => ['boolean'],
        ];
    }
}

class UpdatePricingRuleRequest extends StorePricingRuleRequest
{
    public function rules(): array
    {
        $rules = parent::rules();
        $rules['name']         = ['sometimes', 'string', 'max:200'];
        $rules['rule_type']    = ['sometimes', 'in:early_bird,last_minute,seasonal_peak,seasonal_off,occupancy_based,duration_based,group_discount,repeat_guest,custom'];
        $rules['discount_type']  = ['sometimes', 'in:percentage,fixed'];
        $rules['discount_value'] = ['sometimes', 'numeric', 'min:0.01'];
        return $rules;
    }
}

// ============================================================
// CENTER REQUESTS
// ============================================================

namespace App\Http\Requests\Center;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCenterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('center') ?? auth()->user()->center);
    }

    public function rules(): array
    {
        return [
            'name'                         => ['sometimes', 'string', 'max:100'],
            'meta_title'                   => ['nullable', 'string', 'max:255'],
            'keywords'                     => ['nullable', 'string'],
            'meta_description'             => ['nullable', 'string', 'max:500'],
            'gps'                          => ['nullable', 'string', 'max:80'],
            'location'                     => ['nullable', 'string', 'max:255'],
            'speciality_id'                => ['nullable', 'string'],
            'year_of_foundation'           => ['nullable', 'integer', 'min:1800', 'max:' . date('Y')],
            'founders'                     => ['nullable', 'string', 'max:255'],
            'about_center'                 => ['nullable', 'string'],
            'what_sets_us_apart'           => ['nullable', 'string'],
            'our_philosophy'               => ['nullable', 'string'],
            'our_mission'                  => ['nullable', 'string'],
            'center_highlights'            => ['nullable', 'string'],
            'video_url'                    => ['nullable', 'url', 'max:255'],
            'website'                      => ['nullable', 'url', 'max:250'],
            'address_of_center'            => ['nullable', 'string', 'max:255'],
            'city'                         => ['nullable', 'string', 'max:60'],
            'state'                        => ['nullable', 'string', 'max:100'],
            'country'                      => ['nullable', 'string', 'max:200'],
            'postal_code'                  => ['nullable', 'string', 'max:20'],
            'email_address'                => ['nullable', 'email', 'max:255'],
            'contact_number'               => ['nullable', 'string', 'max:100'],
            'whatsapp_number'              => ['nullable', 'string', 'max:100'],
            'facebook_url'                 => ['nullable', 'url', 'max:250'],
            'instagram_url'                => ['nullable', 'url', 'max:250'],
            'twitter_url'                  => ['nullable', 'url', 'max:250'],
            'youtube_url'                  => ['nullable', 'url', 'max:250'],
            'linkedin_url'                 => ['nullable', 'url', 'max:250'],
            'have_accomodation'            => ['nullable', 'in:Yes,No'],
            'accomodation_overview'        => ['nullable', 'string'],
            'how_to_get_there'             => ['nullable', 'string'],
            'things_to_do_around_the_center'=>['nullable', 'string'],
            'amenities'                    => ['nullable', 'string'],
            'airport_name'                 => ['nullable', 'string', 'max:255'],
            'pickup_drop_cost'             => ['nullable', 'numeric', 'min:0'],
            'timezone'                     => ['nullable', 'string', 'max:100'],
            'currency_code'                => ['nullable', 'string', 'size:3'],
            'operating_hours'              => ['nullable', 'array'],
            'tags'                         => ['nullable', 'string', 'max:500'],
            'latitude'                     => ['nullable', 'numeric', 'between:-90,90'],
            'longitude'                    => ['nullable', 'numeric', 'between:-180,180'],
        ];
    }
}

// ============================================================
// MEDIA REQUESTS
// ============================================================

namespace App\Http\Requests\Media;

use Illuminate\Foundation\Http\FormRequest;

class StoreMediaRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'files'            => ['required', 'array', 'min:1', 'max:20'],
            'files.*'          => ['required', 'file', 'max:102400', 'mimes:jpg,jpeg,png,webp,gif,mp4,mov,pdf,doc,docx'],
            'folder_id'        => ['nullable', 'integer', 'exists:media_folders,id'],
            'collection'       => ['nullable', 'string', 'max:100'],
            'mediable_type'    => ['nullable', 'string', 'max:200'],
            'mediable_id'      => ['nullable', 'integer'],
            'alt_text'         => ['nullable', 'string', 'max:500'],
            'caption'          => ['nullable', 'string', 'max:1000'],
            'category'         => ['nullable', 'string', 'max:100'],
        ];
    }
}

class UpdateMediaRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'alt_text'    => ['nullable', 'string', 'max:500'],
            'caption'     => ['nullable', 'string', 'max:1000'],
            'category'    => ['nullable', 'string', 'max:100'],
            'is_featured' => ['boolean'],
            'sort_order'  => ['nullable', 'integer', 'min:0'],
        ];
    }
}

// ============================================================
// AUTOMATION REQUESTS
// ============================================================

namespace App\Http\Requests\Automation;

use Illuminate\Foundation\Http\FormRequest;

class StoreAutomationRuleRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'                  => ['required', 'string', 'max:200'],
            'description'           => ['nullable', 'string', 'max:500'],
            'trigger_event'         => ['required', 'string', 'max:200'],
            'trigger_conditions'    => ['nullable', 'array'],
            'action_type'           => ['required', 'in:email,whatsapp,sms,webhook,internal_task'],
            'email_template_id'     => ['nullable', 'integer', 'exists:email_templates,id'],
            'whatsapp_template_id'  => ['nullable', 'integer', 'exists:whatsapp_templates,id'],
            'action_config'         => ['nullable', 'array'],
            'delay_unit'            => ['required', 'in:minutes,hours,days'],
            'delay_value'           => ['required', 'integer', 'min:0'],
            'is_active'             => ['boolean'],
        ];
    }
}

class UpdateAutomationRuleRequest extends StoreAutomationRuleRequest
{
    public function rules(): array
    {
        $rules = parent::rules();
        $rules['name']           = ['sometimes', 'string', 'max:200'];
        $rules['trigger_event']  = ['sometimes', 'string', 'max:200'];
        $rules['action_type']    = ['sometimes', 'in:email,whatsapp,sms,webhook,internal_task'];
        $rules['delay_unit']     = ['sometimes', 'in:minutes,hours,days'];
        $rules['delay_value']    = ['sometimes', 'integer', 'min:0'];
        return $rules;
    }
}
