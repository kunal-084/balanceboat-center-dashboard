<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OnboardingController extends Controller
{
    private const STEPS = [
        1 => 'center-profile',
        2 => 'first-retreat',
        3 => 'invite-team',
        4 => 'complete',
    ];

    public function show(Request $request)
    {
        /** @var User $user */
        $user  = Auth::user();
        $step  = (int) $request->get('step', $this->currentStep($user));
        $center = $user->center;

        return view('onboarding.wizard', [
            'step'   => $step,
            'steps'  => self::STEPS,
            'center' => $center,
            'user'   => $user,
        ]);
    }

    public function saveStep(Request $request, int $step)
    {
        /** @var User $user */
        $user = Auth::user();

        match ($step) {
            1 => $this->saveProfile($request, $user),
            2 => $this->saveFirstRetreat($request, $user),
            3 => $this->saveTeamInvite($request, $user),
            default => null,
        };

        $nextStep = $step + 1;

        if ($nextStep > count(self::STEPS)) {
            $user->center?->update(['onboarding_completed_at' => now()]);
            return redirect()->route('dashboard')->with('success', 'Welcome aboard! Your center is all set. 🎉');
        }

        return redirect()->route('onboarding', ['step' => $nextStep]);
    }

    public function skip(Request $request, int $step)
    {
        $nextStep = $step + 1;

        if ($nextStep > count(self::STEPS)) {
            return redirect()->route('dashboard');
        }

        return redirect()->route('onboarding', ['step' => $nextStep]);
    }

    // ─── Private Helpers ─────────────────────────────────────────────────────

    private function saveProfile(Request $request, User $user): void
    {
        $validated = $request->validate([
            'center_name'  => ['required', 'string', 'max:100'],
            'center_type'  => ['required', 'string'],
            'country'      => ['required', 'string'],
            'phone'        => ['nullable', 'string'],
            'logo'         => ['nullable', 'image', 'max:2048'],
        ]);

        $center = $user->center ?? Center::create([
            'owner_id' => $user->id,
            'name'     => $validated['center_name'],
        ]);

        $center->update([
            'name'        => $validated['center_name'],
            'center_type' => $validated['center_type'],
            'country'     => $validated['country'],
            'phone'       => $validated['phone'],
        ]);

        if ($request->hasFile('logo')) {
            $path = $request->file('logo')->store('logos', 's3');
            $center->update(['logo' => $path]);
        }

        $user->update(['center_id' => $center->id]);
    }

    private function saveFirstRetreat(Request $request, User $user): void
    {
        $validated = $request->validate([
            'title'         => ['required', 'string', 'max:150'],
            'style'         => ['required', 'string'],
            'duration_days' => ['required', 'integer', 'min:1'],
            'max_capacity'  => ['required', 'integer', 'min:1'],
            'base_price'    => ['required', 'numeric', 'min:0'],
        ]);

        $user->center?->experiences()->create(array_merge($validated, [
            'status'   => 'draft',
            'currency' => 'USD',
        ]));
    }

    private function saveTeamInvite(Request $request, User $user): void
    {
        $validated = $request->validate([
            'invite_emails' => ['nullable', 'string'],
        ]);

        if (empty($validated['invite_emails'])) {
            return;
        }

        $emails = array_filter(
            array_map('trim', explode(',', $validated['invite_emails']))
        );

        foreach ($emails as $email) {
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                // Fire invitation — handled by TeamInvitationSent event
                event(new \App\Events\TeamMemberInvited($user->center, $email, 'staff'));
            }
        }
    }

    private function currentStep(User $user): int
    {
        if (! $user->center) return 1;
        if ($user->center->experiences()->count() === 0) return 2;
        return 3;
    }
}
