<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

// ─────────────────────────────────────────────────────────────────────────────
// DashboardController
// ─────────────────────────────────────────────────────────────────────────────

class DashboardController extends Controller
{
    public function __construct(
        private readonly \App\Services\AnalyticsService $analyticsService,
        private readonly \App\Repositories\BookingRepository $bookingRepo,
        private readonly \App\Services\AiService $aiService,
    ) {}

    public function index(Request $request): View
    {
        $user     = auth()->user();
        $center   = $user->center;
        $centerId = $user->center_id;
        $period   = $request->get('period', '30d');

        $kpis           = $this->analyticsService->getDashboardKpis($centerId, $period);
        $revenueChart   = $this->analyticsService->getRevenueChart($centerId, now()->subDays(30)->toDateString(), today()->toDateString());
        $topRetreats    = $this->analyticsService->getTopRetreats($centerId, 5);
        $todayCheckIns  = $this->bookingRepo->todayCheckIns($centerId);
        $currentGuests  = $this->bookingRepo->currentGuests($centerId);
        $upcomingBookings = $this->bookingRepo->upcomingForCenter($centerId, 7);
        $aiRecs         = \App\Models\AiRecommendation::forCenter($centerId)->active()->latest()->limit(3)->get();
        $pendingReviews = \App\Models\CenterReview::where('center_id', $centerId)->pending()->count();
        $recentInquiries= \App\Models\Inquiry::where('center_id', $centerId)->latest()->limit(5)->get();
        $bookingFunnel  = $this->analyticsService->getBookingFunnel($centerId, now()->subDays(30)->toDateString(), today()->toDateString());

        return view('dashboard.index', compact(
            'center', 'kpis', 'revenueChart', 'topRetreats',
            'todayCheckIns', 'currentGuests', 'upcomingBookings',
            'aiRecs', 'pendingReviews', 'recentInquiries', 'bookingFunnel', 'period'
        ));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RetreatController
// ─────────────────────────────────────────────────────────────────────────────

class RetreatController extends Controller
{
    public function __construct(
        private readonly ExperienceRepository  $repository,
        private readonly CreateRetreatAction   $createAction,
        private readonly UpdateRetreatAction   $updateAction,
        private readonly PublishRetreatAction  $publishAction,
        private readonly UnpublishRetreatAction $unpublishAction,
        private readonly DuplicateRetreatAction $duplicateAction,
        private readonly AvailabilityService   $availabilityService,
    ) {}

    public function index(Request $request): View
    {
        $this->authorize('viewAny', Experience::class);

        $retreats = $this->repository->paginateForCenter(
            centerId: auth()->user()->center_id,
            filters:  $request->only(['status', 'search', 'category_id', 'featured']),
            sortBy:   $request->get('sort', 'created_at'),
            sortDir:  $request->get('dir', 'desc'),
        );

        $categories = Category::where('type', 0)->orderBy('name')->get();
        $stats      = app(RetreatService::class)->getStats(auth()->user()->center_id);

        return view('retreats.index', compact('retreats', 'categories', 'stats'));
    }

    public function create(): View
    {
        $this->authorize('create', Experience::class);

        $categories     = Category::where('type', 0)->orderBy('name')->get();
        $teachers       = Teacher::forCenter(auth()->user()->center_id)->active()->orderBy('name')->get();
        $accommodations = Accomodation::all();

        return view('retreats.create', compact('categories', 'teachers', 'accommodations'));
    }

    public function store(StoreRetreatRequest $request): RedirectResponse
    {
        $dto     = RetreatDTO::fromRequest($request, auth()->user()->center_id);
        $retreat = $this->createAction->handle($dto);

        // Queue availability calendar generation
        \App\Jobs\RefreshAvailabilityCalendarJob::dispatch($retreat)->onQueue('default');

        return redirect()
            ->route('retreats.show', $retreat)
            ->with('success', "Retreat \"{$retreat->name}\" created successfully.");
    }

    public function show(Experience $retreat): View
    {
        $this->authorize('view', $retreat);

        $retreat->load([
            'center', 'categories', 'teachers', 'accommodations.prices',
            'faqs', 'benefits', 'itineraryDays.sessions', 'imageGallery',
            'pricingRules', 'seoMetadata', 'aiRecommendations',
        ]);

        $recentBookings = \App\Models\Booking::where('experience_id', $retreat->id)
            ->with('userInfo')
            ->latest()
            ->limit(10)
            ->get();

        $availability = $this->availabilityService->getCalendar(
            $retreat->id,
            now(),
            now()->addMonths(3)
        );

        $reviewStats = [
            'avg'   => $retreat->computed_average_rating,
            'total' => $retreat->review_count,
        ];

        return view('retreats.show', compact('retreat', 'recentBookings', 'availability', 'reviewStats'));
    }

    public function edit(Experience $retreat): View
    {
        $this->authorize('update', $retreat);

        $retreat->load(['categories', 'teachers', 'accommodations', 'faqs', 'benefits', 'itineraryDays.sessions']);

        $categories     = Category::where('type', 0)->orderBy('name')->get();
        $teachers       = Teacher::forCenter(auth()->user()->center_id)->active()->orderBy('name')->get();
        $accommodations = Accomodation::all();

        return view('retreats.edit', compact('retreat', 'categories', 'teachers', 'accommodations'));
    }

    public function update(UpdateRetreatRequest $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $this->updateAction->handle($retreat, $request->validated());

        return redirect()
            ->route('retreats.show', $retreat)
            ->with('success', 'Retreat updated successfully.');
    }

    public function destroy(Experience $retreat): RedirectResponse
    {
        $this->authorize('delete', $retreat);

        $name = $retreat->name;
        $retreat->delete();

        return redirect()
            ->route('retreats.index')
            ->with('success', "\"{$name}\" has been archived.");
    }

    public function publish(Experience $retreat): RedirectResponse
    {
        $this->authorize('publish', $retreat);

        $this->publishAction->handle($retreat);

        return back()->with('success', 'Retreat is now live and accepting bookings.');
    }

    public function unpublish(Experience $retreat): RedirectResponse
    {
        $this->authorize('publish', $retreat);

        $this->unpublishAction->handle($retreat);

        return back()->with('success', 'Retreat has been unpublished.');
    }

    public function duplicate(Experience $retreat): RedirectResponse
    {
        $this->authorize('duplicate', $retreat);

        $clone = $this->duplicateAction->handle($retreat);

        return redirect()
            ->route('retreats.edit', $clone)
            ->with('success', 'Retreat duplicated successfully. Please review and update the copy.');
    }

    public function availability(Request $request, Experience $retreat): View
    {
        $this->authorize('view', $retreat);

        $from = $request->get('from', now()->startOfMonth()->toDateString());
        $to   = $request->get('to', now()->addMonths(3)->endOfMonth()->toDateString());

        $calendar = $this->availabilityService->getCalendar($retreat->id, \Carbon\Carbon::parse($from), \Carbon\Carbon::parse($to));

        return view('retreats.availability', compact('retreat', 'calendar', 'from', 'to'));
    }

    public function blockDates(Request $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);
        $request->validate([
            'dates'  => ['required', 'array', 'min:1'],
            'dates.*'=> ['date'],
            'reason' => ['nullable', 'string', 'max:255'],
        ]);

        $this->availabilityService->blockDates($retreat->id, $request->dates, $request->reason ?? '');

        return back()->with('success', count($request->dates) . ' date(s) blocked successfully.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// BookingController
// ─────────────────────────────────────────────────────────────────────────────

class BookingController extends Controller
{
    public function __construct(
        private readonly \App\Repositories\BookingRepository $repository,
        private readonly \App\Services\BookingService        $bookingService,
        private readonly \App\Actions\Booking\ConfirmBookingAction $confirmAction,
        private readonly \App\Actions\Booking\CancelBookingAction  $cancelAction,
        private readonly \App\Actions\Booking\CheckInGuestAction   $checkInAction,
        private readonly \App\Actions\Booking\CheckOutGuestAction  $checkOutAction,
    ) {}

    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\Booking::class);

        $centerId = auth()->user()->center_id;
        $bookings = $this->repository->paginateForCenter(
            centerId: $centerId,
            filters:  $request->only(['stage', 'search', 'date_from', 'date_to', 'assigned_to', 'experience_id']),
            sortBy:   $request->get('sort', 'created_at'),
            sortDir:  $request->get('dir', 'desc'),
        );

        $stageCounts = $this->repository->stageCountsForCenter($centerId);
        $experiences = Experience::forCenter($centerId)->published()->orderBy('name')->get(['id', 'name']);
        $staff       = \App\Models\User::where('center_id', $centerId)->whereIn('center_role', ['owner','manager','staff'])->get(['id', 'first_name', 'last_name']);

        return view('bookings.index', compact('bookings', 'stageCounts', 'experiences', 'staff'));
    }

    public function show(\App\Models\Booking $booking): View
    {
        $this->authorize('view', $booking);

        $booking->load([
            'experience.center', 'userInfo', 'experienceInfo',
            'transactionInfo', 'addressInfo', 'promoCode',
            'assignedStaff', 'accommodation', 'couponRedemption',
        ]);

        $auditLogs = \App\Models\AuditLog::where('auditable_type', get_class($booking))
            ->where('auditable_id', $booking->id)
            ->latest()
            ->limit(20)
            ->get();

        return view('bookings.show', compact('booking', 'auditLogs'));
    }

    public function edit(\App\Models\Booking $booking): View
    {
        $this->authorize('update', $booking);

        $booking->load(['experience', 'userInfo', 'assignedStaff']);
        $staff = \App\Models\User::where('center_id', auth()->user()->center_id)->get(['id', 'first_name', 'last_name', 'center_role']);

        return view('bookings.edit', compact('booking', 'staff'));
    }

    public function update(\App\Http\Requests\Booking\UpdateBookingRequest $request, \App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $booking->update($request->validated());

        return back()->with('success', 'Booking updated successfully.');
    }

    public function confirm(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $this->confirmAction->handle($booking);

        return back()->with('success', "Booking {$booking->booking_reference} confirmed.");
    }

    public function checkIn(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('checkIn', $booking);

        $this->checkInAction->handle($booking);

        return back()->with('success', "Guest {$booking->guest_name} checked in successfully.");
    }

    public function checkOut(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('checkOut', $booking);

        $this->checkOutAction->handle($booking);

        return back()->with('success', "Guest {$booking->guest_name} checked out. Stay complete.");
    }

    public function cancel(\App\Http\Requests\Booking\CancelBookingRequest $request, \App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('cancel', $booking);

        $this->cancelAction->handle($booking, $request->reason, $request->boolean('process_refund'));

        return back()->with('success', "Booking {$booking->booking_reference} has been cancelled.");
    }

    public function assign(Request $request, \App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);
        $request->validate(['staff_id' => ['required', 'integer', 'exists:users,id']]);

        $this->bookingService->assignToStaff($booking, $request->staff_id);

        return back()->with('success', 'Booking assigned successfully.');
    }

    public function destroy(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('delete', $booking);
        $booking->delete();
        return redirect()->route('bookings.index')->with('success', 'Booking deleted.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// InquiryController
// ─────────────────────────────────────────────────────────────────────────────

class InquiryController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\Inquiry::class);

        $centerId = auth()->user()->center_id;

        $inquiries = \App\Models\Inquiry::where('center_id', $centerId)
            ->when($request->stage, fn($q, $s) => $q->forStage($s))
            ->when($request->search, fn($q, $term) =>
                $q->where('name', 'like', "%{$term}%")
                  ->orWhere('email', 'like', "%{$term}%")
                  ->orWhere('phone', 'like', "%{$term}%")
            )
            ->when($request->assigned_to, fn($q, $id) => $q->where('assigned_to', $id))
            ->with(['experience', 'assignedTo'])
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $stageCounts = \App\Models\Inquiry::where('center_id', $centerId)
            ->selectRaw('pipeline_stage as stage, COUNT(*) as count')
            ->groupBy('pipeline_stage')
            ->pluck('count', 'stage')
            ->toArray();

        $staff = \App\Models\User::where('center_id', $centerId)->get(['id', 'first_name', 'last_name']);

        return view('inquiries.index', compact('inquiries', 'stageCounts', 'staff'));
    }

    public function show(\App\Models\Inquiry $inquiry): View
    {
        $this->authorize('view', $inquiry);

        $inquiry->load(['experience', 'assignedTo', 'convertedBooking', 'center']);
        $messages = \App\Models\InquiryMessage::where('conversation_id', $inquiry->conversation_id)
            ->orderBy('created_at')
            ->get();

        return view('inquiries.show', compact('inquiry', 'messages'));
    }

    public function update(\App\Http\Requests\Inquiry\UpdateInquiryRequest $request, \App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('update', $inquiry);

        $data = $request->validated();

        if (isset($data['pipeline_stage']) && $data['pipeline_stage'] !== $inquiry->pipeline_stage) {
            $data['last_contacted_at'] = now();
            if ($data['pipeline_stage'] !== 'new') {
                $data['contact_attempts'] = $inquiry->contact_attempts + 1;
            }
        }

        $inquiry->update($data);

        return back()->with('success', 'Inquiry updated.');
    }

    public function reply(Request $request, \App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('update', $inquiry);
        $request->validate([
            'message' => ['required', 'string', 'min:1', 'max:5000'],
            'channel' => ['required', 'in:email,whatsapp,sms,internal_note'],
        ]);

        \App\Models\InquiryMessage::create([
            'inquiry_id'      => $inquiry->id,
            'conversation_id' => $inquiry->conversation_id,
            'sender_id'       => auth()->id(),
            'center_id'       => auth()->user()->center_id,
            'channel'         => $request->channel,
            'direction'       => 'outbound',
            'message'         => $request->message,
        ]);

        $inquiry->update(['last_contacted_at' => now()]);

        if ($request->channel === 'email') {
            \App\Jobs\SendEmailJob::dispatch(
                to:       $inquiry->email,
                name:     $inquiry->name,
                template: 'inquiry_reply',
                data:     ['name' => $inquiry->name, 'message' => $request->message]
            )->onQueue('emails');
        } elseif ($request->channel === 'whatsapp' && $inquiry->phone) {
            \App\Jobs\SendWhatsAppJob::dispatch(
                phone:    $inquiry->phone,
                template: 'inquiry_reply',
                params:   [$inquiry->name, $request->message]
            )->onQueue('notifications');
        }

        return back()->with('success', 'Reply sent successfully.');
    }

    public function destroy(\App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('delete', $inquiry);
        $inquiry->delete();
        return redirect()->route('inquiries.index')->with('success', 'Inquiry deleted.');
    }

    public function convert(\App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('update', $inquiry);
        return redirect()->route('bookings.create', ['inquiry_id' => $inquiry->id]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TeacherController
// ─────────────────────────────────────────────────────────────────────────────

class TeacherController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\Teacher::class);

        $teachers = \App\Models\Teacher::whereHas('centers', fn($q) => $q->where('centers.id', auth()->user()->center_id))
            ->when($request->search, fn($q, $term) => $q->where('name', 'like', "%{$term}%"))
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->with(['imageGallery' => fn($q) => $q->limit(1)])
            ->withCount('experiences')
            ->orderBy('name')
            ->paginate(15)
            ->withQueryString();

        return view('teachers.index', compact('teachers'));
    }

    public function create(): View
    {
        $this->authorize('create', \App\Models\Teacher::class);

        $expertises   = \App\Models\Expertise::orderBy('name')->get();
        $certificates = \App\Models\Certificate::orderBy('name')->get();

        return view('teachers.create', compact('expertises', 'certificates'));
    }

    public function store(\App\Http\Requests\Teacher\StoreTeacherRequest $request): RedirectResponse
    {
        $data    = $request->validated();
        $teacher = \App\Models\Teacher::create($data);

        $teacher->centers()->attach(auth()->user()->center_id);

        return redirect()->route('teachers.show', $teacher)->with('success', 'Teacher profile created.');
    }

    public function show(\App\Models\Teacher $teacher): View
    {
        $this->authorize('view', $teacher);

        $teacher->load(['imageGallery', 'experiences' => fn($q) => $q->forCenter(auth()->user()->center_id), 'centers']);

        return view('teachers.show', compact('teacher'));
    }

    public function edit(\App\Models\Teacher $teacher): View
    {
        $this->authorize('update', $teacher);

        $expertises   = \App\Models\Expertise::orderBy('name')->get();
        $certificates = \App\Models\Certificate::orderBy('name')->get();

        return view('teachers.edit', compact('teacher', 'expertises', 'certificates'));
    }

    public function update(\App\Http\Requests\Teacher\UpdateTeacherRequest $request, \App\Models\Teacher $teacher): RedirectResponse
    {
        $this->authorize('update', $teacher);

        $teacher->update($request->validated());

        return redirect()->route('teachers.show', $teacher)->with('success', 'Teacher profile updated.');
    }

    public function destroy(\App\Models\Teacher $teacher): RedirectResponse
    {
        $this->authorize('delete', $teacher);

        $teacher->centers()->detach(auth()->user()->center_id);

        return redirect()->route('teachers.index')->with('success', 'Teacher removed from your center.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PricingController
// ─────────────────────────────────────────────────────────────────────────────

class PricingController extends Controller
{
    public function __construct(private readonly \App\Services\PricingService $pricingService) {}

    public function rules(Request $request): View
    {
        $centerId = auth()->user()->center_id;
        $rules    = \App\Models\PricingRule::where('center_id', $centerId)
            ->when($request->experience_id, fn($q, $id) => $q->where('experience_id', $id))
            ->when($request->type, fn($q, $t) => $q->where('rule_type', $t))
            ->with('experience')
            ->orderByDesc('priority')
            ->paginate(20)
            ->withQueryString();

        $experiences = Experience::forCenter($centerId)->published()->orderBy('name')->get(['id', 'name']);

        return view('pricing.rules', compact('rules', 'experiences'));
    }

    public function storeRule(\App\Http\Requests\Pricing\StorePricingRuleRequest $request): RedirectResponse
    {
        $data              = $request->validated();
        $data['center_id'] = auth()->user()->center_id;

        \App\Models\PricingRule::create($data);

        return back()->with('success', 'Pricing rule created successfully.');
    }

    public function updateRule(\App\Http\Requests\Pricing\UpdatePricingRuleRequest $request, \App\Models\PricingRule $rule): RedirectResponse
    {
        $rule->update($request->validated());
        return back()->with('success', 'Pricing rule updated.');
    }

    public function destroyRule(\App\Models\PricingRule $rule): RedirectResponse
    {
        $rule->delete();
        return back()->with('success', 'Pricing rule deleted.');
    }

    public function promoCodes(Request $request): View
    {
        $centerId   = auth()->user()->center_id;
        $promoCodes = \App\Models\PromoCode::where('center_id', $centerId)
            ->when($request->search, fn($q, $term) => $q->where('code', 'like', "%{$term}%"))
            ->withCount('redemptions')
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $experiences = Experience::forCenter($centerId)->published()->orderBy('name')->get(['id','name']);

        return view('pricing.promo-codes', compact('promoCodes', 'experiences'));
    }

    public function storePromoCode(\App\Http\Requests\PromoCode\StorePromoCodeRequest $request): RedirectResponse
    {
        $data              = $request->validated();
        $data['center_id'] = auth()->user()->center_id;
        $data['code']      = strtoupper($data['code']);

        \App\Models\PromoCode::create($data);

        return back()->with('success', "Promo code {$data['code']} created successfully.");
    }

    public function updatePromoCode(\App\Http\Requests\PromoCode\UpdatePromoCodeRequest $request, \App\Models\PromoCode $promoCode): RedirectResponse
    {
        $promoCode->update($request->validated());
        return back()->with('success', 'Promo code updated.');
    }

    public function destroyPromoCode(\App\Models\PromoCode $promoCode): RedirectResponse
    {
        $promoCode->delete();
        return back()->with('success', 'Promo code deleted.');
    }

    public function calculatePrice(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'experience_id'  => ['required', 'integer', 'exists:experiences,id'],
            'base_price'     => ['required', 'numeric', 'min:0'],
            'currency'       => ['required', 'string'],
            'guest_count'    => ['nullable', 'integer', 'min:1'],
            'arrival_date'   => ['nullable', 'date'],
            'promo_code'     => ['nullable', 'string'],
        ]);

        $experience = Experience::findOrFail($request->experience_id);
        $dto        = new \App\DTOs\PricingDTO(
            experienceId:  $experience->id,
            basePrice:     (float) $request->base_price,
            currency:      $request->currency,
            guestCount:    (int) $request->get('guest_count', 1),
            occupancyRate: $experience->occupancy_rate,
            daysUntilStart:$request->arrival_date ? now()->diffInDays($request->arrival_date) : null,
            startDate:     $request->arrival_date ? \Carbon\Carbon::parse($request->arrival_date) : null,
            promoCode:     $request->promo_code,
        );

        return response()->json($this->pricingService->calculatePrice($dto));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AnalyticsController
// ─────────────────────────────────────────────────────────────────────────────

class AnalyticsController extends Controller
{
    public function __construct(
        private readonly \App\Services\AnalyticsService  $analyticsService,
        private readonly \App\Repositories\AnalyticsRepository $analyticsRepo,
    ) {}

    public function index(Request $request): View
    {
        $centerId = auth()->user()->center_id;
        $from     = $request->get('from', now()->startOfMonth()->toDateString());
        $to       = $request->get('to', today()->toDateString());
        $group    = $request->get('group', 'day');

        $kpis          = $this->analyticsService->getDashboardKpis($centerId, '30d');
        $revenueChart  = $this->analyticsService->getRevenueChart($centerId, $from, $to, $group);
        $bookingFunnel = $this->analyticsService->getBookingFunnel($centerId, $from, $to);
        $topRetreats   = $this->analyticsService->getTopRetreats($centerId, 10);
        $occupancyData = $this->analyticsService->getOccupancyByMonth($centerId, 6);
        $inquiriesBySource = $this->analyticsRepo->inquiriesBySource($centerId, $from, $to);
        $inquiriesByBudget = $this->analyticsRepo->inquiriesByBudget($centerId, $from, $to);
        $revenueByRetreat  = $this->analyticsRepo->revenueByRetreat($centerId, $from, $to);
        $guestCountries    = $this->analyticsRepo->bookingsByGuestCountry($centerId, $from, $to);

        return view('analytics.index', compact(
            'kpis', 'revenueChart', 'bookingFunnel', 'topRetreats',
            'occupancyData', 'inquiriesBySource', 'inquiriesByBudget',
            'revenueByRetreat', 'guestCountries', 'from', 'to', 'group'
        ));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FinanceController
// ─────────────────────────────────────────────────────────────────────────────

class FinanceController extends Controller
{
    public function index(Request $request): View
    {
        $centerId = auth()->user()->center_id;

        $bookings = \App\Models\Booking::forCenter($centerId)
            ->where('stage', 'completed')
            ->when($request->from, fn($q, $from) => $q->where('arrival_date', '>=', $from))
            ->when($request->to, fn($q, $to) => $q->where('arrival_date', '<=', $to))
            ->with(['experience', 'userInfo'])
            ->latest()
            ->paginate(25)
            ->withQueryString();

        $summary = [
            'gross_revenue'    => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('booking_amount'),
            'total_discounts'  => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('discount_amount'),
            'platform_commission' => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('commission_amount'),
            'net_revenue'      => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('pay_amount'),
        ];

        $payouts = \App\Models\PayoutRequest::where('center_id', $centerId)
            ->latest()
            ->limit(10)
            ->get();

        return view('finance.index', compact('bookings', 'summary', 'payouts'));
    }

    public function requestPayout(Request $request): RedirectResponse
    {
        $request->validate([
            'period_from' => ['required', 'date'],
            'period_to'   => ['required', 'date', 'after_or_equal:period_from'],
        ]);

        $center = auth()->user()->center;
        $payout = app(\App\Actions\Finance\CreatePayoutRequestAction::class)
            ->handle($center, $request->period_from, $request->period_to);

        return redirect()->route('finance.index')->with('success', "Payout request {$payout->reference} submitted.");
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MediaController
// ─────────────────────────────────────────────────────────────────────────────

class MediaController extends Controller
{
    public function __construct(private readonly \App\Services\MediaService $mediaService) {}

    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\MediaAsset::class);

        $centerId = auth()->user()->center_id;

        $assets = \App\Models\MediaAsset::where('center_id', $centerId)
            ->when($request->folder_id, fn($q, $id) => $q->where('folder_id', $id))
            ->when($request->type, fn($q, $type) => $q->where('media_type', $type))
            ->when($request->search, fn($q, $term) => $q->where('original_filename', 'like', "%{$term}%"))
            ->when($request->collection, fn($q, $col) => $q->where('collection', $col))
            ->orderBy('sort_order')
            ->orderByDesc('created_at')
            ->paginate(30)
            ->withQueryString();

        $folders = \App\Models\MediaFolder::where('center_id', $centerId)
            ->whereNull('parent_id')
            ->orderBy('name')
            ->get();

        $stats = [
            'total'    => \App\Models\MediaAsset::where('center_id', $centerId)->count(),
            'images'   => \App\Models\MediaAsset::where('center_id', $centerId)->where('media_type', 'image')->count(),
            'videos'   => \App\Models\MediaAsset::where('center_id', $centerId)->where('media_type', 'video')->count(),
            'total_mb' => round(\App\Models\MediaAsset::where('center_id', $centerId)->sum('size_bytes') / 1048576, 1),
        ];

        return view('media.index', compact('assets', 'folders', 'stats'));
    }

    public function store(\App\Http\Requests\Media\StoreMediaRequest $request): \Illuminate\Http\JsonResponse
    {
        $this->authorize('create', \App\Models\MediaAsset::class);

        $centerId = auth()->user()->center_id;
        $uploaded = [];

        $dto = new \App\DTOs\MediaUploadDTO(
            centerId:     $centerId,
            disk:         config('filesystems.default', 's3'),
            collection:   $request->get('collection', 'default'),
            folderId:     $request->folder_id,
            mediableType: $request->mediable_type,
            mediableId:   $request->mediable_id ? (int) $request->mediable_id : null,
            altText:      $request->alt_text,
            caption:      $request->caption,
            category:     $request->category,
        );

        foreach ($request->file('files') as $file) {
            $uploaded[] = $this->mediaService->upload($file, $dto);
        }

        return response()->json([
            'success' => true,
            'assets'  => $uploaded,
            'count'   => count($uploaded),
        ]);
    }

    public function update(\App\Http\Requests\Media\UpdateMediaRequest $request, \App\Models\MediaAsset $asset): \Illuminate\Http\JsonResponse
    {
        $this->authorize('update', $asset);

        $asset->update($request->validated());

        return response()->json(['success' => true, 'asset' => $asset->fresh()]);
    }

    public function destroy(\App\Models\MediaAsset $asset): \Illuminate\Http\JsonResponse
    {
        $this->authorize('delete', $asset);

        $this->mediaService->delete($asset);

        return response()->json(['success' => true]);
    }

    public function reorder(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate(['ids' => ['required', 'array'], 'ids.*' => ['integer']]);

        $this->mediaService->reorder($request->ids);

        return response()->json(['success' => true]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AiController
// ─────────────────────────────────────────────────────────────────────────────

class AiController extends Controller
{
    public function __construct(private readonly \App\Services\AiService $aiService) {}

    public function index(): View
    {
        $centerId = auth()->user()->center_id;
        $recs     = \App\Models\AiRecommendation::forCenter($centerId)
            ->active()
            ->with('experience')
            ->latest()
            ->paginate(20);

        return view('ai.index', compact('recs'));
    }

    public function generateContent(Request $request): \Illuminate\Http\JsonResponse
    {
        abort_unless(auth()->user()->center?->canUseFeature('ai'), 403, 'AI module not available on your plan.');

        $request->validate([
            'type'            => ['required', 'in:title,summary,description,seo_title,seo_desc,faqs,benefits,itinerary'],
            'retreat_type'    => ['required', 'string', 'max:100'],
            'experience_id'   => ['nullable', 'integer', 'exists:experiences,id'],
            'location'        => ['nullable', 'string', 'max:200'],
            'duration_nights' => ['nullable', 'integer'],
            'target_audience' => ['nullable', 'string', 'max:200'],
            'tone'            => ['nullable', 'in:luxury,spiritual,scientific,holistic,adventurous'],
        ]);

        $dto = new \App\DTOs\AiContentDTO(
            type:             $request->type,
            retreatType:      $request->retreat_type,
            centerId:         auth()->user()->center_id,
            experienceId:     $request->experience_id,
            location:         $request->location,
            durationNights:   $request->duration_nights,
            targetAudience:   $request->target_audience,
            tone:             $request->get('tone', 'luxury'),
        );

        $content = $this->aiService->generateContent($dto);

        return response()->json(['success' => true, 'content' => $content]);
    }

    public function generateSeo(Request $request): \Illuminate\Http\JsonResponse
    {
        abort_unless(auth()->user()->center?->canUseFeature('ai'), 403);

        $request->validate(['experience_id' => ['required', 'integer', 'exists:experiences,id']]);

        $experience = Experience::findOrFail($request->experience_id);
        $seo        = $this->aiService->generateSeoMetadata($experience);

        return response()->json(['success' => true, 'seo' => $seo]);
    }

    public function applyRecommendation(\App\Models\AiRecommendation $recommendation): RedirectResponse
    {
        app(\App\Actions\AI\ApplyAiRecommendationAction::class)->handle($recommendation);

        return back()->with('success', 'AI recommendation applied successfully.');
    }

    public function dismissRecommendation(\App\Models\AiRecommendation $recommendation): RedirectResponse
    {
        $recommendation->dismiss(auth()->id());
        return back()->with('success', 'Recommendation dismissed.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AutomationController
// ─────────────────────────────────────────────────────────────────────────────

class AutomationController extends Controller
{
    public function index(): View
    {
        $this->authorize('viewAny', \App\Models\AutomationRule::class);

        $centerId = auth()->user()->center_id;

        $rules = \App\Models\AutomationRule::where('center_id', $centerId)
            ->with(['emailTemplate', 'executions' => fn($q) => $q->latest()->limit(1)])
            ->withCount(['executions', 'executions as failed_count' => fn($q) => $q->where('status', 'failed')])
            ->orderByDesc('created_at')
            ->paginate(20);

        $emailTemplates   = \App\Models\EmailTemplate::where('center_id', $centerId)->where('is_active', true)->get();
        $triggerEvents    = $this->getTriggerEvents();

        return view('automations.index', compact('rules', 'emailTemplates', 'triggerEvents'));
    }

    public function store(\App\Http\Requests\Automation\StoreAutomationRuleRequest $request): RedirectResponse
    {
        $this->authorize('create', \App\Models\AutomationRule::class);

        $data              = $request->validated();
        $data['center_id'] = auth()->user()->center_id;

        \App\Models\AutomationRule::create($data);

        return back()->with('success', 'Automation rule created.');
    }

    public function update(\App\Http\Requests\Automation\UpdateAutomationRuleRequest $request, \App\Models\AutomationRule $automationRule): RedirectResponse
    {
        $this->authorize('update', $automationRule);

        $automationRule->update($request->validated());

        return back()->with('success', 'Automation rule updated.');
    }

    public function toggle(\App\Models\AutomationRule $automationRule): RedirectResponse
    {
        $this->authorize('update', $automationRule);

        $automationRule->update(['is_active' => ! $automationRule->is_active]);

        $status = $automationRule->fresh()->is_active ? 'enabled' : 'disabled';
        return back()->with('success', "Automation rule {$status}.");
    }

    public function destroy(\App\Models\AutomationRule $automationRule): RedirectResponse
    {
        $this->authorize('delete', $automationRule);

        $automationRule->delete();
        return back()->with('success', 'Automation rule deleted.');
    }

    public function executions(\App\Models\AutomationRule $automationRule): View
    {
        $executions = $automationRule->executions()->latest()->paginate(30);
        return view('automations.executions', compact('automationRule', 'executions'));
    }

    protected function getTriggerEvents(): array
    {
        return [
            'booking.confirmed'    => 'When a Booking is Confirmed',
            'booking.cancelled'    => 'When a Booking is Cancelled',
            'booking.checked_in'   => 'When a Guest Checks In',
            'booking.completed'    => 'When a Guest Checks Out',
            'booking.upcoming_3d'  => '3 Days Before Retreat Starts',
            'booking.upcoming_7d'  => '7 Days Before Retreat Starts',
            'inquiry.received'     => 'When a New Inquiry is Received',
            'inquiry.no_reply_24h' => 'When an Inquiry Has No Reply for 24h',
            'review.submitted'     => 'When a Review is Submitted',
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ReviewController
// ─────────────────────────────────────────────────────────────────────────────

class ReviewController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\CenterReview::class);

        $centerId = auth()->user()->center_id;
        $reviews  = \App\Models\CenterReview::where('center_id', $centerId)
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->rating, fn($q, $r) => $q->where('overall_rating', '>=', $r))
            ->with(['experience', 'response', 'user'])
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $stats = [
            'avg_rating'   => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'approved')->avg('overall_rating') ?? 0,
            'total'        => \App\Models\CenterReview::where('center_id', $centerId)->count(),
            'pending'      => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'pending')->count(),
            'approved'     => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'approved')->count(),
        ];

        return view('reviews.index', compact('reviews', 'stats'));
    }

    public function approve(\App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('approve', $review);

        $review->approve(auth()->id());

        return back()->with('success', 'Review approved and published.');
    }

    public function reject(Request $request, \App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('approve', $review);
        $request->validate(['reason' => ['required', 'string', 'min:5', 'max:500']]);

        $review->reject($request->reason, auth()->id());

        return back()->with('success', 'Review rejected.');
    }

    public function respond(Request $request, \App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('respond', $review);
        $request->validate(['response' => ['required', 'string', 'min:10', 'max:2000']]);

        \App\Models\ReviewResponse::updateOrCreate(
            ['review_id' => $review->id],
            ['responded_by' => auth()->id(), 'response' => $request->response, 'responded_at' => now()]
        );

        return back()->with('success', 'Response published.');
    }

    public function destroy(\App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('delete', $review);

        $review->delete();
        return back()->with('success', 'Review deleted.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SettingsController
// ─────────────────────────────────────────────────────────────────────────────

class SettingsController extends Controller
{
    public function centerProfile(): View
    {
        $center = auth()->user()->center;
        $this->authorize('update', $center);

        $centerTypes  = \App\Models\CenterType::orderBy('name')->get();
        $certificates = \App\Models\Certificate::orderBy('name')->get();
        $amenities    = \App\Models\Amenities::orderBy('name')->get();

        return view('settings.center-profile', compact('center', 'centerTypes', 'certificates', 'amenities'));
    }

    public function updateCenterProfile(\App\Http\Requests\Center\UpdateCenterRequest $request): RedirectResponse
    {
        $center = auth()->user()->center;
        $this->authorize('update', $center);

        $center->update($request->validated());

        return back()->with('success', 'Center profile updated successfully.');
    }

    public function team(): View
    {
        $center = auth()->user()->center;
        $staff  = \App\Models\User::where('center_id', $center->id)->with('roles')->orderBy('first_name')->get();

        return view('settings.team', compact('center', 'staff'));
    }

    public function emailTemplates(): View
    {
        $centerId  = auth()->user()->center_id;
        $templates = \App\Models\EmailTemplate::where(fn($q) => $q->where('center_id', $centerId)->orWhereNull('center_id'))
            ->orderBy('name')
            ->get();

        return view('settings.email-templates', compact('templates'));
    }

    public function preferences(): View
    {
        $prefs = auth()->user()->preferences ?? new \App\Models\UserPreference();
        return view('settings.preferences', compact('prefs'));
    }

    public function updatePreferences(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'timezone'              => ['required', 'string', 'timezone'],
            'locale'                => ['required', 'string'],
            'currency'              => ['required', 'string', 'size:3'],
            'email_notifications'   => ['boolean'],
            'whatsapp_notifications'=> ['boolean'],
            'browser_notifications' => ['boolean'],
        ]);

        auth()->user()->preferences()->updateOrCreate(
            ['user_id' => auth()->id()],
            $data
        );

        return back()->with('success', 'Preferences saved.');
    }

    public function subscription(): View
    {
        $center = auth()->user()->center;
        $plans  = \App\Models\SubscriptionPlan::where('is_active', true)->orderBy('sort_order')->get();

        return view('settings.subscription', compact('center', 'plans'));
    }
}
