<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

// ─────────────────────────────────────────────────────────────────────────────
// Admin Dashboard
// ─────────────────────────────────────────────────────────────────────────────

class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_centers'      => Center::count(),
            'active_centers'     => Center::where('status', 'active')->count(),
            'total_users'        => User::count(),
            'mrr'                => DB::table('center_subscriptions')
                                     ->join('subscription_plans', 'center_subscriptions.plan_id', '=', 'subscription_plans.id')
                                     ->where('center_subscriptions.status', 'active')
                                     ->sum('subscription_plans.price'),
            'new_centers_month'  => Center::whereBetween('created_at', [now()->startOfMonth(), now()])->count(),
            'churned_month'      => Center::whereBetween('cancelled_at', [now()->startOfMonth(), now()])->count(),
        ];

        $recentCenters    = Center::with('owner', 'subscription.plan')->latest()->take(5)->get();
        $recentUsers      = User::latest()->take(5)->get();
        $planDistribution = DB::table('center_subscriptions')
            ->join('subscription_plans', 'center_subscriptions.plan_id', '=', 'subscription_plans.id')
            ->where('center_subscriptions.status', 'active')
            ->select('subscription_plans.name', DB::raw('count(*) as count'))
            ->groupBy('subscription_plans.id', 'subscription_plans.name')
            ->get();

        return view('admin.dashboard', compact('stats', 'recentCenters', 'recentUsers', 'planDistribution'));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin: Centers
// ─────────────────────────────────────────────────────────────────────────────

class AdminCenterController extends Controller
{
    public function index(Request $request)
    {
        $centers = Center::with('owner', 'subscription.plan')
            ->when($request->search, fn($q) => $q->where('name', 'like', "%{$request->search}%"))
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->plan,   fn($q) => $q->whereHas('subscription', fn($s) => $s->where('plan_id', $request->plan)))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $plans = SubscriptionPlan::all();

        return view('admin.centers.index', compact('centers', 'plans'));
    }

    public function show(Center $center)
    {
        $center->load(['owner', 'subscription.plan', 'experiences', 'users']);

        $stats = [
            'bookings'  => $center->bookings()->count(),
            'revenue'   => $center->bookings()->sum('total_price'),
            'retreats'  => $center->experiences()->count(),
        ];

        return view('admin.centers.show', compact('center', 'stats'));
    }

    public function suspend(Request $request, Center $center)
    {
        $center->update(['status' => 'suspended', 'suspended_at' => now(), 'suspend_reason' => $request->reason]);

        // Notify owner
        $center->owner->notify(new \App\Notifications\CenterSuspendedNotification($request->reason));

        return back()->with('success', "Center '{$center->name}' suspended.");
    }

    public function reinstate(Center $center)
    {
        $center->update(['status' => 'active', 'suspended_at' => null, 'suspend_reason' => null]);

        return back()->with('success', "Center '{$center->name}' reinstated.");
    }

    public function impersonate(Center $center)
    {
        session(['impersonating' => auth()->id()]);
        auth()->login($center->owner);

        return redirect()->route('dashboard');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin: Subscription Plans
// ─────────────────────────────────────────────────────────────────────────────

class AdminPlanController extends Controller
{
    public function index()
    {
        $plans = SubscriptionPlan::withCount('activeSubscriptions')->get();
        return view('admin.plans.index', compact('plans'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'          => ['required', 'string', 'max:50'],
            'slug'          => ['required', 'string', 'unique:subscription_plans'],
            'price'         => ['required', 'numeric', 'min:0'],
            'billing_cycle' => ['required', 'in:monthly,annually'],
            'features'      => ['required', 'array'],
            'limits'        => ['required', 'array'],
            'is_active'     => ['boolean'],
        ]);

        SubscriptionPlan::create($data);

        return back()->with('success', 'Plan created.');
    }

    public function update(Request $request, SubscriptionPlan $plan)
    {
        $plan->update($request->validate([
            'name'      => ['required', 'string'],
            'price'     => ['required', 'numeric'],
            'features'  => ['nullable', 'array'],
            'limits'    => ['nullable', 'array'],
            'is_active' => ['boolean'],
        ]));

        return back()->with('success', 'Plan updated.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin: Users
// ─────────────────────────────────────────────────────────────────────────────

class AdminUserController extends Controller
{
    public function index(Request $request)
    {
        $users = User::with('roles', 'center')
            ->when($request->search, fn($q) => $q->where(fn($q) =>
                $q->where('first_name', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%")
            ))
            ->when($request->role, fn($q) => $q->whereHas('roles', fn($r) => $r->where('name', $request->role)))
            ->latest()
            ->paginate(25)
            ->withQueryString();

        $roles = Role::all();

        return view('admin.users.index', compact('users', 'roles'));
    }

    public function show(User $user)
    {
        $user->load(['roles', 'center', 'notifications']);
        return view('admin.users.show', compact('user'));
    }

    public function ban(Request $request, User $user)
    {
        $user->update(['banned_at' => now(), 'ban_reason' => $request->reason]);
        return back()->with('success', 'User banned.');
    }

    public function unban(User $user)
    {
        $user->update(['banned_at' => null, 'ban_reason' => null]);
        return back()->with('success', 'User unbanned.');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin: Audit Log
// ─────────────────────────────────────────────────────────────────────────────

class AdminAuditController extends Controller
{
    public function index(Request $request)
    {
        $logs = DB::table('audit_logs')
            ->join('users', 'audit_logs.user_id', '=', 'users.id')
            ->select('audit_logs.*', DB::raw("CONCAT(users.first_name, ' ', users.last_name) as user_name"), 'users.email')
            ->when($request->event,   fn($q) => $q->where('audit_logs.event', $request->event))
            ->when($request->user_id, fn($q) => $q->where('audit_logs.user_id', $request->user_id))
            ->latest('audit_logs.created_at')
            ->paginate(50)
            ->withQueryString();

        return view('admin.audit.index', compact('logs'));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin: Platform Settings
// ─────────────────────────────────────────────────────────────────────────────

class AdminSettingsController extends Controller
{
    public function index()
    {
        $settings = DB::table('system_settings')->pluck('value', 'key');
        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        foreach ($request->except('_token', '_method') as $key => $value) {
            DB::table('system_settings')
                ->updateOrInsert(['key' => $key], ['value' => $value, 'updated_at' => now()]);
        }

        return back()->with('success', 'Platform settings saved.');
    }
}
