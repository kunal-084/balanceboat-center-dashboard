<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller
{
    public function index(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();

        $notifications = $user->notifications()
            ->latest()
            ->paginate(20);

        return view('notifications.index', compact('notifications'));
    }

    public function markRead(Request $request, string $id)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();

        $notification = $user->notifications()->findOrFail($id);
        $notification->markAsRead();

        if ($request->wantsJson()) {
            return response()->json(['ok' => true]);
        }

        return back();
    }

    public function markAllRead(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();
        $user->unreadNotifications->markAsRead();

        if ($request->wantsJson()) {
            return response()->json(['ok' => true]);
        }

        return back()->with('success', 'All notifications marked as read.');
    }

    public function destroy(Request $request, string $id)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();

        $user->notifications()->findOrFail($id)->delete();

        if ($request->wantsJson()) {
            return response()->json(['ok' => true]);
        }

        return back();
    }

    public function clearAll(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();
        $user->notifications()->delete();

        return back()->with('success', 'All notifications cleared.');
    }

    /**
     * AJAX polling endpoint — returns unread count + latest 5.
     */
    public function poll(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();

        $unread = $user->unreadNotifications()
            ->latest()
            ->take(5)
            ->get()
            ->map(fn($n) => [
                'id'      => $n->id,
                'type'    => class_basename($n->type),
                'title'   => $n->data['title'] ?? 'Notification',
                'body'    => $n->data['body']  ?? '',
                'url'     => $n->data['url']   ?? null,
                'icon'    => $n->data['icon']  ?? '🔔',
                'time'    => $n->created_at->diffForHumans(),
            ]);

        return response()->json([
            'count'         => $user->unreadNotifications()->count(),
            'notifications' => $unread,
        ]);
    }
}
