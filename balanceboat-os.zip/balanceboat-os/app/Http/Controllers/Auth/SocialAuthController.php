<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;

class SocialAuthController extends Controller
{
    private const ALLOWED_PROVIDERS = ['google', 'facebook'];

    public function redirect(string $provider)
    {
        $this->validateProvider($provider);

        return Socialite::driver($provider)
            ->scopes($this->scopesFor($provider))
            ->redirect();
    }

    public function callback(string $provider)
    {
        $this->validateProvider($provider);

        try {
            $socialUser = Socialite::driver($provider)->user();
        } catch (\Exception) {
            return redirect()->route('login')->withErrors(['email' => 'Social login failed. Please try again.']);
        }

        $user = $this->findOrCreateUser($provider, $socialUser);

        Auth::login($user, remember: true);

        $user->update([
            'last_login_at' => now(),
            'last_login_ip' => request()->ip(),
        ]);

        return redirect()->intended(route('dashboard'));
    }

    private function findOrCreateUser(string $provider, mixed $socialUser): User
    {
        // Try to find by provider ID first
        $user = User::where("social_{$provider}_id", $socialUser->getId())->first();

        if ($user) {
            // Sync latest avatar if changed
            $user->update(['avatar' => $socialUser->getAvatar()]);
            return $user;
        }

        // Try to find by email (merge accounts)
        $user = User::where('email', $socialUser->getEmail())->first();

        if ($user) {
            $user->update([
                "social_{$provider}_id" => $socialUser->getId(),
                'avatar'                => $user->avatar ?? $socialUser->getAvatar(),
                'email_verified_at'     => $user->email_verified_at ?? now(),
            ]);
            return $user;
        }

        // Create new user
        [$firstName, $lastName] = $this->splitName($socialUser->getName());

        $user = User::create([
            'first_name'              => $firstName,
            'last_name'               => $lastName,
            'email'                   => $socialUser->getEmail(),
            'password'                => bcrypt(Str::random(32)),
            'avatar'                  => $socialUser->getAvatar(),
            "social_{$provider}_id"   => $socialUser->getId(),
            'email_verified_at'       => now(),
        ]);

        $user->assignRole('center-owner');

        return $user;
    }

    private function validateProvider(string $provider): void
    {
        if (! in_array($provider, self::ALLOWED_PROVIDERS, true)) {
            abort(404, "Provider '{$provider}' is not supported.");
        }
    }

    private function scopesFor(string $provider): array
    {
        return match ($provider) {
            'google'   => ['openid', 'profile', 'email'],
            'facebook' => ['email', 'public_profile'],
            default    => [],
        };
    }

    private function splitName(?string $name): array
    {
        if (! $name) {
            return ['Guest', ''];
        }
        $parts = explode(' ', trim($name), 2);
        return [$parts[0], $parts[1] ?? ''];
    }
}
