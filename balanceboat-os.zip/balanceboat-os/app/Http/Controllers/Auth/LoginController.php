<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\OtpService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

class LoginController extends Controller
{
    public function __construct(private OtpService $otpService) {}

    public function showLogin()
    {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        }

        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $this->ensureNotRateLimited($request);

        if (! Auth::attempt($request->only('email', 'password'), $request->boolean('remember'))) {
            RateLimiter::hit($this->throttleKey($request));

            throw ValidationException::withMessages([
                'email' => __('auth.failed'),
            ]);
        }

        RateLimiter::clear($this->throttleKey($request));
        $request->session()->regenerate();

        /** @var User $user */
        $user = Auth::user();
        $user->update(['last_login_at' => now(), 'last_login_ip' => $request->ip()]);

        // Check if 2FA is enabled
        if ($user->two_factor_enabled) {
            Auth::logout();
            $request->session()->put('login.id', $user->id);
            return redirect()->route('auth.otp');
        }

        return redirect()->intended($this->redirectTo($user));
    }

    /**
     * Handle OTP-only (passwordless) login — sends OTP then redirects.
     */
    public function sendOtpLogin(Request $request)
    {
        $request->validate(['email' => ['required', 'email', 'exists:users,email']]);

        $user = User::where('email', $request->email)->firstOrFail();
        $this->otpService->sendLoginOtp($user);

        $request->session()->put('login.id', $user->id);

        return redirect()->route('auth.otp')->with('info', 'OTP sent to ' . $user->email);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }

    private function redirectTo(User $user): string
    {
        if ($user->hasRole('super-admin') || $user->hasRole('balanceboat-admin')) {
            return route('admin.dashboard');
        }

        return route('dashboard');
    }

    private function ensureNotRateLimited(Request $request): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey($request), 5)) {
            return;
        }

        $seconds = RateLimiter::availableIn($this->throttleKey($request));

        throw ValidationException::withMessages([
            'email' => __('auth.throttle', [
                'seconds' => $seconds,
                'minutes' => ceil($seconds / 60),
            ]),
        ]);
    }

    private function throttleKey(Request $request): string
    {
        return strtolower($request->email) . '|' . $request->ip();
    }
}
