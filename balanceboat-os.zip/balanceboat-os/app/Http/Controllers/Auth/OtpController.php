<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\OtpService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OtpController extends Controller
{
    public function __construct(private OtpService $otpService) {}

    public function showOtp(Request $request)
    {
        if (! $request->session()->has('login.id')) {
            return redirect()->route('login');
        }

        $user = User::findOrFail($request->session()->get('login.id'));

        return view('auth.otp', [
            'maskedEmail' => $this->maskEmail($user->email),
        ]);
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => ['required', 'string', 'digits:6'],
        ]);

        $userId = $request->session()->get('login.id');

        if (! $userId) {
            return redirect()->route('login')->withErrors(['otp' => 'Session expired. Please log in again.']);
        }

        $user = User::findOrFail($userId);

        if (! $this->otpService->verify($user, $request->otp)) {
            return back()->withErrors(['otp' => 'Invalid or expired code. Please try again.']);
        }

        $request->session()->forget('login.id');
        $request->session()->regenerate();

        Auth::login($user, remember: $request->session()->pull('login.remember', false));

        $user->update([
            'last_login_at' => now(),
            'last_login_ip' => $request->ip(),
        ]);

        return redirect()->intended(route('dashboard'));
    }

    public function resendOtp(Request $request)
    {
        $userId = $request->session()->get('login.id');

        if (! $userId) {
            return response()->json(['error' => 'Session expired'], 400);
        }

        $user = User::findOrFail($userId);
        $this->otpService->sendLoginOtp($user);

        return back()->with('info', 'A new code has been sent to your email.');
    }

    private function maskEmail(string $email): string
    {
        [$local, $domain] = explode('@', $email);
        $masked = substr($local, 0, 2) . str_repeat('*', max(0, strlen($local) - 2));
        return $masked . '@' . $domain;
    }
}
