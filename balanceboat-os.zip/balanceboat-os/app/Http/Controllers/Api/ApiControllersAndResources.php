<?php
// ============================================================
// API RESOURCES
// ============================================================

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class ExperienceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'name'            => $this->name,
            'slug'            => $this->slug,
            'status'          => $this->status_label,
            'publish_status'  => $this->publish_status,
            'summary'         => $this->experience_summary,
            'price_per_person'=> (float) $this->price_per_person,
            'currency'        => $this->currency,
            'duration_nights' => $this->duration_nights,
            'batch_size'      => $this->batch_size,
            'occupancy_rate'  => $this->occupancy_rate,
            'average_rating'  => (float) $this->average_rating,
            'review_count'    => $this->review_count,
            'is_bookable'     => $this->is_bookable,
            'is_featured'     => $this->is_featured,
            'start_date_time' => $this->start_date_time?->toIso8601String(),
            'end_date_time'   => $this->end_date_time?->toIso8601String(),
            'food'            => $this->food,
            'skill_level'     => $this->skill_level,
            'language_spoken' => $this->language_spoken,
            'banner_image_url'=> $this->banner_image_url,
            'thumbnail_image_url'=> $this->thumbnail_image_url,
            'video_url'       => $this->video_url,
            'has_early_bird'  => $this->has_early_bird,
            'early_bird_deadline' => $this->early_bird_deadline?->toDateString(),
            'early_bird_discount' => $this->eirly_bird_discount,
            'gps'             => $this->gps,
            'meta_title'      => $this->meta_title,
            'meta_description'=> $this->meta_description,
            'center'          => $this->whenLoaded('center', fn() => new CenterResource($this->center)),
            'categories'      => $this->whenLoaded('categories', fn() => CategoryResource::collection($this->categories)),
            'teachers'        => $this->whenLoaded('teachers', fn() => TeacherResource::collection($this->teachers)),
            'accommodations'  => $this->whenLoaded('accommodations', fn() => AccommodationResource::collection($this->accommodations)),
            'faqs'            => $this->whenLoaded('faqs', fn() => FaqResource::collection($this->faqs)),
            'benefits'        => $this->whenLoaded('benefits', fn() => $this->benefits->pluck('benefit')),
            'itinerary_days'  => $this->whenLoaded('itineraryDays', fn() => ItineraryDayResource::collection($this->itineraryDays)),
            'image_gallery'   => $this->whenLoaded('imageGallery', fn() => $this->imageGallery->map(fn($img) => ['url' => $img->image_url, 'title' => $img->image_title])),
            'pricing_rules'   => $this->whenLoaded('pricingRules', fn() => PricingRuleResource::collection($this->pricingRules)),
            'created_at'      => $this->created_at->toIso8601String(),
            'updated_at'      => $this->updated_at->toIso8601String(),
        ];
    }
}

class CenterResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'name'            => $this->name,
            'slug'            => $this->slug,
            'status'          => $this->status,
            'about'           => $this->about_center,
            'philosophy'      => $this->our_philosophy,
            'location'        => $this->location,
            'city'            => $this->city,
            'country'         => $this->country,
            'gps'             => $this->gps,
            'latitude'        => $this->latitude,
            'longitude'       => $this->longitude,
            'email'           => $this->email_address,
            'phone'           => $this->contact_number,
            'whatsapp'        => $this->whatsapp_number,
            'website'         => $this->website,
            'banner_image_url'=> $this->banner_image_url,
            'video_url'       => $this->video_url,
            'have_accommodation'=> $this->have_accomodation,
            'average_rating'  => $this->average_rating,
            'is_verified'     => $this->is_verified,
            'is_featured'     => $this->is_featured,
            'social'          => [
                'facebook'  => $this->facebook_url,
                'instagram' => $this->instagram_url,
                'youtube'   => $this->youtube_url,
                'twitter'   => $this->twitter_url,
            ],
            'meta_title'      => $this->meta_title,
            'meta_description'=> $this->meta_description,
            'created_at'      => $this->created_at?->toIso8601String(),
        ];
    }
}

class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                => $this->id,
            'reference'         => $this->booking_reference,
            'stage'             => $this->stage,
            'stage_label'       => $this->stage_label,
            'stage_color'       => $this->stage_color,
            'guest_count'       => $this->guest_count,
            'arrival_date'      => $this->arrival_date?->toDateString(),
            'start_date_time'   => $this->start_date_time?->toIso8601String(),
            'end_date_time'     => $this->end_date_time?->toIso8601String(),
            'check_in_at'       => $this->check_in_at?->toIso8601String(),
            'check_out_at'      => $this->check_out_at?->toIso8601String(),
            'currency'          => $this->currency,
            'booking_amount'    => (float) $this->booking_amount,
            'discount_amount'   => (float) $this->discount_amount,
            'commission_amount' => (float) $this->commission_amount,
            'pay_amount'        => (float) $this->pay_amount,
            'net_amount'        => $this->net_amount,
            'payment_status'    => $this->payment_status,
            'order_status'      => $this->order_status,
            'internal_notes'    => $this->when($request->user()?->center_id, $this->internal_notes),
            'allowed_transitions'=> \App\Models\Booking::ALLOWED_TRANSITIONS[$this->stage] ?? [],
            'experience'        => $this->whenLoaded('experience', fn() => new ExperienceResource($this->experience)),
            'guest'             => $this->whenLoaded('userInfo', fn() => [
                'name'    => $this->userInfo->firstname . ' ' . $this->userInfo->lastname,
                'email'   => $this->userInfo->email,
                'phone'   => $this->userInfo->phone,
                'message' => $this->userInfo->message,
            ]),
            'assigned_staff'    => $this->whenLoaded('assignedStaff', fn() => [
                'id'   => $this->assignedStaff->id,
                'name' => $this->assignedStaff->full_name,
            ]),
            'created_at'        => $this->created_at->toIso8601String(),
        ];
    }
}

class TeacherResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'name'            => $this->name,
            'slug'            => $this->slug,
            'short_bio'       => $this->short_description,
            'teaching_since'  => $this->teaching_since,
            'years_experience'=> $this->full_years_experience,
            'languages'       => $this->languages,
            'nationality'     => $this->nationality,
            'status'          => $this->status,
            'is_featured'     => $this->is_featured,
            'is_verified'     => $this->is_verified,
            'average_rating'  => (float) $this->average_rating,
            'total_reviews'   => $this->total_reviews,
            'profile_image_url'=> $this->profile_image_url,
            'social'          => [
                'website'   => $this->website_url,
                'instagram' => $this->instagram_url,
                'facebook'  => $this->facebook_url,
                'youtube'   => $this->youtube_url,
            ],
            'created_at'      => $this->created_at?->toIso8601String(),
        ];
    }
}

class AccommodationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                    => $this->id,
            'title'                 => $this->title ?? $this->when($this->accomodation, $this->accomodation?->name),
            'about'                 => $this->about,
            'max_guests'            => $this->max_guest_in_room,
            'is_default'            => (bool) $this->accomodation_default,
            'price_per_night'       => (float) $this->price_per_night_per_guest,
            'currency'              => $this->currency,
            'price_single_occupancy'=> (float) ($this->price_single_occupancy ?? 0),
            'price_double_occupancy'=> (float) ($this->price_double_occupancy ?? 0),
            'price_twin_sharing'    => (float) ($this->price_twin_sharing ?? 0),
        ];
    }
}

class PricingRuleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'type'          => $this->rule_type,
            'discount_type' => $this->discount_type,
            'discount_value'=> (float) $this->discount_value,
            'is_stackable'  => $this->is_stackable,
            'priority'      => $this->priority,
            'start_date'    => $this->start_date?->toDateString(),
            'end_date'      => $this->end_date?->toDateString(),
            'is_active'     => $this->is_active,
        ];
    }
}

class InquiryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'             => $this->id,
            'name'           => $this->full_name,
            'email'          => $this->email,
            'phone'          => $this->phone,
            'whatsapp'       => $this->whatsapp,
            'message'        => $this->message,
            'retreat_type'   => $this->retreat_type,
            'destination'    => $this->destination,
            'budget'         => $this->budget,
            'timeline'       => $this->timeline,
            'pipeline_stage' => $this->pipeline_stage,
            'stage_color'    => $this->stage_color,
            'follow_up_at'   => $this->follow_up_at?->toIso8601String(),
            'created_at'     => $this->created_at->toIso8601String(),
            'experience'     => $this->whenLoaded('experience', fn() => ['id' => $this->experience->id, 'name' => $this->experience->name]),
        ];
    }
}

class CategoryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return ['id' => $this->id, 'name' => $this->name, 'slug' => $this->slug, 'image_url' => $this->image_url];
    }
}

class FaqResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return ['id' => $this->id, 'question' => $this->question, 'answer' => $this->answer, 'sort_order' => $this->sort_order];
    }
}

class ItineraryDayResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'day_number' => $this->day_number,
            'title'      => $this->title,
            'description'=> $this->description,
            'theme'      => $this->theme,
            'sessions'   => $this->whenLoaded('sessions', fn() => $this->sessions->map(fn($s) => [
                'id'          => $s->id,
                'start_time'  => $s->start_time,
                'end_time'    => $s->end_time,
                'activity'    => $s->activity,
                'description' => $s->description,
                'type'        => $s->session_type,
                'location'    => $s->location,
                'is_optional' => $s->is_optional,
            ])),
        ];
    }
}

// ============================================================
// API CONTROLLERS
// ============================================================

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\{ExperienceResource, BookingResource, CenterResource, TeacherResource, InquiryResource};
use App\Models\{Experience, Booking, Center, Teacher, Inquiry};
use App\Repositories\{ExperienceRepository, BookingRepository};
use App\Services\{BookingService, PricingService};
use Illuminate\Http\{JsonResponse, Request};

class ApiExperienceController extends Controller
{
    public function __construct(private readonly ExperienceRepository $repository) {}

    public function index(Request $request): JsonResponse
    {
        $centerId  = auth()->user()->center_id;
        $retreats  = $this->repository->paginateForCenter(
            centerId: $centerId,
            filters:  $request->only(['status', 'search', 'category_id']),
            perPage:  $request->get('per_page', 15),
        );

        return response()->json([
            'data' => ExperienceResource::collection($retreats->items()),
            'meta' => [
                'current_page' => $retreats->currentPage(),
                'last_page'    => $retreats->lastPage(),
                'total'        => $retreats->total(),
                'per_page'     => $retreats->perPage(),
            ],
        ]);
    }

    public function show(Experience $experience): JsonResponse
    {
        $this->authorize('view', $experience);

        $experience->load(['center', 'categories', 'teachers', 'accommodations', 'faqs', 'benefits', 'itineraryDays.sessions', 'pricingRules']);

        return response()->json(new ExperienceResource($experience));
    }

    public function store(\App\Http\Requests\Retreat\StoreRetreatRequest $request): JsonResponse
    {
        $dto      = \App\DTOs\RetreatDTO::fromRequest($request, auth()->user()->center_id);
        $retreat  = app(\App\Actions\Retreat\CreateRetreatAction::class)->handle($dto);

        return response()->json(new ExperienceResource($retreat), 201);
    }

    public function update(\App\Http\Requests\Retreat\UpdateRetreatRequest $request, Experience $experience): JsonResponse
    {
        $this->authorize('update', $experience);

        app(\App\Actions\Retreat\UpdateRetreatAction::class)->handle($experience, $request->validated());

        return response()->json(new ExperienceResource($experience->fresh(['categories', 'teachers'])));
    }

    public function destroy(Experience $experience): JsonResponse
    {
        $this->authorize('delete', $experience);

        $experience->delete();

        return response()->json(['message' => 'Retreat deleted successfully.']);
    }
}

class ApiBookingController extends Controller
{
    public function __construct(
        private readonly BookingRepository $repository,
        private readonly BookingService    $bookingService,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $bookings = $this->repository->paginateForCenter(
            centerId: auth()->user()->center_id,
            filters:  $request->only(['stage', 'search', 'date_from', 'date_to']),
            perPage:  $request->get('per_page', 20),
        );

        return response()->json([
            'data' => BookingResource::collection($bookings->items()),
            'meta' => ['total' => $bookings->total(), 'current_page' => $bookings->currentPage(), 'last_page' => $bookings->lastPage()],
        ]);
    }

    public function show(Booking $booking): JsonResponse
    {
        $this->authorize('view', $booking);

        $booking->load(['experience', 'userInfo', 'experienceInfo', 'transactionInfo', 'assignedStaff', 'promoCode']);

        return response()->json(new BookingResource($booking));
    }

    public function store(\App\Http\Requests\Booking\StoreBookingRequest $request): JsonResponse
    {
        $dto     = \App\DTOs\BookingDTO::fromRequest($request, auth()->user()->center_id);
        $booking = $this->bookingService->create($dto);

        return response()->json(new BookingResource($booking), 201);
    }

    public function update(\App\Http\Requests\Booking\UpdateBookingRequest $request, Booking $booking): JsonResponse
    {
        $this->authorize('update', $booking);

        $booking->update($request->validated());

        return response()->json(new BookingResource($booking->fresh()));
    }

    public function checkIn(Booking $booking): JsonResponse
    {
        $this->authorize('checkIn', $booking);

        $this->bookingService->checkIn($booking);

        return response()->json(new BookingResource($booking->fresh()));
    }

    public function checkOut(Booking $booking): JsonResponse
    {
        $this->authorize('checkOut', $booking);

        $this->bookingService->checkOut($booking);

        return response()->json(new BookingResource($booking->fresh()));
    }

    public function cancel(\App\Http\Requests\Booking\CancelBookingRequest $request, Booking $booking): JsonResponse
    {
        $this->authorize('cancel', $booking);

        $this->bookingService->cancel($booking, $request->reason, $request->boolean('process_refund'));

        return response()->json(new BookingResource($booking->fresh()));
    }
}

class ApiPricingController extends Controller
{
    public function __construct(private readonly PricingService $pricingService) {}

    public function calculate(Request $request): JsonResponse
    {
        $request->validate([
            'experience_id'  => ['required', 'integer', 'exists:experiences,id'],
            'base_price'     => ['required', 'numeric', 'min:0'],
            'currency'       => ['required', 'string', 'size:3'],
            'guest_count'    => ['nullable', 'integer', 'min:1'],
            'arrival_date'   => ['nullable', 'date'],
            'duration_nights'=> ['nullable', 'integer', 'min:1'],
            'promo_code'     => ['nullable', 'string', 'max:50'],
        ]);

        $experience = Experience::findOrFail($request->experience_id);

        $dto = new \App\DTOs\PricingDTO(
            experienceId:  $experience->id,
            basePrice:     (float) $request->base_price * ($request->guest_count ?? 1),
            currency:      $request->currency,
            guestCount:    (int) $request->get('guest_count', 1),
            durationNights:(int) $request->get('duration_nights', 1),
            occupancyRate: $experience->occupancy_rate,
            daysUntilStart:$request->arrival_date ? now()->diffInDays($request->arrival_date) : null,
            startDate:     $request->arrival_date ? \Carbon\Carbon::parse($request->arrival_date) : null,
            promoCode:     $request->promo_code,
        );

        return response()->json($this->pricingService->calculatePrice($dto));
    }

    public function validatePromoCode(Request $request): JsonResponse
    {
        $request->validate([
            'code'          => ['required', 'string', 'max:50'],
            'amount'        => ['required', 'numeric', 'min:0'],
            'experience_id' => ['required', 'integer', 'exists:experiences,id'],
        ]);

        $result = $this->pricingService->validatePromoCode(
            $request->code,
            (float) $request->amount,
            (int) $request->experience_id
        );

        return response()->json($result);
    }
}

class ApiAnalyticsController extends Controller
{
    public function __construct(private readonly \App\Services\AnalyticsService $analyticsService) {}

    public function kpis(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $period   = $request->get('period', '30d');

        return response()->json($this->analyticsService->getDashboardKpis($centerId, $period));
    }

    public function revenue(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $from     = $request->get('from', now()->subMonths(3)->toDateString());
        $to       = $request->get('to', today()->toDateString());
        $group    = $request->get('group', 'day');

        return response()->json($this->analyticsService->getRevenueChart($centerId, $from, $to, $group));
    }

    public function occupancy(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $months   = (int) $request->get('months', 6);

        return response()->json($this->analyticsService->getOccupancyByMonth($centerId, $months));
    }

    public function topRetreats(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $limit    = (int) $request->get('limit', 5);
        $orderBy  = $request->get('order_by', 'revenue');

        return response()->json($this->analyticsService->getTopRetreats($centerId, $limit, $orderBy));
    }
}

class ApiMediaController extends Controller
{
    public function __construct(private readonly \App\Services\MediaService $mediaService) {}

    public function index(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;

        $assets = \App\Models\MediaAsset::where('center_id', $centerId)
            ->when($request->mediable_type, fn($q, $type) => $q->where('mediable_type', $type))
            ->when($request->mediable_id, fn($q, $id) => $q->where('mediable_id', $id))
            ->when($request->collection, fn($q, $col) => $q->where('collection', $col))
            ->when($request->type, fn($q, $type) => $q->where('media_type', $type))
            ->orderBy('sort_order')
            ->orderByDesc('created_at')
            ->paginate($request->get('per_page', 30));

        return response()->json([
            'data' => $assets->items(),
            'meta' => ['total' => $assets->total()],
        ]);
    }

    public function store(\App\Http\Requests\Media\StoreMediaRequest $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $uploaded = [];

        $dto = new \App\DTOs\MediaUploadDTO(
            centerId:     $centerId,
            disk:         config('filesystems.default', 's3'),
            collection:   $request->get('collection', 'default'),
            folderId:     $request->folder_id,
            mediableType: $request->mediable_type,
            mediableId:   $request->mediable_id ? (int) $request->mediable_id : null,
        );

        foreach ($request->file('files') as $file) {
            $uploaded[] = $this->mediaService->upload($file, $dto);
        }

        return response()->json(['success' => true, 'assets' => $uploaded], 201);
    }

    public function destroy(\App\Models\MediaAsset $asset): JsonResponse
    {
        $this->authorize('delete', $asset);

        $this->mediaService->delete($asset);

        return response()->json(['message' => 'Asset deleted.']);
    }
}
