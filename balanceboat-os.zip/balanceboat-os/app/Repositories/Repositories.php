<?php

namespace App\Repositories;

use App\Models\Booking;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

// ─────────────────────────────────────────────────────────────────────────────
// BookingRepository
// ─────────────────────────────────────────────────────────────────────────────

class BookingRepository
{
    public function findById(int $id): ?Booking
    {
        return Booking::with([
            'experience.center',
            'userInfo',
            'experienceInfo',
            'transactionInfo',
            'addressInfo',
            'promoCode',
            'assignedStaff',
        ])->find($id);
    }

    public function findByReference(string $ref): ?Booking
    {
        return Booking::where('booking_reference', $ref)
            ->with(['experience', 'userInfo', 'experienceInfo'])
            ->first();
    }

    public function paginateForCenter(
        int    $centerId,
        array  $filters   = [],
        int    $perPage   = 20,
        string $sortBy    = 'created_at',
        string $sortDir   = 'desc'
    ): LengthAwarePaginator {
        return Booking::forCenter($centerId)
            ->when($filters['stage'] ?? null, fn($q, $stage) => $q->inStage($stage))
            ->when($filters['search'] ?? null, fn($q, $term) => $q->search($term))
            ->when($filters['date_from'] ?? null, fn($q, $from) => $q->where('arrival_date', '>=', $from))
            ->when($filters['date_to'] ?? null, fn($q, $to) => $q->where('arrival_date', '<=', $to))
            ->when($filters['assigned_to'] ?? null, fn($q, $id) => $q->where('assigned_staff_id', $id))
            ->when($filters['experience_id'] ?? null, fn($q, $id) => $q->where('experience_id', $id))
            ->with(['experience', 'userInfo', 'assignedStaff'])
            ->orderBy($sortBy, $sortDir)
            ->paginate($perPage)
            ->withQueryString();
    }

    public function todayCheckIns(int $centerId): Collection
    {
        return Booking::forCenter($centerId)
            ->inStage('confirmed')
            ->where('arrival_date', today())
            ->with(['experience', 'userInfo'])
            ->orderBy('arrival_date')
            ->get();
    }

    public function currentGuests(int $centerId): Collection
    {
        return Booking::forCenter($centerId)
            ->inStage('checked_in')
            ->with(['experience', 'userInfo', 'accommodation'])
            ->orderBy('check_in_at')
            ->get();
    }

    public function upcomingForCenter(int $centerId, int $days = 30): Collection
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed'])
            ->whereBetween('arrival_date', [today(), today()->addDays($days)])
            ->with(['experience', 'userInfo'])
            ->orderBy('arrival_date')
            ->get();
    }

    public function revenueByMonth(int $centerId, int $months = 12): array
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->where('created_at', '>=', now()->subMonths($months))
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(pay_amount) as revenue, COUNT(*) as count")
            ->groupBy('month')
            ->orderBy('month')
            ->get()
            ->toArray();
    }

    public function stageCountsForCenter(int $centerId): array
    {
        return Booking::forCenter($centerId)
            ->selectRaw('stage, COUNT(*) as count')
            ->groupBy('stage')
            ->pluck('count', 'stage')
            ->toArray();
    }

    public function delete(Booking $booking): bool
    {
        return $booking->delete();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ExperienceRepository
// ─────────────────────────────────────────────────────────────────────────────

class ExperienceRepository
{
    public function findById(int $id): ?\App\Models\Experience
    {
        return \App\Models\Experience::with([
            'center', 'categories', 'teachers',
            'accommodations', 'faqs', 'benefits',
            'itineraryDays.sessions', 'imageGallery',
            'pricingRules', 'seoMetadata',
        ])->find($id);
    }

    public function paginateForCenter(
        int    $centerId,
        array  $filters = [],
        int    $perPage = 15,
        string $sortBy  = 'created_at',
        string $sortDir = 'desc'
    ): LengthAwarePaginator {
        return \App\Models\Experience::forCenter($centerId)
            ->when($filters['status'] ?? null, function ($q, $status) {
                match ($status) {
                    'published' => $q->published(),
                    'draft'     => $q->draft(),
                    default     => $q->where('publish_status', $status),
                };
            })
            ->when($filters['search'] ?? null, fn($q, $term) => $q->search($term))
            ->when($filters['category_id'] ?? null, fn($q, $id) => $q->byCategory((int)$id))
            ->when($filters['featured'] ?? null, fn($q) => $q->featured())
            ->with(['categories', 'teachers', 'imageGallery' => fn($q) => $q->limit(1)])
            ->withCount(['bookings as active_bookings' => fn($q) => $q->whereIn('stage', ['confirmed','checked_in'])])
            ->orderBy($sortBy, $sortDir)
            ->paginate($perPage)
            ->withQueryString();
    }

    public function getPublishedForCenter(int $centerId): Collection
    {
        return \App\Models\Experience::forCenter($centerId)
            ->published()
            ->with(['categories', 'teachers'])
            ->orderByDesc('created_at')
            ->get();
    }

    public function getTemplates(int $centerId): Collection
    {
        return \App\Models\Experience::forCenter($centerId)
            ->where('is_draft', true)
            ->whereIn('tags', ['%template%'])
            ->orderByDesc('created_at')
            ->get();
    }

    public function create(array $data): \App\Models\Experience
    {
        return \App\Models\Experience::create($data);
    }

    public function update(\App\Models\Experience $experience, array $data): \App\Models\Experience
    {
        $experience->update($data);
        return $experience->fresh();
    }

    public function delete(\App\Models\Experience $experience): bool
    {
        return $experience->delete();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CenterRepository
// ─────────────────────────────────────────────────────────────────────────────

class CenterRepository
{
    public function findById(int $id): ?\App\Models\Center
    {
        return \App\Models\Center::with([
            'owner', 'activeSubscription.plan',
            'staff', 'reviews',
        ])->find($id);
    }

    public function findByUserId(int $userId): ?\App\Models\Center
    {
        return \App\Models\Center::where('user_id', $userId)->first();
    }

    public function update(\App\Models\Center $center, array $data): \App\Models\Center
    {
        $center->update($data);
        return $center->fresh();
    }

    public function getStaff(int $centerId): Collection
    {
        return \App\Models\User::where('center_id', $centerId)
            ->with('roles')
            ->orderBy('first_name')
            ->get();
    }

    public function getDashboardSummary(int $centerId): array
    {
        $center = \App\Models\Center::find($centerId);

        return [
            'total_retreats'   => \App\Models\Experience::forCenter($centerId)->count(),
            'published_retreats'=> \App\Models\Experience::forCenter($centerId)->published()->count(),
            'total_bookings'   => Booking::forCenter($centerId)->count(),
            'total_inquiries'  => \App\Models\Inquiry::where('center_id', $centerId)->count(),
            'total_revenue'    => Booking::forCenter($centerId)->whereIn('stage', ['confirmed','checked_in','completed'])->sum('pay_amount'),
            'pending_reviews'  => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'pending')->count(),
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AnalyticsRepository
// ─────────────────────────────────────────────────────────────────────────────

class AnalyticsRepository
{
    public function inquiriesBySource(int $centerId, string $from, string $to): array
    {
        return \App\Models\Inquiry::where('center_id', $centerId)
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->selectRaw('COALESCE(source, "direct") as source, COUNT(*) as count')
            ->groupBy('source')
            ->orderByDesc('count')
            ->get()
            ->toArray();
    }

    public function inquiriesByBudget(int $centerId, string $from, string $to): array
    {
        return \App\Models\Inquiry::where('center_id', $centerId)
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->whereNotNull('budget')
            ->selectRaw('budget, COUNT(*) as count')
            ->groupBy('budget')
            ->orderByDesc('count')
            ->get()
            ->toArray();
    }

    public function revenueByRetreat(int $centerId, string $from, string $to): array
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed','checked_in','completed'])
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->join('experiences', 'bookings.experience_id', '=', 'experiences.id')
            ->selectRaw('experiences.name, SUM(bookings.pay_amount) as revenue, COUNT(bookings.id) as bookings')
            ->groupBy('experiences.id', 'experiences.name')
            ->orderByDesc('revenue')
            ->limit(10)
            ->get()
            ->toArray();
    }

    public function bookingsByGuestCountry(int $centerId, string $from, string $to): array
    {
        return Booking::forCenter($centerId)
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->join('booking_transaction_address_info as bta', 'bookings.id', '=', 'bta.booking_id')
            ->selectRaw('bta.billing_country as country, COUNT(*) as count')
            ->whereNotNull('bta.billing_country')
            ->groupBy('bta.billing_country')
            ->orderByDesc('count')
            ->limit(15)
            ->get()
            ->toArray();
    }

    public function occupancyHeatmap(int $centerId, string $year): array
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed','checked_in','completed'])
            ->whereYear('arrival_date', $year)
            ->selectRaw('arrival_date, SUM(guest_count) as guests')
            ->groupBy('arrival_date')
            ->orderBy('arrival_date')
            ->get()
            ->map(fn($r) => ['date' => $r->arrival_date->format('Y-m-d'), 'value' => $r->guests])
            ->toArray();
    }
}
