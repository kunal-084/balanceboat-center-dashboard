<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

// ─────────────────────────────────────────────────────────────────────────────
// Teacher
// ─────────────────────────────────────────────────────────────────────────────
class Teacher extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id', 'name', 'slug', 'meta_title', 'keywords', 'meta_description',
        'short_description', 'expertise_id', 'certificate_id', 'teaching_since',
        'complete_bio', 'currently_working_with',
        'hourly_rate', 'rate_currency', 'languages', 'nationality',
        'website_url', 'instagram_url', 'facebook_url', 'youtube_url',
        'status', 'is_featured', 'is_verified', 'verified_at',
        'average_rating', 'total_reviews',
        'profile_image_title', 'profile_image_url', 'profile_image_path',
        'image_gallery',
    ];

    protected $casts = [
        'languages'    => 'array',
        'is_featured'  => 'boolean',
        'is_verified'  => 'boolean',
        'verified_at'  => 'datetime',
        'deleted_at'   => 'datetime',
        'hourly_rate'  => 'decimal:2',
        'average_rating' => 'decimal:1',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->slug ??= Teacher::generateUniqueSlug($m->name));
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function imageGallery(): HasMany
    {
        return $this->hasMany(TeacherImageGallery::class, 'teacher_id');
    }

    public function experiences(): BelongsToMany
    {
        return $this->belongsToMany(Experience::class, 'experience_teachers', 'teacher_id', 'experience_id')
                    ->withTimestamps();
    }

    public function centers(): BelongsToMany
    {
        return $this->belongsToMany(Center::class, 'center_teachers', 'teacher_id', 'center_id')
                    ->withTimestamps();
    }

    public function mediaAssets(): MorphMany
    {
        return $this->morphMany(MediaAsset::class, 'mediable');
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }
    public function scopeFeatured($query) { return $query->where('is_featured', true); }
    public function scopeVerified($query) { return $query->where('is_verified', true); }

    public function getFullYearsExperienceAttribute(): int
    {
        return $this->teaching_since ? now()->year - $this->teaching_since : 0;
    }

    public static function generateUniqueSlug(string $name): string
    {
        $base = Str::slug($name); $slug = $base; $i = 1;
        while (static::where('slug', $slug)->exists()) { $slug = "{$base}-{$i}"; $i++; }
        return $slug;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Inquiry
// ─────────────────────────────────────────────────────────────────────────────
class Inquiry extends Model
{
    use HasFactory, SoftDeletes;

    const PIPELINE_STAGES = ['new', 'contacted', 'qualified', 'proposal', 'negotiating', 'won', 'lost'];

    const STAGE_COLORS = [
        'new'         => 'slate',
        'contacted'   => 'blue',
        'qualified'   => 'indigo',
        'proposal'    => 'amber',
        'negotiating' => 'orange',
        'won'         => 'emerald',
        'lost'        => 'red',
    ];

    protected $fillable = [
        'name', 'lastname', 'email', 'country_code', 'phone',
        'message', 'retreat_type', 'destination', 'budget', 'timeline',
        'whatsapp', 'conversation_id', 'source', 'experience_id', 'ref_url', 'note',
        'whatsapp_verified', 'email_verified', 'instagram_verified',
        'pipeline_stage', 'assigned_to', 'center_id', 'converted_booking_id',
        'follow_up_at', 'lost_reason', 'last_contacted_at', 'contact_attempts',
        'group_size', 'utm_source', 'utm_medium', 'utm_campaign',
    ];

    protected $casts = [
        'whatsapp'       => 'boolean',
        'follow_up_at'   => 'datetime',
        'last_contacted_at' => 'datetime',
        'deleted_at'     => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->conversation_id ??= (string) Str::uuid());
    }

    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function assignedTo(): BelongsTo { return $this->belongsTo(User::class, 'assigned_to'); }
    public function convertedBooking(): BelongsTo { return $this->belongsTo(Booking::class, 'converted_booking_id'); }

    public function scopeForStage($query, string $stage) { return $query->where('pipeline_stage', $stage); }
    public function scopeForCenter($query, int $centerId) { return $query->where('center_id', $centerId); }
    public function scopeOpen($query) { return $query->whereNotIn('pipeline_stage', ['won', 'lost']); }

    public function getFullNameAttribute(): string { return trim("{$this->name} {$this->lastname}"); }
    public function getStageColorAttribute(): string { return self::STAGE_COLORS[$this->pipeline_stage] ?? 'slate'; }
    public function getIsConvertedAttribute(): bool { return $this->pipeline_stage === 'won' && $this->converted_booking_id; }

    public function advancePipeline(): bool
    {
        $index = array_search($this->pipeline_stage, self::PIPELINE_STAGES);
        if ($index === false || $index >= count(self::PIPELINE_STAGES) - 3) {
            return false;
        }
        $this->update([
            'pipeline_stage'   => self::PIPELINE_STAGES[$index + 1],
            'last_contacted_at'=> now(),
            'contact_attempts' => $this->contact_attempts + 1,
        ]);
        return true;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PromoCode
// ─────────────────────────────────────────────────────────────────────────────
class PromoCode extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'center_id', 'created_by', 'code', 'description',
        'discount_type', 'discount_value', 'min_booking_amount', 'max_discount_cap',
        'max_uses', 'max_uses_per_user', 'used_count',
        'valid_from', 'valid_until',
        'applies_to_all', 'applicable_experience_ids', 'applicable_category_ids',
        'is_active',
    ];

    protected $casts = [
        'valid_from'               => 'date',
        'valid_until'              => 'date',
        'applies_to_all'           => 'boolean',
        'is_active'                => 'boolean',
        'applicable_experience_ids'=> 'array',
        'applicable_category_ids'  => 'array',
        'discount_value'           => 'decimal:2',
        'min_booking_amount'       => 'decimal:2',
        'max_discount_cap'         => 'decimal:2',
        'deleted_at'               => 'datetime',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function redemptions(): HasMany { return $this->hasMany(CouponRedemption::class, 'promo_code_id'); }

    public function scopeActive($query)
    {
        return $query->where('is_active', true)
            ->where(fn($q) => $q->whereNull('valid_from')->orWhere('valid_from', '<=', today()))
            ->where(fn($q) => $q->whereNull('valid_until')->orWhere('valid_until', '>=', today()));
    }

    public function getIsExpiredAttribute(): bool
    {
        return $this->valid_until && $this->valid_until->isPast();
    }

    public function getIsExhaustedAttribute(): bool
    {
        return $this->max_uses && $this->used_count >= $this->max_uses;
    }

    public function getIsUsableAttribute(): bool
    {
        return $this->is_active && ! $this->is_expired && ! $this->is_exhausted;
    }

    public function calculateDiscount(float $amount): float
    {
        if (! $this->is_usable) return 0;
        if ($this->min_booking_amount && $amount < $this->min_booking_amount) return 0;

        $discount = $this->discount_type === 'percentage'
            ? $amount * ($this->discount_value / 100)
            : $this->discount_value;

        if ($this->max_discount_cap) {
            $discount = min($discount, (float) $this->max_discount_cap);
        }

        return min($discount, $amount);
    }

    public function incrementUsage(): void
    {
        $this->increment('used_count');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PricingRule
// ─────────────────────────────────────────────────────────────────────────────
class PricingRule extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'center_id', 'experience_id', 'accommodation_id', 'name', 'description',
        'rule_type', 'discount_type', 'discount_value', 'min_price_cap',
        'days_before', 'occupancy_threshold_pct', 'min_duration_nights', 'min_group_size',
        'start_date', 'end_date', 'priority', 'is_stackable', 'is_active',
    ];

    protected $casts = [
        'start_date'     => 'date',
        'end_date'       => 'date',
        'is_stackable'   => 'boolean',
        'is_active'      => 'boolean',
        'discount_value' => 'decimal:2',
        'min_price_cap'  => 'decimal:2',
        'deleted_at'     => 'datetime',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeHighPriority($query) { return $query->orderBy('priority', 'desc'); }

    public function appliesToDate(\Carbon\Carbon $date): bool
    {
        if ($this->start_date && $date->lt($this->start_date)) return false;
        if ($this->end_date && $date->gt($this->end_date)) return false;
        return true;
    }

    public function appliesToOccupancy(float $occupancyPct): bool
    {
        if ($this->rule_type !== 'occupancy_based') return true;
        return $occupancyPct >= (int) $this->occupancy_threshold_pct;
    }

    public function appliesToBookingLeadTime(int $daysBeforeStart): bool
    {
        return match ($this->rule_type) {
            'early_bird'  => $daysBeforeStart >= (int) $this->days_before,
            'last_minute' => $daysBeforeStart <= (int) $this->days_before,
            default       => true,
        };
    }

    public function calculateDiscount(float $basePrice): float
    {
        $discount = $this->discount_type === 'percentage'
            ? $basePrice * ($this->discount_value / 100)
            : (float) $this->discount_value;

        if ($this->min_price_cap) {
            $discount = min($discount, $basePrice - (float) $this->min_price_cap);
        }

        return max(0, $discount);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AiRecommendation
// ─────────────────────────────────────────────────────────────────────────────
class AiRecommendation extends Model
{
    use HasFactory;

    protected $fillable = [
        'center_id', 'experience_id', 'type', 'title', 'recommendation',
        'confidence_score', 'estimated_impact_pct', 'supporting_data',
        'action_payload', 'status', 'applied_at', 'applied_by',
        'dismissed_at', 'dismissed_by', 'expires_at', 'ai_model',
    ];

    protected $casts = [
        'supporting_data'     => 'array',
        'action_payload'      => 'array',
        'applied_at'          => 'datetime',
        'dismissed_at'        => 'datetime',
        'expires_at'          => 'datetime',
        'confidence_score'    => 'decimal:2',
        'estimated_impact_pct'=> 'decimal:2',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }

    public function scopeActive($query) { return $query->where('status', 'active')->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now())); }
    public function scopeForCenter($query, int $centerId) { return $query->where('center_id', $centerId); }
    public function scopeOfType($query, string $type) { return $query->where('type', $type); }

    public function apply(int $userId): void
    {
        $this->update(['status' => 'applied', 'applied_at' => now(), 'applied_by' => $userId]);
    }

    public function dismiss(int $userId): void
    {
        $this->update(['status' => 'dismissed', 'dismissed_at' => now(), 'dismissed_by' => $userId]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AutomationRule
// ─────────────────────────────────────────────────────────────────────────────
class AutomationRule extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'center_id', 'name', 'description', 'trigger_event',
        'trigger_conditions', 'action_type', 'email_template_id',
        'whatsapp_template_id', 'action_config', 'delay_unit', 'delay_value',
        'is_active', 'execution_count', 'last_executed_at',
    ];

    protected $casts = [
        'trigger_conditions' => 'array',
        'action_config'      => 'array',
        'is_active'          => 'boolean',
        'last_executed_at'   => 'datetime',
        'deleted_at'         => 'datetime',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function emailTemplate(): BelongsTo { return $this->belongsTo(EmailTemplate::class); }
    public function executions(): HasMany { return $this->hasMany(AutomationExecution::class); }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeForEvent($query, string $event) { return $query->where('trigger_event', $event); }

    public function getDelayInMinutesAttribute(): int
    {
        return match ($this->delay_unit) {
            'minutes' => (int) $this->delay_value,
            'hours'   => (int) $this->delay_value * 60,
            'days'    => (int) $this->delay_value * 1440,
            default   => 0,
        };
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Supporting Models
// ─────────────────────────────────────────────────────────────────────────────

class AuditLog extends Model
{
    const UPDATED_AT = null;

    protected $fillable = [
        'user_id', 'user_name', 'user_email', 'event',
        'auditable_type', 'auditable_id',
        'old_values', 'new_values',
        'ip_address', 'user_agent', 'url', 'http_method',
        'center_id', 'tags',
    ];

    protected $casts = [
        'old_values' => 'array',
        'new_values' => 'array',
        'created_at' => 'datetime',
    ];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function scopeForCenter($query, int $id) { return $query->where('center_id', $id); }
    public function scopeForEvent($query, string $event) { return $query->where('event', $event); }
}

class RetreatFaq extends Model
{
    protected $fillable = ['experience_id', 'question', 'answer', 'sort_order', 'is_published'];
    protected $casts = ['is_published' => 'boolean'];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
}

class RetreatBenefit extends Model
{
    protected $fillable = ['experience_id', 'benefit', 'icon', 'category', 'sort_order'];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
}

class RetreatItineraryDay extends Model
{
    protected $fillable = ['experience_id', 'day_number', 'title', 'description', 'theme'];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function sessions(): HasMany { return $this->hasMany(RetreatItinerarySession::class, 'day_id')->orderBy('sort_order'); }
}

class RetreatItinerarySession extends Model
{
    protected $fillable = [
        'day_id', 'start_time', 'end_time', 'activity', 'description',
        'session_type', 'location', 'facilitator', 'is_optional', 'sort_order',
    ];
    protected $casts = ['is_optional' => 'boolean'];
    public function day(): BelongsTo { return $this->belongsTo(RetreatItineraryDay::class, 'day_id'); }
}

class CenterReview extends Model
{
    protected $fillable = [
        'center_id', 'experience_id', 'booking_id', 'user_id',
        'reviewer_name', 'reviewer_email', 'reviewer_country',
        'overall_rating', 'accommodation_rating', 'food_rating',
        'teacher_rating', 'value_rating', 'cleanliness_rating',
        'title', 'body', 'status', 'rejection_reason',
        'source', 'external_id', 'reviewed_at', 'approved_at', 'approved_by',
        'is_verified_guest', 'is_featured',
    ];
    protected $casts = [
        'overall_rating'      => 'decimal:1',
        'accommodation_rating'=> 'decimal:1',
        'food_rating'         => 'decimal:1',
        'teacher_rating'      => 'decimal:1',
        'value_rating'        => 'decimal:1',
        'cleanliness_rating'  => 'decimal:1',
        'is_verified_guest'   => 'boolean',
        'is_featured'         => 'boolean',
        'reviewed_at'         => 'datetime',
        'approved_at'         => 'datetime',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function response(): HasOne { return $this->hasOne(ReviewResponse::class, 'review_id'); }
    public function scopeApproved($query) { return $query->where('status', 'approved'); }
    public function scopePending($query) { return $query->where('status', 'pending'); }
    public function approve(int $userId): void { $this->update(['status' => 'approved', 'approved_at' => now(), 'approved_by' => $userId]); }
    public function reject(string $reason, int $userId): void { $this->update(['status' => 'rejected', 'rejection_reason' => $reason, 'approved_by' => $userId]); }
}

class ReviewResponse extends Model
{
    protected $fillable = ['review_id', 'responded_by', 'response', 'responded_at'];
    protected $casts = ['responded_at' => 'datetime'];
    public function review(): BelongsTo { return $this->belongsTo(CenterReview::class, 'review_id'); }
}

class AvailabilityCalendar extends Model
{
    protected $fillable = [
        'experience_id', 'accommodation_id', 'calendar_date',
        'total_units', 'available_units', 'booked_units', 'blocked_units',
        'status', 'override_price', 'block_reason',
    ];
    protected $casts = [
        'calendar_date'  => 'date',
        'override_price' => 'decimal:2',
    ];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function scopeAvailable($query) { return $query->where('status', 'open')->where('available_units', '>', 0); }
    public function scopeForDateRange($query, string $from, string $to) { return $query->whereBetween('calendar_date', [$from, $to]); }
}

class MediaAsset extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'center_id', 'folder_id', 'uploaded_by', 'mediable_type', 'mediable_id',
        'collection', 'filename', 'original_filename', 'disk', 'path', 'url', 'cdn_url',
        'mime_type', 'media_type', 'size_bytes', 'width', 'height', 'duration_seconds',
        'alt_text', 'caption', 'category', 'sort_order', 'is_featured',
        'metadata', 'thumbnails',
    ];
    protected $casts = [
        'is_featured' => 'boolean',
        'metadata'    => 'array',
        'thumbnails'  => 'array',
        'deleted_at'  => 'datetime',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function getPublicUrlAttribute(): string { return $this->cdn_url ?? $this->url ?? ''; }
    public function getThumbnailUrlAttribute(): string
    {
        $thumbs = $this->thumbnails ?? [];
        return $thumbs['medium'] ?? $thumbs['small'] ?? $this->public_url;
    }
    public function scopeImages($query) { return $query->where('media_type', 'image'); }
    public function scopeVideos($query) { return $query->where('media_type', 'video'); }
    public function scopeFeatured($query) { return $query->where('is_featured', true); }
}

class EmailTemplate extends Model
{
    protected $fillable = [
        'center_id', 'name', 'slug', 'subject', 'body_html', 'body_text',
        'variables', 'category', 'is_active', 'is_system',
    ];
    protected $casts = ['variables' => 'array', 'is_active' => 'boolean', 'is_system' => 'boolean'];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function render(array $data): string
    {
        $html = $this->body_html;
        foreach ($data as $key => $value) {
            $html = str_replace("{{$key}}", $value, $html);
        }
        return $html;
    }
}

class PayoutRequest extends Model
{
    protected $fillable = [
        'center_id', 'reference', 'gross_amount', 'commission_deducted',
        'tax_deducted', 'net_payout', 'currency', 'status', 'payment_method',
        'bank_details', 'transaction_reference', 'admin_notes', 'processed_by',
        'requested_at', 'processed_at', 'paid_at', 'period_from', 'period_to',
        'included_booking_ids',
    ];
    protected $casts = [
        'bank_details'        => 'array',
        'included_booking_ids'=> 'array',
        'gross_amount'        => 'decimal:2',
        'commission_deducted' => 'decimal:2',
        'tax_deducted'        => 'decimal:2',
        'net_payout'          => 'decimal:2',
        'requested_at'        => 'datetime',
        'processed_at'        => 'datetime',
        'paid_at'             => 'datetime',
        'period_from'         => 'date',
        'period_to'           => 'date',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function scopePending($query) { return $query->where('status', 'pending'); }
}

class SubscriptionPlan extends Model
{
    protected $fillable = [
        'name', 'slug', 'description', 'monthly_price', 'annual_price',
        'commission_rate', 'max_retreats', 'max_staff', 'max_accommodations',
        'ai_enabled', 'analytics_enabled', 'automation_enabled',
        'whatsapp_enabled', 'api_access', 'custom_domain', 'priority_support',
        'features', 'trial_days', 'is_active', 'sort_order',
    ];
    protected $casts = [
        'features'           => 'array',
        'ai_enabled'         => 'boolean',
        'analytics_enabled'  => 'boolean',
        'automation_enabled' => 'boolean',
        'whatsapp_enabled'   => 'boolean',
        'api_access'         => 'boolean',
        'custom_domain'      => 'boolean',
        'priority_support'   => 'boolean',
        'is_active'          => 'boolean',
        'monthly_price'      => 'decimal:2',
        'annual_price'       => 'decimal:2',
        'commission_rate'    => 'decimal:2',
    ];
    public function centers(): HasMany { return $this->hasMany(Center::class, 'subscription_plan_id'); }
}

class SystemSetting extends Model
{
    protected $fillable = ['key', 'value', 'group', 'type', 'label', 'description', 'is_public'];
    protected $casts = ['is_public' => 'boolean'];

    public static function get(string $key, mixed $default = null): mixed
    {
        $setting = static::where('key', $key)->first();
        if (! $setting) return $default;
        return match ($setting->type) {
            'boolean' => (bool) $setting->value,
            'integer' => (int) $setting->value,
            'float'   => (float) $setting->value,
            'json', 'array' => json_decode($setting->value, true),
            default   => $setting->value,
        };
    }

    public static function set(string $key, mixed $value): void
    {
        static::updateOrCreate(['key' => $key], [
            'value' => is_array($value) ? json_encode($value) : $value,
        ]);
    }
}

class UserPreference extends Model
{
    protected $fillable = [
        'user_id', 'timezone', 'locale', 'currency', 'date_format',
        'email_notifications', 'whatsapp_notifications', 'sms_notifications', 'browser_notifications',
        'notification_types', 'dashboard_widgets', 'table_columns',
    ];
    protected $casts = [
        'email_notifications'   => 'boolean',
        'whatsapp_notifications'=> 'boolean',
        'sms_notifications'     => 'boolean',
        'browser_notifications' => 'boolean',
        'notification_types'    => 'array',
        'dashboard_widgets'     => 'array',
        'table_columns'         => 'array',
    ];
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}

class AutomationExecution extends Model
{
    protected $fillable = [
        'automation_rule_id', 'trigger_event', 'trigger_data',
        'status', 'error_message', 'result_data', 'scheduled_at', 'executed_at',
    ];
    protected $casts = [
        'trigger_data'  => 'array',
        'result_data'   => 'array',
        'scheduled_at'  => 'datetime',
        'executed_at'   => 'datetime',
    ];
    public function rule(): BelongsTo { return $this->belongsTo(AutomationRule::class, 'automation_rule_id'); }
}

class CouponRedemption extends Model
{
    protected $fillable = ['promo_code_id', 'booking_id', 'user_id', 'original_amount', 'discount_applied', 'final_amount'];
    protected $casts = ['original_amount' => 'decimal:2', 'discount_applied' => 'decimal:2', 'final_amount' => 'decimal:2'];
    public function promoCode(): BelongsTo { return $this->belongsTo(PromoCode::class); }
    public function booking(): BelongsTo { return $this->belongsTo(Booking::class); }
}

class SeoMetadata extends Model
{
    protected $fillable = [
        'seoable_type', 'seoable_id', 'title', 'description', 'keywords',
        'og_title', 'og_description', 'og_image',
        'twitter_title', 'twitter_description', 'twitter_image',
        'canonical_url', 'robots', 'schema_org',
    ];
    protected $casts = ['schema_org' => 'array'];
}

class CenterSubscription extends Model
{
    protected $fillable = [
        'center_id', 'plan_id', 'status', 'billing_cycle',
        'trial_ends_at', 'current_period_start', 'current_period_end', 'cancelled_at',
        'stripe_subscription_id', 'stripe_customer_id', 'amount_paid', 'currency', 'metadata',
    ];
    protected $casts = [
        'trial_ends_at'        => 'datetime',
        'current_period_start' => 'datetime',
        'current_period_end'   => 'datetime',
        'cancelled_at'         => 'datetime',
        'metadata'             => 'array',
        'amount_paid'          => 'decimal:2',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function plan(): BelongsTo { return $this->belongsTo(SubscriptionPlan::class, 'plan_id'); }
    public function getIsTrialingAttribute(): bool { return $this->status === 'trialing'; }
    public function getIsActiveAttribute(): bool { return in_array($this->status, ['trialing', 'active']); }
}
