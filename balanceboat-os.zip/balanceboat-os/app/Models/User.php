<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasOne, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasRoles;

    protected $fillable = [
        'first_name', 'last_name', 'email', 'password',
        'phone_number', 'date_of_birth', 'street_address', 'city',
        'zipcode', 'country', 'profile_image_url',
        'center_id', 'center_role', 'is_active', 'email_verified',
        'email_verified_at', 'two_factor_secret', 'two_factor_recovery_codes',
        'two_factor_enabled', 'timezone', 'locale',
        'last_login_at', 'last_login_ip',
    ];

    protected $hidden = [
        'password', 'remember_token',
        'two_factor_secret', 'two_factor_recovery_codes',
    ];

    protected $casts = [
        'date_of_birth'              => 'date',
        'is_active'                  => 'boolean',
        'email_verified'             => 'boolean',
        'email_verified_at'          => 'datetime',
        'two_factor_enabled'         => 'boolean',
        'two_factor_recovery_codes'  => 'array',
        'last_login_at'              => 'datetime',
        'deleted_at'                 => 'datetime',
        'password'                   => 'hashed',
    ];

    // ─── Relationships ───────────────────────────────────────────────────────

    public function center(): BelongsTo
    {
        return $this->belongsTo(Center::class);
    }

    public function preferences(): HasOne
    {
        return $this->hasOne(UserPreference::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    public function inquiries(): HasMany
    {
        return $this->hasMany(Inquiry::class, 'assigned_to');
    }

    public function auditLogs(): HasMany
    {
        return $this->hasMany(AuditLog::class);
    }

    // ─── Accessors ───────────────────────────────────────────────────────────

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    public function getAvatarUrlAttribute(): string
    {
        if ($this->profile_image_url) {
            return $this->profile_image_url;
        }

        $name = urlencode($this->full_name ?: 'User');
        return "https://ui-avatars.com/api/?name={$name}&background=7c3aed&color=fff&size=128";
    }

    public function getIsOwnerAttribute(): bool
    {
        return $this->center_role === 'owner';
    }

    public function getIsManagerAttribute(): bool
    {
        return in_array($this->center_role, ['owner', 'manager']);
    }

    // ─── Scopes ──────────────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForCenter($query, int $centerId)
    {
        return $query->where('center_id', $centerId);
    }

    public function scopeWithRole($query, string $role)
    {
        return $query->where('center_role', $role);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    public function belongsToCenter(int $centerId): bool
    {
        return $this->center_id === $centerId;
    }

    public function getPreferenceAttribute(string $key, mixed $default = null): mixed
    {
        return $this->preferences?->{$key} ?? $default;
    }

    public function recordLogin(string $ip): void
    {
        $this->update([
            'last_login_at' => now(),
            'last_login_ip' => $ip,
        ]);
    }
}
