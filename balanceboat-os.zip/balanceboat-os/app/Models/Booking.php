<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasOne};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Booking extends Model
{
    use HasFactory, SoftDeletes;

    // Pipeline stages in order
    const STAGES = [
        'inquiry', 'qualified', 'proposal_sent', 'confirmed',
        'checked_in', 'completed', 'cancelled', 'refunded',
    ];

    const STAGE_LABELS = [
        'inquiry'       => 'Inquiry',
        'qualified'     => 'Qualified',
        'proposal_sent' => 'Proposal Sent',
        'confirmed'     => 'Confirmed',
        'checked_in'    => 'Checked In',
        'completed'     => 'Completed',
        'cancelled'     => 'Cancelled',
        'refunded'      => 'Refunded',
    ];

    const STAGE_COLORS = [
        'inquiry'       => 'slate',
        'qualified'     => 'blue',
        'proposal_sent' => 'amber',
        'confirmed'     => 'emerald',
        'checked_in'    => 'purple',
        'completed'     => 'green',
        'cancelled'     => 'red',
        'refunded'      => 'orange',
    ];

    const ALLOWED_TRANSITIONS = [
        'inquiry'       => ['qualified', 'cancelled'],
        'qualified'     => ['proposal_sent', 'cancelled'],
        'proposal_sent' => ['confirmed', 'cancelled'],
        'confirmed'     => ['checked_in', 'cancelled'],
        'checked_in'    => ['completed'],
        'completed'     => ['refunded'],
        'cancelled'     => [],
        'refunded'      => [],
    ];

    protected $fillable = [
        'booking_reference', 'experience_id', 'experience_accomodation_id',
        'user_id', 'assigned_staff_id', 'promo_code_id',
        'stage', 'guest_count', 'duration',
        'price_per_person', 'currency', 'currency_rate',
        'booking_currency', 'booking_currency_rate',
        'arrival_date', 'start_date_time', 'end_date_time',
        'is_full_day_event', 'is_recurring',
        'booking_amount', 'discount_amount', 'commission_amount', 'pay_amount',
        'order_status', 'payment_status', 'transaction_id',
        'check_in_at', 'check_out_at', 'internal_notes',
        'cancellation_reason', 'cancelled_at',
    ];

    protected $casts = [
        'arrival_date'    => 'date',
        'start_date_time' => 'datetime',
        'end_date_time'   => 'datetime',
        'check_in_at'     => 'datetime',
        'check_out_at'    => 'datetime',
        'cancelled_at'    => 'datetime',
        'deleted_at'      => 'datetime',
        'is_full_day_event'=> 'boolean',
        'is_recurring'    => 'boolean',
        'booking_amount'  => 'decimal:2',
        'discount_amount' => 'float',
        'commission_amount'=> 'float',
        'pay_amount'      => 'float',
        'price_per_person'=> 'float',
        'currency_rate'   => 'decimal:2',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $model) {
            if (empty($model->booking_reference)) {
                $model->booking_reference = static::generateReference();
            }
        });
    }

    // ─── Relationships ───────────────────────────────────────────────────────

    public function experience(): BelongsTo
    {
        return $this->belongsTo(Experience::class);
    }

    public function accommodation(): BelongsTo
    {
        return $this->belongsTo(ExperienceAccomodation::class, 'experience_accomodation_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function assignedStaff(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_staff_id');
    }

    public function promoCode(): BelongsTo
    {
        return $this->belongsTo(PromoCode::class);
    }

    public function experienceInfo(): HasOne
    {
        return $this->hasOne(BookingExperienceInfo::class);
    }

    public function transactionInfo(): HasOne
    {
        return $this->hasOne(BookingTransactionInfo::class);
    }

    public function addressInfo(): HasOne
    {
        return $this->hasOne(BookingTransactionAddressInfo::class);
    }

    public function userInfo(): HasOne
    {
        return $this->hasOne(BookingUserInfo::class);
    }

    public function couponRedemption(): HasOne
    {
        return $this->hasOne(CouponRedemption::class);
    }

    // ─── Scopes ──────────────────────────────────────────────────────────────

    public function scopeInStage($query, string $stage)
    {
        return $query->where('stage', $stage);
    }

    public function scopeActive($query)
    {
        return $query->whereIn('stage', ['confirmed', 'checked_in']);
    }

    public function scopeCompleted($query)
    {
        return $query->where('stage', 'completed');
    }

    public function scopeCancelled($query)
    {
        return $query->whereIn('stage', ['cancelled', 'refunded']);
    }

    public function scopeForCenter($query, int $centerId)
    {
        return $query->whereHas('experience', fn($q) => $q->where('center_id', $centerId));
    }

    public function scopeForDateRange($query, string $from, string $to)
    {
        return $query->whereBetween('arrival_date', [$from, $to]);
    }

    public function scopeForMonth($query, int $year, int $month)
    {
        return $query->whereYear('arrival_date', $year)->whereMonth('arrival_date', $month);
    }

    public function scopeSearch($query, string $term)
    {
        return $query->where('booking_reference', 'like', "%{$term}%")
            ->orWhereHas('userInfo', fn($q) =>
                $q->where('firstname', 'like', "%{$term}%")
                  ->orWhere('lastname', 'like', "%{$term}%")
                  ->orWhere('email', 'like', "%{$term}%")
            );
    }

    // ─── Accessors ───────────────────────────────────────────────────────────

    public function getStageLabelAttribute(): string
    {
        return self::STAGE_LABELS[$this->stage] ?? ucfirst($this->stage);
    }

    public function getStageColorAttribute(): string
    {
        return self::STAGE_COLORS[$this->stage] ?? 'slate';
    }

    public function getGuestNameAttribute(): string
    {
        $info = $this->userInfo;
        return $info ? trim("{$info->firstname} {$info->lastname}") : 'Unknown Guest';
    }

    public function getGuestEmailAttribute(): string
    {
        return $this->userInfo?->email ?? $this->user?->email ?? '';
    }

    public function getNetAmountAttribute(): float
    {
        return max(0, (float) $this->pay_amount - (float) $this->commission_amount);
    }

    public function getDurationNightsAttribute(): int
    {
        if ($this->start_date_time && $this->end_date_time) {
            return (int) $this->start_date_time->diffInDays($this->end_date_time);
        }

        return (int) $this->duration;
    }

    public function getIsActiveAttribute(): bool
    {
        return in_array($this->stage, ['confirmed', 'checked_in']);
    }

    public function getIsRefundableAttribute(): bool
    {
        return in_array($this->stage, ['confirmed', 'checked_in', 'completed']);
    }

    // ─── State Machine Helpers ────────────────────────────────────────────────

    public function canTransitionTo(string $newStage): bool
    {
        return in_array($newStage, self::ALLOWED_TRANSITIONS[$this->stage] ?? []);
    }

    public function transitionTo(string $newStage, array $extra = []): bool
    {
        if (! $this->canTransitionTo($newStage)) {
            return false;
        }

        $data = array_merge(['stage' => $newStage], $extra);

        if ($newStage === 'checked_in' && empty($extra['check_in_at'])) {
            $data['check_in_at'] = now();
        }

        if ($newStage === 'completed' && empty($extra['check_out_at'])) {
            $data['check_out_at'] = now();
        }

        if ($newStage === 'cancelled') {
            $data['cancelled_at'] = now();
        }

        $this->update($data);
        return true;
    }

    public function confirm(): bool
    {
        return $this->transitionTo('confirmed');
    }

    public function checkIn(): bool
    {
        return $this->transitionTo('checked_in');
    }

    public function complete(): bool
    {
        return $this->transitionTo('completed');
    }

    public function cancel(string $reason = ''): bool
    {
        return $this->transitionTo('cancelled', ['cancellation_reason' => $reason]);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    public static function generateReference(): string
    {
        do {
            $ref = 'BB-' . strtoupper(Str::random(8));
        } while (static::where('booking_reference', $ref)->exists());

        return $ref;
    }
}
