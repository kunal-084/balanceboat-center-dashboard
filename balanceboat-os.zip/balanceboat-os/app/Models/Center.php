<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasMany, HasOne, BelongsToMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Center extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'slug', 'meta_title', 'keywords', 'meta_description',
        'gps', 'location', 'center_type', 'speciality_id',
        'year_of_foundation', 'founders', 'about_center',
        'what_sets_us_apart', 'our_philosophy', 'our_mission',
        'center_highlights', 'video_url',
        'banner_image_title', 'banner_image_url', 'banner_image_path',
        'website', 'certificate_id', 'awards',
        'address_of_center', 'city', 'state', 'country', 'postal_code',
        'email_address', 'contact_number', 'whatsapp_number',
        'balancegurus_profile_link', 'tags', 'category_id',
        'have_accomodation', 'center_features', 'accomodation_overview',
        'accomodation_banner_image_title', 'accomodation_banner_image_url',
        'how_to_get_there', 'things_to_do_around_the_center',
        'amenities', 'airport_name', 'pickup_drop_cost',
        'facebook_url', 'instagram_url', 'twitter_url',
        'youtube_url', 'linkedin_url', 'tiktok_url',
        'bg_id', 'user_id',
        'is_draft', 'status', 'verified_at',
        'subscription_plan_id', 'trial_ends_at',
        'timezone', 'currency_code',
        'latitude', 'longitude',
        'operating_hours', 'tax_id', 'registration_number',
        'number_of_staff', 'is_featured',
    ];

    protected $casts = [
        'is_draft'       => 'boolean',
        'is_featured'    => 'boolean',
        'verified_at'    => 'datetime',
        'trial_ends_at'  => 'datetime',
        'deleted_at'     => 'datetime',
        'operating_hours'=> 'array',
        'pickup_drop_cost'=> 'decimal:2',
        'latitude'       => 'decimal:7',
        'longitude'      => 'decimal:7',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $model) {
            if (empty($model->slug)) {
                $model->slug = static::generateUniqueSlug($model->name);
            }
        });

        static::updating(function (self $model) {
            if ($model->isDirty('name') && empty($model->slug)) {
                $model->slug = static::generateUniqueSlug($model->name);
            }
        });
    }

    // ─── Relationships ───────────────────────────────────────────────────────

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function subscriptionPlan(): BelongsTo
    {
        return $this->belongsTo(SubscriptionPlan::class, 'subscription_plan_id');
    }

    public function activeSubscription(): HasOne
    {
        return $this->hasOne(CenterSubscription::class)
                    ->whereIn('status', ['trialing', 'active'])
                    ->latest();
    }

    public function staff(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function experiences(): HasMany
    {
        return $this->hasMany(Experience::class);
    }

    public function publishedExperiences(): HasMany
    {
        return $this->hasMany(Experience::class)->published();
    }

    public function teachers(): BelongsToMany
    {
        return $this->belongsToMany(Teacher::class, 'center_teachers', 'center_id', 'teacher_id')
                    ->withPivot('created_at')
                    ->withTimestamps();
    }

    public function accommodations(): BelongsToMany
    {
        return $this->belongsToMany(Accomodation::class, 'center_accomodations', 'center_id', 'accomodation_id')
                    ->withTimestamps();
    }

    public function imageGallery(): HasMany
    {
        return $this->hasMany(CenterImageGallery::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(CenterReview::class);
    }

    public function approvedReviews(): HasMany
    {
        return $this->hasMany(CenterReview::class)->where('status', 'approved');
    }

    public function pricingRules(): HasMany
    {
        return $this->hasMany(PricingRule::class);
    }

    public function promoCodes(): HasMany
    {
        return $this->hasMany(PromoCode::class);
    }

    public function emailTemplates(): HasMany
    {
        return $this->hasMany(EmailTemplate::class);
    }

    public function automationRules(): HasMany
    {
        return $this->hasMany(AutomationRule::class);
    }

    public function aiRecommendations(): HasMany
    {
        return $this->hasMany(AiRecommendation::class)->active();
    }

    public function payoutRequests(): HasMany
    {
        return $this->hasMany(PayoutRequest::class);
    }

    public function mediaAssets(): HasMany
    {
        return $this->hasMany(MediaAsset::class);
    }

    public function seoMetadata(): MorphMany
    {
        return $this->morphMany(SeoMetadata::class, 'seoable');
    }

    public function commissions(): HasMany
    {
        return $this->hasMany(CenterCommission::class);
    }

    // ─── Scopes ──────────────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('status', 'active')->where('is_draft', false);
    }

    public function scopeVerified($query)
    {
        return $query->whereNotNull('verified_at');
    }

    public function scopeFeatured($query)
    {
        return $query->where('is_featured', true);
    }

    public function scopeByCountry($query, string $country)
    {
        return $query->where('country', $country);
    }

    public function scopeSearch($query, string $term)
    {
        return $query->where(function ($q) use ($term) {
            $q->where('name', 'like', "%{$term}%")
              ->orWhere('city', 'like', "%{$term}%")
              ->orWhere('country', 'like', "%{$term}%");
        });
    }

    // ─── Accessors ───────────────────────────────────────────────────────────

    public function getIsVerifiedAttribute(): bool
    {
        return ! is_null($this->verified_at);
    }

    public function getIsActiveAttribute(): bool
    {
        return $this->status === 'active';
    }

    public function getAverageRatingAttribute(): float
    {
        return (float) ($this->approvedReviews()->avg('overall_rating') ?? 0);
    }

    public function getTotalRevenueAttribute(): float
    {
        return (float) Booking::whereHas('experience', fn($q) => $q->where('center_id', $this->id))
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->sum('pay_amount');
    }

    public function getOccupancyRateAttribute(): float
    {
        $totalCapacity = $this->experiences()->sum('batch_size');
        if (! $totalCapacity) {
            return 0;
        }

        $booked = Booking::whereHas('experience', fn($q) => $q->where('center_id', $this->id))
            ->whereIn('stage', ['confirmed', 'checked_in'])
            ->sum('guest_count');

        return round(($booked / $totalCapacity) * 100, 1);
    }

    public function getHasActiveSubscriptionAttribute(): bool
    {
        return $this->activeSubscription()->exists();
    }

    public function canUseFeature(string $feature): bool
    {
        $plan = $this->subscriptionPlan;

        if (! $plan) {
            return false;
        }

        return match ($feature) {
            'ai'         => $plan->ai_enabled,
            'analytics'  => $plan->analytics_enabled,
            'automation' => $plan->automation_enabled,
            'whatsapp'   => $plan->whatsapp_enabled,
            'api'        => $plan->api_access,
            default      => in_array($feature, $plan->features ?? []),
        };
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    public static function generateUniqueSlug(string $name): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $counter = 1;

        while (static::where('slug', $slug)->exists()) {
            $slug = "{$base}-{$counter}";
            $counter++;
        }

        return $slug;
    }
}
