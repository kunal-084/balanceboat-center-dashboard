<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{
    BelongsTo, HasMany, BelongsToMany, MorphMany, MorphOne
};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Experience extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'slug', 'meta_title', 'meta_description', 'keywords',
        'gps', 'experience_category', 'price_per_person', 'currency',
        'avg_price', 'price_shared', 'price_private', 'website', 'batch_size',
        'center_id', 'experience_summary', 'date_time', 'start_date_time',
        'end_date_time', 'is_full_day_event', 'is_recurring',
        'experience_certification_id', 'language_spoken', 'experience_overview',
        'video_url', 'thumbnail_image_url', 'banner_image_title',
        'banner_image_url', 'banner_image_path', 'styles_taught', 'food',
        'skill_level', 'skill_level_normalized', 'area', 'atmosphere',
        'experience_details', 'experience_highlights', 'food_overview',
        'food_banner_image_title', 'food_banner_image_url', 'schedule',
        'what_is_included', 'what_is_not_included', 'how_to_get_here',
        'booking_info', 'cancellation_policy', 'deposit_policy',
        'deposit_amount', 'cancellation_policy_condition',
        'cancellation_policy_days', 'rest_of_payment', 'rest_of_payment_days',
        'commission', 'tax', 'duration', 'duration_nights',
        'is_bookable', 'is_draft', 'publish_status', 'display_on_home',
        'eirly_bird_before_days', 'eirly_bird_discount', 'eirly_bird_discount_type',
        'offer_start_date', 'offer_end_date', 'offer_discount', 'offer_discount_type',
        'featured_experiences', 'best_off_season_deals', 'deals_of_the_month',
        'advance_trainings', 'weekend_retreats', 'couple_retreats',
        'blessed_by_the_sea', 'retreats_by_the_mountains',
        'luxury_retreats', 'budget_retreats', 'is_featured',
        'tags', 'ref_link', 'published_at',
    ];

    protected $casts = [
        'start_date_time'              => 'datetime',
        'end_date_time'                => 'datetime',
        'date_time'                    => 'datetime',
        'offer_start_date'             => 'date',
        'offer_end_date'               => 'date',
        'published_at'                 => 'datetime',
        'deleted_at'                   => 'datetime',
        'is_full_day_event'            => 'boolean',
        'is_recurring'                 => 'boolean',
        'is_bookable'                  => 'boolean',
        'is_draft'                     => 'boolean',
        'is_featured'                  => 'boolean',
        'display_on_home'              => 'boolean',
        'deposit_policy'               => 'boolean',
        'cancellation_policy_condition'=> 'boolean',
        'rest_of_payment'              => 'boolean',
        'featured_experiences'         => 'boolean',
        'best_off_season_deals'        => 'boolean',
        'deals_of_the_month'           => 'boolean',
        'advance_trainings'            => 'boolean',
        'weekend_retreats'             => 'boolean',
        'couple_retreats'              => 'boolean',
        'blessed_by_the_sea'           => 'boolean',
        'retreats_by_the_mountains'    => 'boolean',
        'luxury_retreats'              => 'boolean',
        'price_per_person'             => 'float',
        'avg_price'                    => 'float',
        'price_shared'                 => 'decimal:2',
        'price_private'                => 'decimal:2',
        'deposit_amount'               => 'float',
        'commission'                   => 'float',
        'eirly_bird_discount'          => 'float',
        'offer_discount'               => 'float',
        'average_rating'               => 'decimal:1',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $model) {
            if (empty($model->slug)) {
                $model->slug = static::generateUniqueSlug($model->name);
            }
        });
    }

    // ─── Relationships ───────────────────────────────────────────────────────

    public function center(): BelongsTo
    {
        return $this->belongsTo(Center::class);
    }

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class, 'experience_category', 'experience_id', 'category_id')
                    ->withTimestamps();
    }

    public function teachers(): BelongsToMany
    {
        return $this->belongsToMany(Teacher::class, 'experience_teachers', 'experience_id', 'teacher_id')
                    ->withTimestamps();
    }

    public function accommodations(): HasMany
    {
        return $this->hasMany(ExperienceAccomodation::class, 'experience_id');
    }

    public function accommodationPrices(): HasMany
    {
        return $this->hasMany(ExperienceAccomodationPrice::class, 'experience_id');
    }

    public function durationPrices(): HasMany
    {
        return $this->hasMany(ExperienceDurationPrice::class, 'experience_id');
    }

    public function imageGallery(): HasMany
    {
        return $this->hasMany(ExperienceImageGallery::class, 'experience_id');
    }

    public function foodImageGallery(): HasMany
    {
        return $this->hasMany(ExperienceFoodImageGallery::class, 'experience_id');
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(ExperienceSchedule::class, 'experience_id');
    }

    public function recurring(): HasMany
    {
        return $this->hasMany(ExperienceRecurring::class, 'experience_id');
    }

    public function recurringManually(): HasMany
    {
        return $this->hasMany(ExperienceRecurringManually::class, 'experience_id');
    }

    public function recurringExceptions(): HasMany
    {
        return $this->hasMany(ExperienceRecurringException::class, 'experience_id');
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class, 'experience_id');
    }

    public function inquiries(): HasMany
    {
        return $this->hasMany(Inquiry::class, 'experience_id');
    }

    public function faqs(): HasMany
    {
        return $this->hasMany(RetreatFaq::class, 'experience_id')
                    ->orderBy('sort_order');
    }

    public function benefits(): HasMany
    {
        return $this->hasMany(RetreatBenefit::class, 'experience_id')
                    ->orderBy('sort_order');
    }

    public function itineraryDays(): HasMany
    {
        return $this->hasMany(RetreatItineraryDay::class, 'experience_id')
                    ->orderBy('day_number');
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(CenterReview::class, 'experience_id');
    }

    public function approvedReviews(): HasMany
    {
        return $this->hasMany(CenterReview::class, 'experience_id')
                    ->where('status', 'approved');
    }

    public function pricingRules(): HasMany
    {
        return $this->hasMany(PricingRule::class, 'experience_id')
                    ->where('is_active', true)
                    ->orderBy('priority', 'desc');
    }

    public function availabilityCalendar(): HasMany
    {
        return $this->hasMany(AvailabilityCalendar::class, 'experience_id');
    }

    public function mediaAssets(): MorphMany
    {
        return $this->morphMany(MediaAsset::class, 'mediable');
    }

    public function seoMetadata(): MorphOne
    {
        return $this->morphOne(SeoMetadata::class, 'seoable');
    }

    public function aiRecommendations(): HasMany
    {
        return $this->hasMany(AiRecommendation::class, 'experience_id');
    }

    // ─── Scopes ──────────────────────────────────────────────────────────────

    public function scopePublished($query)
    {
        return $query->where('publish_status', 'published')
                     ->where('is_draft', false)
                     ->where('is_bookable', true);
    }

    public function scopeDraft($query)
    {
        return $query->where('is_draft', true);
    }

    public function scopeForCenter($query, int $centerId)
    {
        return $query->where('center_id', $centerId);
    }

    public function scopeUpcoming($query)
    {
        return $query->where('start_date_time', '>', now());
    }

    public function scopeFeatured($query)
    {
        return $query->where('featured_experiences', true)->orWhere('is_featured', true);
    }

    public function scopeLuxury($query)
    {
        return $query->where('luxury_retreats', true);
    }

    public function scopeByCategory($query, int $categoryId)
    {
        return $query->whereHas('categories', fn($q) => $q->where('category.id', $categoryId));
    }

    public function scopeSearch($query, string $term)
    {
        return $query->where(function ($q) use ($term) {
            $q->where('name', 'like', "%{$term}%")
              ->orWhere('experience_summary', 'like', "%{$term}%")
              ->orWhere('tags', 'like', "%{$term}%");
        });
    }

    public function scopePriceBetween($query, float $min, float $max)
    {
        return $query->whereBetween('price_per_person', [$min, $max]);
    }

    public function scopeDurationBetween($query, int $minNights, int $maxNights)
    {
        return $query->whereBetween('duration_nights', [$minNights, $maxNights]);
    }

    // ─── Accessors ───────────────────────────────────────────────────────────

    public function getStatusLabelAttribute(): string
    {
        if ($this->is_draft) return 'Draft';
        return match ($this->publish_status) {
            'published' => 'Live',
            'archived'  => 'Archived',
            'paused'    => 'Paused',
            default     => 'Draft',
        };
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->status_label) {
            'Live'     => 'emerald',
            'Draft'    => 'amber',
            'Archived' => 'slate',
            'Paused'   => 'orange',
            default    => 'slate',
        };
    }

    public function getOccupancyRateAttribute(): float
    {
        if (! $this->batch_size) {
            return 0;
        }

        $booked = $this->bookings()
            ->whereIn('stage', ['confirmed', 'checked_in'])
            ->sum('guest_count');

        return round(($booked / $this->batch_size) * 100, 1);
    }

    public function getFormattedPriceAttribute(): string
    {
        return "{$this->currency} " . number_format((float) $this->price_per_person, 0);
    }

    public function getIsFullAttribute(): bool
    {
        return $this->occupancy_rate >= 100;
    }

    public function getComputedAverageRatingAttribute(): float
    {
        return (float) ($this->approvedReviews()->avg('overall_rating') ?? 0);
    }

    public function getHasEarlyBirdAttribute(): bool
    {
        return $this->eirly_bird_before_days > 0 && $this->eirly_bird_discount > 0;
    }

    public function getEarlyBirdDeadlineAttribute(): ?\Carbon\Carbon
    {
        if (! $this->has_early_bird || ! $this->start_date_time) {
            return null;
        }

        return $this->start_date_time->subDays($this->eirly_bird_before_days);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    public static function generateUniqueSlug(string $name): string
    {
        $base    = Str::slug($name);
        $slug    = $base;
        $counter = 1;

        while (static::where('slug', $slug)->exists()) {
            $slug = "{$base}-{$counter}";
            $counter++;
        }

        return $slug;
    }

    public function publish(): void
    {
        $this->update([
            'is_draft'       => false,
            'is_bookable'    => true,
            'publish_status' => 'published',
            'published_at'   => now(),
        ]);
    }

    public function archive(): void
    {
        $this->update([
            'is_draft'       => false,
            'is_bookable'    => false,
            'publish_status' => 'archived',
        ]);
    }

    public function duplicate(): self
    {
        $clone = $this->replicate([
            'slug', 'booking_count', 'view_count', 'review_count',
            'average_rating', 'published_at', 'created_at', 'updated_at',
        ]);

        $clone->name         = $this->name . ' (Copy)';
        $clone->slug         = static::generateUniqueSlug($clone->name);
        $clone->is_draft     = true;
        $clone->is_bookable  = false;
        $clone->publish_status = 'draft';
        $clone->published_at  = null;
        $clone->save();

        // Clone categories
        $clone->categories()->sync($this->categories()->pluck('category.id'));

        // Clone teachers
        $clone->teachers()->sync($this->teachers()->pluck('teachers.id'));

        // Clone faqs
        foreach ($this->faqs as $faq) {
            $clone->faqs()->create($faq->only(['question', 'answer', 'sort_order', 'is_published']));
        }

        // Clone benefits
        foreach ($this->benefits as $benefit) {
            $clone->benefits()->create($benefit->only(['benefit', 'icon', 'category', 'sort_order']));
        }

        // Clone itinerary
        foreach ($this->itineraryDays()->with('sessions')->get() as $day) {
            $newDay = $clone->itineraryDays()->create($day->only(['day_number', 'title', 'description', 'theme']));
            foreach ($day->sessions as $session) {
                $newDay->sessions()->create($session->only([
                    'start_time', 'end_time', 'activity', 'description',
                    'session_type', 'location', 'facilitator', 'is_optional', 'sort_order',
                ]));
            }
        }

        return $clone;
    }
}
