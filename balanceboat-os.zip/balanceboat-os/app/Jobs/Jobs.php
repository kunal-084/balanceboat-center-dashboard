<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

// ─────────────────────────────────────────────────────────────────────────────
// SendEmailJob
// ─────────────────────────────────────────────────────────────────────────────

class SendEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries    = 3;
    public int $backoff  = 60;
    public string $queue = 'emails';

    public function __construct(
        public readonly string $to,
        public readonly string $name,
        public readonly string $template,
        public readonly array  $data = []
    ) {}

    public function handle(): void
    {
        // Load template from DB first, fall back to blade view
        $emailTemplate = \App\Models\EmailTemplate::where('slug', $this->template)
            ->where('is_active', true)
            ->first();

        if ($emailTemplate) {
            $htmlBody = $emailTemplate->render($this->data);
            $subject  = $this->renderString($emailTemplate->subject, $this->data);

            Mail::html($htmlBody, function ($message) use ($subject) {
                $message->to($this->to, $this->name)
                        ->subject($subject)
                        ->from(config('mail.from.address'), config('mail.from.name'));
            });
        } else {
            // Fallback to Mailable class
            $mailableClass = 'App\\Mail\\' . str_replace(' ', '', ucwords(str_replace('_', ' ', $this->template))) . 'Mail';
            if (class_exists($mailableClass)) {
                Mail::to($this->to)->send(new $mailableClass($this->data));
            } else {
                Log::warning("Email template not found: {$this->template}");
            }
        }
    }

    protected function renderString(string $template, array $data): string
    {
        foreach ($data as $key => $value) {
            $template = str_replace("{{$key}}", $value, $template);
        }
        return $template;
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("SendEmailJob failed", [
            'to'       => $this->to,
            'template' => $this->template,
            'error'    => $exception->getMessage(),
        ]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SendWhatsAppJob
// ─────────────────────────────────────────────────────────────────────────────

class SendWhatsAppJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int    $tries    = 3;
    public int    $backoff  = 120;
    public string $queue    = 'notifications';

    public function __construct(
        public readonly string $phone,
        public readonly string $template,
        public readonly array  $params = [],
        public readonly string $languageCode = 'en'
    ) {}

    public function handle(): void
    {
        $accessToken = config('services.whatsapp.access_token');
        $phoneId     = config('services.whatsapp.phone_number_id');

        if (! $accessToken || ! $phoneId) {
            Log::warning('WhatsApp credentials not configured.');
            return;
        }

        $response = \Illuminate\Support\Facades\Http::withToken($accessToken)
            ->post("https://graph.facebook.com/v18.0/{$phoneId}/messages", [
                'messaging_product' => 'whatsapp',
                'to'                => $this->normalizePhone($this->phone),
                'type'              => 'template',
                'template'          => [
                    'name'     => $this->template,
                    'language' => ['code' => $this->languageCode],
                    'components' => ! empty($this->params)
                        ? [[
                            'type'       => 'body',
                            'parameters' => array_map(fn($p) => ['type' => 'text', 'text' => (string)$p], $this->params),
                        ]]
                        : [],
                ],
            ]);

        if (! $response->successful()) {
            Log::error('WhatsApp send failed', [
                'phone'    => $this->phone,
                'template' => $this->template,
                'response' => $response->json(),
            ]);
            throw new \RuntimeException('WhatsApp API returned: ' . $response->status());
        }
    }

    protected function normalizePhone(string $phone): string
    {
        return preg_replace('/[^0-9]/', '', $phone);
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("SendWhatsAppJob failed", ['phone' => $this->phone, 'error' => $exception->getMessage()]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ProcessAutomationJob
// ─────────────────────────────────────────────────────────────────────────────

class ProcessAutomationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int    $tries    = 2;
    public string $queue    = 'automations';
    public int    $backoff  = 300;

    public function __construct(
        public readonly AutomationRule $rule,
        public readonly array          $triggerData = []
    ) {}

    public function handle(\App\Actions\Automation\DispatchAutomationAction $action): void
    {
        if (! $this->rule->is_active) {
            return;
        }

        $action->handle($this->rule, $this->triggerData);
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("ProcessAutomationJob failed", [
            'rule_id' => $this->rule->id,
            'error'   => $exception->getMessage(),
        ]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GenerateThumbnailsJob
// ─────────────────────────────────────────────────────────────────────────────

class GenerateThumbnailsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'media';

    public function __construct(public readonly MediaAsset $asset) {}

    public function handle(): void
    {
        if ($this->asset->media_type !== 'image') return;

        $content = Storage::disk($this->asset->disk)->get($this->asset->path);
        if (! $content) {
            Log::warning("GenerateThumbnailsJob: Could not read file", ['path' => $this->asset->path]);
            return;
        }

        $image     = imagecreatefromstring($content);
        if (! $image) return;

        $thumbSizes = ['small' => 150, 'medium' => 400, 'large' => 800];
        $thumbnails = [];

        foreach ($thumbSizes as $size => $maxWidth) {
            [$thumbContent, $thumbPath] = $this->resizeImage(
                $image, $content, $maxWidth, $size, $this->asset
            );

            if ($thumbContent) {
                Storage::disk($this->asset->disk)->put($thumbPath, $thumbContent);
                $thumbnails[$size] = Storage::disk($this->asset->disk)->url($thumbPath);
            }
        }

        imagedestroy($image);

        $this->asset->update(['thumbnails' => $thumbnails]);
    }

    protected function resizeImage($image, string $content, int $maxWidth, string $size, MediaAsset $asset): array
    {
        $origWidth  = imagesx($image);
        $origHeight = imagesy($image);

        if ($origWidth <= $maxWidth) {
            $thumbPath = str_replace('/uploads/', "/thumbs/{$size}/", $asset->path);
            return [$content, $thumbPath];
        }

        $ratio     = $maxWidth / $origWidth;
        $newWidth  = $maxWidth;
        $newHeight = (int) ($origHeight * $ratio);

        $thumb = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($thumb, $image, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        ob_start();
        imagejpeg($thumb, null, 85);
        $thumbContent = ob_get_clean();
        imagedestroy($thumb);

        $thumbPath = str_replace('/uploads/', "/thumbs/{$size}/", $asset->path);
        $thumbPath = preg_replace('/\.[^.]+$/', '.jpg', $thumbPath);

        return [$thumbContent, $thumbPath];
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("GenerateThumbnailsJob failed", ['asset_id' => $this->asset->id, 'error' => $exception->getMessage()]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GenerateAiRecommendationsJob
// ─────────────────────────────────────────────────────────────────────────────

class GenerateAiRecommendationsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue   = 'ai';
    public int    $timeout = 300;

    public function __construct(public readonly Center $center) {}

    public function handle(AiService $aiService): void
    {
        $aiService->generateRecommendations($this->center);
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("GenerateAiRecommendationsJob failed", ['center_id' => $this->center->id, 'error' => $exception->getMessage()]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RefreshAvailabilityCalendarJob
// ─────────────────────────────────────────────────────────────────────────────

class RefreshAvailabilityCalendarJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'default';

    public function __construct(public readonly Experience $experience, public readonly int $days = 90) {}

    public function handle(\App\Services\AvailabilityService $service): void
    {
        $service->refreshCalendarForExperience($this->experience, $this->days);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SendFollowUpSequenceJob
// ─────────────────────────────────────────────────────────────────────────────

class SendFollowUpSequenceJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'emails';
    public int    $tries = 2;

    public function __construct(
        public readonly \App\Models\Inquiry $inquiry,
        public readonly int                 $sequenceStep = 1
    ) {}

    public function handle(): void
    {
        if ($inquiry = $this->inquiry->fresh()) {
            // Don't follow up on converted or lost inquiries
            if (in_array($inquiry->pipeline_stage, ['won', 'lost'])) return;

            $templates = [
                1 => 'inquiry_follow_up_1',
                2 => 'inquiry_follow_up_2',
                3 => 'inquiry_follow_up_3',
            ];

            $template = $templates[$this->sequenceStep] ?? null;
            if (! $template || ! $inquiry->email) return;

            SendEmailJob::dispatch(
                to:       $inquiry->email,
                name:     $inquiry->name,
                template: $template,
                data:     [
                    'name'         => $inquiry->name,
                    'retreat_name' => $inquiry->experience?->name,
                ]
            )->onQueue('emails');

            $inquiry->update([
                'last_contacted_at' => now(),
                'contact_attempts'  => $inquiry->contact_attempts + 1,
            ]);

            // Queue next step if applicable
            if ($this->sequenceStep < 3) {
                self::dispatch($inquiry, $this->sequenceStep + 1)
                    ->delay(now()->addDays(3))
                    ->onQueue('emails');
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ProcessPayoutJob
// ─────────────────────────────────────────────────────────────────────────────

class ProcessPayoutJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'finance';

    public function __construct(public readonly \App\Models\PayoutRequest $payout) {}

    public function handle(): void
    {
        // Integrate with Wise / Stripe Connect for actual transfers
        // For now: mark as processing and notify admin
        $this->payout->update([
            'status'       => 'processing',
            'processed_at' => now(),
        ]);

        // Notify center owner
        $owner = $this->payout->center->owner;
        if ($owner) {
            $owner->notify(new \App\Notifications\PayoutProcessedNotification($this->payout));
        }

        Log::info("Payout processed", ['reference' => $this->payout->reference, 'amount' => $this->payout->net_payout]);
    }

    public function failed(\Throwable $exception): void
    {
        $this->payout->update(['status' => 'failed']);
        Log::error("ProcessPayoutJob failed", ['payout_id' => $this->payout->id, 'error' => $exception->getMessage()]);
    }
}
