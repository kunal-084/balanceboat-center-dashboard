<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

/**
 * OTP Service
 *
 * Handles generation, delivery, and verification of one-time passwords.
 * Uses Redis/Cache as the backing store with configurable TTL.
 *
 * Cache key format: otp:{purpose}:{user_id}
 * Value: hashed OTP + metadata (attempts, created_at)
 */
class OtpService
{
    private const OTP_LENGTH   = 6;
    private const OTP_TTL_MINS = 10;
    private const MAX_ATTEMPTS = 5;

    public function __construct(
        private readonly EmailService   $emailService,
        private readonly WhatsAppService $whatsAppService,
    ) {}

    /**
     * Generate and send a login OTP to the given user.
     */
    public function sendLoginOtp(User $user, string $channel = 'email'): bool
    {
        $otp = $this->generate();

        $this->store($user, 'login', $otp);

        return match ($channel) {
            'whatsapp' => $this->sendViaWhatsApp($user, $otp),
            default    => $this->sendViaEmail($user, $otp),
        };
    }

    /**
     * Verify a submitted OTP for the given user and purpose.
     * Returns true if valid; false if expired, wrong, or too many attempts.
     */
    public function verify(User $user, string $submitted, string $purpose = 'login'): bool
    {
        $key  = $this->cacheKey($user, $purpose);
        $data = Cache::get($key);

        if (! $data) {
            return false; // Expired or never set
        }

        // Increment attempt counter
        $data['attempts'] = ($data['attempts'] ?? 0) + 1;
        Cache::put($key, $data, now()->addMinutes(self::OTP_TTL_MINS));

        if ($data['attempts'] > self::MAX_ATTEMPTS) {
            Cache::forget($key);
            Log::warning("OTP max attempts exceeded", ['user_id' => $user->id]);
            return false;
        }

        if (! hash_equals($data['hash'], hash('sha256', $submitted))) {
            return false;
        }

        // Valid — consume the OTP so it can't be reused
        Cache::forget($key);
        return true;
    }

    /**
     * Invalidate any existing OTP for this user/purpose.
     */
    public function invalidate(User $user, string $purpose = 'login'): void
    {
        Cache::forget($this->cacheKey($user, $purpose));
    }

    /**
     * Check if an OTP has been sent recently (rate-limiting helper).
     */
    public function recentlySent(User $user, string $purpose = 'login'): bool
    {
        $data = Cache::get($this->cacheKey($user, $purpose));
        if (! $data) return false;

        $created = $data['created_at'] ?? 0;
        return (time() - $created) < 60; // True if sent within last 60 seconds
    }

    // ─── Private Helpers ─────────────────────────────────────────────────────

    private function generate(): string
    {
        return str_pad((string) random_int(0, 10 ** self::OTP_LENGTH - 1), self::OTP_LENGTH, '0', STR_PAD_LEFT);
    }

    private function store(User $user, string $purpose, string $otp): void
    {
        Cache::put(
            $this->cacheKey($user, $purpose),
            [
                'hash'       => hash('sha256', $otp),
                'attempts'   => 0,
                'created_at' => time(),
            ],
            now()->addMinutes(self::OTP_TTL_MINS)
        );
    }

    private function sendViaEmail(User $user, string $otp): bool
    {
        try {
            $this->emailService->sendRaw(
                to:      $user->email,
                subject: "Your BalanceBoat login code: {$otp}",
                body:    $this->emailBody($user, $otp),
            );
            return true;
        } catch (\Throwable $e) {
            Log::error('OTP email delivery failed', ['user_id' => $user->id, 'error' => $e->getMessage()]);
            return false;
        }
    }

    private function sendViaWhatsApp(User $user, string $otp): bool
    {
        if (! $user->phone) {
            return $this->sendViaEmail($user, $otp);
        }

        try {
            $this->whatsAppService->sendTemplate(
                phone:    $user->phone,
                template: 'otp_login',
                params:   [$otp, self::OTP_TTL_MINS . ' minutes'],
            );
            return true;
        } catch (\Throwable $e) {
            Log::warning('OTP WhatsApp failed, falling back to email', ['user_id' => $user->id]);
            return $this->sendViaEmail($user, $otp);
        }
    }

    private function cacheKey(User $user, string $purpose): string
    {
        return "otp:{$purpose}:{$user->id}";
    }

    private function emailBody(User $user, string $otp): string
    {
        return <<<HTML
        <!DOCTYPE html><html><body style="font-family:sans-serif;max-width:480px;margin:32px auto;color:#1f2937;">
        <div style="background:#f5f3ff;border-radius:16px;padding:32px;text-align:center;">
            <div style="font-size:40px;margin-bottom:12px;">🔐</div>
            <h2 style="margin:0 0 8px;color:#1f2937;">Your login code</h2>
            <p style="color:#6b7280;font-size:14px;margin:0 0 20px;">Hi {$user->first_name}, here's your one-time login code for BalanceBoat.</p>
            <div style="background:#fff;border:2px solid #ede9fe;border-radius:12px;padding:16px 32px;display:inline-block;margin-bottom:20px;">
                <span style="font-size:36px;font-weight:800;letter-spacing:10px;color:#7c3aed;">{$otp}</span>
            </div>
            <p style="color:#9ca3af;font-size:12px;margin:0;">This code expires in <strong>{self::OTP_TTL_MINS} minutes</strong>. Don't share it with anyone.</p>
        </div>
        <p style="text-align:center;font-size:11px;color:#d1d5db;margin-top:16px;">BalanceBoat Center OS · If you didn't request this, ignore this email.</p>
        </body></html>
        HTML;
    }
}
