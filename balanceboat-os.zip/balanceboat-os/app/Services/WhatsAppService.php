<?php

namespace App\Services;

use App\Models\WhatsappTemplate;
use App\Jobs\SendWhatsAppJob;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsAppService
{
    protected string $apiUrl;
    protected string $phoneNumberId;
    protected string $accessToken;
    protected bool   $enabled;

    public function __construct()
    {
        $this->apiUrl        = 'https://graph.facebook.com/v18.0';
        $this->phoneNumberId = config('services.whatsapp.phone_number_id', '');
        $this->accessToken   = config('services.whatsapp.access_token', '');
        $this->enabled       = ! empty($this->phoneNumberId) && ! empty($this->accessToken);
    }

    /**
     * Send a templated WhatsApp message via the Business API.
     */
    public function sendTemplate(
        string $to,
        string $templateName,
        string $languageCode = 'en_US',
        array $components = []
    ): bool {
        if (! $this->enabled) {
            Log::info("WhatsAppService: disabled (no credentials). Would have sent [{$templateName}] to {$to}");
            return false;
        }

        $to = $this->normalizePhoneNumber($to);

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
                'name'     => $templateName,
                'language' => ['code' => $languageCode],
            ],
        ];

        if (! empty($components)) {
            $payload['template']['components'] = $components;
        }

        try {
            $response = Http::withToken($this->accessToken)
                ->timeout(15)
                ->post("{$this->apiUrl}/{$this->phoneNumberId}/messages", $payload);

            if ($response->successful()) {
                Log::info("WhatsAppService: Sent [{$templateName}] to {$to}", [
                    'message_id' => $response->json('messages.0.id'),
                ]);
                return true;
            }

            Log::error("WhatsAppService: Failed to send [{$templateName}] to {$to}", [
                'status'   => $response->status(),
                'response' => $response->json(),
            ]);
            return false;
        } catch (\Throwable $e) {
            Log::error("WhatsAppService: Exception sending [{$templateName}] to {$to}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send a plain text WhatsApp message (only works within 24-hour session window).
     */
    public function sendText(string $to, string $message): bool
    {
        if (! $this->enabled) {
            return false;
        }

        $to = $this->normalizePhoneNumber($to);

        try {
            $response = Http::withToken($this->accessToken)
                ->timeout(15)
                ->post("{$this->apiUrl}/{$this->phoneNumberId}/messages", [
                    'messaging_product' => 'whatsapp',
                    'recipient_type'    => 'individual',
                    'to'                => $to,
                    'type'              => 'text',
                    'text'              => ['body' => $message],
                ]);

            return $response->successful();
        } catch (\Throwable $e) {
            Log::error("WhatsAppService::sendText to {$to}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Queue a WhatsApp message using a DB template slug.
     */
    public function queueFromTemplate(
        string $phone,
        string $templateSlug,
        array $variables = []
    ): void {
        $template = WhatsappTemplate::where('slug', $templateSlug)
            ->where('is_active', true)
            ->first();

        if (! $template) {
            Log::warning("WhatsAppService: template [{$templateSlug}] not found for {$phone}");
            return;
        }

        SendWhatsAppJob::dispatch(
            $phone,
            $template->wa_template_name,
            $template->language_code ?? 'en_US',
            $this->buildComponents($template, $variables)
        );
    }

    /**
     * Build WhatsApp template components from stored template definition and variables.
     */
    protected function buildComponents(WhatsappTemplate $template, array $variables): array
    {
        $components = [];

        if ($template->header_text) {
            $rendered = $this->interpolate($template->header_text, $variables);
            $components[] = [
                'type'       => 'header',
                'parameters' => [['type' => 'text', 'text' => $rendered]],
            ];
        }

        if ($template->body_text) {
            $rendered   = $this->interpolate($template->body_text, $variables);
            $parameters = [];

            // Collect {{1}}, {{2}}, ... positional parameters
            preg_match_all('/\{\{(\d+)\}\}/', $template->body_text, $matches);
            foreach ($matches[1] as $index => $position) {
                $parameters[] = ['type' => 'text', 'text' => $variables["param{$position}"] ?? ''];
            }

            if (! empty($parameters)) {
                $components[] = ['type' => 'body', 'parameters' => $parameters];
            }
        }

        return $components;
    }

    protected function interpolate(string $text, array $vars): string
    {
        foreach ($vars as $key => $value) {
            $text = str_replace('{{' . $key . '}}', (string) $value, $text);
        }
        return $text;
    }

    /**
     * Normalize phone number to E.164 format (e.g. +918012345678).
     */
    protected function normalizePhoneNumber(string $phone): string
    {
        $phone = preg_replace('/[^0-9+]/', '', $phone);

        if (! str_starts_with($phone, '+')) {
            $phone = '+91' . ltrim($phone, '0');
        }

        return $phone;
    }

    /**
     * Check if the service is properly configured.
     */
    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * Send booking confirmation via WhatsApp using template components.
     */
    public function sendBookingConfirmation(string $phone, array $bookingData): bool
    {
        return $this->sendTemplate(
            phone: $phone,
            templateName: 'booking_confirmed',
            languageCode: 'en_US',
            components: [
                [
                    'type'       => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $bookingData['guest_name'] ?? 'Guest'],
                        ['type' => 'text', 'text' => $bookingData['retreat_name'] ?? ''],
                        ['type' => 'text', 'text' => $bookingData['booking_reference'] ?? ''],
                        ['type' => 'text', 'text' => $bookingData['start_date'] ?? ''],
                        ['type' => 'text', 'text' => $bookingData['center_name'] ?? ''],
                    ],
                ],
            ]
        );
    }

    /**
     * Send retreat reminder 24 hours before start.
     */
    public function sendRetreatReminder(string $phone, array $data): bool
    {
        return $this->sendTemplate(
            phone: $phone,
            templateName: 'retreat_reminder_24h',
            languageCode: 'en_US',
            components: [
                [
                    'type'       => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $data['guest_name'] ?? 'Guest'],
                        ['type' => 'text', 'text' => $data['retreat_name'] ?? ''],
                        ['type' => 'text', 'text' => $data['start_time'] ?? ''],
                        ['type' => 'text', 'text' => $data['center_name'] ?? ''],
                    ],
                ],
            ]
        );
    }

    /**
     * Send review request post-completion.
     */
    public function sendReviewRequest(string $phone, array $data): bool
    {
        return $this->sendTemplate(
            phone: $phone,
            templateName: 'review_request',
            languageCode: 'en_US',
            components: [
                [
                    'type'       => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $data['guest_name'] ?? 'Guest'],
                        ['type' => 'text', 'text' => $data['retreat_name'] ?? ''],
                        ['type' => 'text', 'text' => $data['review_link'] ?? config('app.url')],
                    ],
                ],
            ]
        );
    }
}
