<?php

namespace App\Services;

use App\DTOs\{RetreatDTO, PricingDTO, MediaUploadDTO, AiContentDTO};
use App\Models\{
    Experience, Center, AvailabilityCalendar, MediaAsset, MediaFolder,
    AiRecommendation, PricingRule
};
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{DB, Http, Log, Storage};
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

// ─────────────────────────────────────────────────────────────────────────────
// RetreatService
// ─────────────────────────────────────────────────────────────────────────────

class RetreatService
{
    public function create(RetreatDTO $dto): Experience
    {
        return DB::transaction(function () use ($dto) {
            $data = $dto->toArray();
            $data['slug'] = $data['slug'] ?? Experience::generateUniqueSlug($dto->name);

            $experience = Experience::create($data);

            if ($dto->categoryIds) {
                $experience->categories()->sync($dto->categoryIds);
            }

            if ($dto->teacherIds) {
                $experience->teachers()->sync($dto->teacherIds);
            }

            return $experience->load(['categories', 'teachers']);
        });
    }

    public function update(Experience $experience, array $data): Experience
    {
        return DB::transaction(function () use ($experience, $data) {
            $categoryIds = $data['category_ids'] ?? null;
            $teacherIds  = $data['teacher_ids'] ?? null;

            unset($data['category_ids'], $data['teacher_ids']);

            $experience->update($data);

            if ($categoryIds !== null) {
                $experience->categories()->sync($categoryIds);
            }

            if ($teacherIds !== null) {
                $experience->teachers()->sync($teacherIds);
            }

            return $experience->fresh(['categories', 'teachers']);
        });
    }

    public function publish(Experience $experience): Experience
    {
        $this->assertPublishable($experience);
        $experience->publish();

        event(new \App\Events\RetreatPublished($experience));

        return $experience->fresh();
    }

    public function unpublish(Experience $experience): Experience
    {
        $experience->update([
            'is_draft'       => true,
            'is_bookable'    => false,
            'publish_status' => 'draft',
        ]);

        return $experience->fresh();
    }

    public function duplicate(Experience $experience): Experience
    {
        return $experience->duplicate();
    }

    public function getStats(int $centerId): array
    {
        return [
            'total'          => Experience::forCenter($centerId)->count(),
            'published'      => Experience::forCenter($centerId)->published()->count(),
            'draft'          => Experience::forCenter($centerId)->draft()->count(),
            'upcoming'       => Experience::forCenter($centerId)->published()->upcoming()->count(),
            'avg_occupancy'  => $this->calculateAvgOccupancy($centerId),
            'total_bookings' => \App\Models\Booking::forCenter($centerId)->count(),
        ];
    }

    protected function assertPublishable(Experience $experience): void
    {
        $errors = [];

        if (empty($experience->name))              $errors[] = 'Retreat name is required.';
        if (empty($experience->experience_summary)) $errors[] = 'Retreat summary is required.';
        if (! $experience->price_per_person)       $errors[] = 'Price per person is required.';
        if (! $experience->batch_size)             $errors[] = 'Maximum capacity is required.';
        if (! $experience->banner_image_url)       $errors[] = 'Banner image is required.';
        if ($experience->categories()->count() === 0) $errors[] = 'At least one category is required.';

        if (! empty($errors)) {
            throw ValidationException::withMessages(['publish' => $errors]);
        }
    }

    protected function calculateAvgOccupancy(int $centerId): float
    {
        $experiences = Experience::forCenter($centerId)->published()->get();

        if ($experiences->isEmpty()) return 0;

        $rates = $experiences->map(fn($e) => $e->occupancy_rate);

        return round($rates->avg(), 1);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AvailabilityService
// ─────────────────────────────────────────────────────────────────────────────

class AvailabilityService
{
    public function assertAvailable(int $experienceId, string $date, int $guestCount): void
    {
        $calendar = AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->first();

        if (! $calendar) {
            return; // No calendar record means open by default
        }

        if ($calendar->status === 'closed' || $calendar->status === 'blocked') {
            throw ValidationException::withMessages([
                'arrival_date' => 'This date is not available for booking.',
            ]);
        }

        if ($calendar->status === 'sold_out' || $calendar->available_units < $guestCount) {
            throw ValidationException::withMessages([
                'guest_count' => "Only {$calendar->available_units} spots remaining on this date.",
            ]);
        }
    }

    public function lockUnits(int $experienceId, string $date, int $units): void
    {
        AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->update([
                'booked_units'    => DB::raw("booked_units + {$units}"),
                'available_units' => DB::raw("GREATEST(0, available_units - {$units})"),
            ]);

        // Auto-update status if sold out
        $calendar = AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->first();

        if ($calendar && $calendar->available_units <= 0) {
            $calendar->update(['status' => 'sold_out']);
        }
    }

    public function releaseUnits(int $experienceId, string $date, int $units): void
    {
        AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->update([
                'booked_units'    => DB::raw("GREATEST(0, booked_units - {$units})"),
                'available_units' => DB::raw("available_units + {$units}"),
                'status'          => 'open',
            ]);
    }

    public function getCalendar(int $experienceId, Carbon $from, Carbon $to): array
    {
        $records = AvailabilityCalendar::where('experience_id', $experienceId)
            ->whereBetween('calendar_date', [$from->format('Y-m-d'), $to->format('Y-m-d')])
            ->orderBy('calendar_date')
            ->get()
            ->keyBy(fn($r) => $r->calendar_date->format('Y-m-d'));

        $experience = Experience::find($experienceId);
        $calendar   = [];
        $current    = $from->copy();

        while ($current->lte($to)) {
            $dateKey = $current->format('Y-m-d');
            $record  = $records[$dateKey] ?? null;

            $calendar[$dateKey] = [
                'date'            => $dateKey,
                'status'          => $record?->status ?? 'open',
                'available_units' => $record?->available_units ?? ($experience?->batch_size ?? 0),
                'booked_units'    => $record?->booked_units ?? 0,
                'override_price'  => $record?->override_price,
                'is_available'    => (! $record || $record->status === 'open') && ($record?->available_units ?? ($experience?->batch_size ?? 1)) > 0,
            ];

            $current->addDay();
        }

        return $calendar;
    }

    public function blockDates(int $experienceId, array $dates, string $reason = ''): void
    {
        $experience = Experience::findOrFail($experienceId);

        foreach ($dates as $date) {
            AvailabilityCalendar::updateOrCreate(
                ['experience_id' => $experienceId, 'calendar_date' => $date],
                [
                    'status'          => 'blocked',
                    'total_units'     => $experience->batch_size ?? 0,
                    'available_units' => 0,
                    'block_reason'    => $reason,
                ]
            );
        }
    }

    public function unblockDates(int $experienceId, array $dates): void
    {
        $experience = Experience::findOrFail($experienceId);

        AvailabilityCalendar::where('experience_id', $experienceId)
            ->whereIn('calendar_date', $dates)
            ->update([
                'status'          => 'open',
                'available_units' => DB::raw('total_units - booked_units'),
                'block_reason'    => null,
            ]);
    }

    public function refreshCalendarForExperience(Experience $experience, int $days = 90): void
    {
        $batchSize = $experience->batch_size ?? 0;
        $from      = today();
        $to        = today()->addDays($days);

        $existing = AvailabilityCalendar::where('experience_id', $experience->id)
            ->whereBetween('calendar_date', [$from, $to])
            ->pluck('calendar_date')
            ->map(fn($d) => $d->format('Y-m-d'))
            ->toArray();

        $current = $from->copy();

        while ($current->lte($to)) {
            $dateStr = $current->format('Y-m-d');

            if (! in_array($dateStr, $existing)) {
                AvailabilityCalendar::create([
                    'experience_id'  => $experience->id,
                    'calendar_date'  => $dateStr,
                    'total_units'    => $batchSize,
                    'available_units'=> $batchSize,
                    'booked_units'   => 0,
                    'blocked_units'  => 0,
                    'status'         => 'open',
                ]);
            }

            $current->addDay();
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AnalyticsService
// ─────────────────────────────────────────────────────────────────────────────

class AnalyticsService
{
    public function getDashboardKpis(int $centerId, string $period = '30d'): array
    {
        $days    = (int) rtrim($period, 'd');
        $from    = now()->subDays($days);
        $prevFrom= now()->subDays($days * 2);
        $prevTo  = now()->subDays($days);

        $bookings      = fn() => \App\Models\Booking::forCenter($centerId);
        $paidBookings  = fn() => $bookings()->whereIn('stage', ['confirmed', 'checked_in', 'completed']);

        $currentRevenue = $paidBookings()->where('created_at', '>=', $from)->sum('pay_amount');
        $prevRevenue    = $paidBookings()->whereBetween('created_at', [$prevFrom, $prevTo])->sum('pay_amount');

        $currentBookings= $bookings()->where('created_at', '>=', $from)->count();
        $prevBookings   = $bookings()->whereBetween('created_at', [$prevFrom, $prevTo])->count();

        $currentInquiries = \App\Models\Inquiry::where('center_id', $centerId)->where('created_at', '>=', $from)->count();
        $prevInquiries    = \App\Models\Inquiry::where('center_id', $centerId)->whereBetween('created_at', [$prevFrom, $prevTo])->count();

        $wonInquiries     = \App\Models\Inquiry::where('center_id', $centerId)->where('pipeline_stage', 'won')->where('created_at', '>=', $from)->count();
        $conversionRate   = $currentInquiries > 0 ? round(($wonInquiries / $currentInquiries) * 100, 1) : 0;

        return [
            'revenue'         => ['current' => (float)$currentRevenue, 'previous' => (float)$prevRevenue, 'change_pct' => $this->changePct($prevRevenue, $currentRevenue)],
            'bookings'        => ['current' => $currentBookings, 'previous' => $prevBookings, 'change_pct' => $this->changePct($prevBookings, $currentBookings)],
            'inquiries'       => ['current' => $currentInquiries, 'previous' => $prevInquiries, 'change_pct' => $this->changePct($prevInquiries, $currentInquiries)],
            'conversion_rate' => ['current' => $conversionRate, 'won' => $wonInquiries],
            'avg_booking_value'=> round((float)$paidBookings()->where('created_at', '>=', $from)->avg('pay_amount'), 2),
            'occupancy_rate'  => $this->getCenterOccupancyRate($centerId),
            'today_checkins'  => $bookings()->inStage('confirmed')->where('arrival_date', today())->count(),
            'current_guests'  => $bookings()->inStage('checked_in')->count(),
        ];
    }

    public function getRevenueChart(int $centerId, string $from, string $to, string $group = 'day'): array
    {
        $query = \App\Models\Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"]);

        $format = match ($group) {
            'week'  => '%Y-%u',
            'month' => '%Y-%m',
            default => '%Y-%m-%d',
        };

        return $query->selectRaw("DATE_FORMAT(created_at, '{$format}') as period, SUM(pay_amount) as revenue, COUNT(*) as bookings")
            ->groupBy('period')
            ->orderBy('period')
            ->get()
            ->map(fn($row) => ['period' => $row->period, 'revenue' => (float)$row->revenue, 'bookings' => $row->bookings])
            ->toArray();
    }

    public function getBookingFunnel(int $centerId, string $from, string $to): array
    {
        $inquiries = \App\Models\Inquiry::where('center_id', $centerId)->whereBetween('created_at', [$from, $to]);

        $total      = (clone $inquiries)->count();
        $contacted  = (clone $inquiries)->whereNotIn('pipeline_stage', ['new'])->count();
        $qualified  = (clone $inquiries)->whereIn('pipeline_stage', ['qualified','proposal','negotiating','won'])->count();
        $proposed   = (clone $inquiries)->whereIn('pipeline_stage', ['proposal','negotiating','won'])->count();
        $won        = (clone $inquiries)->where('pipeline_stage', 'won')->count();

        return [
            ['stage' => 'Inquiries',   'count' => $total,     'pct' => 100],
            ['stage' => 'Contacted',   'count' => $contacted,  'pct' => $total > 0 ? round($contacted/$total*100,1) : 0],
            ['stage' => 'Qualified',   'count' => $qualified,  'pct' => $total > 0 ? round($qualified/$total*100,1) : 0],
            ['stage' => 'Proposals',   'count' => $proposed,   'pct' => $total > 0 ? round($proposed/$total*100,1) : 0],
            ['stage' => 'Converted',   'count' => $won,        'pct' => $total > 0 ? round($won/$total*100,1) : 0],
        ];
    }

    public function getTopRetreats(int $centerId, int $limit = 5, string $orderBy = 'revenue'): array
    {
        return Experience::forCenter($centerId)
            ->withCount(['bookings as booking_count' => fn($q) => $q->whereIn('stage', ['confirmed','checked_in','completed'])])
            ->withSum(['bookings as total_revenue' => fn($q) => $q->whereIn('stage', ['confirmed','checked_in','completed'])], 'pay_amount')
            ->orderByDesc($orderBy === 'revenue' ? 'total_revenue' : 'booking_count')
            ->limit($limit)
            ->get()
            ->map(fn($e) => [
                'id'             => $e->id,
                'name'           => $e->name,
                'booking_count'  => $e->booking_count,
                'total_revenue'  => (float) $e->total_revenue,
                'occupancy_rate' => $e->occupancy_rate,
                'avg_rating'     => $e->computed_average_rating,
            ])
            ->toArray();
    }

    public function getOccupancyByMonth(int $centerId, int $months = 6): array
    {
        $results = [];
        for ($i = 0; $i < $months; $i++) {
            $month = now()->subMonths($i);
            $occupancy = \App\Models\Booking::forCenter($centerId)
                ->forMonth($month->year, $month->month)
                ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
                ->sum('guest_count');

            $capacity = Experience::forCenter($centerId)
                ->published()
                ->sum('batch_size');

            $results[] = [
                'period' => $month->format('Y-m'),
                'label'  => $month->format('M Y'),
                'booked' => $occupancy,
                'capacity' => $capacity,
                'rate'   => $capacity > 0 ? round($occupancy / $capacity * 100, 1) : 0,
            ];
        }

        return array_reverse($results);
    }

    protected function getCenterOccupancyRate(int $centerId): float
    {
        $capacity = Experience::forCenter($centerId)->published()->sum('batch_size');
        if (! $capacity) return 0;

        $booked = \App\Models\Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in'])
            ->sum('guest_count');

        return round($booked / $capacity * 100, 1);
    }

    protected function changePct($prev, $current): float
    {
        if (! $prev) return $current > 0 ? 100 : 0;
        return round(($current - $prev) / $prev * 100, 1);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MediaService
// ─────────────────────────────────────────────────────────────────────────────

class MediaService
{
    public function upload(UploadedFile $file, MediaUploadDTO $dto): MediaAsset
    {
        $filename = Str::uuid() . '.' . $file->getClientOriginalExtension();
        $path     = "centers/{$dto->centerId}/{$dto->collection}/{$filename}";

        Storage::disk($dto->disk)->put($path, file_get_contents($file->getRealPath()));

        $url = Storage::disk($dto->disk)->url($path);

        [$width, $height] = $this->getImageDimensions($file);

        $asset = MediaAsset::create([
            'center_id'         => $dto->centerId,
            'folder_id'         => $dto->folderId,
            'uploaded_by'       => auth()->id(),
            'mediable_type'     => $dto->mediableType,
            'mediable_id'       => $dto->mediableId,
            'collection'        => $dto->collection,
            'filename'          => $filename,
            'original_filename' => $file->getClientOriginalName(),
            'disk'              => $dto->disk,
            'path'              => $path,
            'url'               => $url,
            'cdn_url'           => $this->toCdnUrl($url),
            'mime_type'         => $file->getMimeType(),
            'media_type'        => $this->classifyMimeType($file->getMimeType()),
            'size_bytes'        => $file->getSize(),
            'width'             => $width,
            'height'            => $height,
            'alt_text'          => $dto->altText,
            'caption'           => $dto->caption,
            'category'          => $dto->category,
        ]);

        if ($dto->generateThumbs && str_starts_with($file->getMimeType(), 'image/')) {
            dispatch(new \App\Jobs\GenerateThumbnailsJob($asset));
        }

        return $asset;
    }

    public function delete(MediaAsset $asset): void
    {
        Storage::disk($asset->disk)->delete($asset->path);

        if ($asset->thumbnails) {
            foreach ($asset->thumbnails as $thumbPath) {
                Storage::disk($asset->disk)->delete($thumbPath);
            }
        }

        $asset->delete();
    }

    public function reorder(array $ids): void
    {
        foreach ($ids as $order => $id) {
            MediaAsset::where('id', $id)->update(['sort_order' => $order]);
        }
    }

    protected function getImageDimensions(UploadedFile $file): array
    {
        if (! str_starts_with($file->getMimeType(), 'image/')) {
            return [null, null];
        }

        try {
            [$width, $height] = getimagesize($file->getRealPath());
            return [$width, $height];
        } catch (\Throwable) {
            return [null, null];
        }
    }

    protected function classifyMimeType(string $mime): string
    {
        if (str_starts_with($mime, 'image/')) return 'image';
        if (str_starts_with($mime, 'video/')) return 'video';
        if (str_starts_with($mime, 'audio/')) return 'audio';
        if (in_array($mime, ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])) return 'document';
        return 'other';
    }

    protected function toCdnUrl(string $url): ?string
    {
        $cdnBase = config('media.cdn_base_url');
        if (! $cdnBase) return null;

        $s3Base = rtrim(config('filesystems.disks.s3.url', ''), '/');
        return $s3Base ? str_replace($s3Base, rtrim($cdnBase, '/'), $url) : null;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AiService
// ─────────────────────────────────────────────────────────────────────────────

class AiService
{
    private string $model;

    public function __construct()
    {
        $this->model = config('services.openai.model', 'gpt-4o');
    }

    public function generateContent(AiContentDTO $dto): string
    {
        $prompts = [
            'title'       => "Write a compelling, SEO-optimized retreat title for a {type} retreat ({duration} nights) at {location}. Maximum 80 characters. Tone: {tone}.",
            'summary'     => "Write a 60-word retreat summary for a {type} retreat at {location}. Include the core transformation and key benefits. Tone: {tone}.",
            'description' => "Write a rich, immersive 300-word retreat description for a {type} retreat at {location} lasting {duration} nights. Include transformation benefits, unique elements, and sensory language. Audience: {audience}. Tone: {tone}.",
            'seo_title'   => "Write an SEO title (max 60 chars) for a {type} retreat at {location}.",
            'seo_desc'    => "Write an SEO meta description (max 155 chars) for a {type} retreat at {location}. Include keywords and a call to action.",
            'faqs'        => "Generate 5 frequently asked questions with concise answers for a {type} retreat at {location}. Return as JSON: [{\"question\":\"\",\"answer\":\"\"}]",
            'benefits'    => "List 8 key transformation benefits of a {type} retreat at {location}. Return as JSON array of strings.",
            'itinerary'   => "Create a sample daily schedule for a {type} retreat. Return as JSON: [{\"time\":\"06:00\",\"activity\":\"\",\"type\":\"yoga\"}]",
        ];

        $prompt = str_replace(
            ['{type}', '{location}', '{duration}', '{audience}', '{tone}'],
            [$dto->retreatType, $dto->location ?? 'a luxury wellness sanctuary', $dto->durationNights ?? 7, $dto->targetAudience ?? 'wellness seekers', $dto->tone],
            $prompts[$dto->type] ?? $prompts['description']
        );

        if ($dto->additionalContext) {
            $prompt .= "\n\nAdditional context: {$dto->additionalContext}";
        }

        return $this->callOpenAi($prompt, $dto->language);
    }

    public function generatePricingRecommendations(Experience $experience, PricingService $pricingService): array
    {
        return $pricingService->getPricingRecommendations($experience);
    }

    public function generateSeoMetadata(Experience $experience): array
    {
        $dto = new AiContentDTO(
            type:         'seo_title',
            retreatType:  $experience->experience_category ?? 'wellness',
            centerId:     $experience->center_id,
            experienceId: $experience->id,
            location:     $experience->center?->city . ', ' . $experience->center?->country,
            durationNights: (int) $experience->duration_nights,
        );

        $title = $this->generateContent($dto);
        $desc  = $this->generateContent(new AiContentDTO(...array_merge((array)$dto, ['type' => 'seo_desc'])));

        return [
            'meta_title'       => $title,
            'meta_description' => $desc,
            'keywords'         => $this->extractKeywords($experience),
        ];
    }

    public function generateRecommendations(Center $center): void
    {
        $pricingService = app(PricingService::class);

        foreach ($center->publishedExperiences as $experience) {
            $recs = $pricingService->getPricingRecommendations($experience);

            foreach ($recs as $rec) {
                AiRecommendation::updateOrCreate(
                    ['center_id' => $center->id, 'experience_id' => $experience->id, 'type' => 'pricing', 'status' => 'active'],
                    [
                        'title'           => "Pricing Recommendation: " . ucwords(str_replace('_', ' ', $rec['type'])),
                        'recommendation'  => $rec['suggestion'],
                        'confidence_score'=> 80.0,
                        'supporting_data' => ['impact' => $rec['impact'], 'priority' => $rec['priority']],
                        'expires_at'      => now()->addDays(7),
                        'ai_model'        => 'rule-engine',
                    ]
                );
            }
        }
    }

    protected function callOpenAi(string $prompt, string $language = 'en'): string
    {
        $apiKey = config('services.openai.key');

        if (! $apiKey) {
            return '[AI generation disabled. Configure OPENAI_API_KEY to enable.]';
        }

        try {
            $response = Http::withToken($apiKey)
                ->timeout(45)
                ->post('https://api.openai.com/v1/chat/completions', [
                    'model'      => $this->model,
                    'max_tokens' => 1500,
                    'messages'   => [
                        [
                            'role'    => 'system',
                            'content' => "You are an expert luxury wellness retreat copywriter. Write compelling, authentic content in {$language}. Respond only with the requested content, no preamble.",
                        ],
                        ['role' => 'user', 'content' => $prompt],
                    ],
                ]);

            return $response->json('choices.0.message.content', '');
        } catch (\Throwable $e) {
            Log::error('OpenAI API error', ['message' => $e->getMessage()]);
            return '';
        }
    }

    protected function extractKeywords(Experience $experience): string
    {
        $keywords = array_filter([
            $experience->name,
            $experience->experience_category,
            $experience->center?->city,
            $experience->center?->country,
            $experience->duration_nights ? "{$experience->duration_nights} night retreat" : null,
            $experience->food,
        ]);

        return implode(', ', $keywords);
    }
}
