<?php

namespace App\Services;

use App\Models\EmailTemplate;
use App\Models\User;
use App\Jobs\SendEmailJob;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Mail\Message;
use Illuminate\Database\Eloquent\Model;

class EmailService
{
    /**
     * Send an email using a named template from the database.
     * Falls back to a plain message if template not found.
     */
    public function sendTemplate(
        string $templateSlug,
        User|string $recipient,
        array $variables = [],
        ?string $subject = null
    ): void {
        $template = EmailTemplate::where('slug', $templateSlug)
            ->where('is_active', true)
            ->first();

        $to = $recipient instanceof User ? $recipient->email : $recipient;
        $name = $recipient instanceof User ? $recipient->name : null;

        if ($template) {
            $renderedSubject = $this->renderTemplate($template->subject, $variables);
            $renderedBody    = $this->renderTemplate($template->body_html, $variables);
            $renderedText    = $this->renderTemplate($template->body_text ?? strip_tags($renderedBody), $variables);

            SendEmailJob::dispatch($to, $renderedSubject, $renderedBody, $renderedText, $name);
        } else {
            Log::warning("EmailService: Template [{$templateSlug}] not found, skipping email to {$to}");
        }
    }

    /**
     * Send a one-off transactional email using a Mailable class.
     */
    public function sendMailable(string $to, object $mailable, bool $queue = true): void
    {
        if ($queue) {
            Mail::to($to)->queue($mailable);
        } else {
            Mail::to($to)->send($mailable);
        }
    }

    /**
     * Send a raw HTML email immediately (useful for system alerts).
     */
    public function sendRaw(string $to, string $subject, string $html, string $name = ''): void
    {
        try {
            Mail::send([], [], function (Message $message) use ($to, $subject, $html, $name) {
                $message->to($to, $name ?: null)
                    ->subject($subject)
                    ->setBody($html, 'text/html');
            });
        } catch (\Throwable $e) {
            Log::error("EmailService::sendRaw failed to {$to}: " . $e->getMessage());
        }
    }

    /**
     * Preview a template with sample data (used in template editor).
     */
    public function previewTemplate(EmailTemplate $template, array $variables = []): array
    {
        $defaults = $this->getDefaultVariables();
        $merged   = array_merge($defaults, $variables);

        return [
            'subject' => $this->renderTemplate($template->subject, $merged),
            'html'    => $this->renderTemplate($template->body_html, $merged),
            'text'    => $this->renderTemplate($template->body_text ?? '', $merged),
        ];
    }

    /**
     * Get list of available template variables.
     */
    public function getAvailableVariables(): array
    {
        return [
            'general'  => ['{{center_name}}', '{{platform_name}}', '{{current_year}}'],
            'booking'  => [
                '{{booking_reference}}', '{{booking_status}}', '{{retreat_name}}',
                '{{retreat_start_date}}', '{{retreat_end_date}}', '{{guest_name}}',
                '{{guest_email}}', '{{total_amount}}', '{{currency}}',
                '{{accommodation_name}}', '{{booking_date}}',
            ],
            'inquiry'  => ['{{inquiry_name}}', '{{inquiry_email}}', '{{inquiry_message}}', '{{retreat_name}}'],
            'review'   => ['{{guest_name}}', '{{rating}}', '{{review_title}}', '{{review_text}}', '{{retreat_name}}'],
            'teacher'  => ['{{teacher_name}}', '{{teacher_bio}}'],
            'auth'     => ['{{user_name}}', '{{reset_link}}', '{{verification_link}}', '{{otp_code}}'],
        ];
    }

    /**
     * Render template using {{variable}} syntax.
     */
    protected function renderTemplate(string $template, array $variables): string
    {
        $defaults = $this->getDefaultVariables();
        $all = array_merge($defaults, $variables);

        foreach ($all as $key => $value) {
            $template = str_replace('{{' . $key . '}}', (string) $value, $template);
        }

        return $template;
    }

    protected function getDefaultVariables(): array
    {
        return [
            'platform_name' => config('app.name', 'BalanceBoat'),
            'platform_url'  => config('app.url'),
            'current_year'  => now()->year,
            'support_email' => config('mail.from.address'),
        ];
    }
}
