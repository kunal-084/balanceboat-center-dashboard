<?php

namespace App\Services;

use App\DTOs\PricingDTO;
use App\Models\{PricingRule, PromoCode, Experience};
use Carbon\Carbon;
use Illuminate\Support\Collection;

class PricingService
{
    /**
     * Calculate the final price for a booking, applying all eligible rules.
     */
    public function calculatePrice(PricingDTO $dto): array
    {
        $rules = $this->getApplicableRules($dto);

        $basePrice     = $dto->basePrice;
        $totalDiscount = 0;
        $appliedRules  = [];

        // Apply rules in priority order
        foreach ($rules as $rule) {
            if (! $this->ruleAppliesToContext($rule, $dto)) {
                continue;
            }

            $discount = $rule->calculateDiscount($basePrice);

            if ($discount <= 0) {
                continue;
            }

            $totalDiscount += $discount;
            $appliedRules[] = [
                'id'        => $rule->id,
                'name'      => $rule->name,
                'type'      => $rule->rule_type,
                'discount'  => round($discount, 2),
                'stackable' => $rule->is_stackable,
            ];

            // Stop if rule is not stackable
            if (! $rule->is_stackable) {
                break;
            }
        }

        // Apply promo code on top
        $promoDiscount = 0;
        $promoCode     = null;

        if ($dto->promoCode) {
            [$promoDiscount, $promoCode] = $this->applyPromoCode(
                $dto->promoCode,
                $basePrice - $totalDiscount,
                $dto->experienceId
            );

            if ($promoDiscount > 0) {
                $totalDiscount += $promoDiscount;
            }
        }

        $finalPrice = max(0, round($basePrice - $totalDiscount, 2));

        return [
            'base_price'      => $basePrice,
            'total_discount'  => round($totalDiscount, 2),
            'promo_discount'  => round($promoDiscount, 2),
            'final_price'     => $finalPrice,
            'final_price_per_person' => $dto->guestCount > 0
                ? round($finalPrice / $dto->guestCount, 2)
                : $finalPrice,
            'currency'        => $dto->currency,
            'applied_rules'   => $appliedRules,
            'promo_code'      => $promoCode?->code,
            'savings_pct'     => $basePrice > 0
                ? round(($totalDiscount / $basePrice) * 100, 1)
                : 0,
        ];
    }

    /**
     * Get all applicable pricing rules for an experience.
     */
    protected function getApplicableRules(PricingDTO $dto): Collection
    {
        return PricingRule::query()
            ->where('is_active', true)
            ->where(function ($q) use ($dto) {
                $q->where('experience_id', $dto->experienceId)
                  ->orWhereNull('experience_id');
            })
            ->when($dto->accommodationId, fn($q) =>
                $q->where(fn($inner) =>
                    $inner->where('accommodation_id', $dto->accommodationId)
                          ->orWhereNull('accommodation_id')
                )
            )
            ->orderBy('priority', 'desc')
            ->get();
    }

    /**
     * Check if a rule applies to the current booking context.
     */
    protected function ruleAppliesToContext(PricingRule $rule, PricingDTO $dto): bool
    {
        // Date window check
        if ($dto->startDate && ! $rule->appliesToDate($dto->startDate)) {
            return false;
        }

        // Lead time check
        if ($dto->daysUntilStart !== null) {
            if (! $rule->appliesToBookingLeadTime($dto->daysUntilStart)) {
                return false;
            }
        }

        // Occupancy check
        if ($rule->rule_type === 'occupancy_based') {
            if (! $rule->appliesToOccupancy($dto->occupancyRate)) {
                return false;
            }
        }

        // Duration check
        if ($rule->rule_type === 'duration_based' && $rule->min_duration_nights) {
            if ($dto->durationNights < $rule->min_duration_nights) {
                return false;
            }
        }

        // Group size check
        if ($rule->rule_type === 'group_discount' && $rule->min_group_size) {
            if ($dto->guestCount < $rule->min_group_size) {
                return false;
            }
        }

        return true;
    }

    /**
     * Apply a promo code and return [discount, PromoCode].
     */
    protected function applyPromoCode(
        string $code,
        float $amount,
        int $experienceId
    ): array {
        $promo = PromoCode::active()
            ->where('code', strtoupper($code))
            ->first();

        if (! $promo) {
            return [0, null];
        }

        // Check experience applicability
        if (! $promo->applies_to_all) {
            $applicable = $promo->applicable_experience_ids ?? [];
            if (! in_array($experienceId, $applicable)) {
                return [0, null];
            }
        }

        // Check user usage limit
        if ($promo->max_uses_per_user > 0 && auth()->check()) {
            $userUsage = $promo->redemptions()
                ->where('user_id', auth()->id())
                ->count();

            if ($userUsage >= $promo->max_uses_per_user) {
                return [0, null];
            }
        }

        $discount = $promo->calculateDiscount($amount);

        return [$discount, $promo];
    }

    /**
     * Validate a promo code and return info without applying it.
     */
    public function validatePromoCode(string $code, float $amount, int $experienceId): array
    {
        $promo = PromoCode::active()
            ->where('code', strtoupper($code))
            ->first();

        if (! $promo) {
            return ['valid' => false, 'message' => 'Promo code not found or expired.'];
        }

        if ($promo->min_booking_amount && $amount < $promo->min_booking_amount) {
            return [
                'valid'   => false,
                'message' => "Minimum booking amount of {$promo->min_booking_amount} required.",
            ];
        }

        $discount = $promo->calculateDiscount($amount);

        return [
            'valid'          => true,
            'code'           => $promo->code,
            'description'    => $promo->description,
            'discount_type'  => $promo->discount_type,
            'discount_value' => $promo->discount_value,
            'discount_amount'=> round($discount, 2),
            'final_amount'   => round($amount - $discount, 2),
        ];
    }

    /**
     * Get the best available price for an experience (for display purposes).
     */
    public function getBestAvailablePrice(Experience $experience): array
    {
        $occupancyRate = $experience->occupancy_rate;

        $dto = new PricingDTO(
            experienceId:  $experience->id,
            basePrice:     (float) $experience->price_per_person,
            currency:      $experience->currency ?? 'USD',
            occupancyRate: $occupancyRate,
            daysUntilStart:$experience->start_date_time
                ? now()->diffInDays($experience->start_date_time)
                : null,
            startDate:     $experience->start_date_time
                ? Carbon::parse($experience->start_date_time)
                : null,
        );

        return $this->calculatePrice($dto);
    }

    /**
     * Get pricing recommendations for AI module.
     */
    public function getPricingRecommendations(Experience $experience): array
    {
        $occupancyRate = $experience->occupancy_rate;
        $basePrice     = (float) $experience->price_per_person;
        $recommendations = [];

        if ($occupancyRate < 30) {
            $recommendations[] = [
                'type'       => 'last_minute',
                'suggestion' => 'Enable a last-minute discount of 15-20% to boost occupancy.',
                'impact'     => 'Estimated +25% occupancy improvement',
                'priority'   => 'high',
            ];
        }

        if ($occupancyRate > 85) {
            $recommendations[] = [
                'type'       => 'price_increase',
                'suggestion' => 'Demand is high. Consider increasing price by 10-15%.',
                'impact'     => "Estimated +{$this->formatCurrency($basePrice * 0.12, $experience->currency)} additional revenue",
                'priority'   => 'medium',
            ];
        }

        $hasEarlyBird = PricingRule::where('experience_id', $experience->id)
            ->where('rule_type', 'early_bird')
            ->where('is_active', true)
            ->exists();

        if (! $hasEarlyBird) {
            $recommendations[] = [
                'type'       => 'early_bird',
                'suggestion' => 'Add an early-bird discount (10% off for 60+ days advance booking).',
                'impact'     => 'Estimated +38% conversion rate improvement',
                'priority'   => 'high',
            ];
        }

        return $recommendations;
    }

    protected function formatCurrency(float $amount, string $currency): string
    {
        return "{$currency} " . number_format($amount, 0);
    }
}
