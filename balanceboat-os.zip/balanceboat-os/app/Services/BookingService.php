<?php

namespace App\Services;

use App\DTOs\BookingDTO;
use App\DTOs\PricingDTO;
use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted};
use App\Models\{Booking, Experience, BookingExperienceInfo, BookingUserInfo, PromoCode, CouponRedemption};
use App\Repositories\BookingRepository;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BookingService
{
    public function __construct(
        private readonly BookingRepository $repository,
        private readonly PricingService    $pricingService,
        private readonly AvailabilityService $availabilityService,
    ) {}

    /**
     * Create a new booking with full pricing and availability validation.
     */
    public function create(BookingDTO $dto): Booking
    {
        return DB::transaction(function () use ($dto) {
            // 1. Validate experience exists and is bookable
            $experience = Experience::findOrFail($dto->experienceId);

            if (! $experience->is_bookable) {
                throw ValidationException::withMessages([
                    'experience_id' => 'This retreat is not currently accepting bookings.',
                ]);
            }

            // 2. Check availability
            $this->availabilityService->assertAvailable(
                $dto->experienceId,
                $dto->arrivalDate,
                $dto->guestCount
            );

            // 3. Calculate final price
            $pricingDto = PricingDTO::fromBookingDTO($dto, $experience->occupancy_rate);
            $pricing    = $this->pricingService->calculatePrice($pricingDto);

            // 4. Create booking record
            $booking = Booking::create([
                'experience_id'            => $dto->experienceId,
                'experience_accomodation_id' => $dto->accommodationId,
                'user_id'                  => $dto->userId,
                'guest_count'              => $dto->guestCount,
                'arrival_date'             => $dto->arrivalDate,
                'start_date_time'          => $dto->startDateTime ?? $dto->arrivalDate,
                'end_date_time'            => $dto->endDateTime,
                'currency'                 => $dto->currency,
                'price_per_person'         => $experience->price_per_person,
                'booking_amount'           => $pricing['base_price'],
                'discount_amount'          => $pricing['total_discount'],
                'commission_amount'        => $pricing['base_price'] * ($experience->commission / 100),
                'pay_amount'               => $pricing['final_price'],
                'stage'                    => 'confirmed',
                'order_status'             => 'Success',
                'payment_status'           => 'Pending',
                'is_full_day_event'        => true,
                'is_recurring'             => false,
            ]);

            // 5. Create booking experience info snapshot
            BookingExperienceInfo::create([
                'booking_id'                => $booking->id,
                'experience_id'             => $experience->id,
                'name'                      => $experience->name,
                'slug'                      => $experience->slug,
                'experience_category'       => $experience->experience_category,
                'price_per_person'          => $experience->price_per_person,
                'currency'                  => $experience->currency,
                'batch_size'                => $experience->batch_size,
                'center_id'                 => $experience->center_id,
                'start_date_time'           => $dto->startDateTime,
                'end_date_time'             => $dto->endDateTime,
                'deposit_policy'            => $experience->deposit_policy,
                'deposit_amount'            => $experience->deposit_amount,
                'cancellation_policy_condition' => $experience->cancellation_policy_condition,
                'cancellation_policy_days'  => $experience->cancellation_policy_days,
                'commission'                => $experience->commission,
                'duration'                  => $experience->duration,
                'eirly_bird_before_days'    => $experience->eirly_bird_before_days,
                'eirly_bird_discount'       => $experience->eirly_bird_discount,
            ]);

            // 6. Create guest info record
            if (! empty($dto->guestInfo)) {
                BookingUserInfo::create(array_merge(
                    $dto->guestInfo,
                    ['booking_id' => $booking->id]
                ));
            }

            // 7. Record promo code redemption
            if ($pricing['promo_code'] && $pricing['promo_discount'] > 0) {
                $promoCode = PromoCode::where('code', $pricing['promo_code'])->first();
                if ($promoCode) {
                    CouponRedemption::create([
                        'promo_code_id'   => $promoCode->id,
                        'booking_id'      => $booking->id,
                        'user_id'         => $dto->userId,
                        'original_amount' => $pricing['base_price'],
                        'discount_applied'=> $pricing['promo_discount'],
                        'final_amount'    => $pricing['final_price'],
                    ]);
                    $promoCode->incrementUsage();
                }
            }

            // 8. Update availability calendar
            $this->availabilityService->lockUnits(
                $dto->experienceId,
                $dto->arrivalDate,
                $dto->guestCount
            );

            // 9. Increment booking count on experience
            $experience->increment('booking_count');

            // 10. Fire domain event
            event(new BookingConfirmed($booking));

            return $booking->load(['experience', 'userInfo', 'experienceInfo']);
        });
    }

    /**
     * Confirm a booking (move from inquiry to confirmed).
     */
    public function confirm(Booking $booking): Booking
    {
        if (! $booking->canTransitionTo('confirmed')) {
            throw new \DomainException("Booking cannot be confirmed from stage: {$booking->stage}");
        }

        $booking->confirm();
        event(new BookingConfirmed($booking));

        return $booking->fresh();
    }

    /**
     * Check in a guest.
     */
    public function checkIn(Booking $booking): Booking
    {
        if (! $booking->canTransitionTo('checked_in')) {
            throw new \DomainException("Guest cannot be checked in. Current stage: {$booking->stage}");
        }

        $booking->checkIn();
        event(new BookingCheckedIn($booking));

        return $booking->fresh();
    }

    /**
     * Check out a guest.
     */
    public function checkOut(Booking $booking): Booking
    {
        if (! $booking->canTransitionTo('completed')) {
            throw new \DomainException("Guest cannot be checked out. Current stage: {$booking->stage}");
        }

        $booking->complete();
        event(new BookingCompleted($booking));

        return $booking->fresh();
    }

    /**
     * Cancel a booking with optional reason and refund processing.
     */
    public function cancel(Booking $booking, string $reason = '', bool $processRefund = false): Booking
    {
        if (! $booking->canTransitionTo('cancelled')) {
            throw new \DomainException("Booking cannot be cancelled from stage: {$booking->stage}");
        }

        DB::transaction(function () use ($booking, $reason, $processRefund) {
            $booking->cancel($reason);

            // Release availability
            $this->availabilityService->releaseUnits(
                $booking->experience_id,
                $booking->arrival_date?->format('Y-m-d'),
                $booking->guest_count
            );

            if ($processRefund) {
                $booking->transitionTo('refunded');
            }
        });

        event(new BookingCancelled($booking));

        return $booking->fresh();
    }

    /**
     * Process a refund for a booking.
     */
    public function processRefund(Booking $booking, float $amount, string $reason = ''): bool
    {
        if (! $booking->is_refundable) {
            throw new \DomainException("Booking #{$booking->booking_reference} is not eligible for refund.");
        }

        // TODO: Integrate with payment gateway (Stripe, etc.)
        // $stripe = app(StripeService::class);
        // $refund = $stripe->refund($booking->transactionInfo->transaction_id, $amount);

        $booking->update([
            'stage'          => 'refunded',
            'internal_notes' => ($booking->internal_notes ? $booking->internal_notes . "\n" : '')
                . "Refund of {$booking->currency} {$amount} processed. Reason: {$reason}",
        ]);

        return true;
    }

    /**
     * Get pipeline statistics for a center.
     */
    public function getPipelineStats(int $centerId, string $period = '30d'): array
    {
        $days = (int) rtrim($period, 'd');
        $from = now()->subDays($days);

        $baseQuery = fn() => Booking::forCenter($centerId)->where('created_at', '>=', $from);

        return [
            'total'         => $baseQuery()->count(),
            'confirmed'     => $baseQuery()->inStage('confirmed')->count(),
            'checked_in'    => $baseQuery()->inStage('checked_in')->count(),
            'completed'     => $baseQuery()->inStage('completed')->count(),
            'cancelled'     => $baseQuery()->cancelled()->count(),
            'total_revenue' => $baseQuery()->whereIn('stage', ['confirmed', 'checked_in', 'completed'])->sum('pay_amount'),
            'avg_booking_value' => $baseQuery()->whereIn('stage', ['confirmed', 'checked_in', 'completed'])->avg('pay_amount'),
            'today_checkins'=> Booking::forCenter($centerId)
                ->where('arrival_date', today())
                ->inStage('confirmed')
                ->count(),
            'current_guests'=> Booking::forCenter($centerId)->inStage('checked_in')->count(),
        ];
    }

    /**
     * Assign booking to a staff member.
     */
    public function assignToStaff(Booking $booking, int $staffId): Booking
    {
        $booking->update(['assigned_staff_id' => $staffId]);
        return $booking->fresh();
    }
}
