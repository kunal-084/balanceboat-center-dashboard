<?php

namespace App\Actions\Booking;

use App\DTOs\BookingDTO;
use App\Models\Booking;
use App\Services\BookingService;

class CreateBookingAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(BookingDTO $dto): Booking
    {
        return $this->bookingService->create($dto);
    }
}

class ConfirmBookingAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking): Booking
    {
        return $this->bookingService->confirm($booking);
    }
}

class CancelBookingAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking, string $reason = '', bool $processRefund = false): Booking
    {
        return $this->bookingService->cancel($booking, $reason, $processRefund);
    }
}

class CheckInGuestAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking): Booking
    {
        return $this->bookingService->checkIn($booking);
    }
}

class CheckOutGuestAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking): Booking
    {
        return $this->bookingService->checkOut($booking);
    }
}

class ProcessRefundAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking, float $amount, string $reason = ''): bool
    {
        return $this->bookingService->processRefund($booking, $amount, $reason);
    }
}

namespace App\Actions\Retreat;

use App\DTOs\RetreatDTO;
use App\Models\Experience;
use App\Services\RetreatService;

class CreateRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(RetreatDTO $dto): Experience
    {
        return $this->retreatService->create($dto);
    }
}

class PublishRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(Experience $experience): Experience
    {
        return $this->retreatService->publish($experience);
    }
}

class UnpublishRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(Experience $experience): Experience
    {
        return $this->retreatService->unpublish($experience);
    }
}

class DuplicateRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(Experience $experience): Experience
    {
        return $this->retreatService->duplicate($experience);
    }
}

class UpdateRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(Experience $experience, array $data): Experience
    {
        return $this->retreatService->update($experience, $data);
    }
}

namespace App\Actions\Media;

use App\DTOs\MediaUploadDTO;
use App\Models\MediaAsset;
use App\Services\MediaService;
use Illuminate\Http\UploadedFile;

class UploadMediaAction
{
    public function __construct(private readonly MediaService $mediaService) {}

    public function handle(UploadedFile $file, MediaUploadDTO $dto): MediaAsset
    {
        return $this->mediaService->upload($file, $dto);
    }
}

class DeleteMediaAction
{
    public function __construct(private readonly MediaService $mediaService) {}

    public function handle(MediaAsset $asset): void
    {
        $this->mediaService->delete($asset);
    }
}

class ReorderMediaAction
{
    public function __construct(private readonly MediaService $mediaService) {}

    public function handle(array $orderedIds): void
    {
        $this->mediaService->reorder($orderedIds);
    }
}

namespace App\Actions\Finance;

use App\Models\{Center, PayoutRequest, Booking};
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class CreatePayoutRequestAction
{
    public function handle(Center $center, string $from, string $to): PayoutRequest
    {
        return DB::transaction(function () use ($center, $from, $to) {
            $plan           = $center->subscriptionPlan;
            $commissionRate = $plan?->commission_rate ?? 10;

            $bookings = Booking::forCenter($center->id)
                ->where('stage', 'completed')
                ->whereBetween('arrival_date', [$from, $to])
                ->whereNull('deleted_at')
                ->get();

            $grossAmount      = $bookings->sum('pay_amount');
            $commissionAmount = round($grossAmount * ($commissionRate / 100), 2);
            $taxAmount        = 0;
            $netPayout        = $grossAmount - $commissionAmount - $taxAmount;

            return PayoutRequest::create([
                'center_id'           => $center->id,
                'reference'           => 'PAY-' . strtoupper(Str::random(10)),
                'gross_amount'        => $grossAmount,
                'commission_deducted' => $commissionAmount,
                'tax_deducted'        => $taxAmount,
                'net_payout'          => $netPayout,
                'currency'            => $center->currency_code ?? 'USD',
                'status'              => 'pending',
                'period_from'         => $from,
                'period_to'           => $to,
                'included_booking_ids'=> $bookings->pluck('id')->toArray(),
                'requested_at'        => now(),
            ]);
        });
    }
}

namespace App\Actions\AI;

use App\DTOs\AiContentDTO;
use App\Models\{Experience, Center, AiRecommendation};
use App\Services\AiService;

class GenerateContentAction
{
    public function __construct(private readonly AiService $aiService) {}

    public function handle(AiContentDTO $dto): string
    {
        return $this->aiService->generateContent($dto);
    }
}

class GenerateSeoMetadataAction
{
    public function __construct(private readonly AiService $aiService) {}

    public function handle(Experience $experience): array
    {
        return $this->aiService->generateSeoMetadata($experience);
    }
}

class ApplyAiRecommendationAction
{
    public function handle(AiRecommendation $recommendation): void
    {
        $recommendation->apply(auth()->id());

        // Execute the recommendation's action payload if present
        $payload = $recommendation->action_payload;
        if (! $payload) return;

        match ($recommendation->type) {
            'pricing' => $this->applyPricingRecommendation($recommendation, $payload),
            default   => null,
        };
    }

    protected function applyPricingRecommendation(AiRecommendation $rec, array $payload): void
    {
        if (isset($payload['create_pricing_rule'])) {
            \App\Models\PricingRule::create(array_merge(
                $payload['create_pricing_rule'],
                ['center_id' => $rec->center_id, 'experience_id' => $rec->experience_id]
            ));
        }
    }
}

namespace App\Actions\Automation;

use App\Models\{AutomationRule, AutomationExecution};
use App\Services\{EmailService, WhatsAppService};
use Illuminate\Support\Facades\{Log, Mail};

class DispatchAutomationAction
{
    public function __construct(
        private readonly EmailService     $emailService,
        private readonly WhatsAppService  $whatsAppService,
    ) {}

    public function handle(AutomationRule $rule, array $triggerData): AutomationExecution
    {
        $execution = AutomationExecution::create([
            'automation_rule_id' => $rule->id,
            'trigger_event'      => $rule->trigger_event,
            'trigger_data'       => $triggerData,
            'status'             => 'running',
            'executed_at'        => now(),
        ]);

        try {
            match ($rule->action_type) {
                'email'     => $this->executeEmailAction($rule, $triggerData),
                'whatsapp'  => $this->executeWhatsAppAction($rule, $triggerData),
                'webhook'   => $this->executeWebhookAction($rule, $triggerData),
                'internal_task' => $this->executeTaskAction($rule, $triggerData),
                default     => null,
            };

            $execution->update(['status' => 'completed', 'result_data' => ['message' => 'Executed successfully']]);
            $rule->increment('execution_count');
            $rule->update(['last_executed_at' => now()]);
        } catch (\Throwable $e) {
            $execution->update(['status' => 'failed', 'error_message' => $e->getMessage()]);
            Log::error("Automation execution failed", ['rule_id' => $rule->id, 'error' => $e->getMessage()]);
        }

        return $execution->fresh();
    }

    protected function executeEmailAction(AutomationRule $rule, array $data): void
    {
        $template = $rule->emailTemplate;
        if (! $template) return;

        $recipient = $data['guest_email'] ?? $data['email'] ?? null;
        if (! $recipient) return;

        $this->emailService->sendTemplate($template, $recipient, $data);
    }

    protected function executeWhatsAppAction(AutomationRule $rule, array $data): void
    {
        $config = $rule->action_config ?? [];
        $phone  = $data['guest_phone'] ?? $data['phone'] ?? null;
        if (! $phone) return;

        $this->whatsAppService->send($phone, $data['message'] ?? '', $config);
    }

    protected function executeWebhookAction(AutomationRule $rule, array $data): void
    {
        $config = $rule->action_config ?? [];
        $url    = $config['webhook_url'] ?? null;
        if (! $url) return;

        \Illuminate\Support\Facades\Http::post($url, array_merge($data, [
            'trigger_event' => $rule->trigger_event,
            'timestamp'     => now()->toIso8601String(),
        ]));
    }

    protected function executeTaskAction(AutomationRule $rule, array $data): void
    {
        // Create internal task / notification for staff
        $config = $rule->action_config ?? [];
        Log::info("Internal task triggered", ['rule' => $rule->name, 'config' => $config]);
    }
}
