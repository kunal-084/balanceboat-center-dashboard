<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

// Events
use App\Events\BookingConfirmed;
use App\Events\BookingCancelled;
use App\Events\BookingCheckedIn;
use App\Events\BookingCompleted;
use App\Events\RetreatPublished;
use App\Events\InquiryReceived;
use App\Events\ReviewSubmitted;
use App\Events\PayoutRequested;
use App\Events\TeamMemberInvited;
use App\Events\CenterOnboarded;

// Listeners
use App\Listeners\SendBookingConfirmationEmail;
use App\Listeners\SendBookingConfirmationWhatsApp;
use App\Listeners\NotifyStaffOfNewBooking;
use App\Listeners\TriggerBookingConfirmedAutomation;
use App\Listeners\UpdateAvailabilityOnBookingCancelled;
use App\Listeners\TriggerBookingCancelledAutomation;
use App\Listeners\SendCheckInNotification;
use App\Listeners\SendReviewRequestAfterCompletion;
use App\Listeners\SendInquiryReceivedNotifications;
use App\Listeners\NotifyReviewSubmitted;
use App\Listeners\GenerateAiRecommendationsOnPublish;
use App\Listeners\LogAuditEvent;
use App\Listeners\SendPayoutRequestNotification;
use App\Listeners\SendTeamInvitationEmail;
use App\Listeners\RunCenterOnboardingSequence;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],

        BookingConfirmed::class => [
            SendBookingConfirmationEmail::class,
            SendBookingConfirmationWhatsApp::class,
            NotifyStaffOfNewBooking::class,
            TriggerBookingConfirmedAutomation::class,
            LogAuditEvent::class,
        ],

        BookingCancelled::class => [
            UpdateAvailabilityOnBookingCancelled::class,
            TriggerBookingCancelledAutomation::class,
            LogAuditEvent::class,
        ],

        BookingCheckedIn::class => [
            SendCheckInNotification::class,
            LogAuditEvent::class,
        ],

        BookingCompleted::class => [
            SendReviewRequestAfterCompletion::class,
            LogAuditEvent::class,
        ],

        RetreatPublished::class => [
            GenerateAiRecommendationsOnPublish::class,
            LogAuditEvent::class,
        ],

        InquiryReceived::class => [
            SendInquiryReceivedNotifications::class,
        ],

        ReviewSubmitted::class => [
            NotifyReviewSubmitted::class,
        ],

        PayoutRequested::class => [
            SendPayoutRequestNotification::class,
        ],

        TeamMemberInvited::class => [
            SendTeamInvitationEmail::class,
        ],

        CenterOnboarded::class => [
            RunCenterOnboardingSequence::class,
            LogAuditEvent::class,
        ],
    ];

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
        //
    }
}
