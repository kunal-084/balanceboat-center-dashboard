<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

// Models
use App\Models\Experience;
use App\Models\Booking;
use App\Models\Center;
use App\Models\Teacher;
use App\Models\MediaAsset;
use App\Models\Inquiry;
use App\Models\PromoCode;
use App\Models\CenterReview;
use App\Models\AutomationRule;
use App\Models\PayoutRequest;
use App\Models\PricingRule;
use App\Models\EmailTemplate;
use App\Models\AiRecommendation;
use App\Models\User;

// Policies
use App\Policies\ExperiencePolicy;
use App\Policies\BookingPolicy;
use App\Policies\CenterPolicy;
use App\Policies\TeacherPolicy;
use App\Policies\MediaPolicy;
use App\Policies\InquiryPolicy;
use App\Policies\PromoCodePolicy;
use App\Policies\ReviewPolicy;
use App\Policies\AutomationPolicy;
use App\Policies\PayoutPolicy;
use App\Policies\PricingRulePolicy;
use App\Policies\EmailTemplatePolicy;
use App\Policies\AiRecommendationPolicy;
use App\Policies\UserPolicy;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        Experience::class        => ExperiencePolicy::class,
        Booking::class           => BookingPolicy::class,
        Center::class            => CenterPolicy::class,
        Teacher::class           => TeacherPolicy::class,
        MediaAsset::class        => MediaPolicy::class,
        Inquiry::class           => InquiryPolicy::class,
        PromoCode::class         => PromoCodePolicy::class,
        CenterReview::class      => ReviewPolicy::class,
        AutomationRule::class    => AutomationPolicy::class,
        PayoutRequest::class     => PayoutPolicy::class,
        PricingRule::class       => PricingRulePolicy::class,
        EmailTemplate::class     => EmailTemplatePolicy::class,
        AiRecommendation::class  => AiRecommendationPolicy::class,
        User::class              => UserPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        /*
        |------------------------------------------------------------------
        | Super Admin Gate — bypasses all policy checks
        |------------------------------------------------------------------
        */
        Gate::before(function (\App\Models\User $user, string $ability) {
            if ($user->hasRole('super-admin')) {
                return true;
            }
        });

        /*
        |------------------------------------------------------------------
        | BalanceBoat Admin Gate — platform-level management
        |------------------------------------------------------------------
        */
        Gate::define('manage-platform', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin']);
        });

        Gate::define('view-all-centers', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin']);
        });

        Gate::define('manage-subscription-plans', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin']);
        });

        Gate::define('view-audit-logs', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner']);
        });

        /*
        |------------------------------------------------------------------
        | Center-Level Gates
        |------------------------------------------------------------------
        */
        Gate::define('manage-center', function (User $user, Center $center) {
            if ($user->hasRole(['super-admin', 'balanceboat-admin'])) {
                return true;
            }
            return $user->center_id === $center->id && $user->hasRole(['center-owner', 'center-manager']);
        });

        Gate::define('view-center-analytics', function (User $user, Center $center = null) {
            if ($user->hasRole(['super-admin', 'balanceboat-admin'])) {
                return true;
            }
            if ($center) {
                return $user->center_id === $center->id;
            }
            return $user->center_id !== null;
        });

        Gate::define('manage-billing', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner', 'accountant']);
        });

        Gate::define('process-payouts', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'accountant']);
        });

        Gate::define('view-financial-reports', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'accountant']);
        });

        Gate::define('manage-ai-features', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager']);
        });

        Gate::define('manage-team', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner']);
        });

        Gate::define('manage-automations', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager']);
        });

        Gate::define('use-bulk-actions', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager']);
        });

        Gate::define('export-data', function (User $user) {
            return $user->hasRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'accountant']);
        });
    }
}
