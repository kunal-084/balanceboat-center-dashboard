<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

// ─────────────────────────────────────────────────────────────────────────────
// BookingDTO
// ─────────────────────────────────────────────────────────────────────────────
final class BookingDTO
{
    public function __construct(
        public readonly int    $experienceId,
        public readonly int    $centerId,
        public readonly int    $guestCount,
        public readonly string $arrivalDate,
        public readonly string $currency,
        public readonly float  $basePrice,
        public readonly ?int   $accommodationId = null,
        public readonly ?int   $userId          = null,
        public readonly ?string $promoCode       = null,
        public readonly ?string $startDateTime   = null,
        public readonly ?string $endDateTime      = null,
        public readonly array  $guestInfo        = [],
    ) {}

    public static function fromRequest(Request $request, int $centerId): self
    {
        return new self(
            experienceId:   (int) $request->experience_id,
            centerId:       $centerId,
            guestCount:     (int) $request->guest_count,
            arrivalDate:    $request->arrival_date,
            currency:       $request->currency ?? 'USD',
            basePrice:      (float) $request->base_price,
            accommodationId:$request->accommodation_id ? (int) $request->accommodation_id : null,
            userId:         auth()->id(),
            promoCode:      $request->promo_code,
            startDateTime:  $request->start_date_time,
            endDateTime:    $request->end_date_time,
            guestInfo:      $request->guest_info ?? [],
        );
    }

    public function getDaysUntilStart(): int
    {
        return Carbon::parse($this->arrivalDate)->diffInDays(now());
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PricingDTO
// ─────────────────────────────────────────────────────────────────────────────
final class PricingDTO
{
    public function __construct(
        public readonly int     $experienceId,
        public readonly float   $basePrice,
        public readonly string  $currency,
        public readonly int     $guestCount        = 1,
        public readonly int     $durationNights    = 1,
        public readonly float   $occupancyRate     = 0,
        public readonly ?int    $daysUntilStart    = null,
        public readonly ?Carbon $startDate         = null,
        public readonly ?string $promoCode         = null,
        public readonly ?int    $accommodationId   = null,
    ) {}

    public static function fromBookingDTO(BookingDTO $booking, float $occupancyRate = 0): self
    {
        return new self(
            experienceId:  $booking->experienceId,
            basePrice:     $booking->basePrice,
            currency:      $booking->currency,
            guestCount:    $booking->guestCount,
            occupancyRate: $occupancyRate,
            daysUntilStart:$booking->getDaysUntilStart(),
            startDate:     Carbon::parse($booking->arrivalDate),
            promoCode:     $booking->promoCode,
            accommodationId: $booking->accommodationId,
        );
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RetreatDTO
// ─────────────────────────────────────────────────────────────────────────────
final class RetreatDTO
{
    public function __construct(
        public readonly int    $centerId,
        public readonly string $name,
        public readonly string $currency,
        public readonly float  $pricePerPerson,
        public readonly ?string $slug             = null,
        public readonly ?string $summary          = null,
        public readonly ?string $overview         = null,
        public readonly ?string $details          = null,
        public readonly ?int    $batchSize        = null,
        public readonly ?int    $durationNights   = null,
        public readonly ?string $startDateTime    = null,
        public readonly ?string $endDateTime      = null,
        public readonly array  $categoryIds       = [],
        public readonly array  $teacherIds        = [],
        public readonly bool   $isDraft           = true,
        public readonly ?string $food             = null,
        public readonly ?string $skillLevel       = null,
        public readonly ?string $language         = 'English',
        public readonly array  $tags             = [],
        public readonly ?string $cancellationPolicy = null,
        public readonly bool   $depositPolicy     = false,
        public readonly ?float $depositAmount     = null,
        public readonly ?int   $earlyBirdDays     = null,
        public readonly ?float $earlyBirdDiscount = null,
        public readonly ?string $earlyBirdDiscountType = null,
    ) {}

    public static function fromRequest(Request $request, int $centerId): self
    {
        return new self(
            centerId:          $centerId,
            name:              $request->name,
            currency:          $request->currency ?? 'USD',
            pricePerPerson:    (float) $request->price_per_person,
            slug:              $request->slug,
            summary:           $request->experience_summary,
            overview:          $request->experience_overview,
            details:           $request->experience_details,
            batchSize:         $request->batch_size ? (int) $request->batch_size : null,
            durationNights:    $request->duration_nights ? (int) $request->duration_nights : null,
            startDateTime:     $request->start_date_time,
            endDateTime:       $request->end_date_time,
            categoryIds:       $request->category_ids ?? [],
            teacherIds:        $request->teacher_ids ?? [],
            isDraft:           (bool) $request->boolean('is_draft', true),
            food:              $request->food,
            skillLevel:        $request->skill_level,
            language:          $request->language_spoken ?? 'English',
            tags:              $request->tags ?? [],
            cancellationPolicy:$request->cancellation_policy,
            depositPolicy:     $request->boolean('deposit_policy', false),
            depositAmount:     $request->deposit_amount ? (float) $request->deposit_amount : null,
            earlyBirdDays:     $request->eirly_bird_before_days ? (int) $request->eirly_bird_before_days : null,
            earlyBirdDiscount: $request->eirly_bird_discount ? (float) $request->eirly_bird_discount : null,
            earlyBirdDiscountType: $request->eirly_bird_discount_type,
        );
    }

    public function toArray(): array
    {
        return [
            'center_id'            => $this->centerId,
            'name'                 => $this->name,
            'currency'             => $this->currency,
            'price_per_person'     => $this->pricePerPerson,
            'slug'                 => $this->slug,
            'experience_summary'   => $this->summary,
            'experience_overview'  => $this->overview,
            'experience_details'   => $this->details,
            'batch_size'           => $this->batchSize,
            'duration_nights'      => $this->durationNights,
            'duration'             => $this->durationNights ? "{$this->durationNights} nights" : null,
            'start_date_time'      => $this->startDateTime,
            'end_date_time'        => $this->endDateTime,
            'is_draft'             => $this->isDraft,
            'publish_status'       => $this->isDraft ? 'draft' : 'published',
            'food'                 => $this->food,
            'skill_level'          => $this->skillLevel,
            'language_spoken'      => $this->language,
            'tags'                 => implode(',', $this->tags),
            'cancellation_policy'  => $this->cancellationPolicy,
            'deposit_policy'       => $this->depositPolicy,
            'deposit_amount'       => $this->depositAmount,
            'eirly_bird_before_days' => $this->earlyBirdDays,
            'eirly_bird_discount'  => $this->earlyBirdDiscount,
            'eirly_bird_discount_type' => $this->earlyBirdDiscountType,
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MediaUploadDTO
// ─────────────────────────────────────────────────────────────────────────────
final class MediaUploadDTO
{
    public function __construct(
        public readonly int    $centerId,
        public readonly string $disk,
        public readonly string $collection,
        public readonly ?int   $folderId          = null,
        public readonly ?string $mediableType     = null,
        public readonly ?int   $mediableId        = null,
        public readonly ?string $altText          = null,
        public readonly ?string $caption          = null,
        public readonly ?string $category         = null,
        public readonly bool   $generateThumbs    = true,
    ) {}
}

// ─────────────────────────────────────────────────────────────────────────────
// AiContentDTO
// ─────────────────────────────────────────────────────────────────────────────
final class AiContentDTO
{
    public function __construct(
        public readonly string $type,
        public readonly string $retreatType,
        public readonly int    $centerId,
        public readonly ?int   $experienceId  = null,
        public readonly ?string $location     = null,
        public readonly ?int   $durationNights= null,
        public readonly ?string $targetAudience= null,
        public readonly ?string $additionalContext = null,
        public readonly string $language      = 'en',
        public readonly string $tone          = 'luxury',
    ) {}
}

// ─────────────────────────────────────────────────────────────────────────────
// InquiryDTO
// ─────────────────────────────────────────────────────────────────────────────
final class InquiryDTO
{
    public function __construct(
        public readonly string  $name,
        public readonly string  $email,
        public readonly ?string $lastname     = null,
        public readonly ?string $phone        = null,
        public readonly bool    $whatsapp     = false,
        public readonly ?string $message      = null,
        public readonly ?string $retreatType  = null,
        public readonly ?string $destination  = null,
        public readonly ?string $budget       = null,
        public readonly ?string $timeline     = null,
        public readonly ?int    $experienceId = null,
        public readonly ?int    $centerId     = null,
        public readonly ?string $source       = null,
        public readonly ?string $refUrl       = null,
        public readonly ?string $utmSource    = null,
        public readonly ?string $utmMedium    = null,
        public readonly ?string $utmCampaign  = null,
        public readonly ?int    $groupSize    = null,
    ) {}

    public static function fromRequest(Request $request): self
    {
        return new self(
            name:         $request->name,
            email:        $request->email,
            lastname:     $request->lastname,
            phone:        $request->phone,
            whatsapp:     $request->boolean('whatsapp', false),
            message:      $request->message,
            retreatType:  $request->retreat_type,
            destination:  $request->destination,
            budget:       $request->budget,
            timeline:     $request->timeline,
            experienceId: $request->experience_id ? (int) $request->experience_id : null,
            centerId:     $request->center_id ? (int) $request->center_id : null,
            source:       $request->source,
            refUrl:       $request->ref_url ?? $request->header('Referer'),
            utmSource:    $request->utm_source,
            utmMedium:    $request->utm_medium,
            utmCampaign:  $request->utm_campaign,
            groupSize:    $request->group_size ? (int) $request->group_size : null,
        );
    }
}
