<?php

namespace App\Events;

use App\Models\Center;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

// ─── Payout Requested ─────────────────────────────────────────────────────────

class PayoutRequested
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public readonly Center $center,
        public readonly float  $amount,
        public readonly string $currency,
        public readonly ?string $notes = null,
    ) {}
}

// ─── Team Member Invited ──────────────────────────────────────────────────────

class TeamMemberInvited
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public readonly Center $center,
        public readonly string $email,
        public readonly string $role,
    ) {}
}

// ─── Center Onboarded ─────────────────────────────────────────────────────────

class CenterOnboarded
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public readonly Center $center,
    ) {}
}
