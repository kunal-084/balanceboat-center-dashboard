<?php

// ============================================================
// EVENTS
// ============================================================

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class BookingConfirmed
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Booking $booking) {}
}

class BookingCancelled
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public readonly Booking $booking,
        public readonly string  $reason = ''
    ) {}
}

class BookingCheckedIn
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Booking $booking) {}
}

class BookingCompleted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Booking $booking) {}
}

class RetreatPublished
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Experience $experience) {}
}

class InquiryReceived
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Inquiry $inquiry) {}
}

class ReviewSubmitted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly CenterReview $review) {}
}

// ============================================================
// LISTENERS
// ============================================================

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

// ─── Booking Confirmed Listeners ─────────────────────────────────────────────

class SendBookingConfirmationEmail implements ShouldQueue
{
    public string $queue = 'emails';

    public function handle(BookingConfirmed $event): void
    {
        $booking = $event->booking->load(['experience.center', 'userInfo']);

        if (! $booking->userInfo?->email) return;

        SendEmailJob::dispatch(
            to:       $booking->userInfo->email,
            name:     $booking->userInfo->firstname . ' ' . $booking->userInfo->lastname,
            template: 'booking_confirmed',
            data:     [
                'booking_reference'    => $booking->booking_reference,
                'retreat_name'         => $booking->experience?->name,
                'arrival_date'         => $booking->arrival_date?->format('d M Y'),
                'guest_count'          => $booking->guest_count,
                'total_amount'         => number_format($booking->pay_amount, 2) . ' ' . $booking->currency,
                'center_name'          => $booking->experience?->center?->name,
                'center_email'         => $booking->experience?->center?->email_address,
                'center_phone'         => $booking->experience?->center?->contact_number,
                'cancellation_policy'  => $booking->experienceInfo?->cancellation_policy_days,
            ]
        )->onQueue('emails');
    }
}

class SendBookingConfirmationWhatsApp implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(BookingConfirmed $event): void
    {
        $booking = $event->booking->load(['userInfo', 'experience']);

        if (! $booking->userInfo?->phone) return;

        SendWhatsAppJob::dispatch(
            phone:    $booking->userInfo->phone,
            template: 'booking_confirmed',
            params:   [
                $booking->userInfo->firstname,
                $booking->experience?->name,
                $booking->booking_reference,
                $booking->arrival_date?->format('d M Y'),
            ]
        )->onQueue('notifications');
    }
}

class NotifyStaffOfNewBooking implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(BookingConfirmed $event): void
    {
        $booking = $event->booking->load(['experience.center.staff']);

        $managers = $booking->experience?->center?->staff()
            ->whereIn('center_role', ['owner', 'manager'])
            ->get() ?? collect();

        foreach ($managers as $manager) {
            $manager->notify(new BookingConfirmedNotification($booking));
        }
    }
}

class TriggerBookingConfirmedAutomation implements ShouldQueue
{
    public string $queue = 'automations';

    public function handle(BookingConfirmed $event): void
    {
        $booking  = $event->booking->load(['experience']);
        $centerId = $booking->experience?->center_id;

        if (! $centerId) return;

        $rules = AutomationRule::active()
            ->where('center_id', $centerId)
            ->forEvent('booking.confirmed')
            ->get();

        foreach ($rules as $rule) {
            ProcessAutomationJob::dispatch($rule, [
                'booking_id'       => $booking->id,
                'booking_reference'=> $booking->booking_reference,
                'guest_name'       => $booking->guest_name,
                'guest_email'      => $booking->guest_email,
                'retreat_name'     => $booking->experience?->name,
                'arrival_date'     => $booking->arrival_date?->format('Y-m-d'),
                'guest_count'      => $booking->guest_count,
                'total_amount'     => $booking->pay_amount,
                'currency'         => $booking->currency,
            ])->delay(now()->addMinutes($rule->delay_in_minutes))->onQueue('automations');
        }
    }
}

class UpdateAvailabilityOnBookingCancelled implements ShouldQueue
{
    public function handle(BookingCancelled $event): void
    {
        $booking = $event->booking;

        if (! $booking->experience_id || ! $booking->arrival_date) return;

        AvailabilityCalendar::where('experience_id', $booking->experience_id)
            ->where('calendar_date', $booking->arrival_date->format('Y-m-d'))
            ->update([
                'booked_units'    => \DB::raw('GREATEST(0, booked_units - ' . $booking->guest_count . ')'),
                'available_units' => \DB::raw('available_units + ' . $booking->guest_count),
                'status'          => 'open',
            ]);
    }
}

class TriggerBookingCancelledAutomation implements ShouldQueue
{
    public string $queue = 'automations';

    public function handle(BookingCancelled $event): void
    {
        $booking  = $event->booking->load(['experience']);
        $centerId = $booking->experience?->center_id;
        if (! $centerId) return;

        $rules = AutomationRule::active()
            ->where('center_id', $centerId)
            ->forEvent('booking.cancelled')
            ->get();

        foreach ($rules as $rule) {
            ProcessAutomationJob::dispatch($rule, [
                'booking_reference' => $booking->booking_reference,
                'guest_name'        => $booking->guest_name,
                'guest_email'       => $booking->guest_email,
                'retreat_name'      => $booking->experience?->name,
                'cancellation_reason' => $event->reason,
            ])->delay(now()->addMinutes($rule->delay_in_minutes))->onQueue('automations');
        }
    }
}

class SendCheckInNotification implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(BookingCheckedIn $event): void
    {
        $booking = $event->booking->load(['experience.center.staff', 'userInfo']);

        // Notify center staff
        $staff = $booking->experience?->center?->staff()
            ->whereIn('center_role', ['owner', 'manager', 'staff'])
            ->get() ?? collect();

        foreach ($staff as $member) {
            $member->notify(new \App\Notifications\GuestCheckedInNotification($booking));
        }
    }
}

class SendReviewRequestAfterCompletion implements ShouldQueue
{
    public string $queue = 'emails';

    public function handle(BookingCompleted $event): void
    {
        $booking = $event->booking->load(['userInfo', 'experience']);

        if (! $booking->userInfo?->email) return;

        // Delay 2 days after completion
        SendEmailJob::dispatch(
            to:       $booking->userInfo->email,
            name:     $booking->userInfo->firstname,
            template: 'review_request',
            data:     [
                'guest_name'   => $booking->userInfo->firstname,
                'retreat_name' => $booking->experience?->name,
                'booking_ref'  => $booking->booking_reference,
                'review_url'   => config('app.url') . '/reviews/submit/' . $booking->booking_reference,
            ]
        )->delay(now()->addDays(2))->onQueue('emails');
    }
}

class SendInquiryReceivedNotifications implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(InquiryReceived $event): void
    {
        $inquiry = $event->inquiry->load(['experience.center.staff']);

        // Notify the inquiry submitter
        SendEmailJob::dispatch(
            to:       $inquiry->email,
            name:     $inquiry->name,
            template: 'inquiry_received',
            data:     [
                'name'         => $inquiry->name,
                'retreat_name' => $inquiry->experience?->name ?? 'our retreats',
            ]
        )->onQueue('emails');

        // Notify center staff
        $centerId = $inquiry->center_id ?? $inquiry->experience?->center_id;
        if (! $centerId) return;

        $managers = \App\Models\User::where('center_id', $centerId)
            ->whereIn('center_role', ['owner', 'manager'])
            ->get();

        foreach ($managers as $manager) {
            $manager->notify(new InquiryReceivedNotification($inquiry));
        }

        // Trigger automation rules
        $rules = AutomationRule::active()
            ->where('center_id', $centerId)
            ->forEvent('inquiry.received')
            ->get();

        foreach ($rules as $rule) {
            ProcessAutomationJob::dispatch($rule, [
                'inquiry_id'   => $inquiry->id,
                'guest_name'   => $inquiry->full_name,
                'guest_email'  => $inquiry->email,
                'guest_phone'  => $inquiry->phone,
                'retreat_name' => $inquiry->experience?->name,
                'budget'       => $inquiry->budget,
                'retreat_type' => $inquiry->retreat_type,
            ])->delay(now()->addMinutes($rule->delay_in_minutes))->onQueue('automations');
        }
    }
}

class NotifyReviewSubmitted implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(ReviewSubmitted $event): void
    {
        $review = $event->review->load(['center.staff']);

        $managers = $review->center?->staff()
            ->whereIn('center_role', ['owner', 'manager'])
            ->get() ?? collect();

        foreach ($managers as $manager) {
            $manager->notify(new \App\Notifications\ReviewSubmittedNotification($review));
        }
    }
}

class GenerateAiRecommendationsOnPublish implements ShouldQueue
{
    public string $queue = 'ai';

    public function handle(RetreatPublished $event): void
    {
        $experience = $event->experience->load('center');

        if ($experience->center?->canUseFeature('ai')) {
            GenerateAiRecommendationsJob::dispatch($experience->center)->onQueue('ai');
        }
    }
}

class LogAuditEvent
{
    public function handle(mixed $event): void
    {
        if (! auth()->check()) return;

        $user     = auth()->user();
        $className= class_basename($event);

        $modelMap = [
            'BookingConfirmed'  => [$event->booking, 'stage_changed'],
            'BookingCancelled'  => [$event->booking, 'cancelled'],
            'BookingCheckedIn'  => [$event->booking, 'checked_in'],
            'BookingCompleted'  => [$event->booking, 'completed'],
            'RetreatPublished'  => [$event->experience, 'published'],
            'InquiryReceived'   => [$event->inquiry, 'received'],
            'ReviewSubmitted'   => [$event->review, 'submitted'],
        ];

        [$model, $eventName] = $modelMap[$className] ?? [null, $className];

        if (! $model) return;

        AuditLog::create([
            'user_id'        => $user->id,
            'user_name'      => $user->full_name,
            'user_email'     => $user->email,
            'event'          => $eventName,
            'auditable_type' => get_class($model),
            'auditable_id'   => $model->id,
            'center_id'      => $user->center_id,
            'ip_address'     => request()->ip(),
            'user_agent'     => request()->userAgent(),
            'url'            => request()->fullUrl(),
            'http_method'    => request()->method(),
        ]);
    }
}
