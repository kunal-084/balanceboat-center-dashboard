<?php

namespace App\Notifications;

use App\Models\{Booking, Inquiry, CenterReview, PayoutRequest};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\{Notification, Messages\MailMessage};

// ─────────────────────────────────────────────────────────────────────────────
// BookingConfirmedNotification
// ─────────────────────────────────────────────────────────────────────────────

class BookingConfirmedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Booking $booking) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("New Booking Confirmed — {$this->booking->booking_reference}")
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("A new booking has been confirmed for {$this->booking->experience?->name}.")
            ->line("**Booking Reference:** {$this->booking->booking_reference}")
            ->line("**Guest:** {$this->booking->guest_name}")
            ->line("**Arrival Date:** {$this->booking->arrival_date?->format('d M Y')}")
            ->line("**Guests:** {$this->booking->guest_count}")
            ->line("**Total:** {$this->booking->currency} " . number_format($this->booking->pay_amount, 2))
            ->action('View Booking', route('bookings.show', $this->booking))
            ->line('Thank you for using BalanceBoat Center OS.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'              => 'booking_confirmed',
            'booking_id'        => $this->booking->id,
            'booking_reference' => $this->booking->booking_reference,
            'guest_name'        => $this->booking->guest_name,
            'retreat_name'      => $this->booking->experience?->name,
            'arrival_date'      => $this->booking->arrival_date?->format('Y-m-d'),
            'amount'            => $this->booking->pay_amount,
            'currency'          => $this->booking->currency,
            'message'           => "New booking {$this->booking->booking_reference} confirmed for {$this->booking->experience?->name}.",
            'url'               => route('bookings.show', $this->booking),
            'icon'              => 'calendar-check',
            'color'             => 'emerald',
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// InquiryReceivedNotification
// ─────────────────────────────────────────────────────────────────────────────

class InquiryReceivedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Inquiry $inquiry) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("New Inquiry from {$this->inquiry->full_name}")
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("You've received a new inquiry from **{$this->inquiry->full_name}**.")
            ->line("**Email:** {$this->inquiry->email}")
            ->line("**Retreat Type:** " . ($this->inquiry->retreat_type ?? 'Not specified'))
            ->line("**Budget:** " . ($this->inquiry->budget ?? 'Not specified'))
            ->line("**Message:** " . ($this->inquiry->message ? substr($this->inquiry->message, 0, 200) . '...' : 'No message'))
            ->action('View Inquiry', route('inquiries.show', $this->inquiry))
            ->line('Respond within 24 hours to improve your conversion rate.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'        => 'inquiry_received',
            'inquiry_id'  => $this->inquiry->id,
            'guest_name'  => $this->inquiry->full_name,
            'guest_email' => $this->inquiry->email,
            'retreat_type'=> $this->inquiry->retreat_type,
            'budget'      => $this->inquiry->budget,
            'message'     => "New inquiry from {$this->inquiry->full_name}.",
            'url'         => route('inquiries.show', $this->inquiry),
            'icon'        => 'mail',
            'color'       => 'blue',
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GuestCheckedInNotification
// ─────────────────────────────────────────────────────────────────────────────

class GuestCheckedInNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Booking $booking) {}

    public function via(object $notifiable): array { return ['database']; }

    public function toArray(object $notifiable): array
    {
        return [
            'type'        => 'guest_checked_in',
            'booking_id'  => $this->booking->id,
            'guest_name'  => $this->booking->guest_name,
            'retreat_name'=> $this->booking->experience?->name,
            'message'     => "{$this->booking->guest_name} has checked in for {$this->booking->experience?->name}.",
            'url'         => route('bookings.show', $this->booking),
            'icon'        => 'log-in',
            'color'       => 'purple',
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ReviewSubmittedNotification
// ─────────────────────────────────────────────────────────────────────────────

class ReviewSubmittedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly CenterReview $review) {}

    public function via(object $notifiable): array { return ['database', 'mail']; }

    public function toMail(object $notifiable): MailMessage
    {
        $stars = str_repeat('⭐', (int) $this->review->overall_rating);
        return (new MailMessage)
            ->subject("New {$this->review->overall_rating}★ Review Received")
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("You've received a new review: {$stars}")
            ->line("**Reviewer:** {$this->review->reviewer_name}")
            ->line("**Title:** {$this->review->title}")
            ->line("\"" . substr($this->review->body, 0, 300) . "...\"")
            ->action('View & Respond', route('reviews.index'))
            ->line('Please review and respond within 48 hours.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'          => 'review_submitted',
            'review_id'     => $this->review->id,
            'reviewer_name' => $this->review->reviewer_name,
            'rating'        => $this->review->overall_rating,
            'title'         => $this->review->title,
            'message'       => "New {$this->review->overall_rating}★ review from {$this->review->reviewer_name}.",
            'url'           => route('reviews.index'),
            'icon'          => 'star',
            'color'         => 'amber',
        ];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PayoutProcessedNotification
// ─────────────────────────────────────────────────────────────────────────────

class PayoutProcessedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly PayoutRequest $payout) {}

    public function via(object $notifiable): array { return ['database', 'mail']; }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("Payout {$this->payout->reference} Processed — {$this->payout->currency} " . number_format($this->payout->net_payout, 2))
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("Your payout request has been processed.")
            ->line("**Reference:** {$this->payout->reference}")
            ->line("**Gross Amount:** {$this->payout->currency} " . number_format($this->payout->gross_amount, 2))
            ->line("**Commission:** {$this->payout->currency} " . number_format($this->payout->commission_deducted, 2))
            ->line("**Net Payout:** {$this->payout->currency} " . number_format($this->payout->net_payout, 2))
            ->line("**Period:** {$this->payout->period_from} to {$this->payout->period_to}")
            ->action('View Finance', route('finance.index'))
            ->line('Funds should arrive within 3-5 business days.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'      => 'payout_processed',
            'payout_id' => $this->payout->id,
            'reference' => $this->payout->reference,
            'amount'    => $this->payout->net_payout,
            'currency'  => $this->payout->currency,
            'message'   => "Payout {$this->payout->reference} of {$this->payout->currency} " . number_format($this->payout->net_payout, 2) . " has been processed.",
            'url'       => route('finance.index'),
            'icon'      => 'credit-card',
            'color'     => 'green',
        ];
    }
}

// ============================================================
// MAILABLES
// ============================================================

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\{Content, Envelope, Address};
use Illuminate\Queue\SerializesModels;

// ─────────────────────────────────────────────────────────────────────────────
// BookingConfirmedMail
// ─────────────────────────────────────────────────────────────────────────────

class BookingConfirmedMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly Booking $booking,
        public readonly string  $guestEmail,
        public readonly string  $guestName
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            from: new Address(config('mail.from.address'), config('mail.from.name')),
            to:   [new Address($this->guestEmail, $this->guestName)],
            subject: "Your Retreat Booking is Confirmed — {$this->booking->booking_reference}",
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.booking-confirmed',
            with: [
                'booking'         => $this->booking,
                'guestName'       => $this->guestName,
                'experience'      => $this->booking->experience,
                'center'          => $this->booking->experience?->center,
                'arrivalDate'     => $this->booking->arrival_date?->format('d F Y'),
                'totalAmount'     => number_format($this->booking->pay_amount, 2) . ' ' . $this->booking->currency,
                'bookingRef'      => $this->booking->booking_reference,
                'supportEmail'    => $this->booking->experience?->center?->email_address ?? config('mail.from.address'),
            ]
        );
    }

    public function attachments(): array { return []; }
}

// ─────────────────────────────────────────────────────────────────────────────
// InquiryReceivedMail
// ─────────────────────────────────────────────────────────────────────────────

class InquiryReceivedMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(public readonly \App\Models\Inquiry $inquiry) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            from:    new Address(config('mail.from.address'), 'BalanceBoat'),
            to:      [new Address($this->inquiry->email, $this->inquiry->name)],
            subject: 'We Received Your Retreat Inquiry — BalanceBoat'
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.inquiry-received',
            with: [
                'inquiry'      => $this->inquiry,
                'guestName'    => $this->inquiry->name,
                'retreatName'  => $this->inquiry->experience?->name ?? 'our wellness retreats',
            ]
        );
    }

    public function attachments(): array { return []; }
}
