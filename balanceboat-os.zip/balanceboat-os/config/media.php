<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Media Disk
    |--------------------------------------------------------------------------
    | 'local' for development, 's3' for production.
    */
    'disk' => env('MEDIA_DISK', 'public'),

    /*
    |--------------------------------------------------------------------------
    | CDN Base URL
    |--------------------------------------------------------------------------
    | When set, CDN_URL is prepended to all public media URLs.
    | Example: https://cdn.yourdomain.com or https://d1234.cloudfront.net
    */
    'cdn_url' => env('CDN_URL', null),

    /*
    |--------------------------------------------------------------------------
    | Allowed MIME Types
    |--------------------------------------------------------------------------
    */
    'allowed_mimes' => [
        'image' => ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'],
        'video' => ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'],
        'document' => ['application/pdf', 'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain'],
    ],

    /*
    |--------------------------------------------------------------------------
    | File Size Limits (bytes)
    |--------------------------------------------------------------------------
    */
    'max_size' => [
        'image'    => 10 * 1024 * 1024,  // 10 MB
        'video'    => 200 * 1024 * 1024, // 200 MB
        'document' => 20 * 1024 * 1024,  // 20 MB
    ],

    /*
    |--------------------------------------------------------------------------
    | Image Processing — Thumbnail Sizes
    |--------------------------------------------------------------------------
    */
    'thumbnails' => [
        'thumb'  => ['width' => 150,  'height' => 150,  'fit' => 'crop'],
        'medium' => ['width' => 600,  'height' => 400,  'fit' => 'contain'],
        'large'  => ['width' => 1200, 'height' => 800,  'fit' => 'contain'],
        'hero'   => ['width' => 1920, 'height' => 1080, 'fit' => 'cover'],
        'card'   => ['width' => 480,  'height' => 320,  'fit' => 'crop'],
        'avatar' => ['width' => 200,  'height' => 200,  'fit' => 'crop'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Image Quality
    |--------------------------------------------------------------------------
    */
    'jpeg_quality' => env('MEDIA_JPEG_QUALITY', 85),
    'webp_quality' => env('MEDIA_WEBP_QUALITY', 80),

    /*
    |--------------------------------------------------------------------------
    | Path Prefixes
    |--------------------------------------------------------------------------
    */
    'paths' => [
        'centers'        => 'centers/{center_id}',
        'experiences'    => 'experiences/{experience_id}',
        'teachers'       => 'teachers/{teacher_id}',
        'accommodations' => 'accommodations/{accommodation_id}',
        'food'           => 'food/{experience_id}',
        'avatars'        => 'avatars',
        'temp'           => 'temp',
        'documents'      => 'documents',
    ],

    /*
    |--------------------------------------------------------------------------
    | Watermark
    |--------------------------------------------------------------------------
    */
    'watermark' => [
        'enabled'  => env('MEDIA_WATERMARK_ENABLED', false),
        'path'     => public_path('images/watermark.png'),
        'position' => 'bottom-right',
        'opacity'  => 40,
    ],

    /*
    |--------------------------------------------------------------------------
    | AWS S3 Configuration
    |--------------------------------------------------------------------------
    */
    's3' => [
        'key'    => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'ap-south-1'),
        'bucket' => env('AWS_BUCKET'),
        'url'    => env('AWS_URL'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Auto-Generate Thumbnails on Upload
    |--------------------------------------------------------------------------
    */
    'auto_thumbnails' => env('MEDIA_AUTO_THUMBNAILS', true),

    /*
    |--------------------------------------------------------------------------
    | Signed URL Expiry (seconds) for private files
    |--------------------------------------------------------------------------
    */
    'signed_url_expiry' => env('MEDIA_SIGNED_URL_EXPIRY', 3600),

    /*
    |--------------------------------------------------------------------------
    | Cache Headers (seconds)
    |--------------------------------------------------------------------------
    */
    'cache_max_age' => env('MEDIA_CACHE_MAX_AGE', 86400 * 30), // 30 days
];
