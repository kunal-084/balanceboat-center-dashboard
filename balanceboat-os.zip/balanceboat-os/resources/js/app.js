/**
 * BalanceBoat Center OS
 * Frontend Application Entry Point
 */

import './bootstrap';

// Alpine.js core + plugins
import Alpine from 'alpinejs';
import collapse from '@alpinejs/collapse';
import focus    from '@alpinejs/focus';
import persist  from '@alpinejs/persist';

Alpine.plugin(collapse);
Alpine.plugin(focus);
Alpine.plugin(persist);

// ── Global Alpine Stores ──────────────────────────────────────────────────────

Alpine.store('ui', {
    sidebarOpen: Alpine.$persist(true).as('sidebar_open'),
    notifications: [],

    addNotification(message, type = 'success', duration = 4000) {
        const id = Date.now();
        this.notifications.push({ id, message, type });
        if (duration > 0) {
            setTimeout(() => this.removeNotification(id), duration);
        }
    },

    removeNotification(id) {
        this.notifications = this.notifications.filter(n => n.id !== id);
    },
});

// ── Alpine Components ─────────────────────────────────────────────────────────

/**
 * Booking state machine transition handler.
 * Usage: x-data="bookingActions({ bookingId: {{ $booking->id }}, status: '{{ $booking->status }}' })"
 */
Alpine.data('bookingActions', ({ bookingId, status }) => ({
    status,
    loading: false,

    async transition(newStatus) {
        this.loading = true;
        try {
            const res = await fetch(`/bookings/${bookingId}/transition`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ status: newStatus }),
            });
            const data = await res.json();
            if (data.success) {
                this.status = data.status;
                Alpine.store('ui').addNotification(`Booking moved to ${newStatus.replace('_', ' ')}`, 'success');
                window.location.reload();
            } else {
                Alpine.store('ui').addNotification(data.message || 'Transition failed', 'error');
            }
        } catch (e) {
            Alpine.store('ui').addNotification('Network error. Please try again.', 'error');
        } finally {
            this.loading = false;
        }
    },
}));

/**
 * Media uploader component.
 */
Alpine.data('mediaUploader', ({ endpoint, maxFiles = 10, maxSizeMB = 20 }) => ({
    files: [],
    uploading: false,
    progress: 0,
    errors: [],

    get remaining() {
        return maxFiles - this.files.length;
    },

    async handleFiles(event) {
        const selected = Array.from(event.target.files);
        this.errors = [];

        for (const file of selected) {
            if (file.size > maxSizeMB * 1024 * 1024) {
                this.errors.push(`${file.name} exceeds ${maxSizeMB}MB limit.`);
                continue;
            }
            await this.upload(file);
        }
    },

    async upload(file) {
        this.uploading = true;
        const fd = new FormData();
        fd.append('file', file);
        fd.append('_token', document.querySelector('meta[name="csrf-token"]').content);

        try {
            const res = await fetch(endpoint, { method: 'POST', body: fd });
            const data = await res.json();
            if (data.success) {
                this.files.push(data.media);
            } else {
                this.errors.push(data.message || `Failed to upload ${file.name}`);
            }
        } catch (e) {
            this.errors.push(`Error uploading ${file.name}`);
        } finally {
            this.uploading = false;
        }
    },

    async remove(id) {
        if (!confirm('Remove this file?')) return;
        await fetch(`/media/${id}`, {
            method: 'DELETE',
            headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
        });
        this.files = this.files.filter(f => f.id !== id);
    },
}));

/**
 * Pricing widget — live price calculator.
 */
Alpine.data('pricingWidget', ({ basePrice, currency = 'USD' }) => ({
    base: basePrice,
    participants: 1,
    addons: [],
    promoCode: '',
    discount: 0,
    loading: false,

    get subtotal() {
        const addonTotal = this.addons.reduce((s, a) => s + (a.selected ? a.price : 0), 0);
        return (this.base + addonTotal) * this.participants;
    },

    get total() {
        return Math.max(0, this.subtotal - this.discount);
    },

    format(amount) {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
    },

    async applyPromo() {
        if (!this.promoCode) return;
        this.loading = true;
        try {
            const res = await fetch(`/promo-codes/validate?code=${this.promoCode}&amount=${this.subtotal}`, {
                headers: { 'Accept': 'application/json' },
            });
            const data = await res.json();
            this.discount = data.discount ?? 0;
        } catch {}
        this.loading = false;
    },
}));

/**
 * Drag-to-reorder for retreat sections / schedule items.
 */
Alpine.data('sortable', ({ url }) => ({
    init() {
        import('sortablejs').then(({ default: Sortable }) => {
            Sortable.create(this.$el, {
                animation: 150,
                handle: '.drag-handle',
                onEnd: async (evt) => {
                    const ids = [...this.$el.querySelectorAll('[data-id]')].map(el => el.dataset.id);
                    await fetch(url, {
                        method: 'PATCH',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        },
                        body: JSON.stringify({ order: ids }),
                    });
                },
            });
        });
    },
}));

// ── Chart.js lazy loader ───────────────────────────────────────────────────────

window.bbChart = async function(canvasId, config) {
    const { Chart, registerables } = await import('chart.js');
    Chart.register(...registerables);

    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    return new Chart(canvas, {
        ...config,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { font: { family: 'Inter', size: 12 }, color: '#6b7280' },
                },
                tooltip: {
                    backgroundColor: '#111827',
                    titleFont: { family: 'Inter', size: 12, weight: '600' },
                    bodyFont: { family: 'Inter', size: 12 },
                    cornerRadius: 8,
                    padding: 10,
                },
            },
            scales: config.type !== 'doughnut' && config.type !== 'pie' ? {
                x: {
                    grid: { color: 'rgba(0,0,0,0.04)' },
                    ticks: { font: { family: 'Inter', size: 11 }, color: '#9ca3af' },
                },
                y: {
                    grid: { color: 'rgba(0,0,0,0.04)' },
                    ticks: { font: { family: 'Inter', size: 11 }, color: '#9ca3af' },
                    beginAtZero: true,
                },
            } : undefined,
            ...config.options,
        },
    });
};

// ── Flatpickr helper ──────────────────────────────────────────────────────────

window.bbDatePicker = function(selector, options = {}) {
    import('flatpickr').then(({ default: flatpickr }) => {
        flatpickr(selector, {
            dateFormat: 'Y-m-d',
            disableMobile: true,
            ...options,
        });
    });
};

// ── Tom Select helper ─────────────────────────────────────────────────────────

window.bbSelect = function(selector, options = {}) {
    import('tom-select').then(({ default: TomSelect }) => {
        document.querySelectorAll(selector).forEach(el => {
            new TomSelect(el, {
                plugins: ['remove_button'],
                ...options,
            });
        });
    });
};

// ── Start Alpine ──────────────────────────────────────────────────────────────

window.Alpine = Alpine;
Alpine.start();

// ── CSRF token for Axios ──────────────────────────────────────────────────────

import axios from 'axios';
window.axios = axios;
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.headers.common['X-CSRF-TOKEN'] =
    document.querySelector('meta[name="csrf-token"]')?.content ?? '';
