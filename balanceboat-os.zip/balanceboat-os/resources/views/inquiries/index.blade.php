@extends('layouts.app')

@section('title', 'Inquiries')
@section('page-title', 'Inquiries')

@section('content')
<div class="space-y-6" x-data="{ selected: null }">

    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Guest inquiries and lead management</p>
        @if($pending = $inquiries->where('status','new')->count())
        <span class="text-xs bg-lavender-100 text-lavender-700 font-semibold px-3 py-1 rounded-full">
            {{ $pending }} new
        </span>
        @endif
    </div>

    <x-alert />

    {{-- Filters --}}
    <form method="GET" action="{{ route('inquiries.index') }}" class="flex items-center gap-3 flex-wrap">
        <div class="relative flex-1 min-w-[200px]">
            <input type="text" name="search" value="{{ request('search') }}"
                placeholder="Search inquiries..."
                class="w-full pl-9 pr-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white">
            <svg class="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 15.803 7.5 7.5 0 0016.803 15.803z"/>
            </svg>
        </div>
        <select name="status" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="">All Statuses</option>
            @foreach(['new','replied','converted','closed'] as $s)
            <option value="{{ $s }}" {{ request('status') === $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
            @endforeach
        </select>
        <button type="submit" class="px-4 py-2.5 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700">Filter</button>
    </form>

    <div class="grid grid-cols-1 lg:grid-cols-5 gap-5">

        {{-- Inquiry List --}}
        <div class="lg:col-span-2 space-y-2">
            @forelse($inquiries as $inquiry)
            <button
                type="button"
                @click="selected = {{ $inquiry->id }}"
                :class="selected === {{ $inquiry->id }} ? 'border-lavender-300 bg-lavender-50' : 'border-gray-100 bg-white hover:border-lavender-200'"
                class="w-full text-left p-4 rounded-xl border transition-all"
            >
                <div class="flex items-start justify-between gap-2 mb-1.5">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 bg-lavender-100 rounded-full flex items-center justify-center text-xs font-bold text-lavender-700 flex-shrink-0">
                            {{ strtoupper(substr($inquiry->name, 0, 1)) }}
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $inquiry->name }}</div>
                            <div class="text-xs text-gray-400">{{ $inquiry->email }}</div>
                        </div>
                    </div>
                    <x-status-badge :status="$inquiry->status" size="xs" />
                </div>
                <p class="text-xs text-gray-500 truncate ml-10">{{ $inquiry->subject ?? $inquiry->message }}</p>
                <div class="text-xs text-gray-400 mt-1.5 ml-10">{{ $inquiry->created_at->diffForHumans() }}</div>
            </button>
            @empty
            <div class="text-center py-10 text-gray-400 text-sm">No inquiries found.</div>
            @endforelse
            <div class="mt-2">{{ $inquiries->links() }}</div>
        </div>

        {{-- Inquiry Detail Panel --}}
        <div class="lg:col-span-3">
            @foreach($inquiries as $inquiry)
            <div x-show="selected === {{ $inquiry->id }}" class="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                {{-- Header --}}
                <div class="px-6 py-5 border-b border-gray-50 flex items-start justify-between">
                    <div>
                        <h3 class="font-semibold text-gray-900">{{ $inquiry->subject ?? 'Inquiry' }}</h3>
                        <div class="flex items-center gap-2 mt-1 text-xs text-gray-500">
                            <span>{{ $inquiry->name }}</span>
                            <span>·</span>
                            <a href="mailto:{{ $inquiry->email }}" class="text-lavender-600 hover:underline">{{ $inquiry->email }}</a>
                            @if($inquiry->phone)
                            <span>·</span>
                            <span>{{ $inquiry->phone }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        @if($inquiry->status !== 'converted')
                        <form method="POST" action="{{ route('inquiries.convert', $inquiry) }}">
                            @csrf @method('PATCH')
                            <button type="submit" class="px-3 py-1.5 text-xs font-medium bg-wellness-500 text-white rounded-lg hover:bg-wellness-600">
                                Convert to Booking
                            </button>
                        </form>
                        @endif
                        @if($inquiry->status !== 'closed')
                        <form method="POST" action="{{ route('inquiries.close', $inquiry) }}">
                            @csrf @method('PATCH')
                            <button type="submit" class="px-3 py-1.5 text-xs font-medium text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50">
                                Close
                            </button>
                        </form>
                        @endif
                    </div>
                </div>

                {{-- Message Thread --}}
                <div class="px-6 py-5 space-y-4 max-h-[320px] overflow-y-auto">
                    {{-- Original Message --}}
                    <div class="flex gap-3">
                        <div class="w-8 h-8 bg-peach-100 rounded-full flex items-center justify-center text-xs font-bold text-peach-700 flex-shrink-0">
                            {{ strtoupper(substr($inquiry->name, 0, 1)) }}
                        </div>
                        <div class="flex-1 bg-gray-50 rounded-xl p-3.5">
                            <div class="text-xs text-gray-400 mb-1.5">{{ $inquiry->created_at->format('d M Y, H:i') }}</div>
                            @if($inquiry->retreat)
                            <div class="text-xs text-lavender-600 font-medium mb-2">Re: {{ $inquiry->retreat->title }}</div>
                            @endif
                            <p class="text-sm text-gray-700 leading-relaxed">{{ $inquiry->message }}</p>
                        </div>
                    </div>

                    {{-- Replies --}}
                    @foreach($inquiry->replies ?? [] as $reply)
                    <div class="flex gap-3 {{ $reply->is_staff ? 'flex-row-reverse' : '' }}">
                        <div class="w-8 h-8 {{ $reply->is_staff ? 'bg-lavender-100' : 'bg-peach-100' }} rounded-full flex items-center justify-center text-xs font-bold {{ $reply->is_staff ? 'text-lavender-700' : 'text-peach-700' }} flex-shrink-0">
                            {{ strtoupper(substr($reply->author_name, 0, 1)) }}
                        </div>
                        <div class="flex-1 {{ $reply->is_staff ? 'bg-lavender-50' : 'bg-gray-50' }} rounded-xl p-3.5">
                            <div class="flex items-center justify-between mb-1.5">
                                <span class="text-xs font-medium text-gray-600">{{ $reply->author_name }}</span>
                                <span class="text-xs text-gray-400">{{ $reply->created_at->format('d M, H:i') }}</span>
                            </div>
                            <p class="text-sm text-gray-700 leading-relaxed">{{ $reply->content }}</p>
                        </div>
                    </div>
                    @endforeach
                </div>

                {{-- Reply Form --}}
                <div class="px-6 py-5 border-t border-gray-50">
                    <form method="POST" action="{{ route('inquiries.reply', $inquiry) }}">
                        @csrf
                        <div class="mb-3">
                            <textarea name="reply" rows="4" placeholder="Type your reply..."
                                class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 resize-none"></textarea>
                        </div>
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-3">
                                <label class="flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer">
                                    <input type="checkbox" name="also_whatsapp" class="w-3.5 h-3.5 text-lavender-600 rounded border-gray-300">
                                    Also send via WhatsApp
                                </label>
                            </div>
                            <button type="submit" class="flex items-center gap-2 px-4 py-2 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700 transition-colors">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5"/>
                                </svg>
                                Send Reply
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            @endforeach

            {{-- Empty State (no selection) --}}
            <div x-show="!selected" class="bg-white rounded-2xl border border-gray-100 h-64 flex items-center justify-center">
                <div class="text-center">
                    <div class="text-4xl mb-3">💬</div>
                    <p class="text-sm text-gray-400">Select an inquiry to view and reply</p>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
