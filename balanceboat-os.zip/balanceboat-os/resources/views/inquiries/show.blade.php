@extends('layouts.app')

@section('title', 'Inquiry #'.$inquiry->id)
@section('page-title', 'Inquiries')

@section('content')
<div class="space-y-6">

    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('inquiries.index') }}" class="hover:text-gray-600">Inquiries</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">{{ $inquiry->guest_name }}</span>
    </nav>

    <x-alert />

    <div class="grid grid-cols-3 gap-6">

        {{-- Main: Conversation --}}
        <div class="col-span-2 space-y-5">

            {{-- Original Inquiry --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <h2 class="font-semibold text-gray-900 text-lg">{{ $inquiry->guest_name }}</h2>
                        <p class="text-sm text-gray-500 mt-0.5">
                            {{ $inquiry->guest_email }} @if($inquiry->guest_phone) · {{ $inquiry->guest_phone }} @endif
                        </p>
                    </div>
                    <div class="flex items-center gap-2">
                        <x-status-badge :status="$inquiry->status" />
                        <span class="text-xs text-gray-400">{{ $inquiry->created_at->diffForHumans() }}</span>
                    </div>
                </div>

                @if($inquiry->experience)
                <div class="flex items-center gap-3 p-3 bg-lavender-50 rounded-xl mb-4">
                    <div class="w-10 h-10 rounded-lg bg-lavender-200 flex items-center justify-center text-lg">🧘</div>
                    <div>
                        <div class="text-sm font-medium text-gray-900">{{ $inquiry->experience->title }}</div>
                        <div class="text-xs text-gray-400">{{ $inquiry->experience->location_name }} · {{ $inquiry->experience->duration_days }} days</div>
                    </div>
                    <a href="{{ route('retreats.show', $inquiry->experience) }}" class="ml-auto text-xs text-lavender-600 hover:underline">
                        View Retreat →
                    </a>
                </div>
                @endif

                <div class="text-sm text-gray-700 leading-relaxed bg-gray-50 rounded-xl p-4">
                    {{ $inquiry->message }}
                </div>

                @if($inquiry->preferred_dates || $inquiry->participants)
                <div class="mt-4 flex items-center gap-4 text-sm">
                    @if($inquiry->preferred_dates)
                    <div class="flex items-center gap-1.5 text-gray-500">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"/>
                        </svg>
                        Preferred: {{ $inquiry->preferred_dates }}
                    </div>
                    @endif
                    @if($inquiry->participants)
                    <div class="flex items-center gap-1.5 text-gray-500">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/>
                        </svg>
                        {{ $inquiry->participants }} participant{{ $inquiry->participants > 1 ? 's' : '' }}
                    </div>
                    @endif
                </div>
                @endif
            </div>

            {{-- Reply Thread --}}
            @if($inquiry->replies->count())
            <div class="space-y-3">
                @foreach($inquiry->replies as $reply)
                <div class="flex gap-3 {{ $reply->is_from_center ? 'flex-row-reverse' : '' }}">
                    <div class="w-8 h-8 rounded-full {{ $reply->is_from_center ? 'bg-lavender-600' : 'bg-gray-200' }} flex items-center justify-center text-xs font-bold {{ $reply->is_from_center ? 'text-white' : 'text-gray-500' }} shrink-0">
                        {{ $reply->is_from_center ? 'You' : strtoupper(substr($inquiry->guest_name, 0, 2)) }}
                    </div>
                    <div class="max-w-[75%]">
                        <div class="p-4 rounded-2xl text-sm {{ $reply->is_from_center ? 'bg-lavender-600 text-white rounded-tr-sm' : 'bg-white border border-gray-100 text-gray-700 rounded-tl-sm' }}">
                            {{ $reply->message }}
                        </div>
                        <div class="text-xs text-gray-400 mt-1 {{ $reply->is_from_center ? 'text-right' : '' }}">
                            {{ $reply->created_at->diffForHumans() }}
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif

            {{-- Reply Box --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-medium text-gray-900 mb-3">Reply to Guest</h3>
                <form method="POST" action="{{ route('inquiries.reply', $inquiry) }}">
                    @csrf
                    <textarea name="message" rows="4" required
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-none"
                        placeholder="Type your reply... it will be sent by email."></textarea>
                    <div class="mt-3 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <label class="flex items-center gap-1.5 text-sm text-gray-500 cursor-pointer">
                                <input type="checkbox" name="send_whatsapp" value="1"
                                    class="w-3.5 h-3.5 text-lavender-600 rounded border-gray-300">
                                Also send via WhatsApp
                            </label>
                        </div>
                        <div class="flex items-center gap-2">
                            <select name="template_id"
                                class="text-xs px-2.5 py-1.5 border border-gray-200 rounded-lg outline-none focus:border-lavender-400">
                                <option value="">— Use template —</option>
                                @foreach($emailTemplates as $tpl)
                                <option value="{{ $tpl->id }}">{{ $tpl->name }}</option>
                                @endforeach
                            </select>
                            <button type="submit"
                                    class="px-4 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                                Send Reply
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        {{-- Sidebar --}}
        <div class="space-y-4">

            {{-- Status Control --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Status</h3>
                <form method="POST" action="{{ route('inquiries.status', $inquiry) }}">
                    @csrf @method('PATCH')
                    <select name="status" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 mb-3"
                        onchange="this.form.submit()">
                        @foreach(['new','in_progress','responded','converted','closed','spam'] as $s)
                        <option value="{{ $s }}" {{ $inquiry->status === $s ? 'selected' : '' }}>
                            {{ ucwords(str_replace('_', ' ', $s)) }}
                        </option>
                        @endforeach
                    </select>
                </form>

                {{-- Convert to Booking --}}
                @if(!in_array($inquiry->status, ['converted', 'closed', 'spam']))
                <div class="border-t border-gray-100 pt-3 mt-3">
                    <a href="{{ route('bookings.create', ['inquiry_id' => $inquiry->id]) }}"
                       class="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-wellness-500 text-white text-sm font-semibold rounded-xl hover:bg-wellness-600 transition-colors">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12h15m0 0l-6.75-6.75M19.5 12l-6.75 6.75"/>
                        </svg>
                        Convert to Booking
                    </a>
                </div>
                @endif
            </div>

            {{-- Assign --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Assigned To</h3>
                <form method="POST" action="{{ route('inquiries.assign', $inquiry) }}">
                    @csrf @method('PATCH')
                    <select name="assigned_to" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 mb-3">
                        <option value="">— Unassigned —</option>
                        @foreach($staffMembers as $member)
                        <option value="{{ $member->id }}" {{ $inquiry->assigned_to == $member->id ? 'selected' : '' }}>
                            {{ $member->full_name }}
                        </option>
                        @endforeach
                    </select>
                    <button type="submit" class="w-full py-2 text-sm text-lavender-600 border border-lavender-200 rounded-xl hover:bg-lavender-50 font-medium transition-colors">
                        Update Assignment
                    </button>
                </form>
            </div>

            {{-- Notes --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Internal Notes</h3>
                <form method="POST" action="{{ route('inquiries.notes', $inquiry) }}">
                    @csrf @method('PATCH')
                    <textarea name="notes" rows="4"
                        class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 resize-none"
                        placeholder="Notes visible only to your team...">{{ $inquiry->notes }}</textarea>
                    <button type="submit" class="mt-2 w-full py-2 text-sm bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 font-medium transition-colors">
                        Save Notes
                    </button>
                </form>
            </div>

            {{-- Meta --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Meta</h3>
                <div class="space-y-2 text-xs text-gray-500">
                    <div class="flex justify-between">
                        <span>Source</span>
                        <span class="font-medium text-gray-700">{{ $inquiry->source ?? 'Website' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Country</span>
                        <span class="font-medium text-gray-700">{{ $inquiry->guest_country ?? '—' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>UTM Campaign</span>
                        <span class="font-medium text-gray-700">{{ $inquiry->utm_campaign ?? '—' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Received</span>
                        <span class="font-medium text-gray-700">{{ $inquiry->created_at->format('d M Y, H:i') }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Last Activity</span>
                        <span class="font-medium text-gray-700">{{ $inquiry->updated_at->diffForHumans() }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
