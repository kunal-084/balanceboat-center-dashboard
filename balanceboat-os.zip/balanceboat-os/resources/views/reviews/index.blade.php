@extends('layouts.app')

@section('title', 'Reviews')
@section('page-title', 'Reviews')

@section('content')
<div class="space-y-6">

    {{-- Header Stats --}}
    <div class="grid grid-cols-4 gap-5">
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div class="text-xs text-gray-400 mb-2">Overall Rating</div>
            <div class="flex items-end gap-2">
                <span class="text-3xl font-bold text-gray-900">{{ number_format($stats['avg_rating'] ?? 0, 1) }}</span>
                <div class="flex items-center gap-0.5 mb-1">
                    @for($i = 1; $i <= 5; $i++)
                    <span class="text-lg {{ $i <= round($stats['avg_rating'] ?? 0) ? 'text-amber-400' : 'text-gray-200' }}">★</span>
                    @endfor
                </div>
            </div>
            <div class="text-xs text-gray-400 mt-1">{{ $stats['total'] ?? 0 }} total reviews</div>
        </div>

        @foreach([5,4,3] as $star)
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
            <div class="flex items-center gap-1 mb-3">
                @for($i=1;$i<=5;$i++)
                <span class="text-sm {{ $i <= $star ? 'text-amber-400' : 'text-gray-200' }}">★</span>
                @endfor
            </div>
            <div class="text-2xl font-bold text-gray-900">{{ $ratingBreakdown[$star] ?? 0 }}</div>
            <div class="mt-2 w-full bg-gray-100 rounded-full h-1.5">
                @php $pct = $stats['total'] > 0 ? (($ratingBreakdown[$star] ?? 0) / $stats['total']) * 100 : 0; @endphp
                <div class="h-1.5 bg-amber-400 rounded-full" style="width: {{ $pct }}%"></div>
            </div>
        </div>
        @endforeach
    </div>

    {{-- Filters --}}
    <div class="flex items-center gap-3 flex-wrap">
        <form method="GET" action="{{ route('reviews.index') }}" class="flex items-center gap-3">
            <div class="flex items-center gap-1 bg-gray-100 rounded-xl p-1">
                @foreach(['all'=>'All','pending'=>'Pending','approved'=>'Approved','flagged'=>'Flagged'] as $k=>$l)
                <a href="{{ route('reviews.index', array_merge(request()->query(), ['status' => $k])) }}"
                   class="px-3.5 py-1.5 text-sm font-medium rounded-lg transition-all
                       {{ request('status', 'all') === $k ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500' }}">
                    {{ $l }}
                </a>
                @endforeach
            </div>

            <select name="retreat_id" onchange="this.form.submit()"
                class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
                <option value="">All Retreats</option>
                @foreach($experiences as $exp)
                <option value="{{ $exp->id }}" {{ request('retreat_id') == $exp->id ? 'selected' : '' }}>
                    {{ $exp->title }}
                </option>
                @endforeach
            </select>

            <select name="rating" onchange="this.form.submit()"
                class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
                <option value="">All Ratings</option>
                @for($i=5;$i>=1;$i--)
                <option value="{{ $i }}" {{ request('rating') == $i ? 'selected' : '' }}>{{ $i }} Stars</option>
                @endfor
            </select>
        </form>

        @if(request()->hasAny(['status','retreat_id','rating']))
        <a href="{{ route('reviews.index') }}" class="text-sm text-gray-400 hover:text-gray-600">Clear filters</a>
        @endif
    </div>

    <x-alert />

    {{-- Reviews List --}}
    <div class="space-y-4">
        @forelse($reviews as $review)
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 {{ $review->status === 'flagged' ? 'border-red-200' : '' }}">
            <div class="flex items-start justify-between gap-4">

                {{-- Left: Review Content --}}
                <div class="flex-1">
                    <div class="flex items-center gap-3 mb-3">
                        {{-- Avatar --}}
                        <div class="w-10 h-10 rounded-full bg-lavender-100 flex items-center justify-center text-sm font-bold text-lavender-700 shrink-0">
                            {{ strtoupper(substr($review->guest_name ?? 'G', 0, 2)) }}
                        </div>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">{{ $review->guest_name }}</div>
                            <div class="text-xs text-gray-400">
                                {{ $review->guest_country }}
                                @if($review->verified_booking) · <span class="text-wellness-600">✓ Verified Guest</span> @endif
                            </div>
                        </div>
                        <div class="flex items-center gap-0.5 ml-auto">
                            @for($i=1;$i<=5;$i++)
                            <span class="text-base {{ $i <= $review->rating ? 'text-amber-400' : 'text-gray-200' }}">★</span>
                            @endfor
                            <span class="text-xs text-gray-400 ml-1">{{ $review->rating }}/5</span>
                        </div>
                    </div>

                    {{-- Retreat Tag --}}
                    @if($review->experience)
                    <div class="flex items-center gap-1.5 text-xs text-lavender-600 mb-3">
                        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"/>
                        </svg>
                        {{ $review->experience->title }}
                    </div>
                    @endif

                    {{-- Review Text --}}
                    <p class="text-sm text-gray-700 leading-relaxed">{{ $review->comment }}</p>

                    {{-- Aspect Ratings (if any) --}}
                    @if($review->aspect_ratings)
                    <div class="mt-3 flex items-center gap-4 flex-wrap">
                        @foreach($review->aspect_ratings as $aspect => $rating)
                        <div class="text-xs">
                            <span class="text-gray-400 capitalize">{{ $aspect }}</span>
                            <span class="font-semibold text-gray-700 ml-1">{{ $rating }}/5</span>
                        </div>
                        @endforeach
                    </div>
                    @endif

                    {{-- Center Reply --}}
                    @if($review->reply)
                    <div class="mt-4 pl-4 border-l-2 border-lavender-200">
                        <div class="text-xs font-semibold text-lavender-700 mb-1">Your Response</div>
                        <p class="text-xs text-gray-600">{{ $review->reply }}</p>
                    </div>
                    @endif
                </div>

                {{-- Right: Actions --}}
                <div class="flex flex-col items-end gap-2 shrink-0">
                    <div class="flex items-center gap-1">
                        <x-status-badge :status="$review->status" />
                        <span class="text-xs text-gray-400">{{ $review->created_at->diffForHumans() }}</span>
                    </div>

                    <div class="flex items-center gap-1 mt-1">
                        @if($review->status === 'pending')
                        <form method="POST" action="{{ route('reviews.approve', $review) }}">
                            @csrf @method('PATCH')
                            <button type="submit" class="text-xs px-2.5 py-1.5 bg-wellness-500 text-white rounded-lg font-medium hover:bg-wellness-600 transition-colors">
                                Approve
                            </button>
                        </form>
                        @endif
                        @if($review->status !== 'flagged')
                        <form method="POST" action="{{ route('reviews.flag', $review) }}">
                            @csrf @method('PATCH')
                            <button type="submit" class="text-xs px-2.5 py-1.5 text-amber-600 hover:bg-amber-50 rounded-lg font-medium transition-colors">
                                Flag
                            </button>
                        </form>
                        @endif
                        <form method="POST" action="{{ route('reviews.destroy', $review) }}">
                            @csrf @method('DELETE')
                            <button type="submit" onclick="return confirm('Delete this review?')"
                                    class="text-xs px-2.5 py-1.5 text-red-400 hover:bg-red-50 rounded-lg font-medium transition-colors">
                                Delete
                            </button>
                        </form>
                    </div>

                    {{-- Reply Form --}}
                    @if(!$review->reply)
                    <div x-data="{ open: false }" class="w-64">
                        <button @click="open = !open" class="text-xs text-lavender-600 hover:underline font-medium">
                            ↩ Reply to review
                        </button>
                        <div x-show="open" x-transition class="mt-2">
                            <form method="POST" action="{{ route('reviews.reply', $review) }}">
                                @csrf
                                <textarea name="reply" rows="3" required
                                    class="w-full px-3 py-2 border border-gray-200 rounded-xl text-xs outline-none focus:border-lavender-400 resize-none"
                                    placeholder="Thank you for your kind words..."></textarea>
                                <button type="submit"
                                        class="mt-1.5 w-full py-1.5 bg-lavender-600 text-white text-xs font-semibold rounded-lg hover:bg-lavender-700">
                                    Post Reply
                                </button>
                            </form>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
        @empty
        <div class="bg-white rounded-2xl border border-dashed border-gray-200 p-16 text-center">
            <div class="text-5xl mb-4">⭐</div>
            <p class="text-gray-400 text-sm font-medium">No reviews yet.</p>
            <p class="text-gray-300 text-xs mt-1">Reviews appear here after guests submit them following their retreat.</p>
        </div>
        @endforelse
    </div>

    <div>{{ $reviews->links() }}</div>

</div>
@endsection
