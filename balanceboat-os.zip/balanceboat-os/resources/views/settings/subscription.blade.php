@extends('layouts.app')

@section('title', 'Subscription')
@section('page-title', 'Settings')

@section('content')
<div class="space-y-6">

    @include('settings._nav', ['active' => 'subscription'])

    <x-alert />

    {{-- Current Plan --}}
    <div class="bg-gradient-to-br from-lavender-600 to-violet-700 rounded-2xl p-6 text-white">
        <div class="flex items-start justify-between">
            <div>
                <div class="text-xs font-semibold uppercase tracking-widest text-lavender-200 mb-1">Current Plan</div>
                <h2 class="text-3xl font-bold mb-1">{{ $subscription?->plan?->name ?? 'Free' }}</h2>
                <p class="text-lavender-200 text-sm">
                    @if($subscription && $subscription->ends_at)
                        Renews {{ $subscription->ends_at->format('d M Y') }}
                    @elseif($subscription)
                        Active subscription
                    @else
                        Limited features — upgrade to unlock full access
                    @endif
                </p>
            </div>
            <div class="text-right">
                @if($subscription)
                <div class="text-3xl font-bold">${{ number_format($subscription->plan->price, 0) }}</div>
                <div class="text-lavender-200 text-sm">/ {{ $subscription->plan->billing_cycle }}</div>
                @endif
            </div>
        </div>

        {{-- Usage --}}
        <div class="mt-6 grid grid-cols-4 gap-4">
            @foreach([
                ['label'=>'Retreats','used'=>$usage['retreats'],'limit'=>$limits['retreats']],
                ['label'=>'Bookings / mo','used'=>$usage['bookings'],'limit'=>$limits['bookings']],
                ['label'=>'Team Members','used'=>$usage['team'],'limit'=>$limits['team']],
                ['label'=>'Storage','used'=>$usage['storage'],'limit'=>$limits['storage']],
            ] as $item)
            <div class="bg-white/10 rounded-xl p-4">
                <div class="text-xs text-lavender-200 mb-2">{{ $item['label'] }}</div>
                <div class="text-sm font-semibold">
                    {{ $item['used'] }}
                    <span class="text-lavender-300 font-normal">/ {{ $item['limit'] === -1 ? '∞' : $item['limit'] }}</span>
                </div>
                @if($item['limit'] !== -1)
                @php $pct = $item['limit'] > 0 ? min(100, ($item['used'] / $item['limit']) * 100) : 0; @endphp
                <div class="mt-2 w-full bg-white/20 rounded-full h-1.5">
                    <div class="h-1.5 {{ $pct >= 90 ? 'bg-red-400' : 'bg-white' }} rounded-full" style="width: {{ $pct }}%"></div>
                </div>
                @endif
            </div>
            @endforeach
        </div>
    </div>

    {{-- Plan Comparison --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="p-6 border-b border-gray-100">
            <h2 class="font-semibold text-gray-900">Available Plans</h2>
        </div>
        <div class="grid grid-cols-3 divide-x divide-gray-100">
            @foreach($plans as $plan)
            <div class="p-6 {{ $plan->id === $subscription?->plan_id ? 'bg-lavender-50' : '' }}">
                @if($plan->id === $subscription?->plan_id)
                <div class="inline-block bg-lavender-600 text-white text-[10px] font-semibold px-2 py-0.5 rounded-full mb-3">
                    Current Plan
                </div>
                @endif
                <div class="text-xl font-bold text-gray-900">{{ $plan->name }}</div>
                <div class="mt-1 mb-4">
                    <span class="text-3xl font-bold text-gray-900">${{ number_format($plan->price, 0) }}</span>
                    <span class="text-gray-400 text-sm"> / {{ $plan->billing_cycle }}</span>
                </div>

                <ul class="space-y-2 mb-6">
                    @foreach($plan->features as $feature)
                    <li class="flex items-center gap-2 text-sm text-gray-600">
                        <span class="text-wellness-500 shrink-0">✓</span>
                        {{ $feature }}
                    </li>
                    @endforeach
                </ul>

                @if($plan->id !== $subscription?->plan_id)
                <form method="POST" action="{{ route('settings.subscription.change') }}">
                    @csrf
                    <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                    <button type="submit"
                            class="w-full py-2.5 {{ $plan->price > ($subscription?->plan?->price ?? 0) ? 'bg-lavender-600 text-white hover:bg-lavender-700' : 'border border-gray-200 text-gray-700 hover:bg-gray-50' }} text-sm font-semibold rounded-xl transition-colors">
                        {{ $plan->price > ($subscription?->plan?->price ?? 0) ? 'Upgrade' : 'Downgrade' }} to {{ $plan->name }}
                    </button>
                </form>
                @else
                <div class="w-full py-2.5 border border-lavender-200 text-lavender-700 text-sm font-semibold rounded-xl text-center bg-lavender-50">
                    Active Plan
                </div>
                @endif
            </div>
            @endforeach
        </div>
    </div>

    {{-- Billing History --}}
    @if($invoices->count())
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="p-5 border-b border-gray-100">
            <h2 class="font-semibold text-gray-900">Billing History</h2>
        </div>
        <x-data-table
            :columns="[
                ['key'=>'date','label'=>'Date'],
                ['key'=>'description','label'=>'Description'],
                ['key'=>'amount','label'=>'Amount'],
                ['key'=>'status','label'=>'Status'],
                ['key'=>'invoice','label'=>''],
            ]"
        >
            @foreach($invoices as $inv)
            <tr class="hover:bg-gray-50">
                <td class="px-5 py-3.5 text-sm text-gray-600">{{ $inv->created_at->format('d M Y') }}</td>
                <td class="px-5 py-3.5 text-sm text-gray-900">{{ $inv->description ?? $subscription?->plan?->name.' subscription' }}</td>
                <td class="px-5 py-3.5 text-sm font-semibold text-gray-900">${{ number_format($inv->amount, 2) }}</td>
                <td class="px-5 py-3.5"><x-status-badge :status="$inv->status" /></td>
                <td class="px-5 py-3.5">
                    @if($inv->invoice_pdf_url)
                    <a href="{{ $inv->invoice_pdf_url }}" target="_blank" class="text-xs text-lavender-600 hover:underline font-medium">
                        Download PDF
                    </a>
                    @endif
                </td>
            </tr>
            @endforeach
        </x-data-table>
    </div>
    @endif

    {{-- Danger Zone --}}
    @if($subscription)
    <div class="bg-white rounded-2xl border border-red-100 shadow-sm p-6">
        <h2 class="font-semibold text-red-700 mb-3">Cancel Subscription</h2>
        <p class="text-sm text-gray-500 mb-4">
            Your subscription will remain active until <strong>{{ $subscription->ends_at?->format('d M Y') ?? 'end of billing period' }}</strong>.
            After that, your account will revert to the Free plan and some data may become inaccessible.
        </p>
        <form method="POST" action="{{ route('settings.subscription.cancel') }}">
            @csrf @method('DELETE')
            <button type="submit" onclick="return confirm('Are you sure you want to cancel your subscription?')"
                    class="px-4 py-2 text-sm font-semibold text-red-600 border border-red-200 rounded-xl hover:bg-red-50 transition-colors">
                Cancel Subscription
            </button>
        </form>
    </div>
    @endif

</div>
@endsection
