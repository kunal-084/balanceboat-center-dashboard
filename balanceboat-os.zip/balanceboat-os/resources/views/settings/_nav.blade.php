{{-- Settings Sub-navigation partial --}}
<div class="flex items-center gap-1 bg-gray-100/70 rounded-xl p-1 overflow-x-auto w-fit">
    @foreach([
        'center-profile' => 'Center Profile',
        'team'           => 'Team',
        'email-templates'=> 'Email Templates',
        'preferences'    => 'Preferences',
        'subscription'   => 'Subscription',
    ] as $key => $label)
    <a href="{{ route('settings.'.$key) }}"
       class="px-3.5 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all
           {{ $active === $key ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700' }}">
        {{ $label }}
    </a>
    @endforeach
</div>
