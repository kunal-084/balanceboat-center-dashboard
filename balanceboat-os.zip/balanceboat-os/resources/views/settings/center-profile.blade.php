@extends('layouts.app')

@section('title', 'Center Profile')
@section('page-title', 'Settings')

@section('content')
<div class="space-y-6">

    {{-- Settings Sub-nav --}}
    @include('settings._nav', ['active' => 'center-profile'])

    <x-alert />

    <form method="POST" action="{{ route('settings.center-profile.update') }}" enctype="multipart/form-data" class="space-y-5">
        @csrf @method('PUT')

        {{-- Identity --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Center Identity</h2>

            <div class="flex items-start gap-6 mb-5">
                {{-- Logo --}}
                <div x-data="{ preview: '{{ $center->logo_url }}' }" class="shrink-0">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Logo</label>
                    <div class="w-24 h-24 rounded-2xl border-2 border-dashed border-lavender-300 overflow-hidden flex items-center justify-center cursor-pointer hover:border-lavender-500 transition-colors bg-lavender-50"
                         onclick="document.getElementById('logo-input').click()">
                        <template x-if="!preview">
                            <span class="text-3xl">🏠</span>
                        </template>
                        <template x-if="preview">
                            <img :src="preview" class="w-full h-full object-contain p-2">
                        </template>
                    </div>
                    <input id="logo-input" type="file" name="logo" accept="image/*" class="hidden"
                        @change="preview = URL.createObjectURL($event.target.files[0])">
                    <p class="text-xs text-gray-400 mt-1 text-center">PNG, SVG preferred</p>
                </div>

                {{-- Cover --}}
                <div x-data="{ preview: '{{ $center->cover_image_url }}' }" class="flex-1">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Cover Image</label>
                    <div class="w-full h-24 rounded-2xl border-2 border-dashed border-lavender-300 overflow-hidden flex items-center justify-center cursor-pointer hover:border-lavender-500 transition-colors bg-lavender-50"
                         onclick="document.getElementById('cover-input').click()">
                        <template x-if="!preview">
                            <span class="text-gray-400 text-sm">Click to upload cover image</span>
                        </template>
                        <template x-if="preview">
                            <img :src="preview" class="w-full h-full object-cover">
                        </template>
                    </div>
                    <input id="cover-input" type="file" name="cover_image" accept="image/*" class="hidden"
                        @change="preview = URL.createObjectURL($event.target.files[0])">
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="name" label="Center Name" required :value="old('name', $center->name)" />
                <x-form-input name="tagline" label="Tagline" :value="old('tagline', $center->tagline)"
                    placeholder="e.g. Your sanctuary for transformation" />
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">About Your Center</label>
                    <textarea name="description" rows="5"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y">{{ old('description', $center->description) }}</textarea>
                </div>
                <x-form-input name="center_type" label="Center Type" type="select"
                    :value="old('center_type', $center->center_type)"
                    :options="['yoga_studio'=>'Yoga Studio','retreat_center'=>'Retreat Center','ayurveda_clinic'=>'Ayurveda Clinic','meditation_center'=>'Meditation Center','wellness_spa'=>'Wellness Spa','ashram'=>'Ashram','other'=>'Other']" />
                <x-form-input name="founded_year" label="Founded Year" type="number" :value="old('founded_year', $center->founded_year)" />
            </div>
        </div>

        {{-- Location --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Location & Address</h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="col-span-2">
                    <x-form-input name="address" label="Street Address" :value="old('address', $center->address)" />
                </div>
                <x-form-input name="city" label="City" :value="old('city', $center->city)" />
                <x-form-input name="state" label="State / Province" :value="old('state', $center->state)" />
                <x-form-input name="country" label="Country" :value="old('country', $center->country)" />
                <x-form-input name="postal_code" label="Postal Code" :value="old('postal_code', $center->postal_code)" />
                <x-form-input name="latitude" label="Latitude" type="number" step="0.000001" :value="old('latitude', $center->latitude)" />
                <x-form-input name="longitude" label="Longitude" type="number" step="0.000001" :value="old('longitude', $center->longitude)" />
                <x-form-input name="timezone" label="Timezone" :value="old('timezone', $center->timezone ?? 'Asia/Kolkata')" />
            </div>
        </div>

        {{-- Contact --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Contact Information</h2>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="email" label="Public Email" type="email" :value="old('email', $center->email)" />
                <x-form-input name="phone" label="Phone / WhatsApp" :value="old('phone', $center->phone)" />
                <x-form-input name="website" label="Website" :value="old('website', $center->website)" placeholder="https://your-center.com" />
                <x-form-input name="booking_email" label="Booking Email" type="email" :value="old('booking_email', $center->booking_email)"
                    hint="Where booking requests are sent" />
            </div>
        </div>

        {{-- Social --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Social Media</h2>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="instagram" label="Instagram" :value="old('instagram', $center->instagram)" placeholder="@handle" />
                <x-form-input name="facebook" label="Facebook" :value="old('facebook', $center->facebook)" />
                <x-form-input name="youtube" label="YouTube" :value="old('youtube', $center->youtube)" />
                <x-form-input name="tripadvisor" label="TripAdvisor" :value="old('tripadvisor', $center->tripadvisor)" />
            </div>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="px-6 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                Save Changes
            </button>
        </div>
    </form>
</div>
@endsection
