@extends('layouts.app')

@section('title', 'Email Templates')
@section('page-title', 'Settings')

@section('content')
<div class="space-y-6" x-data="emailTemplates()">

    @include('settings._nav', ['active' => 'email-templates'])

    <x-alert />

    <div class="grid grid-cols-3 gap-6">

        {{-- Left: Template List --}}
        <div class="space-y-3">
            <div class="flex items-center justify-between">
                <h2 class="font-semibold text-gray-900">Templates</h2>
                <button @click="newTemplate()"
                        class="text-xs px-3 py-1.5 bg-lavender-600 text-white rounded-lg font-medium hover:bg-lavender-700 transition-colors">
                    + New
                </button>
            </div>

            @foreach($templates as $tpl)
            <button @click="selectTemplate({{ json_encode($tpl) }})"
                    :class="selected?.id === {{ $tpl->id }} ? 'border-lavender-400 bg-lavender-50' : 'border-gray-100 bg-white hover:border-lavender-200'"
                    class="w-full text-left p-4 border rounded-xl transition-all">
                <div class="flex items-start justify-between gap-2">
                    <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium text-gray-900 truncate">{{ $tpl->name }}</div>
                        <div class="text-xs text-gray-400 mt-0.5 truncate">{{ $tpl->subject }}</div>
                    </div>
                    <div class="shrink-0">
                        @if($tpl->is_system)
                        <span class="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded font-medium">System</span>
                        @else
                        <span class="text-[10px] bg-lavender-100 text-lavender-700 px-1.5 py-0.5 rounded font-medium">Custom</span>
                        @endif
                    </div>
                </div>
                <div class="flex items-center gap-2 mt-2">
                    <span class="text-[10px] {{ $tpl->is_active ? 'text-wellness-600' : 'text-gray-400' }}">
                        {{ $tpl->is_active ? '● Active' : '○ Inactive' }}
                    </span>
                    <span class="text-[10px] text-gray-300">·</span>
                    <span class="text-[10px] text-gray-400 capitalize">{{ str_replace('_', ' ', $tpl->trigger ?? 'manual') }}</span>
                </div>
            </button>
            @endforeach
        </div>

        {{-- Right: Editor --}}
        <div class="col-span-2">
            <template x-if="!selected">
                <div class="h-full flex items-center justify-center bg-white rounded-2xl border border-dashed border-gray-200 p-12">
                    <div class="text-center">
                        <div class="text-4xl mb-3">📧</div>
                        <p class="text-gray-400 text-sm">Select a template to edit</p>
                        <p class="text-gray-300 text-xs mt-1">or create a new one</p>
                    </div>
                </div>
            </template>

            <template x-if="selected">
                <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div class="p-5 border-b border-gray-100 flex items-center justify-between">
                        <h2 class="font-semibold text-gray-900" x-text="selected.name"></h2>
                        <div class="flex items-center gap-2">
                            <button @click="preview = true"
                                    class="text-sm text-gray-500 hover:text-gray-700 font-medium">
                                Preview
                            </button>
                            <template x-if="!selected.is_system">
                                <form method="POST" :action="`/settings/email-templates/${selected.id}`" class="inline">
                                    @csrf
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" onclick="return confirm('Delete this template?')"
                                            class="text-sm text-red-400 hover:text-red-600 font-medium">
                                        Delete
                                    </button>
                                </form>
                            </template>
                        </div>
                    </div>

                    <div class="p-6 space-y-4">
                        <form method="POST" :action="`/settings/email-templates/${selected.id}`" id="template-form">
                            @csrf
                            <input type="hidden" name="_method" value="PUT">

                            <x-form-input name="name" label="Template Name" required
                                x-bind:value="selected.name" />

                            <x-form-input name="subject" label="Email Subject" required
                                x-bind:value="selected.subject"
                                hint="Supports variables like {{guest_name}}, {{retreat_title}}" />

                            <div>
                                <div class="flex items-center justify-between mb-1.5">
                                    <label class="block text-sm font-medium text-gray-700">Email Body (HTML)</label>
                                    <div class="flex items-center gap-3 text-xs">
                                        <button type="button" @click="bodyMode = 'html'"
                                                :class="bodyMode === 'html' ? 'text-lavender-700 font-semibold' : 'text-gray-400'">
                                            HTML
                                        </button>
                                        <button type="button" @click="bodyMode = 'text'"
                                                :class="bodyMode === 'text' ? 'text-lavender-700 font-semibold' : 'text-gray-400'">
                                            Plain Text
                                        </button>
                                    </div>
                                </div>
                                <textarea :name="bodyMode === 'html' ? 'html_body' : 'text_body'"
                                          rows="16"
                                          class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-xs font-mono outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y"
                                          x-text="bodyMode === 'html' ? selected.html_body : selected.text_body"></textarea>
                            </div>

                            {{-- Variable Hints --}}
                            <div class="bg-amber-50 border border-amber-100 rounded-xl p-4">
                                <div class="text-xs font-semibold text-amber-700 mb-2">Available Variables</div>
                                <div class="flex flex-wrap gap-1.5">
                                    @foreach([
                                        '{{guest_name}}','{{guest_email}}','{{booking_reference}}',
                                        '{{retreat_title}}','{{retreat_dates}}','{{retreat_location}}',
                                        '{{total_price}}','{{amount_paid}}','{{balance_due}}',
                                        '{{center_name}}','{{center_email}}','{{center_phone}}',
                                        '{{booking_url}}','{{invoice_url}}',
                                    ] as $var)
                                    <code class="text-[10px] bg-white border border-amber-200 text-amber-800 px-1.5 py-0.5 rounded cursor-pointer hover:bg-amber-100"
                                          onclick="navigator.clipboard.writeText('{{ $var }}')">
                                        {{ $var }}
                                    </code>
                                    @endforeach
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Auto-Send Trigger</label>
                                    <select name="trigger"
                                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                                        <option value="">Manual only</option>
                                        <option value="booking.confirmed"   :selected="selected.trigger === 'booking.confirmed'">On Booking Confirmed</option>
                                        <option value="inquiry.received"    :selected="selected.trigger === 'inquiry.received'">On Inquiry Received</option>
                                        <option value="payment.received"    :selected="selected.trigger === 'payment.received'">On Payment Received</option>
                                        <option value="retreat.reminder_7d" :selected="selected.trigger === 'retreat.reminder_7d'">7-Day Pre-Retreat</option>
                                    </select>
                                </div>
                                <div class="flex flex-col justify-end">
                                    <label class="flex items-center gap-2 cursor-pointer mb-2">
                                        <input type="checkbox" name="is_active" value="1"
                                            x-bind:checked="selected.is_active"
                                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                                        <span class="text-sm text-gray-700">Active</span>
                                    </label>
                                </div>
                            </div>

                            <div class="flex justify-end gap-3">
                                <button type="button" @click="sendTest()"
                                        class="px-4 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                                    Send Test Email
                                </button>
                                <button type="submit"
                                        class="px-5 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                                    Save Template
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </template>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
function emailTemplates() {
    return {
        selected: null,
        bodyMode: 'html',
        preview: false,

        selectTemplate(tpl) { this.selected = tpl; this.bodyMode = 'html'; },

        newTemplate() {
            this.selected = {
                id: 'new',
                name: 'New Template',
                subject: '',
                html_body: '<p>Hello {{guest_name}},</p>\n\n<p></p>\n\n<p>Warm regards,<br>{{center_name}}</p>',
                text_body: 'Hello {{guest_name}},\n\n\n\nWarm regards,\n{{center_name}}',
                trigger: '',
                is_active: true,
                is_system: false,
            };
        },

        async sendTest() {
            const email = prompt('Send test to email:');
            if (!email) return;
            await fetch(`/settings/email-templates/${this.selected.id}/test`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                body: JSON.stringify({ email }),
            });
            alert('Test email sent!');
        },
    };
}
</script>
@endpush
