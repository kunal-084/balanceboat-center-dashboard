@extends('layouts.app')

@section('title', 'Team')
@section('page-title', 'Settings')

@section('content')
<div class="space-y-6">

    @include('settings._nav', ['active' => 'team'])

    <x-alert />

    {{-- Invite Banner --}}
    <div x-data="{ showInvite: false }" class="space-y-4">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-semibold text-gray-900">Team Members</h2>
                <p class="text-sm text-gray-400 mt-0.5">{{ $members->count() }} members · {{ $pendingInvites->count() }} pending</p>
            </div>
            <button @click="showInvite = !showInvite"
                    class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                </svg>
                Invite Member
            </button>
        </div>

        {{-- Invite Form --}}
        <div x-show="showInvite" x-transition class="bg-lavender-50 border border-lavender-200 rounded-2xl p-5">
            <h3 class="font-medium text-gray-900 mb-4">Send Invitation</h3>
            <form method="POST" action="{{ route('settings.team.invite') }}" class="grid grid-cols-4 gap-4">
                @csrf
                <div class="col-span-2">
                    <x-form-input name="email" label="Email Address" type="email" required placeholder="team@yourcenter.com" />
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Role</label>
                    <select name="role" class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
                        <option value="center-manager">Center Manager</option>
                        <option value="staff">Staff</option>
                        <option value="teacher">Teacher</option>
                        <option value="accountant">Accountant</option>
                    </select>
                </div>
                <div class="flex items-end">
                    <button type="submit" class="w-full py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                        Send Invite
                    </button>
                </div>
            </form>
        </div>
    </div>

    {{-- Current Members --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="divide-y divide-gray-50">
            @foreach($members as $member)
            <div class="flex items-center gap-4 p-5 hover:bg-gray-50/50 transition-colors">
                <img src="{{ $member->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($member->full_name).'&background=ede9fe&color=7c3aed' }}"
                     alt="" class="w-10 h-10 rounded-full object-cover shrink-0">
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2">
                        <span class="text-sm font-medium text-gray-900">{{ $member->full_name }}</span>
                        @if($member->id === auth()->id())
                        <span class="text-xs text-lavender-600 bg-lavender-50 px-1.5 py-0.5 rounded-full font-medium">You</span>
                        @endif
                    </div>
                    <div class="text-xs text-gray-400">{{ $member->email }}</div>
                </div>
                <div class="flex items-center gap-3">
                    @if($member->id !== auth()->id())
                    <form method="POST" action="{{ route('settings.team.update-role', $member) }}">
                        @csrf @method('PATCH')
                        <select name="role" onchange="this.form.submit()"
                            class="px-3 py-1.5 border border-gray-200 rounded-lg text-xs outline-none focus:border-lavender-400 bg-white">
                            @foreach(['center-manager'=>'Manager','staff'=>'Staff','teacher'=>'Teacher','accountant'=>'Accountant'] as $r=>$l)
                            <option value="{{ $r }}" {{ $member->hasRole($r) ? 'selected' : '' }}>{{ $l }}</option>
                            @endforeach
                        </select>
                    </form>
                    @else
                    <span class="text-xs px-3 py-1.5 bg-lavender-100 text-lavender-700 rounded-lg font-medium capitalize">
                        {{ $member->roles->first()?->name ?? 'owner' }}
                    </span>
                    @endif

                    <div class="text-xs text-gray-400">Joined {{ $member->created_at->format('M Y') }}</div>

                    @if($member->id !== auth()->id())
                    <form method="POST" action="{{ route('settings.team.remove', $member) }}">
                        @csrf @method('DELETE')
                        <button type="submit" onclick="return confirm('Remove {{ $member->full_name }} from the team?')"
                                class="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                        </button>
                    </form>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
    </div>

    {{-- Pending Invites --}}
    @if($pendingInvites->count())
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="p-5 border-b border-gray-100">
            <h3 class="font-semibold text-gray-900">Pending Invitations</h3>
        </div>
        <div class="divide-y divide-gray-50">
            @foreach($pendingInvites as $invite)
            <div class="flex items-center gap-4 p-5">
                <div class="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-600 text-xs font-bold shrink-0">
                    ⏳
                </div>
                <div class="flex-1">
                    <div class="text-sm font-medium text-gray-900">{{ $invite->email }}</div>
                    <div class="text-xs text-gray-400">
                        Invited as <span class="font-medium capitalize">{{ $invite->role }}</span> ·
                        Sent {{ $invite->created_at->diffForHumans() }}
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <form method="POST" action="{{ route('settings.team.resend', $invite) }}">
                        @csrf
                        <button type="submit" class="text-xs px-2.5 py-1.5 text-lavender-600 hover:bg-lavender-50 rounded-lg font-medium transition-colors">
                            Resend
                        </button>
                    </form>
                    <form method="POST" action="{{ route('settings.team.cancel-invite', $invite) }}">
                        @csrf @method('DELETE')
                        <button type="submit" class="text-xs px-2.5 py-1.5 text-red-400 hover:bg-red-50 rounded-lg font-medium transition-colors">
                            Cancel
                        </button>
                    </form>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    {{-- Role Permissions Table --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 class="font-semibold text-gray-900 mb-4">Role Permissions</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead>
                    <tr class="border-b border-gray-100">
                        <th class="text-left py-2.5 pr-4 text-gray-500 font-medium w-40">Permission</th>
                        @foreach(['Manager','Staff','Teacher','Accountant'] as $role)
                        <th class="text-center py-2.5 px-3 text-gray-500 font-medium">{{ $role }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    @foreach([
                        'View Dashboard'          => [true, true, true, true],
                        'Manage Retreats'         => [true, false, false, false],
                        'Manage Bookings'         => [true, true, false, false],
                        'View Financials'         => [true, false, false, true],
                        'Manage Team'             => [true, false, false, false],
                        'Manage Settings'         => [true, false, false, false],
                        'Send Communications'     => [true, true, false, false],
                        'View Own Retreats'       => [true, true, true, false],
                    ] as $perm => $roles)
                    <tr>
                        <td class="py-2.5 pr-4 text-gray-700">{{ $perm }}</td>
                        @foreach($roles as $allowed)
                        <td class="text-center py-2.5 px-3">
                            @if($allowed)
                            <span class="text-wellness-500 text-base">✓</span>
                            @else
                            <span class="text-gray-200 text-base">✗</span>
                            @endif
                        </td>
                        @endforeach
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection
