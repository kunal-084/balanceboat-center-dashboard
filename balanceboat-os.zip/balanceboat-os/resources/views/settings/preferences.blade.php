@extends('layouts.app')

@section('title', 'Preferences')
@section('page-title', 'Settings')

@section('content')
<div class="space-y-6">

    @include('settings._nav', ['active' => 'preferences'])

    <x-alert />

    <form method="POST" action="{{ route('settings.preferences.update') }}" class="space-y-5">
        @csrf @method('PUT')

        {{-- Booking --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Booking Settings</h2>
            <div class="grid grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Default Currency</label>
                    <select name="default_currency"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                        @foreach(['USD'=>'USD — US Dollar','EUR'=>'EUR — Euro','GBP'=>'GBP — British Pound','INR'=>'INR — Indian Rupee','AUD'=>'AUD — Australian Dollar','SGD'=>'SGD — Singapore Dollar'] as $code=>$label)
                        <option value="{{ $code }}" {{ $settings->get('default_currency','USD') === $code ? 'selected' : '' }}>
                            {{ $label }}
                        </option>
                        @endforeach
                    </select>
                </div>
                <x-form-input name="default_deposit_percent" label="Default Deposit (%)" type="number"
                    :value="$settings->get('default_deposit_percent', 25)"
                    hint="Applied when creating new retreats" />
                <x-form-input name="booking_hold_hours" label="Booking Hold (hours)" type="number"
                    :value="$settings->get('booking_hold_hours', 48)"
                    hint="How long a booking is held awaiting deposit" />
                <x-form-input name="cancellation_days" label="Free Cancellation (days before)" type="number"
                    :value="$settings->get('cancellation_days', 14)" />
                <div class="col-span-2 space-y-3">
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div>
                            <div class="text-sm font-medium text-gray-900">Instant Booking</div>
                            <div class="text-xs text-gray-400">Allow guests to book without approval</div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="instant_booking_enabled" value="1"
                                {{ $settings->get('instant_booking_enabled') ? 'checked' : '' }}
                                class="sr-only peer">
                            <div class="w-9 h-5 bg-gray-200 rounded-full peer-checked:bg-lavender-600 transition-colors"></div>
                            <div class="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform peer-checked:translate-x-4"></div>
                        </label>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div>
                            <div class="text-sm font-medium text-gray-900">Waitlist Mode</div>
                            <div class="text-xs text-gray-400">Accept waitlist registrations for full retreats</div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="waitlist_enabled" value="1"
                                {{ $settings->get('waitlist_enabled', true) ? 'checked' : '' }}
                                class="sr-only peer">
                            <div class="w-9 h-5 bg-gray-200 rounded-full peer-checked:bg-lavender-600 transition-colors"></div>
                            <div class="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform peer-checked:translate-x-4"></div>
                        </label>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div>
                            <div class="text-sm font-medium text-gray-900">Show Remaining Spots</div>
                            <div class="text-xs text-gray-400">Display "X spots left" on public listings</div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="show_remaining_spots" value="1"
                                {{ $settings->get('show_remaining_spots', true) ? 'checked' : '' }}
                                class="sr-only peer">
                            <div class="w-9 h-5 bg-gray-200 rounded-full peer-checked:bg-lavender-600 transition-colors"></div>
                            <div class="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform peer-checked:translate-x-4"></div>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        {{-- Notifications --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Notification Preferences</h2>
            <div class="space-y-3">
                @foreach([
                    ['key'=>'notify_new_inquiry','label'=>'New Inquiry','desc'=>'Receive an alert when a new inquiry arrives'],
                    ['key'=>'notify_new_booking','label'=>'New Booking','desc'=>'Receive an alert when a booking is confirmed'],
                    ['key'=>'notify_cancellation','label'=>'Cancellation','desc'=>'Alert when a booking is cancelled'],
                    ['key'=>'notify_payment','label'=>'Payment Received','desc'=>'Alert on each payment received'],
                    ['key'=>'notify_review','label'=>'New Review','desc'=>'Alert when a guest leaves a review'],
                    ['key'=>'notify_daily_summary','label'=>'Daily Summary','desc'=>'Morning email digest of yesterday\'s activity'],
                ] as $pref)
                <div class="flex items-center justify-between p-4 border border-gray-100 rounded-xl">
                    <div>
                        <div class="text-sm font-medium text-gray-900">{{ $pref['label'] }}</div>
                        <div class="text-xs text-gray-400 mt-0.5">{{ $pref['desc'] }}</div>
                    </div>
                    <div class="flex items-center gap-3">
                        <label class="flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer">
                            <input type="checkbox" name="{{ $pref['key'] }}_email" value="1"
                                {{ $settings->get($pref['key'].'_email', true) ? 'checked' : '' }}
                                class="w-3.5 h-3.5 text-lavender-600 rounded border-gray-300">
                            Email
                        </label>
                        <label class="flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer">
                            <input type="checkbox" name="{{ $pref['key'] }}_push" value="1"
                                {{ $settings->get($pref['key'].'_push', false) ? 'checked' : '' }}
                                class="w-3.5 h-3.5 text-lavender-600 rounded border-gray-300">
                            Push
                        </label>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Integrations --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Integrations</h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="p-4 border border-gray-100 rounded-xl">
                    <div class="flex items-center gap-3 mb-3">
                        <span class="text-2xl">💬</span>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">WhatsApp Business</div>
                            <div class="text-xs text-gray-400">Send automated messages via Meta API</div>
                        </div>
                    </div>
                    <x-form-input name="whatsapp_phone_number_id" label="Phone Number ID"
                        :value="$settings->get('whatsapp_phone_number_id')" placeholder="Meta WABA Phone Number ID" />
                    <x-form-input name="whatsapp_token" label="Access Token" type="password"
                        :value="$settings->get('whatsapp_token') ? '••••••••' : ''" placeholder="Bearer token" />
                </div>

                <div class="p-4 border border-gray-100 rounded-xl">
                    <div class="flex items-center gap-3 mb-3">
                        <span class="text-2xl">🤖</span>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">OpenAI</div>
                            <div class="text-xs text-gray-400">Powers the AI content assistant</div>
                        </div>
                    </div>
                    <x-form-input name="openai_api_key" label="API Key" type="password"
                        :value="$settings->get('openai_api_key') ? '••••••••' : ''" placeholder="sk-..." />
                </div>

                <div class="p-4 border border-gray-100 rounded-xl">
                    <div class="flex items-center gap-3 mb-3">
                        <span class="text-2xl">💳</span>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">Stripe</div>
                            <div class="text-xs text-gray-400">Accept card payments online</div>
                        </div>
                    </div>
                    <x-form-input name="stripe_publishable_key" label="Publishable Key"
                        :value="$settings->get('stripe_publishable_key')" placeholder="pk_live_..." />
                    <x-form-input name="stripe_secret_key" label="Secret Key" type="password"
                        :value="$settings->get('stripe_secret_key') ? '••••••••' : ''" placeholder="sk_live_..." />
                </div>

                <div class="p-4 border border-gray-100 rounded-xl">
                    <div class="flex items-center gap-3 mb-3">
                        <span class="text-2xl">📧</span>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">SMTP / Email</div>
                            <div class="text-xs text-gray-400">Transactional email sending</div>
                        </div>
                    </div>
                    <x-form-input name="mail_from_name" label="From Name" :value="$settings->get('mail_from_name', config('app.name'))" />
                    <x-form-input name="mail_from_address" label="From Email" type="email" :value="$settings->get('mail_from_address')" />
                </div>
            </div>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="px-6 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                Save Preferences
            </button>
        </div>
    </form>
</div>
@endsection
