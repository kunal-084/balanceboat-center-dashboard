@props([
    'id',
    'title'      => 'Confirm',
    'size'       => 'md',   {{-- sm | md | lg | xl | full --}}
    'footer'     => true,
])

@php
$widths = [
    'sm'   => 'max-w-sm',
    'md'   => 'max-w-lg',
    'lg'   => 'max-w-2xl',
    'xl'   => 'max-w-4xl',
    'full' => 'max-w-6xl',
];
$w = $widths[$size] ?? 'max-w-lg';
@endphp

<div
    x-data="{ open: false }"
    x-on:open-modal-{{ $id }}.window="open = true"
    x-on:close-modal-{{ $id }}.window="open = false"
    x-show="open"
    x-cloak
    class="fixed inset-0 z-50 flex items-center justify-center p-4"
    style="display:none;"
>
    {{-- Backdrop --}}
    <div
        class="absolute inset-0 bg-gray-900/50 backdrop-blur-sm"
        x-show="open"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        @click="open = false"
    ></div>

    {{-- Panel --}}
    <div
        class="relative w-full {{ $w }} bg-white rounded-2xl shadow-2xl shadow-gray-900/20 overflow-hidden"
        x-show="open"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 scale-95 translate-y-2"
        x-transition:enter-end="opacity-100 scale-100 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 scale-100"
        x-transition:leave-end="opacity-0 scale-95"
    >
        {{-- Header --}}
        <div class="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h3 class="font-semibold text-gray-900 text-lg">{{ $title }}</h3>
            <button @click="open = false" class="text-gray-400 hover:text-gray-600 transition-colors rounded-lg p-1">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>

        {{-- Body --}}
        <div class="px-6 py-5 overflow-y-auto max-h-[70vh]">
            {{ $slot }}
        </div>

        {{-- Footer --}}
        @if($footer && isset($footerSlot))
        <div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
            {{ $footerSlot }}
        </div>
        @endif
    </div>
</div>
