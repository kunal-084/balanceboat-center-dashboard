@props([
    'type'        => 'info',   {{-- success | error | warning | info --}}
    'title'       => null,
    'dismissible' => true,
])

@php
$styles = [
    'success' => ['bg' => 'bg-wellness-50', 'border' => 'border-wellness-200', 'text' => 'text-wellness-800', 'icon_color' => 'text-wellness-500',
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>'],
    'error'   => ['bg' => 'bg-red-50', 'border' => 'border-red-200', 'text' => 'text-red-800', 'icon_color' => 'text-red-500',
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>'],
    'warning' => ['bg' => 'bg-amber-50', 'border' => 'border-amber-200', 'text' => 'text-amber-800', 'icon_color' => 'text-amber-500',
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>'],
    'info'    => ['bg' => 'bg-blue-50', 'border' => 'border-blue-200', 'text' => 'text-blue-800', 'icon_color' => 'text-blue-500',
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>'],
];
$s = $styles[$type] ?? $styles['info'];
@endphp

@if(session('success') || session('error') || session('warning') || session('info') || isset($slot) && $slot->isNotEmpty())
<div
    x-data="{ show: true }"
    x-show="show"
    x-transition:leave="transition ease-in duration-200"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    class="rounded-xl border p-4 {{ $s['bg'] }} {{ $s['border'] }} {{ $s['text'] }}"
    role="alert"
>
    <div class="flex items-start gap-3">
        <svg class="w-5 h-5 {{ $s['icon_color'] }} flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
            {!! $s['icon'] !!}
        </svg>
        <div class="flex-1 text-sm">
            @if($title)
            <p class="font-semibold mb-0.5">{{ $title }}</p>
            @endif

            @if(session($type))
                {{ session($type) }}
            @else
                {{ $slot }}
            @endif
        </div>
        @if($dismissible)
        <button @click="show = false" class="text-current opacity-50 hover:opacity-100 transition-opacity ml-2">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>
        @endif
    </div>
</div>
@endif

{{-- Auto-render session alerts --}}
@foreach(['success', 'error', 'warning', 'info'] as $sessionType)
    @if(session($sessionType))
    @php $sStyle = $styles[$sessionType]; @endphp
    <div
        x-data="{ show: true }"
        x-show="show"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="rounded-xl border p-4 {{ $sStyle['bg'] }} {{ $sStyle['border'] }} {{ $sStyle['text'] }} mb-3"
        role="alert"
    >
        <div class="flex items-start gap-3">
            <svg class="w-5 h-5 {{ $sStyle['icon_color'] }} flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                {!! $sStyle['icon'] !!}
            </svg>
            <p class="flex-1 text-sm">{{ session($sessionType) }}</p>
            <button @click="show = false" class="text-current opacity-50 hover:opacity-100 transition-opacity">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>
    </div>
    @endif
@endforeach
