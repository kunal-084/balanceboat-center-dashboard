@props([
    'experience',
    'batches'      => collect(),
    'showPromo'    => true,
    'showRooms'    => true,
    'submitLabel'  => 'Book Now',
    'submitRoute'  => null,
])

<div
    x-data="pricingWidget({{ $experience->id }})"
    class="bg-white rounded-2xl border border-gray-100 shadow-md p-6 sticky top-5"
>
    {{-- Base Price --}}
    <div class="mb-5">
        <div class="text-xs text-gray-400 mb-1">Starting from</div>
        <div class="flex items-end gap-2">
            <span class="text-3xl font-bold text-gray-900" x-text="'$' + total.toLocaleString()">
                ${{ number_format($experience->base_price, 0) }}
            </span>
            <span class="text-sm text-gray-400 mb-0.5">/ person</span>
        </div>
        <div class="text-xs text-gray-400 mt-0.5">
            {{ $experience->duration_days }} days · includes accommodation &amp; meals
        </div>
    </div>

    {{-- Batch Selector --}}
    @if($batches->count())
    <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1.5">Select Dates</label>
        <select x-model="batchId" @change="recalculate()"
            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
            <option value="">— Choose batch —</option>
            @foreach($batches as $batch)
            <option value="{{ $batch->id }}"
                    {{ $batch->spots_available <= 0 ? 'disabled' : '' }}>
                {{ $batch->start_date->format('d M') }} – {{ $batch->end_date->format('d M Y') }}
                @if($batch->spots_available > 0)
                  · {{ $batch->spots_available }} spots
                @else
                  · Full
                @endif
            </option>
            @endforeach
        </select>
    </div>
    @endif

    {{-- Participants --}}
    <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1.5">Participants</label>
        <div class="flex items-center border border-gray-200 rounded-xl overflow-hidden">
            <button type="button" @click="participants = Math.max(1, participants-1); recalculate()"
                    class="px-4 py-2.5 text-gray-500 hover:bg-gray-50 hover:text-gray-700 transition-colors text-lg font-medium">
                −
            </button>
            <span class="flex-1 text-center text-sm font-semibold text-gray-900" x-text="participants">1</span>
            <button type="button" @click="participants = Math.min({{ $experience->max_capacity }}, participants+1); recalculate()"
                    class="px-4 py-2.5 text-gray-500 hover:bg-gray-50 hover:text-gray-700 transition-colors text-lg font-medium">
                +
            </button>
        </div>
    </div>

    {{-- Room Type --}}
    @if($showRooms && $experience->roomTypes->count())
    <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1.5">Room Type</label>
        <div class="space-y-2">
            @foreach($experience->roomTypes as $room)
            <label class="flex items-start gap-3 p-3 border rounded-xl cursor-pointer hover:border-lavender-300 transition-colors"
                   :class="roomTypeId === {{ $room->id }} ? 'border-lavender-400 bg-lavender-50' : 'border-gray-200'">
                <input type="radio" name="room_type" value="{{ $room->id }}"
                    x-model="roomTypeId" @change="recalculate()" class="mt-0.5 text-lavender-600">
                <div class="flex-1">
                    <div class="text-sm font-medium text-gray-900">{{ $room->name }}</div>
                    <div class="text-xs text-gray-400">{{ $room->description }}</div>
                </div>
                @if($room->price_adjustment !== 0)
                <div class="text-xs font-semibold {{ $room->price_adjustment > 0 ? 'text-amber-600' : 'text-wellness-600' }} mt-0.5">
                    {{ $room->price_adjustment > 0 ? '+' : '' }}${{ number_format($room->price_adjustment, 0) }}
                </div>
                @endif
            </label>
            @endforeach
        </div>
    </div>
    @endif

    {{-- Promo Code --}}
    @if($showPromo)
    <div class="mb-5">
        <label class="block text-sm font-medium text-gray-700 mb-1.5">Promo Code</label>
        <div class="flex gap-2">
            <input type="text" x-model="promoCode" placeholder="Enter code"
                class="flex-1 px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
            <button type="button" @click="applyPromo()"
                    :disabled="!promoCode || applyingPromo"
                    class="px-4 py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-xl hover:bg-gray-200 disabled:opacity-50 transition-colors">
                Apply
            </button>
        </div>
        <div x-show="promoMessage" class="mt-1.5 text-xs"
             :class="promoValid ? 'text-wellness-600' : 'text-red-500'"
             x-text="promoMessage"></div>
    </div>
    @endif

    {{-- Price Breakdown --}}
    <div class="bg-gray-50 rounded-xl p-4 mb-5 space-y-2">
        <div class="flex justify-between text-sm">
            <span class="text-gray-500">
                $<span x-text="unitPrice">{{ number_format($experience->base_price, 0) }}</span>
                × <span x-text="participants">1</span>
            </span>
            <span x-text="'$' + subtotal.toLocaleString()"></span>
        </div>
        <div x-show="roomAdjustment !== 0" class="flex justify-between text-sm">
            <span class="text-gray-500">Room upgrade</span>
            <span x-text="(roomAdjustment > 0 ? '+' : '') + '$' + Math.abs(roomAdjustment)"></span>
        </div>
        <div x-show="discount > 0" class="flex justify-between text-sm text-wellness-600">
            <span>Promo discount</span>
            <span x-text="'−$' + discount.toLocaleString()"></span>
        </div>
        <div class="border-t border-gray-200 pt-2 flex justify-between text-sm font-bold text-gray-900">
            <span>Total</span>
            <span x-text="'$' + total.toLocaleString()"></span>
        </div>
        <div class="flex justify-between text-xs text-gray-400">
            <span>Deposit due today ({{ $experience->deposit_percent ?? 25 }}%)</span>
            <span x-text="'$' + deposit.toLocaleString()"></span>
        </div>
    </div>

    {{-- CTA --}}
    @if($submitRoute)
    <form method="GET" action="{{ $submitRoute }}">
        <input type="hidden" name="experience_id" value="{{ $experience->id }}">
        <input type="hidden" name="batch_id"      x-model="batchId">
        <input type="hidden" name="participants"   x-model="participants">
        <input type="hidden" name="room_type_id"  x-model="roomTypeId">
        <input type="hidden" name="promo_code"    x-model="promoCode">
        <button type="submit"
                class="w-full py-3.5 bg-gradient-to-r from-lavender-600 to-violet-600 text-white text-sm font-bold rounded-xl
                       hover:from-lavender-700 hover:to-violet-700 transition-all shadow-lg shadow-lavender-200">
            {{ $submitLabel }}
        </button>
    </form>
    @else
    <button type="button" class="w-full py-3.5 bg-gradient-to-r from-lavender-600 to-violet-600 text-white text-sm font-bold rounded-xl
                   hover:from-lavender-700 hover:to-violet-700 transition-all shadow-lg shadow-lavender-200">
        {{ $submitLabel }}
    </button>
    @endif

    <p class="text-center text-xs text-gray-400 mt-3">
        🔒 Secure booking · Free cancellation up to {{ $experience->cancellation_days ?? 14 }} days before
    </p>
</div>

@push('scripts')
<script>
function pricingWidget(experienceId) {
    return {
        experienceId,
        batchId:       '',
        participants:  1,
        roomTypeId:    null,
        promoCode:     '',
        promoMessage:  '',
        promoValid:    false,
        applyingPromo: false,

        unitPrice:     {{ $experience->base_price }},
        roomAdjustment: 0,
        discount:      0,

        get subtotal()  { return (this.unitPrice + this.roomAdjustment) * this.participants; },
        get total()     { return Math.max(0, this.subtotal - this.discount); },
        get deposit()   { return Math.round(this.total * ({{ $experience->deposit_percent ?? 25 }} / 100)); },

        async recalculate() {
            try {
                const res = await fetch('/api/pricing/calculate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
                    body: JSON.stringify({
                        experience_id:  this.experienceId,
                        batch_id:       this.batchId,
                        participants:   this.participants,
                        room_type_id:   this.roomTypeId,
                        promo_code:     this.promoCode,
                    }),
                });
                const data = await res.json();
                if (data.unit_price !== undefined) {
                    this.unitPrice      = data.unit_price;
                    this.roomAdjustment = data.room_adjustment ?? 0;
                    this.discount       = data.discount ?? 0;
                }
            } catch {}
        },

        async applyPromo() {
            this.applyingPromo = true;
            await this.recalculate();
            this.promoValid    = this.discount > 0;
            this.promoMessage  = this.discount > 0
                ? `Code applied — saving $${this.discount.toLocaleString()}!`
                : 'Invalid or expired promo code.';
            this.applyingPromo = false;
        },
    };
}
</script>
@endpush
