@props(['status', 'size' => 'sm'])

@php
$map = [
    // Booking statuses
    'pending'     => ['label' => 'Pending',    'bg' => 'bg-amber-50',    'text' => 'text-amber-700',   'dot' => 'bg-amber-400'],
    'confirmed'   => ['label' => 'Confirmed',  'bg' => 'bg-lavender-50', 'text' => 'text-lavender-700','dot' => 'bg-lavender-500'],
    'checked_in'  => ['label' => 'Checked In', 'bg' => 'bg-wellness-50', 'text' => 'text-wellness-600','dot' => 'bg-wellness-500'],
    'completed'   => ['label' => 'Completed',  'bg' => 'bg-indigo-50',   'text' => 'text-indigo-700',  'dot' => 'bg-indigo-500'],
    'cancelled'   => ['label' => 'Cancelled',  'bg' => 'bg-red-50',      'text' => 'text-red-600',     'dot' => 'bg-red-400'],
    'refunded'    => ['label' => 'Refunded',   'bg' => 'bg-gray-100',    'text' => 'text-gray-600',    'dot' => 'bg-gray-400'],
    // Experience statuses
    'draft'       => ['label' => 'Draft',      'bg' => 'bg-gray-100',    'text' => 'text-gray-600',    'dot' => 'bg-gray-400'],
    'published'   => ['label' => 'Published',  'bg' => 'bg-wellness-50', 'text' => 'text-wellness-600','dot' => 'bg-wellness-500'],
    'archived'    => ['label' => 'Archived',   'bg' => 'bg-gray-100',    'text' => 'text-gray-500',    'dot' => 'bg-gray-300'],
    // Inquiry statuses
    'new'         => ['label' => 'New',        'bg' => 'bg-blue-50',     'text' => 'text-blue-700',    'dot' => 'bg-blue-500'],
    'replied'     => ['label' => 'Replied',    'bg' => 'bg-teal-50',     'text' => 'text-teal-700',    'dot' => 'bg-teal-500'],
    'converted'   => ['label' => 'Converted',  'bg' => 'bg-wellness-50', 'text' => 'text-wellness-600','dot' => 'bg-wellness-500'],
    'closed'      => ['label' => 'Closed',     'bg' => 'bg-gray-100',    'text' => 'text-gray-500',    'dot' => 'bg-gray-300'],
    // Generic
    'active'      => ['label' => 'Active',     'bg' => 'bg-wellness-50', 'text' => 'text-wellness-600','dot' => 'bg-wellness-500'],
    'inactive'    => ['label' => 'Inactive',   'bg' => 'bg-gray-100',    'text' => 'text-gray-500',    'dot' => 'bg-gray-300'],
];

$style = $map[strtolower($status)] ?? ['label' => ucfirst($status), 'bg' => 'bg-gray-100', 'text' => 'text-gray-600', 'dot' => 'bg-gray-400'];
$padding = $size === 'xs' ? 'px-1.5 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';
@endphp

<span class="inline-flex items-center gap-1.5 {{ $padding }} {{ $style['bg'] }} {{ $style['text'] }} rounded-full font-medium">
    <span class="w-1.5 h-1.5 rounded-full {{ $style['dot'] }} flex-shrink-0"></span>
    {{ $style['label'] }}
</span>
