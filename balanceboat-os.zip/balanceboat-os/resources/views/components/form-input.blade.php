@props([
    'label'       => null,
    'name',
    'type'        => 'text',
    'placeholder' => '',
    'required'    => false,
    'hint'        => null,
    'value'       => null,
    'rows'        => 4,         {{-- only for textarea --}}
    'options'     => [],        {{-- for select: ['value' => 'label', ...] --}}
    'selected'    => null,      {{-- for select/radio --}}
    'prefix'      => null,      {{-- icon/text prefix --}}
    'suffix'      => null,      {{-- icon/text suffix --}}
])

@php
$hasError = $errors->has($name);
$baseClass = 'w-full px-3 py-2.5 text-sm border rounded-xl outline-none transition-all duration-150 bg-white';
$normalBorder = 'border-gray-200 focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100';
$errorBorder  = 'border-red-400 focus:border-red-400 focus:ring-2 focus:ring-red-100 bg-red-50';
$borderClass  = $hasError ? $errorBorder : $normalBorder;
$hasPrefix    = (bool) $prefix;
$hasSuffix    = (bool) $suffix;
@endphp

<div class="w-full">
    @if($label)
    <label for="{{ $name }}" class="block text-sm font-medium text-gray-700 mb-1.5">
        {{ $label }}
        @if($required)<span class="text-red-500 ml-0.5">*</span>@endif
    </label>
    @endif

    <div class="relative">
        @if($hasPrefix)
        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400 text-sm">
            {!! $prefix !!}
        </div>
        @endif

        @if($type === 'textarea')
            <textarea
                id="{{ $name }}"
                name="{{ $name }}"
                rows="{{ $rows }}"
                placeholder="{{ $placeholder }}"
                {{ $required ? 'required' : '' }}
                {{ $attributes->merge(['class' => $baseClass . ' ' . $borderClass . ' resize-none' . ($hasPrefix ? ' pl-9' : '') . ($hasSuffix ? ' pr-9' : '')]) }}
            >{{ old($name, $value) }}</textarea>

        @elseif($type === 'select')
            <select
                id="{{ $name }}"
                name="{{ $name }}"
                {{ $required ? 'required' : '' }}
                {{ $attributes->merge(['class' => $baseClass . ' ' . $borderClass . ' cursor-pointer' . ($hasPrefix ? ' pl-9' : '')]) }}
            >
                @if($placeholder)
                    <option value="">{{ $placeholder }}</option>
                @endif
                @foreach($options as $optVal => $optLabel)
                    <option value="{{ $optVal }}" {{ (old($name, $selected) == $optVal) ? 'selected' : '' }}>
                        {{ $optLabel }}
                    </option>
                @endforeach
            </select>

        @else
            <input
                id="{{ $name }}"
                name="{{ $name }}"
                type="{{ $type }}"
                value="{{ old($name, $value) }}"
                placeholder="{{ $placeholder }}"
                {{ $required ? 'required' : '' }}
                {{ $attributes->merge(['class' => $baseClass . ' ' . $borderClass . ($hasPrefix ? ' pl-9' : '') . ($hasSuffix ? ' pr-9' : '')]) }}
            >
        @endif

        @if($hasSuffix)
        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-gray-400 text-sm">
            {!! $suffix !!}
        </div>
        @endif
    </div>

    @if($hint && !$hasError)
    <p class="mt-1.5 text-xs text-gray-400">{{ $hint }}</p>
    @endif

    @error($name)
    <p class="mt-1.5 text-xs text-red-600 flex items-center gap-1">
        <svg class="w-3.5 h-3.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
        </svg>
        {{ $message }}
    </p>
    @enderror
</div>
