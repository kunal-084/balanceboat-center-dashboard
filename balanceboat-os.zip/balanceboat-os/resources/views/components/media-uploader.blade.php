@props([
    'name'      => 'media',
    'accept'    => 'image/*',
    'multiple'  => true,
    'maxMb'     => 10,
    'label'     => 'Drop files here or click to upload',
    'endpoint'  => null,  {{-- AJAX upload URL --}}
])

<div
    x-data="mediaUploader('{{ $name }}', '{{ $endpoint ?? route('media.upload') }}', {{ $multiple ? 'true' : 'false' }}, {{ $maxMb }})"
    class="w-full"
>
    {{-- Drop Zone --}}
    <div
        @dragover.prevent="dragging = true"
        @dragleave.prevent="dragging = false"
        @drop.prevent="handleDrop($event)"
        @click="$refs.fileInput.click()"
        :class="dragging ? 'border-lavender-400 bg-lavender-50' : 'border-gray-200 bg-gray-50 hover:border-lavender-300 hover:bg-lavender-50/50'"
        class="relative border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200"
    >
        <input
            type="file"
            name="{{ $name }}{{ $multiple ? '[]' : '' }}"
            x-ref="fileInput"
            @change="handleFiles($event.target.files)"
            accept="{{ $accept }}"
            {{ $multiple ? 'multiple' : '' }}
            class="sr-only"
        >

        <div x-show="!files.length">
            <div class="w-12 h-12 bg-lavender-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                <svg class="w-6 h-6 text-lavender-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"/>
                </svg>
            </div>
            <p class="text-sm font-medium text-gray-700">{{ $label }}</p>
            <p class="text-xs text-gray-400 mt-1">Max {{ $maxMb }}MB per file · {{ str_replace('/*', '', $accept) }}</p>
        </div>

        {{-- Preview Grid --}}
        <div x-show="files.length" @click.stop class="grid grid-cols-3 sm:grid-cols-4 gap-3 text-left">
            <template x-for="(file, idx) in files" :key="idx">
                <div class="relative group rounded-xl overflow-hidden border border-gray-200 aspect-square bg-white">
                    <img x-show="file.preview" :src="file.preview" class="w-full h-full object-cover">
                    <div x-show="!file.preview" class="w-full h-full flex items-center justify-center bg-gray-100">
                        <svg class="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </div>

                    {{-- Progress Bar --}}
                    <div x-show="file.progress < 100" class="absolute bottom-0 left-0 right-0 h-1 bg-gray-200">
                        <div class="h-full bg-lavender-500 transition-all" :style="`width:${file.progress}%`"></div>
                    </div>

                    {{-- Remove Button --}}
                    <button
                        @click.stop="removeFile(idx)"
                        class="absolute top-1 right-1 w-5 h-5 bg-red-500 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                        type="button"
                    >
                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>

                    <p class="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[10px] px-1.5 py-1 truncate" x-text="file.name"></p>
                </div>
            </template>

            {{-- Add More --}}
            @if($multiple)
            <div
                @click="$refs.fileInput.click()"
                class="aspect-square rounded-xl border-2 border-dashed border-gray-200 flex items-center justify-center cursor-pointer hover:border-lavender-300 hover:bg-lavender-50 transition-all"
            >
                <svg class="w-6 h-6 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                </svg>
            </div>
            @endif
        </div>
    </div>

    {{-- Error Messages --}}
    <div x-show="errors.length" class="mt-2 space-y-1">
        <template x-for="err in errors" :key="err">
            <p class="text-xs text-red-600 flex items-center gap-1">
                <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                </svg>
                <span x-text="err"></span>
            </p>
        </template>
    </div>
</div>

<script>
function mediaUploader(fieldName, endpoint, multiple, maxMb) {
    return {
        files: [],
        dragging: false,
        errors: [],

        handleFiles(fileList) {
            this.errors = [];
            const newFiles = Array.from(fileList);
            for (const f of newFiles) {
                if (f.size > maxMb * 1024 * 1024) {
                    this.errors.push(`"${f.name}" exceeds ${maxMb}MB limit`);
                    continue;
                }
                const entry = { name: f.name, progress: 0, preview: null, id: null };
                if (f.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = e => entry.preview = e.target.result;
                    reader.readAsDataURL(f);
                }
                this.files.push(entry);
                this.upload(f, this.files.length - 1);
            }
        },

        handleDrop(e) {
            this.dragging = false;
            this.handleFiles(e.dataTransfer.files);
        },

        removeFile(idx) {
            this.files.splice(idx, 1);
        },

        async upload(file, idx) {
            const fd = new FormData();
            fd.append('file', file);
            fd.append('_token', document.querySelector('meta[name=csrf-token]').content);
            try {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', endpoint);
                xhr.upload.onprogress = e => {
                    if (e.lengthComputable) this.files[idx].progress = Math.round(e.loaded / e.total * 100);
                };
                xhr.onload = () => {
                    const res = JSON.parse(xhr.responseText);
                    if (res.id) this.files[idx].id = res.id;
                    this.files[idx].progress = 100;
                };
                xhr.send(fd);
            } catch(e) {
                this.errors.push(`Upload failed for "${file.name}"`);
            }
        }
    };
}
</script>
