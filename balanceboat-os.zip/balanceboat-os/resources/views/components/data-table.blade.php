@props([
    'columns'     => [],   {{-- [['key'=>'name','label'=>'Name','sortable'=>true,'class'=>''], ...] --}}
    'sortBy'      => null,
    'sortDir'     => 'asc',
    'emptyText'   => 'No records found.',
    'emptyIcon'   => '📋',
    'loading'     => false,
    'striped'     => false,
    'compact'     => false,
])

@php
$cellPad = $compact ? 'px-4 py-2.5' : 'px-5 py-3.5';
@endphp

<div class="bg-white rounded-2xl border border-gray-100 overflow-hidden">
    {{-- Table Header Slot (search / filters / actions) --}}
    @if(isset($header))
    <div class="px-5 py-4 border-b border-gray-50 flex items-center justify-between gap-4 flex-wrap">
        {{ $header }}
    </div>
    @endif

    {{-- Table --}}
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-gray-100 bg-gray-50/50">
                    @foreach($columns as $col)
                    <th class="{{ $cellPad }} text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap {{ $col['class'] ?? '' }}">
                        @if(($col['sortable'] ?? false))
                            <a href="{{ request()->fullUrlWithQuery(['sort' => $col['key'], 'dir' => ($sortBy === $col['key'] && $sortDir === 'asc') ? 'desc' : 'asc']) }}"
                               class="flex items-center gap-1 hover:text-lavender-600 transition-colors">
                                {{ $col['label'] }}
                                <span class="flex flex-col">
                                    <svg class="w-2.5 h-2.5 {{ $sortBy === $col['key'] && $sortDir === 'asc' ? 'text-lavender-600' : 'text-gray-300' }}" fill="currentColor" viewBox="0 0 10 6"><path d="M0 6l5-6 5 6z"/></svg>
                                    <svg class="w-2.5 h-2.5 {{ $sortBy === $col['key'] && $sortDir === 'desc' ? 'text-lavender-600' : 'text-gray-300' }}" fill="currentColor" viewBox="0 0 10 6"><path d="M0 0l5 6 5-6z"/></svg>
                                </span>
                            </a>
                        @else
                            {{ $col['label'] }}
                        @endif
                    </th>
                    @endforeach
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                @if($loading)
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        @foreach($columns as $_)
                        <td class="{{ $cellPad }}">
                            <div class="h-4 bg-gray-100 rounded animate-pulse w-3/4"></div>
                        </td>
                        @endforeach
                    </tr>
                    @endfor
                @else
                    {{ $slot }}
                @endif
            </tbody>
        </table>
    </div>

    {{-- Empty State --}}
    @if(!$loading && isset($empty))
    {{ $empty }}
    @elseif(!$loading)
    <div class="py-16 text-center" x-show="$el.previousElementSibling.querySelector('tbody').children.length === 0">
        <div class="text-4xl mb-3">{{ $emptyIcon }}</div>
        <p class="text-gray-400 text-sm">{{ $emptyText }}</p>
    </div>
    @endif

    {{-- Pagination --}}
    @if(isset($pagination))
    <div class="px-5 py-4 border-t border-gray-50">
        {{ $pagination }}
    </div>
    @endif
</div>
