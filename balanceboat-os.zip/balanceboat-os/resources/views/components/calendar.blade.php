@props([
    'batches'     => collect(),
    'month'       => null,
    'year'        => null,
    'interactive' => false,
    'onSelect'    => null,
])

@php
    $now    = now();
    $month  = (int) ($month ?? $now->month);
    $year   = (int) ($year  ?? $now->year);
    $start  = \Carbon\Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $end    = $start->copy()->endOfMonth();
    $cursor = $start->copy()->startOfWeek(\Carbon\Carbon::MONDAY);

    // Index batches by date range for fast lookup
    $dateMap = [];
    foreach ($batches as $batch) {
        $s = \Carbon\Carbon::parse($batch->start_date);
        $e = \Carbon\Carbon::parse($batch->end_date);
        while ($s <= $e) {
            $key = $s->format('Y-m-d');
            $dateMap[$key][] = $batch;
            $s->addDay();
        }
    }
@endphp

<div
    x-data="{
        month: {{ $month }},
        year:  {{ $year }},
        selected: null,
        navigate(delta) {
            let d = new Date(this.year, this.month - 1 + delta, 1);
            this.month = d.getMonth() + 1;
            this.year  = d.getFullYear();
            this.$dispatch('calendar-navigate', { month: this.month, year: this.year });
        },
    }"
    class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 w-full select-none"
>
    {{-- Header --}}
    <div class="flex items-center justify-between mb-4">
        <button @click="navigate(-1)" class="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
            </svg>
        </button>
        <span class="text-sm font-semibold text-gray-900">
            {{ $start->format('F Y') }}
        </span>
        <button @click="navigate(1)" class="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
            </svg>
        </button>
    </div>

    {{-- Day headers --}}
    <div class="grid grid-cols-7 mb-1">
        @foreach(['Mo','Tu','We','Th','Fr','Sa','Su'] as $day)
        <div class="text-center text-[10px] font-semibold text-gray-400 py-1">{{ $day }}</div>
        @endforeach
    </div>

    {{-- Cells --}}
    <div class="grid grid-cols-7 gap-px">
        @while($cursor <= $end->copy()->endOfWeek(\Carbon\Carbon::SUNDAY))
        @php
            $key        = $cursor->format('Y-m-d');
            $isToday    = $cursor->isToday();
            $isThisMonth = $cursor->month === $month;
            $batchesHere = $dateMap[$key] ?? [];
            $hasBatch   = count($batchesHere) > 0;
            $isFull     = $hasBatch && collect($batchesHere)->every(fn($b) => ($b->spots_available ?? 1) === 0);
            $isStart    = $hasBatch && collect($batchesHere)->some(fn($b) => \Carbon\Carbon::parse($b->start_date)->isSameDay($cursor));
            $isEnd      = $hasBatch && collect($batchesHere)->some(fn($b) => \Carbon\Carbon::parse($b->end_date)->isSameDay($cursor));
            $day        = $cursor->day;
        @endphp
        <div
            class="relative text-center py-2 text-xs transition-all cursor-default
                {{ !$isThisMonth ? 'opacity-30' : '' }}
                {{ $isToday ? 'font-bold' : '' }}
                {{ $hasBatch && !$isFull ? 'bg-lavender-50' : '' }}
                {{ $hasBatch && $isFull  ? 'bg-gray-100' : '' }}
                {{ $isStart ? 'rounded-l-full' : '' }}
                {{ $isEnd   ? 'rounded-r-full' : '' }}
                {{ $interactive && $isThisMonth ? 'hover:bg-lavender-100 cursor-pointer' : '' }}
            "
            @if($interactive && $isThisMonth && $hasBatch)
            @click="selected = '{{ $key }}'; $dispatch('calendar-select', { date: '{{ $key }}', batches: {{ json_encode($batchesHere) }} })"
            title="{{ count($batchesHere) }} batch(es)"
            @endif
        >
            <span class="relative z-10 inline-flex w-6 h-6 items-center justify-center mx-auto rounded-full
                {{ $isToday ? 'bg-lavender-600 text-white' : ($isThisMonth ? 'text-gray-800' : 'text-gray-300') }}">
                {{ $day }}
            </span>
            @if($hasBatch && !$isToday)
            <span class="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full
                {{ $isFull ? 'bg-gray-400' : 'bg-lavender-500' }}"></span>
            @endif
        </div>
        @php $cursor->addDay() @endphp
        @endwhile
    </div>

    {{-- Legend --}}
    <div class="mt-4 flex items-center gap-4 text-[10px] text-gray-400">
        <span class="flex items-center gap-1">
            <span class="w-2.5 h-2.5 rounded-full bg-lavender-500 inline-block"></span>
            Available
        </span>
        <span class="flex items-center gap-1">
            <span class="w-2.5 h-2.5 rounded-full bg-gray-400 inline-block"></span>
            Full
        </span>
        <span class="flex items-center gap-1">
            <span class="w-5 h-5 rounded-full bg-lavender-600 inline-block flex items-center justify-center text-white" style="font-size:9px">●</span>
            Today
        </span>
    </div>
</div>
