@props([
    'label',
    'value',
    'icon'    => '📊',
    'change'  => null,
    'trend'   => 'up',
    'sub'     => null,
    'href'    => null,
    'color'   => 'lavender',
])

@php
$trendUp = $trend === 'up';
$trendBg   = $trendUp ? 'bg-wellness-50' : 'bg-red-50';
$trendText = $trendUp ? 'text-wellness-600' : 'text-red-600';
$arrow     = $trendUp ? '↑' : '↓';
@endphp

<div @class([
    'bg-white rounded-2xl p-5 border border-gray-100 transition-all duration-300',
    'hover:shadow-lg hover:shadow-lavender-100/50 cursor-pointer' => $href,
]) {{ $href ? "onclick=window.location='$href'" : '' }}>
    <div class="flex items-start justify-between mb-3">
        <div class="text-2xl leading-none">{{ $icon }}</div>
        @if($change)
        <span class="text-xs font-medium px-2 py-0.5 rounded-full {{ $trendBg }} {{ $trendText }}">
            {{ $arrow }} {{ $change }}
        </span>
        @endif
    </div>
    <div class="font-serif text-2xl font-bold text-gray-900 mb-0.5">{{ $value }}</div>
    <div class="text-xs text-gray-500">{{ $label }}</div>
    @if($sub)
    <div class="text-xs text-gray-400 mt-0.5">{{ $sub }}</div>
    @endif
</div>
