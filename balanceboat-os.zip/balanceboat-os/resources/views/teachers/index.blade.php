@extends('layouts.app')

@section('title', 'Teachers')
@section('page-title', 'Teachers')

@section('content')
<div class="space-y-6">

    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Manage your teachers and wellness practitioners</p>
        <a href="{{ route('teachers.create') }}"
           class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-semibold hover:bg-lavender-700 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            Add Teacher
        </a>
    </div>

    <x-alert />

    {{-- Filters --}}
    <form method="GET" action="{{ route('teachers.index') }}" class="flex items-center gap-3 flex-wrap">
        <div class="relative flex-1 min-w-[200px]">
            <input type="text" name="search" value="{{ request('search') }}"
                placeholder="Search teachers..."
                class="w-full pl-9 pr-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white">
            <svg class="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 15.803 7.5 7.5 0 0016.803 15.803z"/>
            </svg>
        </div>
        <select name="specialty" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="">All Specialties</option>
            @foreach(['yoga','meditation','ayurveda','nutrition','sound healing','breathwork','reiki'] as $spec)
            <option value="{{ $spec }}" {{ request('specialty') === $spec ? 'selected' : '' }}>{{ ucfirst($spec) }}</option>
            @endforeach
        </select>
        <select name="is_active" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="">All</option>
            <option value="1" {{ request('is_active') === '1' ? 'selected' : '' }}>Active</option>
            <option value="0" {{ request('is_active') === '0' ? 'selected' : '' }}>Inactive</option>
        </select>
        <button type="submit" class="px-4 py-2.5 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700">Filter</button>
    </form>

    {{-- Teacher Grid --}}
    @if($teachers->count())
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        @foreach($teachers as $teacher)
        <div class="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg hover:shadow-lavender-100/50 transition-all duration-300 group">

            {{-- Avatar --}}
            <div class="relative h-36 bg-gradient-to-br from-lavender-100 to-peach-100 flex items-center justify-center">
                @if($teacher->avatar_url)
                <img src="{{ $teacher->avatar_url }}" alt="{{ $teacher->name }}"
                     class="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md">
                @else
                <div class="w-24 h-24 rounded-full bg-lavender-600 border-4 border-white shadow-md flex items-center justify-center text-3xl font-bold text-white">
                    {{ strtoupper(substr($teacher->name, 0, 1)) }}
                </div>
                @endif

                @if(!$teacher->is_active)
                <div class="absolute top-2 right-2 bg-red-100 text-red-600 text-[10px] font-bold px-2 py-0.5 rounded-full">Inactive</div>
                @endif
            </div>

            <div class="p-4">
                <h3 class="font-semibold text-gray-900 text-center mb-0.5">{{ $teacher->name }}</h3>
                @if($teacher->specialty)
                <p class="text-xs text-lavender-600 text-center font-medium mb-3">{{ ucfirst($teacher->specialty) }}</p>
                @endif

                @if($teacher->bio)
                <p class="text-xs text-gray-500 text-center line-clamp-2 mb-3">{{ $teacher->bio }}</p>
                @endif

                <div class="grid grid-cols-3 gap-2 text-center mb-4">
                    <div>
                        <div class="text-sm font-bold text-gray-900">{{ $teacher->retreats_count ?? 0 }}</div>
                        <div class="text-xs text-gray-400">Retreats</div>
                    </div>
                    <div>
                        <div class="text-sm font-bold text-gray-900">{{ $teacher->years_experience ?? 0 }}y</div>
                        <div class="text-xs text-gray-400">Experience</div>
                    </div>
                    <div>
                        <div class="text-sm font-bold text-gray-900">{{ number_format($teacher->avg_rating ?? 0, 1) }}</div>
                        <div class="text-xs text-gray-400">Rating</div>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <a href="{{ route('teachers.show', $teacher) }}"
                       class="flex-1 text-center py-2 text-xs font-medium border border-gray-200 text-gray-600 rounded-lg hover:border-lavender-200 hover:text-lavender-700 hover:bg-lavender-50 transition-colors">
                        View Profile
                    </a>
                    <a href="{{ route('teachers.edit', $teacher) }}"
                       class="flex-1 text-center py-2 text-xs font-medium bg-lavender-50 text-lavender-700 rounded-lg hover:bg-lavender-100 transition-colors">
                        Edit
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <div>{{ $teachers->withQueryString()->links() }}</div>

    @else
    <div class="bg-white rounded-2xl border border-gray-100 py-20 text-center">
        <div class="text-6xl mb-4">🧘</div>
        <h3 class="font-semibold text-gray-900 mb-2">No teachers yet</h3>
        <p class="text-gray-400 text-sm mb-6">Add your first teacher or practitioner to assign them to retreats.</p>
        <a href="{{ route('teachers.create') }}"
           class="inline-flex items-center gap-2 px-5 py-2.5 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700 transition-colors">
            Add Teacher
        </a>
    </div>
    @endif

</div>
@endsection
