@extends('layouts.app')

@section('title', $teacher->full_name)
@section('page-title', 'Teachers')

@section('content')
<div class="space-y-6">

    {{-- Breadcrumb --}}
    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('teachers.index') }}" class="hover:text-gray-600">Teachers</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">{{ $teacher->full_name }}</span>
    </nav>

    <div class="grid grid-cols-3 gap-6">

        {{-- Left Column --}}
        <div class="space-y-5">

            {{-- Profile Card --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 text-center">
                <img src="{{ $teacher->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($teacher->full_name).'&size=128&background=ede9fe&color=7c3aed' }}"
                     alt="{{ $teacher->full_name }}"
                     class="w-24 h-24 rounded-2xl object-cover mx-auto mb-4 shadow-sm">
                <h1 class="text-lg font-bold text-gray-900">{{ $teacher->full_name }}</h1>
                <p class="text-sm text-lavender-600 font-medium mt-0.5">{{ $teacher->specialty }}</p>
                <div class="mt-3">
                    <x-status-badge :status="$teacher->status" />
                    @if($teacher->featured)
                    <span class="ml-1.5 text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">⭐ Featured</span>
                    @endif
                </div>

                <div class="mt-4 flex justify-center gap-3">
                    <a href="{{ route('teachers.edit', $teacher) }}"
                       class="px-3.5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                        Edit Profile
                    </a>
                    <form method="POST" action="{{ route('teachers.toggle', $teacher) }}">
                        @csrf @method('PATCH')
                        <button type="submit"
                                class="px-3.5 py-2 text-sm font-medium border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                            {{ $teacher->status === 'active' ? 'Deactivate' : 'Activate' }}
                        </button>
                    </form>
                </div>
            </div>

            {{-- Contact --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Contact</h3>
                <div class="space-y-2 text-sm">
                    @if($teacher->email)
                    <div class="flex items-center gap-2 text-gray-600">
                        <svg class="w-4 h-4 text-gray-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"/>
                        </svg>
                        <a href="mailto:{{ $teacher->email }}" class="hover:text-lavender-600">{{ $teacher->email }}</a>
                    </div>
                    @endif
                    @if($teacher->phone)
                    <div class="flex items-center gap-2 text-gray-600">
                        <svg class="w-4 h-4 text-gray-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"/>
                        </svg>
                        <span>{{ $teacher->phone }}</span>
                    </div>
                    @endif
                    @if($teacher->website)
                    <div class="flex items-center gap-2">
                        <svg class="w-4 h-4 text-gray-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253"/>
                        </svg>
                        <a href="{{ $teacher->website }}" target="_blank" class="text-lavender-600 hover:underline truncate">
                            {{ parse_url($teacher->website, PHP_URL_HOST) }}
                        </a>
                    </div>
                    @endif
                </div>
            </div>

            {{-- Stats --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Stats</h3>
                <div class="space-y-3">
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Retreats Led</span>
                        <span class="font-semibold text-gray-900">{{ $teacher->experiences_count }}</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Total Guests</span>
                        <span class="font-semibold text-gray-900">{{ $stats['total_guests'] ?? 0 }}</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Avg Rating</span>
                        <span class="font-semibold text-gray-900">
                            {{ $stats['avg_rating'] ? number_format($stats['avg_rating'], 1).' ⭐' : '—' }}
                        </span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Member Since</span>
                        <span class="text-gray-900">{{ $teacher->created_at->format('M Y') }}</span>
                    </div>
                </div>
            </div>
        </div>

        {{-- Right: Main Content --}}
        <div class="col-span-2 space-y-5">

            {{-- Bio --}}
            @if($teacher->bio)
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h2 class="font-semibold text-gray-900 mb-3">About</h2>
                <p class="text-sm text-gray-600 leading-relaxed">{{ $teacher->bio }}</p>
                @if($teacher->teaching_style)
                <div class="mt-4 p-4 bg-lavender-50 rounded-xl">
                    <h3 class="text-xs font-semibold text-lavender-700 uppercase tracking-wide mb-2">Teaching Style</h3>
                    <p class="text-sm text-gray-600">{{ $teacher->teaching_style }}</p>
                </div>
                @endif
            </div>
            @endif

            {{-- Professional --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h2 class="font-semibold text-gray-900 mb-4">Professional Details</h2>
                <div class="grid grid-cols-3 gap-4">
                    <div class="bg-gray-50 rounded-xl p-4">
                        <div class="text-xs text-gray-400 mb-1">Experience</div>
                        <div class="text-sm font-semibold text-gray-900">{{ $teacher->experience_years ?? '—' }} years</div>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-4">
                        <div class="text-xs text-gray-400 mb-1">Teaching Since</div>
                        <div class="text-sm font-semibold text-gray-900">{{ $teacher->teaching_since ?? '—' }}</div>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-4">
                        <div class="text-xs text-gray-400 mb-1">Certifications</div>
                        <div class="text-sm font-semibold text-gray-900">{{ $teacher->certifications ?? '—' }}</div>
                    </div>
                </div>
            </div>

            {{-- Retreats --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="font-semibold text-gray-900">Assigned Retreats</h2>
                    <span class="text-xs text-gray-400">{{ $teacher->experiences->count() }} total</span>
                </div>
                @forelse($teacher->experiences as $exp)
                <div class="flex items-center gap-4 py-3 border-b border-gray-50 last:border-0">
                    @if($exp->thumbnail)
                    <img src="{{ $exp->thumbnail }}" alt="" class="w-12 h-12 rounded-xl object-cover shrink-0">
                    @else
                    <div class="w-12 h-12 rounded-xl bg-lavender-100 flex items-center justify-center text-xl shrink-0">🧘</div>
                    @endif
                    <div class="flex-1 min-w-0">
                        <a href="{{ route('retreats.show', $exp) }}" class="text-sm font-medium text-gray-900 hover:text-lavender-600 truncate block">
                            {{ $exp->title }}
                        </a>
                        <div class="text-xs text-gray-400 mt-0.5">{{ $exp->duration_days }} days · {{ $exp->location_name }}</div>
                    </div>
                    <x-status-badge :status="$exp->status" />
                </div>
                @empty
                <div class="text-center py-8">
                    <p class="text-gray-400 text-sm">Not assigned to any retreats yet.</p>
                    <a href="{{ route('retreats.index') }}" class="mt-2 inline-block text-sm text-lavender-600 hover:underline">
                        Assign to a retreat →
                    </a>
                </div>
                @endforelse
            </div>

            {{-- Reviews --}}
            @if($teacher->reviews->count())
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h2 class="font-semibold text-gray-900 mb-4">Guest Reviews</h2>
                <div class="space-y-4">
                    @foreach($teacher->reviews->take(3) as $review)
                    <div class="p-4 bg-gray-50 rounded-xl">
                        <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center gap-1">
                                @for($i=1;$i<=5;$i++)
                                <span class="text-sm {{ $i <= $review->rating ? 'text-amber-400' : 'text-gray-200' }}">★</span>
                                @endfor
                            </div>
                            <span class="text-xs text-gray-400">{{ $review->created_at->format('d M Y') }}</span>
                        </div>
                        <p class="text-sm text-gray-600">{{ $review->comment }}</p>
                        <p class="text-xs text-gray-400 mt-1">— {{ $review->guest_name }}</p>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection
