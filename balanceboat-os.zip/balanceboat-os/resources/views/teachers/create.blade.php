@extends('layouts.app')

@section('title', 'Add Teacher')
@section('page-title', 'Teachers')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">

    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('teachers.index') }}" class="hover:text-gray-600">Teachers</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">Add Teacher</span>
    </nav>

    <x-alert />

    <form method="POST" action="{{ route('teachers.store') }}" enctype="multipart/form-data" class="space-y-5">
        @csrf

        {{-- Basic Info --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Basic Information</h2>
            <div class="flex items-start gap-6">
                {{-- Avatar --}}
                <div class="shrink-0">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Profile Photo</label>
                    <div x-data="{ preview: null }" class="space-y-2">
                        <div class="w-24 h-24 rounded-2xl bg-lavender-100 border-2 border-dashed border-lavender-300 overflow-hidden flex items-center justify-center cursor-pointer hover:border-lavender-500 transition-colors"
                             onclick="document.getElementById('avatar-input').click()">
                            <template x-if="!preview">
                                <svg class="w-8 h-8 text-lavender-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                </svg>
                            </template>
                            <template x-if="preview">
                                <img :src="preview" class="w-full h-full object-cover">
                            </template>
                        </div>
                        <input id="avatar-input" type="file" name="avatar" accept="image/*" class="hidden"
                            @change="preview = URL.createObjectURL($event.target.files[0])">
                        <p class="text-xs text-gray-400 text-center">Click to upload</p>
                    </div>
                </div>

                {{-- Name Fields --}}
                <div class="flex-1 grid grid-cols-2 gap-4">
                    <x-form-input name="first_name" label="First Name" required :value="old('first_name')" />
                    <x-form-input name="last_name" label="Last Name" :value="old('last_name')" />
                    <x-form-input name="email" label="Email" type="email" required :value="old('email')"
                        hint="Used for portal access (optional)" />
                    <x-form-input name="phone" label="Phone / WhatsApp" :value="old('phone')" />
                </div>
            </div>
        </div>

        {{-- Professional --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Professional Details</h2>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="specialty" label="Primary Specialty" :value="old('specialty')"
                    placeholder="e.g. Hatha Yoga, Ayurveda, Sound Healing" />
                <x-form-input name="experience_years" label="Years of Experience" type="number" :value="old('experience_years')" />
                <x-form-input name="certifications" label="Certifications" :value="old('certifications')"
                    placeholder="RYT-500, BAMS, etc." />
                <x-form-input name="teaching_since" label="Teaching Since" type="number" :value="old('teaching_since', 2010)"
                    placeholder="Year" />
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Short Bio</label>
                    <textarea name="bio" rows="4"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y"
                        placeholder="A few sentences about the teacher's background, approach, and philosophy...">{{ old('bio') }}</textarea>
                </div>
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Teaching Style / Philosophy</label>
                    <textarea name="teaching_style" rows="3"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y"
                        placeholder="How does this teacher work with students?">{{ old('teaching_style') }}</textarea>
                </div>
            </div>
        </div>

        {{-- Social & Online --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Online Presence</h2>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="website" label="Website" :value="old('website')" placeholder="https://teacher-name.com" />
                <x-form-input name="instagram" label="Instagram Handle" :value="old('instagram')" placeholder="@username" />
                <x-form-input name="youtube" label="YouTube Channel" :value="old('youtube')" placeholder="https://youtube.com/..." />
                <x-form-input name="facebook" label="Facebook Profile" :value="old('facebook')" />
            </div>
        </div>

        {{-- Settings --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Profile Settings</h2>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <div class="space-y-2">
                        @foreach(['active'=>'Active — visible in listings','inactive'=>'Inactive — hidden from guests'] as $val=>$label)
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="radio" name="status" value="{{ $val }}"
                                {{ old('status','active') === $val ? 'checked' : '' }}
                                class="text-lavender-600 border-gray-300">
                            <span class="text-sm text-gray-700">{{ $label }}</span>
                        </label>
                        @endforeach
                    </div>
                </div>
                <div class="space-y-3">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="featured" value="1" {{ old('featured') ? 'checked' : '' }}
                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                        <span class="text-sm text-gray-700">Feature on homepage</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="invite_to_portal" value="1"
                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                        <span class="text-sm text-gray-700">Send portal invitation email</span>
                    </label>
                </div>
            </div>
        </div>

        <div class="flex justify-between items-center">
            <a href="{{ route('teachers.index') }}"
               class="px-4 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                Cancel
            </a>
            <button type="submit"
                    class="px-6 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                Add Teacher
            </button>
        </div>
    </form>
</div>
@endsection
