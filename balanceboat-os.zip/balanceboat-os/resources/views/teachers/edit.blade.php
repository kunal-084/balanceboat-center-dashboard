@extends('layouts.app')

@section('title', 'Edit Teacher')
@section('page-title', 'Teachers')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">

    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('teachers.index') }}" class="hover:text-gray-600">Teachers</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <a href="{{ route('teachers.show', $teacher) }}" class="hover:text-gray-600">{{ $teacher->full_name }}</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">Edit</span>
    </nav>

    <x-alert />

    <form method="POST" action="{{ route('teachers.update', $teacher) }}" enctype="multipart/form-data" class="space-y-5">
        @csrf
        @method('PUT')

        {{-- Basic Info --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Basic Information</h2>
            <div class="flex items-start gap-6">
                <div class="shrink-0" x-data="{ preview: '{{ $teacher->avatar_url }}' }">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Profile Photo</label>
                    <div class="w-24 h-24 rounded-2xl border-2 border-dashed border-lavender-300 overflow-hidden flex items-center justify-center cursor-pointer hover:border-lavender-500 transition-colors"
                         onclick="document.getElementById('avatar-edit').click()">
                        <template x-if="!preview">
                            <svg class="w-8 h-8 text-lavender-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                            </svg>
                        </template>
                        <template x-if="preview">
                            <img :src="preview" class="w-full h-full object-cover">
                        </template>
                    </div>
                    <input id="avatar-edit" type="file" name="avatar" accept="image/*" class="hidden"
                        @change="preview = URL.createObjectURL($event.target.files[0])">
                    <p class="text-xs text-gray-400 text-center mt-1">Click to change</p>
                </div>

                <div class="flex-1 grid grid-cols-2 gap-4">
                    <x-form-input name="first_name" label="First Name" required :value="old('first_name', $teacher->first_name)" />
                    <x-form-input name="last_name" label="Last Name" :value="old('last_name', $teacher->last_name)" />
                    <x-form-input name="email" label="Email" type="email" :value="old('email', $teacher->email)" />
                    <x-form-input name="phone" label="Phone / WhatsApp" :value="old('phone', $teacher->phone)" />
                </div>
            </div>
        </div>

        {{-- Professional --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Professional Details</h2>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="specialty" label="Primary Specialty" :value="old('specialty', $teacher->specialty)" />
                <x-form-input name="experience_years" label="Years of Experience" type="number" :value="old('experience_years', $teacher->experience_years)" />
                <x-form-input name="certifications" label="Certifications" :value="old('certifications', $teacher->certifications)" />
                <x-form-input name="teaching_since" label="Teaching Since" type="number" :value="old('teaching_since', $teacher->teaching_since)" />
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Short Bio</label>
                    <textarea name="bio" rows="4"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y">{{ old('bio', $teacher->bio) }}</textarea>
                </div>
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Teaching Style</label>
                    <textarea name="teaching_style" rows="3"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y">{{ old('teaching_style', $teacher->teaching_style) }}</textarea>
                </div>
            </div>
        </div>

        {{-- Social --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Online Presence</h2>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="website" label="Website" :value="old('website', $teacher->website)" />
                <x-form-input name="instagram" label="Instagram" :value="old('instagram', $teacher->instagram)" />
                <x-form-input name="youtube" label="YouTube" :value="old('youtube', $teacher->youtube)" />
                <x-form-input name="facebook" label="Facebook" :value="old('facebook', $teacher->facebook)" />
            </div>
        </div>

        {{-- Settings --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-5">Profile Settings</h2>
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <div class="space-y-2">
                        @foreach(['active'=>'Active','inactive'=>'Inactive'] as $val=>$label)
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="radio" name="status" value="{{ $val }}"
                                {{ old('status', $teacher->status) === $val ? 'checked' : '' }}
                                class="text-lavender-600 border-gray-300">
                            <span class="text-sm text-gray-700">{{ $label }}</span>
                        </label>
                        @endforeach
                    </div>
                </div>
                <div>
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="featured" value="1" {{ old('featured', $teacher->featured) ? 'checked' : '' }}
                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                        <span class="text-sm text-gray-700">Feature on homepage</span>
                    </label>
                </div>
            </div>
        </div>

        <div class="flex justify-between items-center">
            <div class="flex gap-3">
                <a href="{{ route('teachers.show', $teacher) }}"
                   class="px-4 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                    Cancel
                </a>
                <form method="POST" action="{{ route('teachers.destroy', $teacher) }}" class="inline">
                    @csrf @method('DELETE')
                    <button type="submit" onclick="return confirm('Remove {{ $teacher->full_name }} from this center?')"
                            class="px-4 py-2.5 text-sm text-red-500 border border-red-200 rounded-xl hover:bg-red-50">
                        Delete
                    </button>
                </form>
            </div>
            <button type="submit"
                    class="px-6 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                Save Changes
            </button>
        </div>
    </form>
</div>
@endsection
