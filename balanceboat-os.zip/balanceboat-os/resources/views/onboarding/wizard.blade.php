@extends('layouts.app')

@section('title', 'Setup Your Center')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-lavender-50 via-white to-peach-50 flex flex-col items-center justify-start py-12 px-4">

    {{-- Brand --}}
    <div class="flex items-center gap-2.5 mb-10">
        <span class="text-3xl">🌿</span>
        <span class="text-xl font-bold text-gray-900">BalanceBoat</span>
    </div>

    <div class="w-full max-w-2xl">

        {{-- Progress --}}
        <div class="mb-8">
            <div class="flex items-center justify-between mb-3">
                @php $steps = [1=>'Center Profile', 2=>'Your First Retreat', 3=>'Invite Team', 4=>'Done!']; @endphp
                @foreach($steps as $n => $label)
                <div class="flex flex-col items-center">
                    <div class="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all
                        {{ $step > $n ? 'bg-wellness-500 text-white' :
                           ($step === $n ? 'bg-lavender-600 text-white shadow-lg shadow-lavender-200' : 'bg-gray-100 text-gray-400') }}">
                        @if($step > $n)
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                        @else
                        {{ $n }}
                        @endif
                    </div>
                    <span class="text-[11px] mt-1.5 font-medium {{ $step === $n ? 'text-lavender-700' : 'text-gray-400' }} hidden sm:block">{{ $label }}</span>
                </div>
                @if($n < count($steps))
                <div class="flex-1 h-px mx-2 {{ $step > $n ? 'bg-wellness-400' : 'bg-gray-200' }} transition-colors"></div>
                @endif
                @endforeach
            </div>
        </div>

        {{-- Card --}}
        <div class="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">

            {{-- Step 1: Center Profile --}}
            @if($step === 1)
            <div class="text-center mb-7">
                <div class="text-4xl mb-3">🏠</div>
                <h1 class="text-2xl font-bold text-gray-900">Tell us about your center</h1>
                <p class="text-gray-500 text-sm mt-1">This appears on your public profile and retreat listings.</p>
            </div>

            <form method="POST" action="{{ route('onboarding.save', 1) }}" enctype="multipart/form-data" class="space-y-5">
                @csrf

                <div class="grid grid-cols-2 gap-4">
                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Center Name <span class="text-red-400">*</span></label>
                        <input type="text" name="center_name" required
                            value="{{ old('center_name', $center?->name) }}"
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100"
                            placeholder="e.g. Ananda Wellness Retreat">
                        @error('center_name')<p class="mt-1 text-xs text-red-500">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Center Type <span class="text-red-400">*</span></label>
                        <select name="center_type" required class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            <option value="">— Select type —</option>
                            @foreach(['yoga_studio'=>'Yoga Studio','retreat_center'=>'Retreat Center','ayurveda_clinic'=>'Ayurveda Clinic','meditation_center'=>'Meditation Center','wellness_spa'=>'Wellness Spa','ashram'=>'Ashram','other'=>'Other'] as $v=>$l)
                            <option value="{{ $v }}" {{ old('center_type', $center?->center_type) === $v ? 'selected' : '' }}>{{ $l }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Country <span class="text-red-400">*</span></label>
                        <input type="text" name="country" required
                            value="{{ old('country', $center?->country) }}"
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400"
                            placeholder="e.g. India">
                    </div>

                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">WhatsApp / Phone</label>
                        <input type="tel" name="phone"
                            value="{{ old('phone', $center?->phone) }}"
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400"
                            placeholder="+91 98765 43210">
                    </div>

                    <div class="col-span-2" x-data="{ preview: '{{ $center?->logo_url }}' }">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Center Logo</label>
                        <div class="flex items-center gap-4">
                            <div class="w-16 h-16 rounded-xl bg-lavender-50 border-2 border-dashed border-lavender-200 flex items-center justify-center overflow-hidden cursor-pointer hover:border-lavender-400 transition-colors"
                                 onclick="document.getElementById('logo-upload').click()">
                                <template x-if="!preview"><span class="text-2xl">🏠</span></template>
                                <template x-if="preview"><img :src="preview" class="w-full h-full object-contain p-1"></template>
                            </div>
                            <div>
                                <input id="logo-upload" type="file" name="logo" accept="image/*" class="hidden"
                                    @change="preview = URL.createObjectURL($event.target.files[0])">
                                <button type="button" onclick="document.getElementById('logo-upload').click()"
                                        class="text-sm text-lavender-600 font-medium hover:text-lavender-700">
                                    Upload logo
                                </button>
                                <p class="text-xs text-gray-400 mt-0.5">PNG, SVG, or JPG · max 2MB</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex justify-between pt-2">
                    <a href="{{ route('dashboard') }}" class="text-sm text-gray-400 hover:text-gray-600">Skip setup for now</a>
                    <button type="submit" class="px-7 py-3 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                        Continue →
                    </button>
                </div>
            </form>
            @endif

            {{-- Step 2: First Retreat --}}
            @if($step === 2)
            <div class="text-center mb-7">
                <div class="text-4xl mb-3">🧘</div>
                <h1 class="text-2xl font-bold text-gray-900">Create your first retreat</h1>
                <p class="text-gray-500 text-sm mt-1">You can fill in full details later — just the basics for now.</p>
            </div>

            <form method="POST" action="{{ route('onboarding.save', 2) }}" class="space-y-5">
                @csrf

                <div class="grid grid-cols-2 gap-4">
                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Retreat Title <span class="text-red-400">*</span></label>
                        <input type="text" name="title" required
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400"
                            placeholder="e.g. 7-Day Transformational Yoga & Meditation Retreat">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Style</label>
                        <select name="style" class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            @foreach(['yoga'=>'Yoga','meditation'=>'Meditation','ayurveda'=>'Ayurveda','sound_healing'=>'Sound Healing','wellness'=>'General Wellness','detox'=>'Detox','breathwork'=>'Breathwork','tantra'=>'Tantra'] as $v=>$l)
                            <option value="{{ $v }}">{{ $l }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Duration (days) <span class="text-red-400">*</span></label>
                        <input type="number" name="duration_days" required min="1" value="7"
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Max Participants <span class="text-red-400">*</span></label>
                        <input type="number" name="max_capacity" required min="1" value="12"
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Starting Price (USD) <span class="text-red-400">*</span></label>
                        <div class="relative">
                            <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
                            <input type="number" name="base_price" required min="0" step="1" value="1200"
                                class="w-full pl-8 pr-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                        </div>
                    </div>
                </div>

                <div class="flex justify-between pt-2">
                    <form method="POST" action="{{ route('onboarding.skip', 2) }}" class="inline">
                        @csrf
                        <button type="submit" class="text-sm text-gray-400 hover:text-gray-600">Skip this step</button>
                    </form>
                    <button type="submit" class="px-7 py-3 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                        Continue →
                    </button>
                </div>
            </form>
            @endif

            {{-- Step 3: Invite Team --}}
            @if($step === 3)
            <div class="text-center mb-7">
                <div class="text-4xl mb-3">👥</div>
                <h1 class="text-2xl font-bold text-gray-900">Invite your team</h1>
                <p class="text-gray-500 text-sm mt-1">Add staff, teachers, or managers. You can also do this later from Settings.</p>
            </div>

            <form method="POST" action="{{ route('onboarding.save', 3) }}" class="space-y-5">
                @csrf

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Addresses</label>
                    <textarea name="invite_emails" rows="3"
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 resize-none"
                        placeholder="team@yourcenter.com, teacher@yourcenter.com&#10;(separate with commas or new lines)"></textarea>
                    <p class="text-xs text-gray-400 mt-1">They'll receive an email invitation to join your workspace.</p>
                </div>

                <div class="flex justify-between pt-2">
                    <form method="POST" action="{{ route('onboarding.skip', 3) }}" class="inline">
                        @csrf
                        <button type="submit" class="text-sm text-gray-400 hover:text-gray-600">Skip for now</button>
                    </form>
                    <button type="submit" class="px-7 py-3 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                        Send Invites →
                    </button>
                </div>
            </form>
            @endif

            {{-- Step 4: Complete --}}
            @if($step === 4)
            <div class="text-center py-8">
                <div class="w-20 h-20 bg-wellness-100 rounded-full flex items-center justify-center mx-auto mb-5">
                    <svg class="w-10 h-10 text-wellness-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h1 class="text-2xl font-bold text-gray-900 mb-2">You're all set! 🎉</h1>
                <p class="text-gray-500 mb-6">
                    <strong>{{ $center?->name ?? 'Your center' }}</strong> is ready on BalanceBoat.<br>
                    Start managing retreats, bookings, and guest communications.
                </p>
                <div class="grid grid-cols-3 gap-4 mb-8">
                    @foreach([
                        ['icon'=>'🧘','title'=>'Create Retreats','desc'=>'Publish and manage your offerings'],
                        ['icon'=>'📅','title'=>'Manage Bookings','desc'=>'Track and handle every booking'],
                        ['icon'=>'📊','title'=>'View Analytics','desc'=>'Understand your center performance'],
                    ] as $item)
                    <div class="bg-gray-50 rounded-xl p-4 text-center">
                        <div class="text-2xl mb-1">{{ $item['icon'] }}</div>
                        <div class="text-xs font-semibold text-gray-900">{{ $item['title'] }}</div>
                        <div class="text-[11px] text-gray-400 mt-0.5">{{ $item['desc'] }}</div>
                    </div>
                    @endforeach
                </div>
                <a href="{{ route('dashboard') }}"
                   class="inline-block px-8 py-3.5 bg-gradient-to-r from-lavender-600 to-violet-600 text-white text-sm font-semibold rounded-xl hover:from-lavender-700 hover:to-violet-700 transition-all shadow-lg shadow-lavender-200">
                    Go to Dashboard →
                </a>
            </div>
            @endif

        </div>

        <p class="text-center text-xs text-gray-400 mt-6">
            Need help? <a href="mailto:support@balanceboat.io" class="text-lavender-600 hover:underline">Contact support</a>
        </p>
    </div>
</div>
@endsection
