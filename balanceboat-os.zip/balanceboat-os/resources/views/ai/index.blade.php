@extends('layouts.app')

@section('title', 'AI Assistant')
@section('page-title', 'AI Assistant')

@section('content')
<div class="space-y-6" x-data="aiDashboard()">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <div>
            <p class="text-gray-500 text-sm">Powered by GPT-4o · generates content, scores leads, and surfaces insights</p>
        </div>
        <div class="flex items-center gap-2 px-3 py-1.5 bg-wellness-50 border border-wellness-200 rounded-full text-xs font-medium text-wellness-700">
            <span class="w-1.5 h-1.5 rounded-full bg-wellness-500 animate-pulse"></span>
            AI Online
        </div>
    </div>

    <x-alert />

    {{-- Tab Bar --}}
    <div class="flex items-center gap-1 bg-gray-100/70 rounded-xl p-1 w-fit">
        @foreach(['generate'=>'✍️ Content','inquiries'=>'🎯 Lead Scoring','insights'=>'💡 Insights','history'=>'📜 History'] as $k=>$l)
        <button @click="tab = '{{ $k }}'"
                :class="tab === '{{ $k }}' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'"
                class="px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all">
            {{ $l }}
        </button>
        @endforeach
    </div>

    {{-- ======= CONTENT GENERATOR ======= --}}
    <div x-show="tab === 'generate'" class="grid grid-cols-5 gap-6">

        {{-- Left: Generator Panel --}}
        <div class="col-span-2 space-y-4">
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h2 class="font-semibold text-gray-900 mb-4">Generate Content</h2>

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Content Type</label>
                        <select x-model="contentType"
                            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            <option value="retreat_description">Retreat Description</option>
                            <option value="email_campaign">Email Campaign</option>
                            <option value="social_post">Social Media Post</option>
                            <option value="inquiry_reply">Inquiry Reply</option>
                            <option value="seo_meta">SEO Meta Tags</option>
                            <option value="whatsapp">WhatsApp Message</option>
                            <option value="teacher_bio">Teacher Bio</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Select Retreat <span class="text-gray-400 font-normal">(optional)</span></label>
                        <select x-model="selectedRetreat"
                            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            <option value="">— General / No retreat —</option>
                            @foreach($experiences as $exp)
                            <option value="{{ $exp->id }}">{{ $exp->title }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Tone</label>
                        <div class="flex items-center gap-1 flex-wrap">
                            @foreach(['warm'=>'🌿 Warm','inspiring'=>'✨ Inspiring','professional'=>'📋 Professional','playful'=>'🎉 Playful','luxurious'=>'💎 Luxurious'] as $k=>$l)
                            <button type="button" @click="tone = '{{ $k }}'"
                                    :class="tone === '{{ $k }}' ? 'bg-lavender-100 text-lavender-700 border-lavender-300' : 'bg-gray-50 text-gray-600 border-gray-200'"
                                    class="px-2.5 py-1 rounded-lg text-xs font-medium border transition-all">
                                {{ $l }}
                            </button>
                            @endforeach
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Additional Context</label>
                        <textarea x-model="context" rows="4"
                            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 resize-none"
                            placeholder="e.g. This email is for a winter promotion targeting yoga practitioners aged 30–50..."></textarea>
                    </div>

                    <button @click="generate()"
                            :disabled="generating"
                            class="w-full py-3 bg-gradient-to-r from-lavender-600 to-violet-600 text-white text-sm font-semibold rounded-xl hover:from-lavender-700 hover:to-violet-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
                        <template x-if="!generating">
                            <span>✨ Generate with AI</span>
                        </template>
                        <template x-if="generating">
                            <span class="flex items-center gap-2">
                                <svg class="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                                </svg>
                                Generating...
                            </span>
                        </template>
                    </button>
                </div>
            </div>

            {{-- Quick Prompts --}}
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-medium text-gray-900 mb-3 text-sm">Quick Prompts</h3>
                <div class="space-y-2">
                    @foreach([
                        'Write a compelling retreat description that highlights transformation',
                        'Draft a last-minute availability email with a 10% discount',
                        'Create 3 Instagram captions for our yoga retreat photos',
                        'Write a warm welcome email for new inquiries',
                    ] as $prompt)
                    <button @click="context = '{{ $prompt }}'; contentType = 'email_campaign'"
                            class="w-full text-left text-xs text-gray-600 p-2.5 bg-gray-50 rounded-lg hover:bg-lavender-50 hover:text-lavender-700 transition-colors">
                        {{ $prompt }}
                    </button>
                    @endforeach
                </div>
            </div>
        </div>

        {{-- Right: Output --}}
        <div class="col-span-3">
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm h-full flex flex-col">
                <div class="p-5 border-b border-gray-100 flex items-center justify-between">
                    <h2 class="font-semibold text-gray-900">Generated Output</h2>
                    <div class="flex items-center gap-2" x-show="output">
                        <button @click="navigator.clipboard.writeText(output)"
                                class="text-xs px-2.5 py-1.5 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 font-medium">
                            Copy
                        </button>
                        <button @click="saveToHistory()"
                                class="text-xs px-2.5 py-1.5 text-lavender-600 border border-lavender-200 rounded-lg hover:bg-lavender-50 font-medium">
                            Save
                        </button>
                    </div>
                </div>

                <div class="flex-1 p-5">
                    <template x-if="!output && !generating">
                        <div class="h-full flex flex-col items-center justify-center text-center">
                            <div class="text-5xl mb-4">🤖</div>
                            <p class="text-gray-400 text-sm">Configure your content type and click Generate.</p>
                            <p class="text-gray-300 text-xs mt-1">Results appear here instantly.</p>
                        </div>
                    </template>
                    <template x-if="generating">
                        <div class="h-full flex flex-col items-center justify-center">
                            <div class="flex gap-1.5 mb-3">
                                <span class="w-2 h-2 rounded-full bg-lavender-400 animate-bounce" style="animation-delay:0s"></span>
                                <span class="w-2 h-2 rounded-full bg-lavender-400 animate-bounce" style="animation-delay:.15s"></span>
                                <span class="w-2 h-2 rounded-full bg-lavender-400 animate-bounce" style="animation-delay:.3s"></span>
                            </div>
                            <p class="text-gray-400 text-sm">AI is crafting your content...</p>
                        </div>
                    </template>
                    <template x-if="output && !generating">
                        <div>
                            <div class="prose prose-sm max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap" x-text="output"></div>
                            <div class="mt-4 pt-4 border-t border-gray-100 flex items-center gap-2">
                                <button @click="generate()" class="text-xs text-lavender-600 hover:text-lavender-700 font-medium">
                                    ↻ Regenerate
                                </button>
                                <span class="text-gray-300">·</span>
                                <button class="text-xs text-gray-500 hover:text-gray-700 font-medium">
                                    Make shorter
                                </button>
                                <span class="text-gray-300">·</span>
                                <button class="text-xs text-gray-500 hover:text-gray-700 font-medium">
                                    Make more formal
                                </button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>

    {{-- ======= LEAD SCORING ======= --}}
    <div x-show="tab === 'inquiries'">
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="p-5 border-b border-gray-100">
                <h2 class="font-semibold text-gray-900">AI Lead Scoring</h2>
                <p class="text-xs text-gray-400 mt-0.5">Each inquiry is scored 1–100 based on intent, urgency, and profile fit</p>
            </div>
            <x-data-table
                :columns="[
                    ['key'=>'score','label'=>'Score'],
                    ['key'=>'guest','label'=>'Guest'],
                    ['key'=>'retreat','label'=>'Retreat Interest'],
                    ['key'=>'signal','label'=>'Key Signal'],
                    ['key'=>'received','label'=>'Received'],
                    ['key'=>'actions','label'=>''],
                ]"
            >
                @forelse($scoredInquiries as $inq)
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-5 py-3.5">
                        <div class="flex items-center gap-2">
                            <div class="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold
                                {{ ($inq->ai_score ?? 0) >= 75 ? 'bg-wellness-100 text-wellness-700' :
                                   (($inq->ai_score ?? 0) >= 50 ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500') }}">
                                {{ $inq->ai_score ?? '?' }}
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-3.5">
                        <div class="text-sm font-medium text-gray-900">{{ $inq->guest_name }}</div>
                        <div class="text-xs text-gray-400">{{ $inq->guest_country }}</div>
                    </td>
                    <td class="px-5 py-3.5 text-sm text-gray-600">{{ $inq->experience?->title ?? 'General' }}</td>
                    <td class="px-5 py-3.5">
                        <span class="text-xs bg-lavender-50 text-lavender-700 px-2 py-0.5 rounded-full">
                            {{ $inq->ai_signal ?? 'Needs analysis' }}
                        </span>
                    </td>
                    <td class="px-5 py-3.5 text-sm text-gray-500">{{ $inq->created_at->diffForHumans() }}</td>
                    <td class="px-5 py-3.5">
                        <a href="{{ route('inquiries.show', $inq) }}"
                           class="text-xs text-lavender-600 hover:underline font-medium">View →</a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="px-5 py-16 text-center">
                        <div class="text-4xl mb-3">🎯</div>
                        <p class="text-gray-400 text-sm">No scored inquiries yet. AI scores are applied as inquiries arrive.</p>
                    </td>
                </tr>
                @endforelse
            </x-data-table>
        </div>
    </div>

    {{-- ======= INSIGHTS ======= --}}
    <div x-show="tab === 'insights'">
        <div class="grid grid-cols-2 gap-5">
            @foreach($insights as $insight)
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <div class="flex items-start gap-3">
                    <div class="text-2xl">{{ $insight['icon'] }}</div>
                    <div>
                        <div class="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">{{ $insight['category'] }}</div>
                        <p class="text-sm font-medium text-gray-900 mb-1">{{ $insight['title'] }}</p>
                        <p class="text-sm text-gray-500">{{ $insight['body'] }}</p>
                        @if(isset($insight['action']))
                        <a href="{{ $insight['action']['url'] }}" class="mt-2 inline-block text-xs text-lavender-600 font-medium hover:underline">
                            {{ $insight['action']['label'] }} →
                        </a>
                        @endif
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    {{-- ======= HISTORY ======= --}}
    <div x-show="tab === 'history'">
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="p-5 border-b border-gray-100">
                <h2 class="font-semibold text-gray-900">Generation History</h2>
            </div>
            <div class="divide-y divide-gray-50">
                @forelse($aiHistory as $item)
                <div class="p-5 hover:bg-gray-50 transition-colors">
                    <div class="flex items-start justify-between">
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="text-xs bg-lavender-100 text-lavender-700 px-2 py-0.5 rounded-full font-medium capitalize">
                                    {{ str_replace('_', ' ', $item->type) }}
                                </span>
                                <span class="text-xs text-gray-400">{{ $item->created_at->diffForHumans() }}</span>
                            </div>
                            <p class="text-sm text-gray-700 line-clamp-2">{{ $item->output }}</p>
                        </div>
                        <button onclick="navigator.clipboard.writeText('{{ addslashes($item->output) }}')"
                                class="ml-3 text-xs text-gray-400 hover:text-gray-600 shrink-0 mt-1">
                            Copy
                        </button>
                    </div>
                </div>
                @empty
                <div class="p-16 text-center">
                    <div class="text-4xl mb-3">📜</div>
                    <p class="text-gray-400 text-sm">No AI generations yet. Start by creating content above.</p>
                </div>
                @endforelse
            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
function aiDashboard() {
    return {
        tab: 'generate',
        contentType: 'retreat_description',
        selectedRetreat: '',
        tone: 'warm',
        context: '',
        generating: false,
        output: '',

        async generate() {
            this.generating = true;
            this.output = '';
            try {
                const res = await fetch('{{ route("ai.generate") }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({
                        type: this.contentType,
                        experience_id: this.selectedRetreat,
                        tone: this.tone,
                        context: this.context,
                    }),
                });
                const data = await res.json();
                this.output = data.content ?? data.error ?? 'Something went wrong.';
            } catch (e) {
                this.output = 'Failed to reach AI service. Please try again.';
            } finally {
                this.generating = false;
            }
        },

        async saveToHistory() {
            await fetch('{{ route("ai.save") }}', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                body: JSON.stringify({ type: this.contentType, output: this.output }),
            });
        },
    };
}
</script>
@endpush
