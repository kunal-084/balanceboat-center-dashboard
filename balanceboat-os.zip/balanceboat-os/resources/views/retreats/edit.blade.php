@extends('layouts.app')

@section('title', 'Edit Retreat')
@section('page-title', 'Retreats')

@section('content')
<div class="space-y-6" x-data="retreatWizard({{ json_encode([
    'title'          => old('title', $experience->title),
    'tagline'        => old('tagline', $experience->tagline),
    'description'    => old('description', $experience->description),
    'style'          => old('style', $experience->style),
    'level'          => old('level', $experience->level),
    'language'       => old('language', $experience->language),
    'duration_days'  => old('duration_days', $experience->duration_days),
    'max_capacity'   => old('max_capacity', $experience->max_capacity),
    'min_capacity'   => old('min_capacity', $experience->min_capacity),
    'status'         => old('status', $experience->status),
]) }})">

    {{-- Breadcrumb --}}
    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('retreats.index') }}" class="hover:text-gray-600">Retreats</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <a href="{{ route('retreats.show', $experience) }}" class="hover:text-gray-600 truncate max-w-xs">{{ $experience->title }}</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">Edit</span>
    </nav>

    <x-alert />

    {{-- Tab Navigation --}}
    <div class="flex items-center gap-1 bg-white rounded-2xl border border-gray-100 p-1.5 shadow-sm overflow-x-auto">
        @foreach([
            ['key'=>'basics',       'label'=>'Basics',        'icon'=>'📝'],
            ['key'=>'details',      'label'=>'Details',       'icon'=>'📋'],
            ['key'=>'schedule',     'label'=>'Schedule',      'icon'=>'📅'],
            ['key'=>'pricing',      'label'=>'Pricing',       'icon'=>'💰'],
            ['key'=>'accommodation','label'=>'Stay',          'icon'=>'🏠'],
            ['key'=>'inclusions',   'label'=>'Inclusions',    'icon'=>'✅'],
            ['key'=>'teachers',     'label'=>'Teachers',      'icon'=>'👤'],
            ['key'=>'publish',      'label'=>'Publish',       'icon'=>'🚀'],
        ] as $tab)
        <button type="button" @click="activeTab = '{{ $tab['key'] }}'"
                :class="activeTab === '{{ $tab['key'] }}' ? 'bg-lavender-50 text-lavender-700 border-lavender-200' : 'text-gray-500 hover:text-gray-700'"
                class="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium border border-transparent whitespace-nowrap transition-all">
            <span class="text-base leading-none">{{ $tab['icon'] }}</span>
            {{ $tab['label'] }}
        </button>
        @endforeach
    </div>

    <form method="POST" action="{{ route('retreats.update', $experience) }}" enctype="multipart/form-data" id="edit-form">
        @csrf
        @method('PUT')

        {{-- TAB: Basics --}}
        <div x-show="activeTab === 'basics'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Basic Information</h2>
            <div class="grid grid-cols-2 gap-5">
                <div class="col-span-2">
                    <x-form-input name="title" label="Retreat Title" required :value="old('title', $experience->title)"
                        placeholder="e.g. 7-Day Ayurvedic Reset Retreat" />
                </div>
                <div class="col-span-2">
                    <x-form-input name="tagline" label="Tagline" :value="old('tagline', $experience->tagline)"
                        placeholder="A short compelling line for listings" />
                </div>
                <x-form-input name="style" label="Retreat Style" type="select" required
                    :value="old('style', $experience->style)"
                    :options="['yoga'=>'Yoga','meditation'=>'Meditation','ayurveda'=>'Ayurveda','detox'=>'Detox','wellness'=>'Wellness','adventure'=>'Adventure','silent'=>'Silent','mixed'=>'Mixed']" />
                <x-form-input name="level" label="Level" type="select"
                    :value="old('level', $experience->level)"
                    :options="['all'=>'All Levels','beginner'=>'Beginner','intermediate'=>'Intermediate','advanced'=>'Advanced']" />
                <x-form-input name="language" label="Language" :value="old('language', $experience->language ?? 'English')" />
                <x-form-input name="duration_days" label="Duration (days)" type="number" required
                    :value="old('duration_days', $experience->duration_days)" />
                <x-form-input name="min_capacity" label="Min Participants" type="number"
                    :value="old('min_capacity', $experience->min_capacity)" />
                <x-form-input name="max_capacity" label="Max Participants" type="number" required
                    :value="old('max_capacity', $experience->max_capacity)" />
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Description</label>
                <textarea name="description" rows="6"
                    class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y"
                    placeholder="Describe the retreat experience, philosophy, and what makes it special...">{{ old('description', $experience->description) }}</textarea>
            </div>
        </div>

        {{-- TAB: Details --}}
        <div x-show="activeTab === 'details'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Retreat Details</h2>
            <div class="grid grid-cols-2 gap-5">
                <x-form-input name="location_name" label="Location Name" :value="old('location_name', $experience->location_name)"
                    placeholder="e.g. Varkala Clifftop" />
                <x-form-input name="address" label="Address" :value="old('address', $experience->address)" />
                <x-form-input name="city" label="City" :value="old('city', $experience->city)" />
                <x-form-input name="country" label="Country" :value="old('country', $experience->country)" />
                <x-form-input name="timezone" label="Timezone" :value="old('timezone', $experience->timezone ?? 'Asia/Kolkata')" />
                <x-form-input name="venue_type" label="Venue Type" type="select"
                    :value="old('venue_type', $experience->venue_type)"
                    :options="['resort'=>'Resort','ashram'=>'Ashram','villa'=>'Villa','hotel'=>'Hotel','outdoor'=>'Outdoor','home'=>'Home Stay','other'=>'Other']" />
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">What to Bring</label>
                <textarea name="what_to_bring" rows="4"
                    class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y">{{ old('what_to_bring', $experience->what_to_bring) }}</textarea>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Cancellation Policy</label>
                <textarea name="cancellation_policy" rows="3"
                    class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y">{{ old('cancellation_policy', $experience->cancellation_policy) }}</textarea>
            </div>
        </div>

        {{-- TAB: Schedule --}}
        <div x-show="activeTab === 'schedule'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Upcoming Dates</h2>
            <p class="text-sm text-gray-500">Existing dates can be managed in the <a href="{{ route('retreats.availability', $experience) }}" class="text-lavender-600 underline">Availability Manager</a>.</p>

            <div x-data="{ dates: [] }" class="space-y-4">
                <div class="flex items-center justify-between">
                    <h3 class="text-sm font-semibold text-gray-700">Add New Dates</h3>
                    <button type="button" @click="dates.push({ start:'', end:'', spots:'' })"
                            class="text-sm text-lavender-600 font-medium hover:text-lavender-700">
                        + Add Date Block
                    </button>
                </div>
                <template x-for="(d, idx) in dates" :key="idx">
                    <div class="flex items-end gap-4 p-4 bg-lavender-50 rounded-xl">
                        <div class="flex-1">
                            <label class="block text-xs font-medium text-gray-600 mb-1">Start Date</label>
                            <input type="date" :name="`new_dates[${idx}][start_date]`" x-model="d.start"
                                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-lavender-400">
                        </div>
                        <div class="flex-1">
                            <label class="block text-xs font-medium text-gray-600 mb-1">End Date</label>
                            <input type="date" :name="`new_dates[${idx}][end_date]`" x-model="d.end"
                                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-lavender-400">
                        </div>
                        <div class="w-28">
                            <label class="block text-xs font-medium text-gray-600 mb-1">Spots</label>
                            <input type="number" :name="`new_dates[${idx}][max_participants]`" x-model="d.spots"
                                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-lavender-400">
                        </div>
                        <button type="button" @click="dates.splice(idx,1)" class="text-red-400 hover:text-red-600 pb-2">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                        </button>
                    </div>
                </template>
            </div>
        </div>

        {{-- TAB: Pricing --}}
        <div x-show="activeTab === 'pricing'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Base Pricing</h2>
            <div class="grid grid-cols-3 gap-5">
                <x-form-input name="base_price" label="Base Price (per person)" type="number"
                    :value="old('base_price', $experience->base_price)" />
                <x-form-input name="currency" label="Currency" type="select"
                    :value="old('currency', $experience->currency ?? 'USD')"
                    :options="['USD'=>'USD ($)','EUR'=>'EUR (€)','GBP'=>'GBP (£)','INR'=>'INR (₹)','AUD'=>'AUD (A$)']" />
                <x-form-input name="deposit_percent" label="Deposit (%)" type="number"
                    :value="old('deposit_percent', $experience->deposit_percent ?? 25)"
                    hint="Percentage required to confirm booking" />
            </div>

            <div class="grid grid-cols-2 gap-5">
                <div class="p-4 bg-gray-50 rounded-xl">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="early_bird_enabled" value="1"
                            {{ old('early_bird_enabled', $experience->early_bird_enabled) ? 'checked' : '' }}
                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                        <span class="text-sm font-medium text-gray-700">Enable Early Bird Discount</span>
                    </label>
                    <div class="mt-3 grid grid-cols-2 gap-3">
                        <x-form-input name="early_bird_discount" label="Discount (%)" type="number"
                            :value="old('early_bird_discount', $experience->early_bird_discount)" />
                        <x-form-input name="early_bird_days" label="Days Before Start" type="number"
                            :value="old('early_bird_days', $experience->early_bird_days ?? 30)" />
                    </div>
                </div>
                <div class="p-4 bg-gray-50 rounded-xl">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="group_discount_enabled" value="1"
                            {{ old('group_discount_enabled', $experience->group_discount_enabled) ? 'checked' : '' }}
                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                        <span class="text-sm font-medium text-gray-700">Enable Group Discount</span>
                    </label>
                    <div class="mt-3 grid grid-cols-2 gap-3">
                        <x-form-input name="group_discount_percent" label="Discount (%)" type="number"
                            :value="old('group_discount_percent', $experience->group_discount_percent)" />
                        <x-form-input name="group_min_size" label="Min Group Size" type="number"
                            :value="old('group_min_size', $experience->group_min_size ?? 4)" />
                    </div>
                </div>
            </div>
        </div>

        {{-- TAB: Accommodation --}}
        <div x-show="activeTab === 'accommodation'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Room & Accommodation Options</h2>
            <p class="text-sm text-gray-500">Define room types available for this retreat. Participants select on booking.</p>

            <div x-data="{ rooms: {{ json_encode($experience->roomTypes ?? []) }} }" class="space-y-4">
                <template x-for="(room, idx) in rooms" :key="idx">
                    <div class="p-4 border border-gray-200 rounded-xl space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-sm font-semibold text-gray-700" x-text="room.name || 'Room Type ' + (idx+1)"></span>
                            <button type="button" @click="rooms.splice(idx,1)"
                                    class="text-red-400 hover:text-red-600 text-xs font-medium">Remove</button>
                        </div>
                        <div class="grid grid-cols-4 gap-3">
                            <div class="col-span-2">
                                <label class="text-xs text-gray-500 mb-1 block">Room Name</label>
                                <input type="text" :name="`rooms[${idx}][name]`" x-model="room.name"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-lavender-400">
                            </div>
                            <div>
                                <label class="text-xs text-gray-500 mb-1 block">Price Add-on</label>
                                <input type="number" :name="`rooms[${idx}][price_addon]`" x-model="room.price_addon"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-lavender-400">
                            </div>
                            <div>
                                <label class="text-xs text-gray-500 mb-1 block">Qty Available</label>
                                <input type="number" :name="`rooms[${idx}][quantity]`" x-model="room.quantity"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-lavender-400">
                            </div>
                        </div>
                    </div>
                </template>
                <button type="button" @click="rooms.push({name:'',price_addon:0,quantity:1})"
                        class="w-full py-3 border-2 border-dashed border-lavender-200 text-lavender-600 text-sm font-medium rounded-xl hover:bg-lavender-50 transition-colors">
                    + Add Room Type
                </button>
            </div>
        </div>

        {{-- TAB: Inclusions --}}
        <div x-show="activeTab === 'inclusions'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">What's Included / Excluded</h2>
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">✅ Included</label>
                    <textarea name="inclusions" rows="8"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y"
                        placeholder="One item per line&#10;Daily yoga sessions&#10;Ayurvedic meals&#10;Airport transfers">{{ old('inclusions', is_array($experience->inclusions) ? implode("\n", $experience->inclusions) : $experience->inclusions) }}</textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">❌ Not Included</label>
                    <textarea name="exclusions" rows="8"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y"
                        placeholder="One item per line&#10;Flights&#10;Travel insurance&#10;Optional spa add-ons">{{ old('exclusions', is_array($experience->exclusions) ? implode("\n", $experience->exclusions) : $experience->exclusions) }}</textarea>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Daily Schedule / Itinerary</label>
                <textarea name="itinerary" rows="10"
                    class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-y font-mono"
                    placeholder="Day 1: Arrival & Welcome&#10;6:00am – Morning meditation&#10;7:30am – Yoga session...">{{ old('itinerary', $experience->itinerary) }}</textarea>
            </div>
        </div>

        {{-- TAB: Teachers --}}
        <div x-show="activeTab === 'teachers'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Assign Teachers / Facilitators</h2>
            <div class="space-y-3">
                @foreach($centerTeachers as $teacher)
                <label class="flex items-center gap-3 p-3 border border-gray-100 rounded-xl hover:bg-lavender-50 cursor-pointer transition-colors">
                    <input type="checkbox" name="teacher_ids[]" value="{{ $teacher->id }}"
                        {{ in_array($teacher->id, $experience->teachers->pluck('id')->toArray()) ? 'checked' : '' }}
                        class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                    <img src="{{ $teacher->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($teacher->full_name).'&background=ede9fe&color=7c3aed' }}"
                         alt="" class="w-9 h-9 rounded-full object-cover">
                    <div class="flex-1">
                        <div class="text-sm font-medium text-gray-900">{{ $teacher->full_name }}</div>
                        <div class="text-xs text-gray-400">{{ $teacher->specialty ?? 'Teacher' }}</div>
                    </div>
                </label>
                @endforeach
            </div>
        </div>

        {{-- TAB: Publish --}}
        <div x-show="activeTab === 'publish'" class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <h2 class="font-semibold text-gray-900">Publish Settings</h2>

            <div class="grid grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <div class="space-y-2">
                        @foreach(['draft'=>'Draft','published'=>'Published','archived'=>'Archived'] as $val => $label)
                        <label class="flex items-center gap-3 p-3 border border-gray-200 rounded-xl cursor-pointer hover:border-lavender-300 transition-colors">
                            <input type="radio" name="status" value="{{ $val }}"
                                {{ old('status', $experience->status) === $val ? 'checked' : '' }}
                                class="text-lavender-600 border-gray-300">
                            <div>
                                <div class="text-sm font-medium text-gray-900">{{ $label }}</div>
                                <div class="text-xs text-gray-400">
                                    @if($val === 'draft') Not visible to guests
                                    @elseif($val === 'published') Visible and bookable
                                    @else Hidden from new bookings @endif
                                </div>
                            </div>
                        </label>
                        @endforeach
                    </div>
                </div>
                <div class="space-y-4">
                    <div>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="featured" value="1"
                                {{ old('featured', $experience->featured) ? 'checked' : '' }}
                                class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                            <span class="text-sm font-medium text-gray-700">Feature on homepage</span>
                        </label>
                    </div>
                    <div>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="instant_book" value="1"
                                {{ old('instant_book', $experience->instant_book) ? 'checked' : '' }}
                                class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                            <span class="text-sm font-medium text-gray-700">Allow instant booking</span>
                        </label>
                    </div>
                    <div>
                        <x-form-input name="seo_title" label="SEO Title" :value="old('seo_title', $experience->seo_title)"
                            placeholder="Override title for search engines" />
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">SEO Description</label>
                        <textarea name="seo_description" rows="3"
                            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 resize-y">{{ old('seo_description', $experience->seo_description) }}</textarea>
                    </div>
                </div>
            </div>
        </div>

        {{-- Sticky Footer --}}
        <div class="flex items-center justify-between bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <a href="{{ route('retreats.show', $experience) }}"
               class="px-4 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                Cancel
            </a>
            <div class="flex items-center gap-3">
                <span class="text-xs text-gray-400">Last saved {{ $experience->updated_at->diffForHumans() }}</span>
                <button type="submit" name="action" value="save"
                        class="px-5 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                    Save Changes
                </button>
            </div>
        </div>
    </form>

</div>
@endsection

@push('scripts')
<script>
function retreatWizard(prefill) {
    return { activeTab: 'basics', data: prefill };
}
</script>
@endpush
