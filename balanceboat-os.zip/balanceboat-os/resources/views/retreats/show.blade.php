@extends('layouts.app')

@section('title', $retreat->title)
@section('page-title', 'Retreat Details')

@section('content')
<div class="space-y-6" x-data="{ activeTab: 'overview' }">

    {{-- Header --}}
    <div class="flex items-start justify-between gap-4">
        <div class="flex items-center gap-3">
            <a href="{{ route('retreats.index') }}" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <x-status-badge :status="$retreat->status" />
                    @if($retreat->is_featured)
                    <span class="text-xs bg-peach-100 text-peach-700 px-2 py-0.5 rounded-full font-medium">⭐ Featured</span>
                    @endif
                </div>
                <h1 class="font-serif text-xl font-bold text-gray-900">{{ $retreat->title }}</h1>
                <p class="text-sm text-gray-400 mt-0.5">
                    {{ $retreat->category?->name }} · {{ $retreat->duration_nights }} nights · Up to {{ $retreat->max_participants }} guests
                </p>
            </div>
        </div>
        <div class="flex items-center gap-2 flex-shrink-0">
            <a href="{{ route('retreats.edit', $retreat) }}"
               class="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931z"/>
                </svg>
                Edit
            </a>

            @if($retreat->status === 'draft')
            <form method="POST" action="{{ route('retreats.publish', $retreat) }}">
                @csrf @method('PATCH')
                <button type="submit" class="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold bg-wellness-500 text-white rounded-xl hover:bg-wellness-600 transition-colors">
                    🌐 Publish
                </button>
            </form>
            @else
            <form method="POST" action="{{ route('retreats.unpublish', $retreat) }}">
                @csrf @method('PATCH')
                <button type="submit" class="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-amber-600 border border-amber-200 rounded-xl hover:bg-amber-50 transition-colors">
                    Unpublish
                </button>
            </form>
            @endif
        </div>
    </div>

    {{-- KPI Strip --}}
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        @php
        $metrics = [
            ['label' => 'Total Bookings', 'value' => $retreat->bookings_count ?? 0, 'icon' => '📅'],
            ['label' => 'Confirmed Revenue', 'value' => '$' . number_format($retreat->confirmed_revenue ?? 0, 0), 'icon' => '💰'],
            ['label' => 'Occupancy Rate', 'value' => ($retreat->occupancy_rate ?? 0) . '%', 'icon' => '🏠'],
            ['label' => 'Avg Rating', 'value' => number_format($retreat->avg_rating ?? 0, 1) . ' ⭐', 'icon' => '⭐'],
        ];
        @endphp
        @foreach($metrics as $metric)
        <div class="bg-white rounded-xl border border-gray-100 p-4">
            <div class="text-2xl mb-1.5">{{ $metric['icon'] }}</div>
            <div class="font-serif text-xl font-bold text-gray-900">{{ $metric['value'] }}</div>
            <div class="text-xs text-gray-500">{{ $metric['label'] }}</div>
        </div>
        @endforeach
    </div>

    {{-- Tabs --}}
    <div class="border-b border-gray-100">
        <nav class="flex gap-1 -mb-px">
            @foreach([
                ['key' => 'overview', 'label' => 'Overview'],
                ['key' => 'bookings', 'label' => 'Bookings (' . ($retreat->bookings_count ?? 0) . ')'],
                ['key' => 'availability', 'label' => 'Availability'],
                ['key' => 'media', 'label' => 'Media'],
                ['key' => 'analytics', 'label' => 'Analytics'],
            ] as $tab)
            <button @click="activeTab = '{{ $tab['key'] }}'"
                    :class="activeTab === '{{ $tab['key'] }}' ? 'border-b-2 border-lavender-600 text-lavender-700 font-semibold' : 'text-gray-500 hover:text-gray-700'"
                    class="px-4 py-3 text-sm transition-colors whitespace-nowrap">
                {{ $tab['label'] }}
            </button>
            @endforeach
        </nav>
    </div>

    {{-- Overview Tab --}}
    <div x-show="activeTab === 'overview'" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 space-y-5">
            {{-- Cover Image --}}
            @if($retreat->cover_image_url)
            <div class="rounded-2xl overflow-hidden h-64">
                <img src="{{ $retreat->cover_image_url }}" alt="{{ $retreat->title }}" class="w-full h-full object-cover">
            </div>
            @endif

            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Description</h3>
                <div class="text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none">
                    {!! nl2br(e($retreat->description)) !!}
                </div>
            </div>

            @if($retreat->itineraryItems->count())
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Daily Itinerary</h3>
                <div class="space-y-3">
                    @foreach($retreat->itineraryItems as $item)
                    <div class="flex gap-3">
                        <div class="w-7 h-7 bg-lavender-600 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">
                            {{ $item->day_number }}
                        </div>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">{{ $item->title }}</div>
                            <p class="text-xs text-gray-500 mt-0.5">{{ $item->description }}</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        </div>

        {{-- Sidebar --}}
        <div class="space-y-4">
            <div class="bg-white rounded-2xl border border-gray-100 p-5 space-y-3 text-sm">
                <h3 class="font-semibold text-gray-900">Details</h3>
                <div class="flex justify-between"><span class="text-gray-500">Base Price</span><span class="font-semibold text-lavender-700">${{ number_format($retreat->base_price) }}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Duration</span><span>{{ $retreat->duration_nights }} nights</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Max Participants</span><span>{{ $retreat->max_participants }}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Start Date</span><span>{{ $retreat->start_date?->format('d M Y') ?? '—' }}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">End Date</span><span>{{ $retreat->end_date?->format('d M Y') ?? '—' }}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Location</span><span>{{ $retreat->city }}, {{ $retreat->country }}</span></div>
            </div>

            @if($retreat->teachers->count())
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Teachers</h3>
                <div class="space-y-2.5">
                    @foreach($retreat->teachers as $teacher)
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 bg-lavender-100 rounded-full flex items-center justify-center text-xs font-bold text-lavender-700">
                            {{ strtoupper(substr($teacher->name, 0, 1)) }}
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $teacher->name }}</div>
                            <div class="text-xs text-gray-400">{{ $teacher->specialty }}</div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif

            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Quick Actions</h3>
                <div class="space-y-2">
                    <a href="{{ route('retreats.duplicate', $retreat) }}" class="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-gray-600 hover:bg-lavender-50 hover:text-lavender-700 transition-colors">
                        📋 Duplicate Retreat
                    </a>
                    <a href="{{ route('retreats.availability', $retreat) }}" class="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-gray-600 hover:bg-lavender-50 hover:text-lavender-700 transition-colors">
                        📅 Manage Availability
                    </a>
                    <a href="{{ route('pricing.index', ['experience_id' => $retreat->id]) }}" class="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-gray-600 hover:bg-lavender-50 hover:text-lavender-700 transition-colors">
                        💰 Pricing Rules
                    </a>
                </div>
            </div>
        </div>
    </div>

    {{-- Bookings Tab --}}
    <div x-show="activeTab === 'bookings'">
        <x-data-table
            :columns="[
                ['key'=>'ref','label'=>'Reference','sortable'=>true],
                ['key'=>'guest','label'=>'Guest'],
                ['key'=>'dates','label'=>'Dates'],
                ['key'=>'amount','label'=>'Amount'],
                ['key'=>'status','label'=>'Status'],
                ['key'=>'actions','label'=>''],
            ]"
            empty-text="No bookings for this retreat yet."
            empty-icon="📅"
        >
            @foreach($retreat->bookings as $booking)
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="px-5 py-3.5 text-sm font-medium text-lavender-700">{{ $booking->reference_number }}</td>
                <td class="px-5 py-3.5">
                    <div class="text-sm font-medium text-gray-900">{{ $booking->guest_name }}</div>
                    <div class="text-xs text-gray-500">{{ $booking->guest_email }}</div>
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-600">
                    {{ $booking->check_in_date?->format('d M') }} — {{ $booking->check_out_date?->format('d M Y') }}
                </td>
                <td class="px-5 py-3.5 text-sm font-semibold text-gray-900">${{ number_format($booking->total_amount, 0) }}</td>
                <td class="px-5 py-3.5"><x-status-badge :status="$booking->status" /></td>
                <td class="px-5 py-3.5">
                    <a href="{{ route('bookings.show', $booking) }}" class="text-xs text-lavender-600 font-medium hover:text-lavender-800">View →</a>
                </td>
            </tr>
            @endforeach
        </x-data-table>
    </div>

    {{-- Availability Tab --}}
    <div x-show="activeTab === 'availability'">
        <div class="bg-white rounded-2xl border border-gray-100 p-6">
            <p class="text-gray-500 text-sm text-center py-8">
                <a href="{{ route('retreats.availability', $retreat) }}" class="text-lavender-600 font-medium">Open Availability Manager →</a>
            </p>
        </div>
    </div>

    {{-- Media Tab --}}
    <div x-show="activeTab === 'media'">
        <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-4">
            <div class="flex items-center justify-between">
                <h3 class="font-semibold text-gray-900">Media Library</h3>
            </div>
            @if($retreat->mediaFiles->count())
            <div class="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                @foreach($retreat->mediaFiles as $media)
                <div class="relative group aspect-square rounded-xl overflow-hidden border border-gray-100">
                    <img src="{{ $media->url }}" alt="{{ $media->name }}" class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <a href="{{ $media->url }}" target="_blank" class="text-white text-xs font-medium">View</a>
                    </div>
                </div>
                @endforeach
            </div>
            @else
            <div class="text-center py-10 text-gray-400 text-sm">No media uploaded yet.</div>
            @endif
        </div>
    </div>

    {{-- Analytics Tab --}}
    <div x-show="activeTab === 'analytics'">
        <div class="bg-white rounded-2xl border border-gray-100 p-6">
            <p class="text-center text-gray-400 text-sm py-8">
                <a href="{{ route('analytics.retreat', $retreat) }}" class="text-lavender-600 font-medium">View Full Analytics Report →</a>
            </p>
        </div>
    </div>

</div>
@endsection
