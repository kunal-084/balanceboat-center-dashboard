@extends('layouts.app')

@section('title', 'Availability')
@section('page-title', 'Retreats')

@section('content')
<div class="space-y-6" x-data="availabilityManager({{ json_encode($batches) }})">

    {{-- Breadcrumb --}}
    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('retreats.index') }}" class="hover:text-gray-600">Retreats</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <a href="{{ route('retreats.show', $experience) }}" class="hover:text-gray-600 truncate max-w-xs">{{ $experience->title }}</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">Availability</span>
    </nav>

    <x-alert />

    <div class="grid grid-cols-3 gap-6">

        {{-- Left: Batch List --}}
        <div class="col-span-2 space-y-4">
            <div class="flex items-center justify-between">
                <h2 class="font-semibold text-gray-900">Date Batches</h2>
                <button @click="showAddForm = !showAddForm"
                        class="flex items-center gap-1.5 px-3.5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                    <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add Dates
                </button>
            </div>

            {{-- Add Batch Form --}}
            <div x-show="showAddForm" x-transition class="bg-lavender-50 border border-lavender-200 rounded-2xl p-5">
                <h3 class="font-medium text-gray-900 mb-4">New Date Batch</h3>
                <form method="POST" action="{{ route('retreats.batches.store', $experience) }}" class="grid grid-cols-2 gap-4">
                    @csrf
                    <x-form-input name="start_date" label="Start Date" type="date" required />
                    <x-form-input name="end_date" label="End Date" type="date" required />
                    <x-form-input name="max_participants" label="Max Participants" type="number"
                        :value="$experience->max_capacity" required />
                    <x-form-input name="price_override" label="Price Override ($)"
                        hint="Leave blank to use base price" type="number" />
                    <div class="col-span-2">
                        <x-form-input name="notes" label="Internal Notes (optional)"
                            placeholder="e.g. Festival season, special guide..." />
                    </div>
                    <div class="col-span-2 flex justify-end gap-3">
                        <button type="button" @click="showAddForm = false"
                                class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-white">
                            Cancel
                        </button>
                        <button type="submit"
                                class="px-5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700">
                            Save Batch
                        </button>
                    </div>
                </form>
            </div>

            {{-- Batch Table --}}
            @forelse($batches as $batch)
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <div class="flex items-start justify-between">
                    <div>
                        <div class="flex items-center gap-3 mb-1">
                            <span class="text-sm font-semibold text-gray-900">
                                {{ $batch->start_date->format('d M Y') }} — {{ $batch->end_date->format('d M Y') }}
                            </span>
                            <x-status-badge :status="$batch->status" />
                        </div>
                        <div class="flex items-center gap-4 text-xs text-gray-500">
                            <span>{{ $batch->duration_nights }} nights</span>
                            <span>{{ $batch->bookings_count }} / {{ $batch->max_participants }} spots filled</span>
                            @if($batch->price_override)
                            <span class="text-lavender-600 font-medium">${{ number_format($batch->price_override, 0) }} override</span>
                            @endif
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <a href="{{ route('bookings.index', ['batch_id' => $batch->id]) }}"
                           class="text-xs px-2.5 py-1.5 text-lavender-600 hover:bg-lavender-50 rounded-lg font-medium transition-colors">
                            View Bookings
                        </a>
                        <button @click="editBatch = {{ json_encode($batch) }}"
                                class="text-xs px-2.5 py-1.5 text-gray-600 hover:bg-gray-50 rounded-lg font-medium transition-colors">
                            Edit
                        </button>
                        <form method="POST" action="{{ route('retreats.batches.destroy', [$experience, $batch]) }}">
                            @csrf @method('DELETE')
                            <button type="submit"
                                    onclick="return confirm('Delete this batch? Existing bookings will be affected.')"
                                    class="text-xs px-2.5 py-1.5 text-red-500 hover:bg-red-50 rounded-lg font-medium transition-colors">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>

                {{-- Capacity Bar --}}
                <div class="mt-3">
                    <div class="flex items-center justify-between text-xs text-gray-400 mb-1">
                        <span>Capacity</span>
                        <span>{{ $batch->bookings_count }} / {{ $batch->max_participants }}</span>
                    </div>
                    @php
                        $pct = $batch->max_participants > 0
                            ? min(100, ($batch->bookings_count / $batch->max_participants) * 100) : 0;
                        $color = $pct >= 90 ? 'bg-red-400' : ($pct >= 70 ? 'bg-amber-400' : 'bg-wellness-500');
                    @endphp
                    <div class="w-full bg-gray-100 rounded-full h-2">
                        <div class="{{ $color }} h-2 rounded-full transition-all" style="width: {{ $pct }}%"></div>
                    </div>
                </div>
            </div>
            @empty
            <div class="bg-white rounded-2xl border border-dashed border-gray-200 p-12 text-center">
                <div class="text-4xl mb-3">📅</div>
                <p class="text-gray-400 text-sm">No date batches yet. Add your first retreat dates above.</p>
            </div>
            @endforelse
        </div>

        {{-- Right: Summary Stats --}}
        <div class="space-y-4">
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Quick Stats</h3>
                <div class="space-y-3">
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-gray-500">Total Batches</span>
                        <span class="font-semibold text-gray-900">{{ $batches->count() }}</span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-gray-500">Upcoming</span>
                        <span class="font-semibold text-gray-900">{{ $batches->where('start_date', '>', now())->count() }}</span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-gray-500">Total Spots</span>
                        <span class="font-semibold text-gray-900">{{ $batches->sum('max_participants') }}</span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-gray-500">Booked Spots</span>
                        <span class="font-semibold text-wellness-600">{{ $batches->sum('bookings_count') }}</span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-gray-500">Available Spots</span>
                        <span class="font-semibold text-lavender-600">
                            {{ $batches->sum('max_participants') - $batches->sum('bookings_count') }}
                        </span>
                    </div>
                    <hr class="border-gray-100">
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-gray-500">Revenue (booked)</span>
                        <span class="font-semibold text-gray-900">${{ number_format($stats['revenue'] ?? 0, 0) }}</span>
                    </div>
                </div>
            </div>

            <div class="bg-peach-50 border border-peach-200 rounded-2xl p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Bulk Actions</h3>
                <form method="POST" action="{{ route('retreats.batches.bulk', $experience) }}" class="space-y-3">
                    @csrf
                    <x-form-input name="repeat_from" label="Repeat From Date" type="date" />
                    <x-form-input name="repeat_count" label="Number of Occurrences" type="number" :value="3" />
                    <x-form-input name="repeat_interval" label="Interval" type="select"
                        :options="['7'=>'Weekly','14'=>'Bi-weekly','30'=>'Monthly']" />
                    <button type="submit"
                            class="w-full py-2.5 bg-peach-400 text-white text-sm font-semibold rounded-xl hover:bg-orange-500 transition-colors">
                        Generate Recurring Batches
                    </button>
                </form>
            </div>
        </div>
    </div>

    {{-- Edit Batch Modal --}}
    <div x-show="editBatch" x-cloak @click="editBatch = null"
         class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" style="display:none">
        <div @click.stop class="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h3 class="font-semibold text-gray-900 mb-4">Edit Batch</h3>
            <template x-if="editBatch">
                <form method="POST" :action="`/retreats/{{ $experience->id }}/batches/${editBatch.id}`" class="space-y-4">
                    @csrf
                    <input type="hidden" name="_method" value="PUT">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-medium text-gray-600 mb-1">Start Date</label>
                            <input type="date" name="start_date" :value="editBatch.start_date?.substring(0,10)"
                                class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                        </div>
                        <div>
                            <label class="block text-xs font-medium text-gray-600 mb-1">End Date</label>
                            <input type="date" name="end_date" :value="editBatch.end_date?.substring(0,10)"
                                class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Max Participants</label>
                        <input type="number" name="max_participants" :value="editBatch.max_participants"
                            class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Price Override ($)</label>
                        <input type="number" name="price_override" :value="editBatch.price_override"
                            class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Status</label>
                        <select name="status"
                            class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            <option value="open" :selected="editBatch.status === 'open'">Open</option>
                            <option value="closed" :selected="editBatch.status === 'closed'">Closed</option>
                            <option value="cancelled" :selected="editBatch.status === 'cancelled'">Cancelled</option>
                        </select>
                    </div>
                    <div class="flex justify-end gap-3 pt-2">
                        <button type="button" @click="editBatch = null"
                                class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                            Cancel
                        </button>
                        <button type="submit"
                                class="px-5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700">
                            Update Batch
                        </button>
                    </div>
                </form>
            </template>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
function availabilityManager(batches) {
    return { batches, showAddForm: false, editBatch: null };
}
</script>
@endpush
