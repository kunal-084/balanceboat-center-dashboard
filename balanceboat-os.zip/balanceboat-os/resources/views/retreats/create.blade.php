@extends('layouts.app')

@section('title', 'Create Retreat')
@section('page-title', 'Create Retreat')

@section('content')
<div class="max-w-4xl mx-auto" x-data="retreatWizard()" x-init="init()">

    {{-- Header --}}
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('retreats.index') }}" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
            <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
        </a>
        <div>
            <h1 class="font-serif text-xl font-bold text-gray-900">Create New Retreat</h1>
            <p class="text-xs text-gray-400 mt-0.5">Step <span x-text="currentStep"></span> of {{ count($tabs) ?? 8 }}</p>
        </div>
        <div class="ml-auto flex items-center gap-3">
            <button type="button" @click="saveDraft()" class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                Save Draft
            </button>
        </div>
    </div>

    {{-- Progress Bar --}}
    <div class="h-1.5 bg-gray-100 rounded-full mb-6 overflow-hidden">
        <div class="h-full bg-gradient-to-r from-lavender-500 to-lavender-600 rounded-full transition-all duration-500"
             :style="`width:${(currentStep / 8) * 100}%`"></div>
    </div>

    {{-- Tab Navigation --}}
    <div class="flex items-center gap-1 overflow-x-auto pb-2 mb-6">
        @php
        $wizardTabs = [
            ['key' => 1, 'icon' => '📝', 'label' => 'Basic Info'],
            ['key' => 2, 'icon' => '📍', 'label' => 'Location'],
            ['key' => 3, 'icon' => '🗓', 'label' => 'Schedule'],
            ['key' => 4, 'icon' => '💰', 'label' => 'Pricing'],
            ['key' => 5, 'icon' => '🏠', 'label' => 'Accommodations'],
            ['key' => 6, 'icon' => '🧘', 'label' => 'Itinerary'],
            ['key' => 7, 'icon' => '🖼', 'label' => 'Media'],
            ['key' => 8, 'icon' => '⚙️', 'label' => 'Settings'],
        ];
        @endphp
        @foreach($wizardTabs as $tab)
        <button
            type="button"
            @click="goToStep({{ $tab['key'] }})"
            :class="currentStep === {{ $tab['key'] }} ? 'bg-lavender-600 text-white shadow-sm' : (completedSteps.includes({{ $tab['key'] }}) ? 'bg-lavender-50 text-lavender-700' : 'text-gray-500 hover:bg-gray-100')"
            class="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all whitespace-nowrap flex-shrink-0"
        >
            <span>{{ $tab['icon'] }}</span>
            <span>{{ $tab['label'] }}</span>
            <span x-show="completedSteps.includes({{ $tab['key'] }}) && currentStep !== {{ $tab['key'] }}" class="text-wellness-500">✓</span>
        </button>
        @endforeach
    </div>

    <form method="POST" action="{{ route('retreats.store') }}" enctype="multipart/form-data" id="retreat-form">
        @csrf

        {{-- ── STEP 1: Basic Info ── --}}
        <div x-show="currentStep === 1" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <h2 class="font-semibold text-gray-900">Basic Information</h2>

                <x-form-input name="title" label="Retreat Title" required placeholder="e.g. 7-Day Ayurvedic Panchakarma Retreat" />

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="category_id" label="Category" type="select" required
                        :options="$categories->pluck('name','id')->toArray()"
                        placeholder="Select category" />
                    <x-form-input name="retreat_type" label="Type" type="select" required
                        :options="['yoga'=>'Yoga','meditation'=>'Meditation','ayurveda'=>'Ayurveda','detox'=>'Detox','wellness'=>'Wellness','spiritual'=>'Spiritual']"
                        placeholder="Select type" />
                </div>

                <x-form-input name="short_description" label="Short Description" type="textarea" rows="2" required
                    placeholder="A compelling 1-2 line summary for listings..." />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Description</label>
                    <textarea name="description" rows="6" id="description-editor"
                        class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-none"
                        placeholder="Detailed description — what guests will experience, benefits, highlights...">{{ old('description') }}</textarea>
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <x-form-input name="duration_nights" label="Duration (nights)" type="number" required
                        placeholder="7" :value="old('duration_nights')" />
                    <x-form-input name="max_participants" label="Max Participants" type="number" required
                        placeholder="20" :value="old('max_participants')" />
                    <x-form-input name="min_participants" label="Min Participants" type="number"
                        placeholder="5" :value="old('min_participants')" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Tags</label>
                    <input type="text" name="tags" value="{{ old('tags') }}"
                        placeholder="e.g. yoga, meditation, beach, detox (comma-separated)"
                        class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400">
                    <p class="text-xs text-gray-400 mt-1.5">Comma-separated tags to help guests discover your retreat</p>
                </div>
            </div>
        </div>

        {{-- ── STEP 2: Location ── --}}
        <div x-show="currentStep === 2" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <h2 class="font-semibold text-gray-900">Location & Venue</h2>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="venue_name" label="Venue Name" placeholder="Ananda Wellness Resort" />
                    <x-form-input name="country" label="Country" type="select"
                        :options="['IN'=>'India','US'=>'United States','TH'=>'Thailand','ID'=>'Indonesia','ES'=>'Spain','PT'=>'Portugal','GR'=>'Greece','NP'=>'Nepal','SL'=>'Sri Lanka','MV'=>'Maldives']"
                        placeholder="Select country" :selected="old('country','IN')" />
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="state" label="State / Region" placeholder="Kerala" />
                    <x-form-input name="city" label="City" placeholder="Varkala" />
                </div>

                <x-form-input name="address_line1" label="Address" placeholder="123 Beach Road" />

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="latitude" label="Latitude" type="number" placeholder="8.7347"
                        hint="Used for map display and distance calculations" />
                    <x-form-input name="longitude" label="Longitude" type="number" placeholder="76.7188" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Getting There</label>
                    <textarea name="getting_there" rows="3"
                        class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 resize-none"
                        placeholder="Nearest airport, transfer options, driving directions...">{{ old('getting_there') }}</textarea>
                </div>
            </div>
        </div>

        {{-- ── STEP 3: Schedule ── --}}
        <div x-show="currentStep === 3" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <h2 class="font-semibold text-gray-900">Dates & Schedule</h2>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="start_date" label="Start Date" type="date" />
                    <x-form-input name="end_date" label="End Date" type="date" />
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="check_in_time" label="Check-in Time" type="time" :value="old('check_in_time','14:00')" />
                    <x-form-input name="check_out_time" label="Check-out Time" type="time" :value="old('check_out_time','11:00')" />
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <x-form-input name="booking_deadline_days" label="Booking Closes (days before)" type="number" :value="old('booking_deadline_days',3)"
                        hint="Days before start date when bookings stop" />
                    <x-form-input name="cancellation_days" label="Free Cancellation (days before)" type="number" :value="old('cancellation_days',14)" />
                    <x-form-input name="deposit_percentage" label="Deposit (%)" type="number" :value="old('deposit_percentage',30)"
                        hint="% required to confirm booking" />
                </div>

                {{-- Teacher Assignment --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Lead Teachers</label>
                    <div class="grid grid-cols-2 gap-3">
                        @foreach($teachers ?? [] as $teacher)
                        <label class="flex items-center gap-2.5 p-3 rounded-xl border border-gray-100 cursor-pointer hover:border-lavender-200 hover:bg-lavender-50 transition-all">
                            <input type="checkbox" name="teacher_ids[]" value="{{ $teacher->id }}"
                                {{ in_array($teacher->id, old('teacher_ids', [])) ? 'checked' : '' }}
                                class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                            <div class="flex items-center gap-2">
                                <div class="w-7 h-7 bg-lavender-100 rounded-full flex items-center justify-center text-xs font-bold text-lavender-700">
                                    {{ strtoupper(substr($teacher->name, 0, 1)) }}
                                </div>
                                <span class="text-sm text-gray-700">{{ $teacher->name }}</span>
                            </div>
                        </label>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        {{-- ── STEP 4: Pricing ── --}}
        <div x-show="currentStep === 4" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <h2 class="font-semibold text-gray-900">Pricing</h2>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="base_price" label="Base Price (per person)" type="number"
                        required placeholder="1500" prefix="$" />
                    <x-form-input name="currency" label="Currency" type="select"
                        :options="['USD'=>'USD — US Dollar','EUR'=>'EUR — Euro','INR'=>'INR — Indian Rupee','GBP'=>'GBP — Pound','SGD'=>'SGD — Singapore Dollar']"
                        :selected="old('currency','USD')" />
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="single_supplement" label="Single Supplement" type="number"
                        placeholder="300" hint="Extra charge for single occupancy" prefix="$" />
                    <x-form-input name="early_bird_discount" label="Early Bird Discount" type="number"
                        placeholder="10" hint="% off if booked 60+ days early" suffix="%" />
                </div>

                {{-- Inclusions / Exclusions --}}
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Inclusions</label>
                        <textarea name="inclusions" rows="5"
                            class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 resize-none"
                            placeholder="Daily yoga classes&#10;All meals (vegan)&#10;Airport transfers&#10;Wellness treatments">{{ old('inclusions') }}</textarea>
                        <p class="text-xs text-gray-400 mt-1">One item per line</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Exclusions</label>
                        <textarea name="exclusions" rows="5"
                            class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 resize-none"
                            placeholder="International flights&#10;Travel insurance&#10;Personal expenses">{{ old('exclusions') }}</textarea>
                        <p class="text-xs text-gray-400 mt-1">One item per line</p>
                    </div>
                </div>
            </div>
        </div>

        {{-- ── STEP 5: Accommodations ── --}}
        <div x-show="currentStep === 5" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <div class="flex items-center justify-between">
                    <h2 class="font-semibold text-gray-900">Accommodation Options</h2>
                    <button type="button" @click="addAccommodation()" class="text-sm text-lavender-600 font-medium hover:text-lavender-800">
                        + Add Option
                    </button>
                </div>

                <template x-for="(acc, i) in accommodations" :key="i">
                    <div class="border border-gray-100 rounded-xl p-4 space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-sm font-medium text-gray-700">Option <span x-text="i + 1"></span></span>
                            <button type="button" @click="accommodations.splice(i, 1)" class="text-xs text-red-500 hover:text-red-700">Remove</button>
                        </div>
                        <div class="grid grid-cols-3 gap-3">
                            <div>
                                <label class="block text-xs font-medium text-gray-600 mb-1">Room Type</label>
                                <input type="text" :name="`accommodations[${i}][name]`" x-model="acc.name"
                                    placeholder="Deluxe Double" class="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:border-lavender-400">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-600 mb-1">Occupancy</label>
                                <select :name="`accommodations[${i}][occupancy]`" x-model="acc.occupancy"
                                    class="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:border-lavender-400">
                                    <option>Single</option>
                                    <option>Double</option>
                                    <option>Triple</option>
                                    <option>Dormitory</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-600 mb-1">Price Modifier</label>
                                <input type="number" :name="`accommodations[${i}][price_modifier]`" x-model="acc.price_modifier"
                                    placeholder="0" class="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:border-lavender-400">
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-medium text-gray-600 mb-1">Description</label>
                            <input type="text" :name="`accommodations[${i}][description]`" x-model="acc.description"
                                placeholder="Air-conditioned room with garden view, private bathroom..."
                                class="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:border-lavender-400">
                        </div>
                    </div>
                </template>

                <div x-show="!accommodations.length" class="text-center py-8 text-gray-400 text-sm">
                    No accommodation options yet. Click "Add Option" to add room types.
                </div>
            </div>
        </div>

        {{-- ── STEP 6: Itinerary ── --}}
        <div x-show="currentStep === 6" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <div class="flex items-center justify-between">
                    <h2 class="font-semibold text-gray-900">Daily Itinerary</h2>
                    <button type="button" @click="addDay()" class="text-sm text-lavender-600 font-medium hover:text-lavender-800">
                        + Add Day
                    </button>
                </div>

                <template x-for="(day, i) in itinerary" :key="i">
                    <div class="border border-gray-100 rounded-xl overflow-hidden">
                        <div class="flex items-center justify-between px-4 py-3 bg-lavender-50">
                            <div class="flex items-center gap-2">
                                <span class="w-7 h-7 bg-lavender-600 rounded-lg flex items-center justify-center text-white text-xs font-bold" x-text="i + 1"></span>
                                <input type="text" :name="`itinerary[${i}][title]`" x-model="day.title"
                                    placeholder="Arrival & Orientation"
                                    class="bg-transparent text-sm font-medium text-lavender-900 outline-none placeholder-lavender-300">
                            </div>
                            <button type="button" @click="itinerary.splice(i, 1)" class="text-xs text-red-400 hover:text-red-600">Remove</button>
                        </div>
                        <div class="p-4">
                            <textarea :name="`itinerary[${i}][description]`" x-model="day.description" rows="3"
                                placeholder="Activities, meals, sessions for this day..."
                                class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg outline-none focus:border-lavender-400 resize-none"></textarea>
                        </div>
                    </div>
                </template>

                <div x-show="!itinerary.length" class="text-center py-8 text-gray-400 text-sm">
                    Add daily itinerary items to help guests understand the retreat schedule.
                </div>
            </div>
        </div>

        {{-- ── STEP 7: Media ── --}}
        <div x-show="currentStep === 7" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <h2 class="font-semibold text-gray-900">Photos & Media</h2>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Cover Image</label>
                    <x-media-uploader name="cover_image" accept="image/*" :multiple="false" label="Upload cover photo (1920×1080 recommended)" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Gallery Photos</label>
                    <x-media-uploader name="gallery" accept="image/*" :multiple="true" label="Upload up to 20 gallery photos" :max-mb="20" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Video URL</label>
                    <input type="url" name="video_url" value="{{ old('video_url') }}"
                        placeholder="https://youtube.com/watch?v=... or Vimeo URL"
                        class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400">
                    <p class="text-xs text-gray-400 mt-1.5">YouTube or Vimeo link for a promo video</p>
                </div>
            </div>
        </div>

        {{-- ── STEP 8: Settings ── --}}
        <div x-show="currentStep === 8" class="space-y-5">
            <div class="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
                <h2 class="font-semibold text-gray-900">Settings & SEO</h2>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="slug" label="URL Slug" placeholder="7-day-ayurvedic-retreat-kerala"
                        hint="Auto-generated from title if empty" />
                    <x-form-input name="language" label="Language" type="select"
                        :options="['en'=>'English','hi'=>'Hindi','es'=>'Spanish','fr'=>'French','de'=>'German']"
                        :selected="old('language','en')" />
                </div>

                <x-form-input name="seo_title" label="SEO Title" placeholder="Leave blank to use retreat title" />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">SEO Meta Description</label>
                    <textarea name="seo_description" rows="2"
                        class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 resize-none"
                        placeholder="Brief description for search engines (150-160 chars)...">{{ old('seo_description') }}</textarea>
                </div>

                <div class="space-y-3">
                    <h3 class="text-sm font-medium text-gray-700">Visibility Options</h3>
                    @foreach([
                        ['is_featured','Featured on homepage'],
                        ['accept_instant_booking','Accept instant booking (no approval required)'],
                        ['allow_partial_payment','Allow partial payment / deposit'],
                        ['requires_health_form','Require health questionnaire before booking'],
                    ] as [$field, $fieldLabel])
                    <label class="flex items-center gap-3 p-3 rounded-xl border border-gray-100 cursor-pointer hover:bg-lavender-50 transition-colors">
                        <input type="checkbox" name="{{ $field }}" value="1"
                            {{ old($field) ? 'checked' : '' }}
                            class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                        <span class="text-sm text-gray-700">{{ $fieldLabel }}</span>
                    </label>
                    @endforeach
                </div>
            </div>
        </div>

        {{-- Navigation Buttons --}}
        <div class="flex items-center justify-between mt-6">
            <button type="button" @click="prevStep()"
                x-show="currentStep > 1"
                class="flex items-center gap-2 px-4 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
                Previous
            </button>
            <div class="flex items-center gap-3 ml-auto">
                <button type="button" @click="nextStep()"
                    x-show="currentStep < 8"
                    class="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold bg-lavender-600 text-white rounded-xl hover:bg-lavender-700 transition-colors">
                    Next
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                    </svg>
                </button>
                <button type="submit"
                    x-show="currentStep === 8"
                    class="flex items-center gap-2 px-6 py-2.5 text-sm font-semibold bg-lavender-600 text-white rounded-xl hover:bg-lavender-700 transition-colors">
                    Create Retreat
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                    </svg>
                </button>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
function retreatWizard() {
    return {
        currentStep: 1,
        completedSteps: [],
        accommodations: [{ name: '', occupancy: 'Double', price_modifier: 0, description: '' }],
        itinerary: [],

        init() {
            const saved = sessionStorage.getItem('retreat_draft');
            if (saved) {
                const d = JSON.parse(saved);
                this.currentStep    = d.step || 1;
                this.accommodations = d.accommodations || this.accommodations;
                this.itinerary      = d.itinerary || [];
            }
        },

        goToStep(step) {
            if (step <= this.currentStep || this.completedSteps.includes(step - 1) || step === 1) {
                if (!this.completedSteps.includes(this.currentStep)) {
                    this.completedSteps.push(this.currentStep);
                }
                this.currentStep = step;
                this.autosave();
            }
        },

        nextStep() {
            if (!this.completedSteps.includes(this.currentStep)) {
                this.completedSteps.push(this.currentStep);
            }
            if (this.currentStep < 8) {
                this.currentStep++;
                this.autosave();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        },

        prevStep() {
            if (this.currentStep > 1) {
                this.currentStep--;
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        },

        addAccommodation() {
            this.accommodations.push({ name: '', occupancy: 'Double', price_modifier: 0, description: '' });
        },

        addDay() {
            this.itinerary.push({ title: `Day ${this.itinerary.length + 1}`, description: '' });
        },

        autosave() {
            sessionStorage.setItem('retreat_draft', JSON.stringify({
                step: this.currentStep,
                accommodations: this.accommodations,
                itinerary: this.itinerary,
            }));
        },

        saveDraft() {
            document.getElementById('retreat-form').submit();
        }
    };
}
</script>
@endpush
