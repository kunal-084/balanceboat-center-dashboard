@extends('layouts.app')

@section('title', 'Retreats')
@section('page-title', 'Retreats')

@section('content')
<div class="space-y-6">

    {{-- Page Header --}}
    <div class="flex items-center justify-between">
        <div>
            <p class="text-gray-500 text-sm mt-0.5">Manage and publish your retreat experiences</p>
        </div>
        <div class="flex items-center gap-3">
            <a href="{{ route('retreats.create') }}"
               class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-semibold hover:bg-lavender-700 transition-colors shadow-sm">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                </svg>
                New Retreat
            </a>
        </div>
    </div>

    {{-- Flash Alerts --}}
    <x-alert />

    {{-- Status Tabs --}}
    <div class="flex items-center gap-1 bg-gray-100/70 rounded-xl p-1 w-fit">
        @php
        $tabs = [
            ['status' => '', 'label' => 'All', 'count' => $counts['all'] ?? 0],
            ['status' => 'published', 'label' => 'Published', 'count' => $counts['published'] ?? 0],
            ['status' => 'draft', 'label' => 'Drafts', 'count' => $counts['draft'] ?? 0],
            ['status' => 'archived', 'label' => 'Archived', 'count' => $counts['archived'] ?? 0],
        ];
        $currentStatus = request('status', '');
        @endphp
        @foreach($tabs as $tab)
        <a href="{{ request()->fullUrlWithQuery(['status' => $tab['status'], 'page' => 1]) }}"
           class="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all
           {{ $currentStatus === $tab['status'] ? 'bg-white text-lavender-700 shadow-sm' : 'text-gray-500 hover:text-gray-700' }}">
            {{ $tab['label'] }}
            <span class="text-xs px-1.5 py-0.5 rounded-full {{ $currentStatus === $tab['status'] ? 'bg-lavender-50 text-lavender-600' : 'bg-gray-200 text-gray-500' }}">
                {{ $tab['count'] }}
            </span>
        </a>
        @endforeach
    </div>

    {{-- Filters Bar --}}
    <form method="GET" action="{{ route('retreats.index') }}" class="flex items-center gap-3 flex-wrap">
        <input type="hidden" name="status" value="{{ request('status') }}">

        <div class="relative flex-1 min-w-[220px]">
            <input type="text" name="search" value="{{ request('search') }}"
                placeholder="Search retreats..."
                class="w-full pl-9 pr-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 bg-white">
            <svg class="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 15.803 7.5 7.5 0 0016.803 15.803z"/>
            </svg>
        </div>

        <select name="category_id" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="">All Categories</option>
            @foreach($categories ?? [] as $cat)
            <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
            @endforeach
        </select>

        <select name="sort" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="latest" {{ request('sort') === 'latest' ? 'selected' : '' }}>Latest</option>
            <option value="oldest" {{ request('sort') === 'oldest' ? 'selected' : '' }}>Oldest</option>
            <option value="popular" {{ request('sort') === 'popular' ? 'selected' : '' }}>Most Popular</option>
            <option value="revenue" {{ request('sort') === 'revenue' ? 'selected' : '' }}>Highest Revenue</option>
        </select>

        <button type="submit" class="px-4 py-2.5 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700 transition-colors">
            Filter
        </button>
        @if(request()->hasAny(['search', 'category_id', 'sort']))
        <a href="{{ route('retreats.index', ['status' => request('status')]) }}" class="px-3 py-2.5 text-sm text-gray-500 hover:text-gray-700 border border-gray-200 rounded-xl bg-white">
            Clear
        </a>
        @endif
    </form>

    {{-- Retreat Grid --}}
    @if($retreats->count())
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        @foreach($retreats as $retreat)
        <div class="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg hover:shadow-lavender-100/50 transition-all duration-300 group flex flex-col">

            {{-- Thumbnail --}}
            <div class="relative h-44 bg-lavender-50 overflow-hidden">
                @if($retreat->cover_image_url)
                <img src="{{ $retreat->cover_image_url }}" alt="{{ $retreat->title }}"
                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                @else
                <div class="w-full h-full flex items-center justify-center">
                    <span class="text-5xl">🧘</span>
                </div>
                @endif

                <div class="absolute top-3 left-3">
                    <x-status-badge :status="$retreat->status" />
                </div>

                @if($retreat->is_featured)
                <div class="absolute top-3 right-3 bg-peach-400 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                    ⭐ FEATURED
                </div>
                @endif
            </div>

            {{-- Body --}}
            <div class="p-5 flex flex-col flex-1">
                <div class="flex items-start justify-between gap-2 mb-2">
                    <h3 class="font-semibold text-gray-900 text-sm leading-snug line-clamp-2 group-hover:text-lavender-700 transition-colors">
                        {{ $retreat->title }}
                    </h3>
                </div>

                @if($retreat->category)
                <span class="text-xs text-lavender-600 font-medium mb-2">{{ $retreat->category->name }}</span>
                @endif

                <p class="text-xs text-gray-500 line-clamp-2 mb-4 flex-1">{{ $retreat->short_description }}</p>

                {{-- Meta Row --}}
                <div class="flex items-center justify-between text-xs text-gray-500 mb-4">
                    <div class="flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5"/>
                        </svg>
                        {{ $retreat->duration_nights ?? '—' }} nights
                    </div>
                    <div class="flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/>
                        </svg>
                        {{ $retreat->max_participants }} spots
                    </div>
                    <div class="font-semibold text-lavender-700">${{ number_format($retreat->base_price, 0) }}</div>
                </div>

                {{-- Actions --}}
                <div class="flex items-center gap-2 pt-3 border-t border-gray-50">
                    <a href="{{ route('retreats.show', $retreat) }}"
                       class="flex-1 text-center py-2 text-xs font-medium text-gray-600 hover:text-lavender-700 hover:bg-lavender-50 rounded-lg transition-colors">
                        View
                    </a>
                    <a href="{{ route('retreats.edit', $retreat) }}"
                       class="flex-1 text-center py-2 text-xs font-medium text-gray-600 hover:text-lavender-700 hover:bg-lavender-50 rounded-lg transition-colors">
                        Edit
                    </a>

                    @if($retreat->status === 'draft')
                    <form method="POST" action="{{ route('retreats.publish', $retreat) }}" class="flex-1">
                        @csrf @method('PATCH')
                        <button type="submit" class="w-full py-2 text-xs font-medium text-wellness-600 hover:bg-wellness-50 rounded-lg transition-colors">
                            Publish
                        </button>
                    </form>
                    @else
                    <form method="POST" action="{{ route('retreats.unpublish', $retreat) }}" class="flex-1">
                        @csrf @method('PATCH')
                        <button type="submit" class="w-full py-2 text-xs font-medium text-amber-600 hover:bg-amber-50 rounded-lg transition-colors">
                            Unpublish
                        </button>
                    </form>
                    @endif

                    <div x-data="{ open: false }" class="relative">
                        <button @click="open = !open" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 5v.01M12 12v.01M12 19v.01"/>
                            </svg>
                        </button>
                        <div x-show="open" @click.outside="open = false"
                             class="absolute right-0 bottom-full mb-1 w-36 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-10">
                            <a href="{{ route('retreats.duplicate', $retreat) }}" class="block px-3.5 py-2 text-xs text-gray-700 hover:bg-lavender-50 hover:text-lavender-700">
                                Duplicate
                            </a>
                            <a href="{{ route('retreats.availability', $retreat) }}" class="block px-3.5 py-2 text-xs text-gray-700 hover:bg-lavender-50 hover:text-lavender-700">
                                Availability
                            </a>
                            <form method="POST" action="{{ route('retreats.destroy', $retreat) }}">
                                @csrf @method('DELETE')
                                <button type="submit"
                                        onclick="return confirm('Delete this retreat?')"
                                        class="w-full text-left px-3.5 py-2 text-xs text-red-600 hover:bg-red-50">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    {{-- Pagination --}}
    <div>{{ $retreats->links() }}</div>

    @else
    {{-- Empty State --}}
    <div class="bg-white rounded-2xl border border-gray-100 py-20 text-center">
        <div class="text-6xl mb-4">🧘</div>
        <h3 class="font-semibold text-gray-900 mb-2">No retreats yet</h3>
        <p class="text-gray-400 text-sm mb-6">Create your first retreat experience to get started.</p>
        <a href="{{ route('retreats.create') }}"
           class="inline-flex items-center gap-2 px-5 py-2.5 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            Create Retreat
        </a>
    </div>
    @endif

</div>
@endsection
