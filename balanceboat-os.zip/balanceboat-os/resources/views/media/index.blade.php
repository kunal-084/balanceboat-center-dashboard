@extends('layouts.app')

@section('title', 'Media Library')
@section('page-title', 'Media Library')

@section('content')
<div class="space-y-6" x-data="mediaLibrary()">

    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Manage images, videos, and documents for your center</p>
        <div class="flex items-center gap-3">
            <span class="text-sm text-gray-400">{{ $totalSize ?? '0 MB' }} used</span>
            <button @click="showUpload = !showUpload"
                    class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-semibold hover:bg-lavender-700 transition-colors">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"/>
                </svg>
                Upload Files
            </button>
        </div>
    </div>

    <x-alert />

    {{-- Upload Area --}}
    <div x-show="showUpload" x-transition class="bg-white rounded-2xl border border-lavender-200 p-6">
        <h3 class="font-semibold text-gray-900 mb-4">Upload Media</h3>
        <form method="POST" action="{{ route('media.upload') }}" enctype="multipart/form-data">
            @csrf
            <x-media-uploader name="files" accept="image/*,video/*,application/pdf" :multiple="true" :max-mb="50"
                label="Drop images, videos, or PDFs here (max 50MB each)" />
            <div class="mt-4 flex items-center gap-3">
                <x-form-input name="folder" label="" placeholder="Folder name (optional, e.g. retreats/kerala-2025)"
                    class="flex-1" />
                <button type="submit" class="px-4 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 mt-auto">
                    Upload
                </button>
            </div>
        </form>
    </div>

    {{-- Filters + Search --}}
    <div class="flex items-center gap-3 flex-wrap">
        <div class="relative flex-1 min-w-[200px]">
            <input type="text" x-model="search" @input.debounce.300ms="filterMedia()" placeholder="Search files..."
                class="w-full pl-9 pr-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white">
            <svg class="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 15.803 7.5 7.5 0 0016.803 15.803z"/>
            </svg>
        </div>

        <div class="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
            @foreach(['all','image','video','document'] as $type)
            <button @click="filterType = '{{ $type }}'; filterMedia()"
                    :class="filterType === '{{ $type }}' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'"
                    class="px-3 py-1.5 text-xs font-medium rounded-md transition-all capitalize">
                {{ ucfirst($type) }}
            </button>
            @endforeach
        </div>

        <div class="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
            <button @click="gridCols = 'cols-4'" :class="gridCols === 'cols-4' ? 'bg-white shadow-sm' : ''" class="p-1.5 rounded-md transition-all">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zm0 9.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zm9.75-9.75A2.25 2.25 0 0115.75 3.75H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zm0 9.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z"/>
                </svg>
            </button>
            <button @click="gridCols = 'cols-6'" :class="gridCols === 'cols-6' ? 'bg-white shadow-sm' : ''" class="p-1.5 rounded-md transition-all">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 4.5v15m6-15v15m-10.875 0h15.75c.621 0 1.125-.504 1.125-1.125V5.625c0-.621-.504-1.125-1.125-1.125H4.125C3.504 4.5 3 5.004 3 5.625v12.75c0 .621.504 1.125 1.125 1.125z"/>
                </svg>
            </button>
        </div>
    </div>

    {{-- Media Grid --}}
    <div :class="`grid gap-3 grid-${gridCols}`" id="media-grid">
        @forelse($mediaFiles as $file)
        <div class="relative group bg-white rounded-xl border border-gray-100 overflow-hidden aspect-square cursor-pointer hover:border-lavender-200 transition-all"
             @click="openPreview('{{ $file->url }}', '{{ $file->name }}', '{{ $file->type }}')">
            @if($file->type === 'image')
            <img src="{{ $file->thumbnail_url ?? $file->url }}" alt="{{ $file->name }}"
                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
            @elseif($file->type === 'video')
            <div class="w-full h-full bg-gray-900 flex items-center justify-center">
                <svg class="w-10 h-10 text-white/70" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z"/>
                </svg>
            </div>
            @else
            <div class="w-full h-full bg-gray-50 flex flex-col items-center justify-center p-3">
                <svg class="w-10 h-10 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                <span class="text-xs text-gray-400 text-center truncate w-full">{{ $file->name }}</span>
            </div>
            @endif

            {{-- Overlay --}}
            <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-2">
                <div class="flex justify-end">
                    <form method="POST" action="{{ route('media.destroy', $file) }}" @click.stop>
                        @csrf @method('DELETE')
                        <button onclick="return confirm('Delete this file?')"
                                class="p-1 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">
                            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                        </button>
                    </form>
                </div>
                <div>
                    <p class="text-white text-[10px] truncate">{{ $file->name }}</p>
                    <p class="text-white/60 text-[10px]">{{ $file->size_human }}</p>
                </div>
            </div>
        </div>
        @empty
        <div class="col-span-6 text-center py-20">
            <div class="text-5xl mb-4">🖼️</div>
            <p class="text-gray-400 text-sm">No media uploaded yet.</p>
        </div>
        @endforelse
    </div>

    {{-- Pagination --}}
    <div>{{ $mediaFiles->links() }}</div>

    {{-- Preview Modal --}}
    <div x-show="preview" x-cloak @click="preview=null" class="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" style="display:none">
        <div @click.stop class="max-w-3xl w-full">
            <template x-if="previewType === 'image'">
                <img :src="previewUrl" class="w-full max-h-[80vh] object-contain rounded-2xl">
            </template>
            <div class="mt-3 flex items-center justify-between">
                <span class="text-white/70 text-sm" x-text="previewName"></span>
                <div class="flex gap-2">
                    <a :href="previewUrl" target="_blank" class="px-3 py-1.5 bg-white/20 text-white text-xs rounded-lg hover:bg-white/30">
                        Open Full Size
                    </a>
                    <button @click="navigator.clipboard.writeText(previewUrl)" class="px-3 py-1.5 bg-white/20 text-white text-xs rounded-lg hover:bg-white/30">
                        Copy URL
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
function mediaLibrary() {
    return {
        showUpload: false,
        search: '',
        filterType: 'all',
        gridCols: 'cols-4',
        preview: null,
        previewUrl: null,
        previewName: null,
        previewType: null,

        openPreview(url, name, type) {
            this.previewUrl = url;
            this.previewName = name;
            this.previewType = type;
            this.preview = true;
        },

        filterMedia() {
            // AJAX filter could be wired here for large libraries
        }
    };
}
</script>
@endpush
