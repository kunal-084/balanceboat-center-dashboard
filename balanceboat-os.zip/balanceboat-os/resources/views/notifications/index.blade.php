@extends('layouts.app')

@section('title', 'Notifications')
@section('page-title', 'Notifications')

@section('content')
<div class="space-y-4 max-w-3xl">

    <div class="flex items-center justify-between">
        <p class="text-sm text-gray-400">{{ $notifications->total() }} notifications</p>
        <div class="flex items-center gap-3">
            <form method="POST" action="{{ route('notifications.mark-all-read') }}">
                @csrf
                <button type="submit" class="text-sm text-lavender-600 font-medium hover:text-lavender-700">
                    Mark all as read
                </button>
            </form>
            <form method="POST" action="{{ route('notifications.clear-all') }}">
                @csrf
                <button type="submit" onclick="return confirm('Clear all notifications?')"
                        class="text-sm text-gray-400 hover:text-red-500 font-medium">
                    Clear all
                </button>
            </form>
        </div>
    </div>

    <x-alert />

    @forelse($notifications as $notification)
    @php
        $data    = $notification->data;
        $isRead  = $notification->read_at !== null;
        $icon    = $data['icon']  ?? '🔔';
        $title   = $data['title'] ?? 'Notification';
        $body    = $data['body']  ?? '';
        $url     = $data['url']   ?? null;
    @endphp
    <div class="bg-white rounded-2xl border {{ $isRead ? 'border-gray-100' : 'border-lavender-200' }} shadow-sm p-5
                {{ $isRead ? '' : 'bg-lavender-50/30' }} transition-all">
        <div class="flex items-start gap-4">

            {{-- Icon --}}
            <div class="w-10 h-10 rounded-xl {{ $isRead ? 'bg-gray-100' : 'bg-lavender-100' }} flex items-center justify-center text-lg shrink-0">
                {{ $icon }}
            </div>

            {{-- Content --}}
            <div class="flex-1 min-w-0">
                <div class="flex items-start justify-between gap-3">
                    <div class="flex-1">
                        <div class="flex items-center gap-2">
                            <p class="text-sm font-{{ $isRead ? 'normal' : 'semibold' }} text-gray-900">{{ $title }}</p>
                            @if(!$isRead)
                            <span class="w-2 h-2 bg-lavender-500 rounded-full shrink-0"></span>
                            @endif
                        </div>
                        @if($body)
                        <p class="text-sm text-gray-500 mt-0.5">{{ $body }}</p>
                        @endif
                        <div class="flex items-center gap-3 mt-2">
                            <span class="text-xs text-gray-400">{{ $notification->created_at->diffForHumans() }}</span>
                            @if($url)
                            <a href="{{ $url }}" class="text-xs text-lavender-600 font-medium hover:underline">View →</a>
                            @endif
                        </div>
                    </div>

                    {{-- Actions --}}
                    <div class="flex items-center gap-1 shrink-0">
                        @if(!$isRead)
                        <form method="POST" action="{{ route('notifications.read', $notification->id) }}">
                            @csrf @method('PATCH')
                            <button type="submit"
                                    class="p-1.5 text-gray-300 hover:text-lavender-600 hover:bg-lavender-50 rounded-lg transition-colors"
                                    title="Mark as read">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                            </button>
                        </form>
                        @endif
                        <form method="POST" action="{{ route('notifications.destroy', $notification->id) }}">
                            @csrf @method('DELETE')
                            <button type="submit"
                                    class="p-1.5 text-gray-300 hover:text-red-400 hover:bg-red-50 rounded-lg transition-colors"
                                    title="Delete">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @empty
    <div class="bg-white rounded-2xl border border-dashed border-gray-200 p-16 text-center">
        <div class="text-5xl mb-4">🔔</div>
        <p class="text-gray-400 text-sm font-medium">No notifications yet.</p>
        <p class="text-gray-300 text-xs mt-1">We'll let you know when something needs your attention.</p>
    </div>
    @endforelse

    <div>{{ $notifications->links() }}</div>

</div>
@endsection
