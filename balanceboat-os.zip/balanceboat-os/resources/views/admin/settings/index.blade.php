@extends('layouts.app')

@section('title', 'Platform Settings')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-6">

    <h2 class="text-lg font-semibold text-gray-900">Platform Settings</h2>

    <x-alert />

    <form method="POST" action="{{ route('admin.settings.update') }}" class="space-y-5">
        @csrf @method('PUT')

        {{-- Platform --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h3 class="font-semibold text-gray-900 mb-5">Platform</h3>
            <div class="grid grid-cols-2 gap-5">
                <x-form-input name="platform_name" label="Platform Name"
                    :value="$settings->get('platform_name', 'BalanceBoat Center OS')" />
                <x-form-input name="support_email" label="Support Email" type="email"
                    :value="$settings->get('support_email')" />
                <x-form-input name="platform_url" label="Platform URL"
                    :value="$settings->get('platform_url', config('app.url'))" />
                <x-form-input name="default_timezone" label="Default Timezone"
                    :value="$settings->get('default_timezone', 'UTC')" />

                <div class="col-span-2 space-y-3">
                    @foreach([
                        ['key'=>'registration_enabled', 'label'=>'Open Registration', 'desc'=>'Allow new centers to sign up'],
                        ['key'=>'trial_enabled',        'label'=>'Free Trial',        'desc'=>'Offer a trial period to new centers'],
                        ['key'=>'maintenance_mode',     'label'=>'Maintenance Mode',  'desc'=>'Show maintenance page to non-admins'],
                    ] as $toggle)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $toggle['label'] }}</div>
                            <div class="text-xs text-gray-400">{{ $toggle['desc'] }}</div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="{{ $toggle['key'] }}" value="1"
                                {{ $settings->get($toggle['key']) ? 'checked' : '' }}
                                class="sr-only peer">
                            <div class="w-9 h-5 bg-gray-200 rounded-full peer-checked:bg-lavender-600 transition-colors"></div>
                            <div class="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform peer-checked:translate-x-4"></div>
                        </label>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        {{-- Trial Settings --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h3 class="font-semibold text-gray-900 mb-5">Trial & Onboarding</h3>
            <div class="grid grid-cols-3 gap-4">
                <x-form-input name="trial_days" label="Trial Duration (days)" type="number"
                    :value="$settings->get('trial_days', 14)" />
                <x-form-input name="trial_plan_id" label="Trial Plan ID" type="number"
                    :value="$settings->get('trial_plan_id')" hint="Plan ID granted during trial" />
                <x-form-input name="welcome_email_delay_hours" label="Welcome Email Delay (hrs)" type="number"
                    :value="$settings->get('welcome_email_delay_hours', 1)" />
            </div>
        </div>

        {{-- Billing --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h3 class="font-semibold text-gray-900 mb-5">Billing</h3>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="platform_fee_percent" label="Platform Fee (%)" type="number" step="0.1"
                    :value="$settings->get('platform_fee_percent', 0)"
                    hint="Percentage taken from each booking (0 = none)" />
                <x-form-input name="stripe_webhook_endpoint" label="Stripe Webhook URL" readonly
                    :value="url('/webhooks/stripe')" />
            </div>
        </div>

        {{-- Email --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h3 class="font-semibold text-gray-900 mb-5">System Email</h3>
            <div class="grid grid-cols-2 gap-4">
                <x-form-input name="system_from_name" label="From Name"
                    :value="$settings->get('system_from_name', 'BalanceBoat')" />
                <x-form-input name="system_from_email" label="From Email" type="email"
                    :value="$settings->get('system_from_email')" />
                <x-form-input name="admin_alert_email" label="Admin Alert Email" type="email"
                    :value="$settings->get('admin_alert_email')" hint="Receives critical platform alerts" />
            </div>
        </div>

        {{-- Danger Zone --}}
        <div class="bg-red-50 rounded-2xl border border-red-100 p-6">
            <h3 class="font-semibold text-red-700 mb-4">Danger Zone</h3>
            <div class="space-y-3">
                <div class="flex items-center justify-between p-3 bg-white border border-red-100 rounded-xl">
                    <div>
                        <div class="text-sm font-medium text-gray-900">Clear All Caches</div>
                        <div class="text-xs text-gray-400">Clears config, route, view, and application caches</div>
                    </div>
                    <form method="POST" action="{{ route('admin.settings.clear-cache') }}">
                        @csrf
                        <button type="submit" class="px-3 py-1.5 text-xs font-semibold text-red-600 border border-red-200 rounded-lg hover:bg-red-50">
                            Clear Caches
                        </button>
                    </form>
                </div>
                <div class="flex items-center justify-between p-3 bg-white border border-red-100 rounded-xl">
                    <div>
                        <div class="text-sm font-medium text-gray-900">Restart Queue Workers</div>
                        <div class="text-xs text-gray-400">Gracefully restarts all queue worker processes</div>
                    </div>
                    <form method="POST" action="{{ route('admin.settings.restart-queues') }}">
                        @csrf
                        <button type="submit" class="px-3 py-1.5 text-xs font-semibold text-red-600 border border-red-200 rounded-lg hover:bg-red-50">
                            Restart Queues
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="px-6 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                Save Platform Settings
            </button>
        </div>
    </form>

</div>
@endsection
