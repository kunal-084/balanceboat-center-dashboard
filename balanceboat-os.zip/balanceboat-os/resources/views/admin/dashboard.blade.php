@extends('layouts.app')

@section('title', 'Platform Dashboard')
@section('page-title', 'Platform Overview')

@section('content')
<div class="space-y-6">

    {{-- Admin banner --}}
    <div class="bg-gradient-to-r from-violet-700 to-indigo-700 text-white rounded-2xl p-5 flex items-center gap-4">
        <div class="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">🛡️</div>
        <div>
            <div class="font-semibold">BalanceBoat Admin</div>
            <div class="text-violet-200 text-xs mt-0.5">You have super-admin access to all platform data.</div>
        </div>
        <div class="ml-auto flex gap-2">
            <a href="{{ route('admin.centers.index') }}" class="px-3 py-1.5 bg-white/20 hover:bg-white/30 text-sm font-medium rounded-lg transition-colors">
                Centers
            </a>
            <a href="{{ route('admin.users.index') }}" class="px-3 py-1.5 bg-white/20 hover:bg-white/30 text-sm font-medium rounded-lg transition-colors">
                Users
            </a>
        </div>
    </div>

    {{-- KPI Row --}}
    <div class="grid grid-cols-3 lg:grid-cols-6 gap-4">
        @foreach([
            ['label'=>'Total Centers',      'value'=>$stats['total_centers'],     'icon'=>'🏠', 'color'=>'lavender'],
            ['label'=>'Active Centers',     'value'=>$stats['active_centers'],    'icon'=>'✅', 'color'=>'wellness'],
            ['label'=>'Total Users',        'value'=>$stats['total_users'],       'icon'=>'👥', 'color'=>'blue'],
            ['label'=>'MRR',                'value'=>'$'.number_format($stats['mrr']), 'icon'=>'💰', 'color'=>'amber'],
            ['label'=>'New This Month',     'value'=>$stats['new_centers_month'], 'icon'=>'🆕', 'color'=>'peach'],
            ['label'=>'Churned This Month', 'value'=>$stats['churned_month'],    'icon'=>'📉', 'color'=>'red'],
        ] as $kpi)
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <div class="flex items-center gap-2 mb-2">
                <span class="text-lg">{{ $kpi['icon'] }}</span>
                <span class="text-xs text-gray-400 font-medium">{{ $kpi['label'] }}</span>
            </div>
            <div class="text-xl font-bold text-gray-900">{{ $kpi['value'] }}</div>
        </div>
        @endforeach
    </div>

    <div class="grid grid-cols-3 gap-6">

        {{-- Recent Centers --}}
        <div class="col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="p-5 border-b border-gray-100 flex items-center justify-between">
                <h2 class="font-semibold text-gray-900">Recently Joined Centers</h2>
                <a href="{{ route('admin.centers.index') }}" class="text-sm text-lavender-600 font-medium">View all →</a>
            </div>
            <div class="divide-y divide-gray-50">
                @foreach($recentCenters as $center)
                <div class="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors">
                    <div class="w-9 h-9 rounded-lg bg-lavender-100 flex items-center justify-center text-sm font-bold text-lavender-700 shrink-0">
                        {{ strtoupper(substr($center->name, 0, 2)) }}
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium text-gray-900 truncate">{{ $center->name }}</div>
                        <div class="text-xs text-gray-400">{{ $center->owner?->email }} · {{ $center->country }}</div>
                    </div>
                    <div class="text-right shrink-0">
                        <x-status-badge :status="$center->status" />
                        <div class="text-xs text-gray-400 mt-0.5">{{ $center->created_at->diffForHumans() }}</div>
                    </div>
                    <a href="{{ route('admin.centers.show', $center) }}"
                       class="text-xs text-lavender-600 font-medium hover:underline shrink-0">
                        View
                    </a>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Plan Distribution --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <h2 class="font-semibold text-gray-900 mb-4">Plan Distribution</h2>
            <div class="space-y-3">
                @foreach($planDistribution as $plan)
                @php $pct = $stats['active_centers'] > 0 ? ($plan->count / $stats['active_centers']) * 100 : 0; @endphp
                <div>
                    <div class="flex items-center justify-between text-sm mb-1">
                        <span class="text-gray-700 font-medium">{{ $plan->name }}</span>
                        <span class="text-gray-400">{{ $plan->count }}</span>
                    </div>
                    <div class="w-full bg-gray-100 rounded-full h-2">
                        <div class="h-2 bg-lavender-500 rounded-full" style="width: {{ $pct }}%"></div>
                    </div>
                </div>
                @endforeach
            </div>
            <a href="{{ route('admin.plans.index') }}" class="mt-4 block text-xs text-lavender-600 font-medium hover:underline">
                Manage plans →
            </a>
        </div>
    </div>

    {{-- Quick Links --}}
    <div class="grid grid-cols-4 gap-4">
        @foreach([
            ['url'=>route('admin.centers.index'),'icon'=>'🏠','title'=>'Centers','desc'=>'Manage all wellness centers'],
            ['url'=>route('admin.plans.index'),  'icon'=>'💳','title'=>'Plans',  'desc'=>'Subscription plan settings'],
            ['url'=>route('admin.users.index'),  'icon'=>'👥','title'=>'Users',  'desc'=>'View and manage all users'],
            ['url'=>route('admin.audit.index'),  'icon'=>'📋','title'=>'Audit Log','desc'=>'Platform activity history'],
        ] as $link)
        <a href="{{ $link['url'] }}"
           class="bg-white rounded-xl border border-gray-100 shadow-sm p-5 hover:border-lavender-200 hover:shadow-md transition-all group">
            <div class="text-3xl mb-3">{{ $link['icon'] }}</div>
            <div class="text-sm font-semibold text-gray-900 group-hover:text-lavender-700">{{ $link['title'] }}</div>
            <div class="text-xs text-gray-400 mt-0.5">{{ $link['desc'] }}</div>
        </a>
        @endforeach
    </div>

</div>
@endsection
