@extends('layouts.app')

@section('title', 'Audit Log')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-5">

    <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold text-gray-900">Audit Log</h2>
        <span class="text-sm text-gray-400">{{ $logs->total() }} entries</span>
    </div>

    <form method="GET" action="{{ route('admin.audit.index') }}"
          class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-3 flex-wrap">
        <select name="event" class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
            <option value="">All Events</option>
            @foreach(['login','logout','booking.created','booking.cancelled','center.suspended','user.banned','plan.changed','settings.updated'] as $evt)
            <option value="{{ $evt }}" {{ request('event') === $evt ? 'selected' : '' }}>{{ $evt }}</option>
            @endforeach
        </select>
        <input type="text" name="user_id" value="{{ request('user_id') }}" placeholder="User ID..."
            class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 w-32">
        <button type="submit" class="px-4 py-2 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700">
            Filter
        </button>
        @if(request()->hasAny(['event','user_id']))
        <a href="{{ route('admin.audit.index') }}" class="text-sm text-gray-400 hover:text-gray-600">Clear</a>
        @endif
    </form>

    <x-alert />

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <x-data-table :columns="[
            ['key'=>'event','label'=>'Event'],
            ['key'=>'user','label'=>'User'],
            ['key'=>'subject','label'=>'Subject'],
            ['key'=>'ip','label'=>'IP'],
            ['key'=>'at','label'=>'When'],
        ]">
            @forelse($logs as $log)
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="px-5 py-3.5">
                    <span class="text-xs font-mono bg-gray-100 text-gray-700 px-2 py-1 rounded-lg">
                        {{ $log->event }}
                    </span>
                </td>
                <td class="px-5 py-3.5">
                    <div class="text-sm font-medium text-gray-900">{{ $log->user_name }}</div>
                    <div class="text-xs text-gray-400">{{ $log->email }}</div>
                </td>
                <td class="px-5 py-3.5">
                    @if($log->subject_type && $log->subject_id)
                    <span class="text-xs text-gray-600">
                        {{ class_basename($log->subject_type) }} #{{ $log->subject_id }}
                    </span>
                    @else
                    <span class="text-gray-300">—</span>
                    @endif
                </td>
                <td class="px-5 py-3.5 text-xs font-mono text-gray-500">{{ $log->ip_address ?? '—' }}</td>
                <td class="px-5 py-3.5 text-sm text-gray-500">
                    {{ \Carbon\Carbon::parse($log->created_at)->format('d M Y, H:i') }}
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="px-5 py-16 text-center text-gray-400 text-sm">No audit entries found.</td>
            </tr>
            @endforelse
        </x-data-table>
        <div class="p-4 border-t border-gray-100">{{ $logs->links() }}</div>
    </div>

</div>
@endsection
