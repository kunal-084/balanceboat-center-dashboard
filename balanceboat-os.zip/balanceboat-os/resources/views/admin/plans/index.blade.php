@extends('layouts.app')

@section('title', 'Subscription Plans')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-6" x-data="{ showCreate: false, editPlan: null }">

    <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold text-gray-900">Subscription Plans</h2>
        <button @click="showCreate = true; editPlan = null"
                class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            New Plan
        </button>
    </div>

    <x-alert />

    <div class="grid grid-cols-3 gap-5">
        @foreach($plans as $plan)
        <div class="bg-white rounded-2xl border {{ $plan->is_active ? 'border-gray-100' : 'border-dashed border-gray-200 opacity-70' }} shadow-sm p-6">
            <div class="flex items-start justify-between mb-4">
                <div>
                    <h3 class="text-lg font-bold text-gray-900">{{ $plan->name }}</h3>
                    <div class="text-2xl font-bold text-lavender-600 mt-1">
                        ${{ number_format($plan->price, 0) }}
                        <span class="text-sm font-normal text-gray-400">/{{ $plan->billing_cycle }}</span>
                    </div>
                </div>
                <span class="text-xs {{ $plan->is_active ? 'bg-wellness-100 text-wellness-700' : 'bg-gray-100 text-gray-500' }} px-2 py-0.5 rounded-full font-medium">
                    {{ $plan->is_active ? 'Active' : 'Inactive' }}
                </span>
            </div>

            <div class="text-3xl font-bold text-gray-900 mb-1">{{ $plan->active_subscriptions_count }}</div>
            <div class="text-xs text-gray-400 mb-4">active subscriptions</div>

            <ul class="space-y-1.5 mb-5">
                @foreach(($plan->features ?? []) as $feature)
                <li class="flex items-center gap-2 text-sm text-gray-600">
                    <span class="text-wellness-500 text-sm">✓</span>
                    {{ $feature }}
                </li>
                @endforeach
            </ul>

            <div class="flex items-center gap-2">
                <button @click="editPlan = {{ json_encode($plan) }}; showCreate = true"
                        class="flex-1 py-2 text-xs font-semibold text-lavender-600 border border-lavender-200 rounded-xl hover:bg-lavender-50 transition-colors text-center">
                    Edit
                </button>
                <form method="POST" action="{{ route('admin.plans.update', $plan) }}" class="flex-1">
                    @csrf @method('PUT')
                    <input type="hidden" name="is_active" value="{{ $plan->is_active ? 0 : 1 }}">
                    <button type="submit"
                            class="w-full py-2 text-xs font-semibold {{ $plan->is_active ? 'text-amber-600 border-amber-200 hover:bg-amber-50' : 'text-wellness-600 border-wellness-200 hover:bg-wellness-50' }} border rounded-xl transition-colors">
                        {{ $plan->is_active ? 'Deactivate' : 'Activate' }}
                    </button>
                </form>
            </div>
        </div>
        @endforeach
    </div>

    {{-- Create/Edit Modal --}}
    <div x-show="showCreate" x-cloak @click.self="showCreate=false"
         class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" style="display:none">
        <div class="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 class="font-semibold text-gray-900 mb-5" x-text="editPlan ? 'Edit Plan' : 'New Plan'"></h3>
            <form method="POST"
                  :action="editPlan ? `/admin/plans/${editPlan.id}` : '{{ route('admin.plans.store') }}'"
                  class="space-y-4">
                @csrf
                <template x-if="editPlan"><input type="hidden" name="_method" value="PUT"></template>

                <div class="grid grid-cols-2 gap-4">
                    <x-form-input name="name" label="Plan Name" required x-bind:value="editPlan?.name ?? ''" />
                    <x-form-input name="slug" label="Slug" required x-bind:value="editPlan?.slug ?? ''"
                        hint="e.g. growth, pro, enterprise" />
                    <x-form-input name="price" label="Price (USD/mo)" type="number" step="0.01" required
                        x-bind:value="editPlan?.price ?? ''" />
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Billing Cycle</label>
                        <select name="billing_cycle" class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            <option value="monthly">Monthly</option>
                            <option value="annually">Annually</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Features (one per line)</label>
                    <textarea name="features_text" rows="6"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 resize-none font-mono"
                        x-bind:value="editPlan ? (editPlan.features ?? []).join('\n') : ''"
                        placeholder="Up to 5 retreats&#10;50 bookings/month&#10;3 team members&#10;Email support"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <label class="font-medium text-gray-700 mb-2 block">Limits (JSON)</label>
                        <textarea name="limits" rows="4"
                            class="w-full px-3 py-2 border border-gray-200 rounded-xl text-xs font-mono outline-none focus:border-lavender-400 resize-none"
                            placeholder='{"retreats":5,"bookings":50,"team":3,"storage_gb":5}'
                            x-text="editPlan ? JSON.stringify(editPlan.limits ?? {}) : ''"></textarea>
                    </div>
                    <div class="space-y-2">
                        <label class="font-medium text-gray-700 block">Options</label>
                        <label class="flex items-center gap-2 cursor-pointer text-gray-600">
                            <input type="checkbox" name="is_active" value="1"
                                x-bind:checked="editPlan ? editPlan.is_active : true"
                                class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                            Active
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer text-gray-600">
                            <input type="checkbox" name="is_featured" value="1"
                                x-bind:checked="editPlan?.is_featured"
                                class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                            Featured (highlighted)
                        </label>
                    </div>
                </div>

                <div class="flex justify-end gap-3 pt-2">
                    <button type="button" @click="showCreate=false; editPlan=null"
                            class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700">
                        Save Plan
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>
@endsection
