@extends('layouts.app')

@section('title', $center->name . ' — Admin')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-6">

    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('admin.dashboard') }}" class="hover:text-gray-600">Admin</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <a href="{{ route('admin.centers.index') }}" class="hover:text-gray-600">Centers</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">{{ $center->name }}</span>
    </nav>

    {{-- Header --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div class="flex items-start gap-5">
            <div class="w-16 h-16 rounded-2xl bg-lavender-100 flex items-center justify-center text-xl font-bold text-lavender-700 shrink-0">
                {{ strtoupper(substr($center->name,0,2)) }}
            </div>
            <div class="flex-1">
                <div class="flex items-center gap-3 mb-1">
                    <h1 class="text-2xl font-bold text-gray-900">{{ $center->name }}</h1>
                    <x-status-badge :status="$center->status" />
                </div>
                <div class="text-sm text-gray-500">
                    {{ $center->city }}, {{ $center->country }} ·
                    {{ $center->email }} ·
                    Joined {{ $center->created_at->format('d M Y') }}
                </div>
            </div>
            <div class="flex items-center gap-2 shrink-0">
                <form method="POST" action="{{ route('admin.centers.impersonate', $center) }}">
                    @csrf
                    <button type="submit" class="px-4 py-2 bg-amber-500 text-white text-sm font-semibold rounded-xl hover:bg-amber-600 transition-colors">
                        Login As Owner
                    </button>
                </form>
                @if($center->status === 'active')
                <button x-data @click="$dispatch('open-modal',{id:'suspend-modal'})"
                        class="px-4 py-2 border border-red-200 text-red-600 text-sm font-semibold rounded-xl hover:bg-red-50 transition-colors">
                    Suspend
                </button>
                @else
                <form method="POST" action="{{ route('admin.centers.reinstate', $center) }}">
                    @csrf @method('PATCH')
                    <button type="submit" class="px-4 py-2 bg-wellness-600 text-white text-sm font-semibold rounded-xl hover:bg-wellness-700 transition-colors">
                        Reinstate
                    </button>
                </form>
                @endif
            </div>
        </div>
    </div>

    {{-- Stats --}}
    <div class="grid grid-cols-4 gap-4">
        @foreach([
            ['label'=>'Total Bookings', 'value'=>$stats['bookings']],
            ['label'=>'Total Revenue',  'value'=>'$'.number_format($stats['revenue'],0)],
            ['label'=>'Retreats',       'value'=>$stats['retreats']],
            ['label'=>'Team Members',   'value'=>$center->users->count()],
        ] as $s)
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <div class="text-xs text-gray-400 mb-1">{{ $s['label'] }}</div>
            <div class="text-2xl font-bold text-gray-900">{{ $s['value'] }}</div>
        </div>
        @endforeach
    </div>

    <div class="grid grid-cols-3 gap-6">

        {{-- Owner & Subscription --}}
        <div class="space-y-4">
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Owner</h3>
                <div class="flex items-center gap-3 mb-3">
                    <img src="{{ $center->owner?->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($center->owner?->full_name ?? 'Owner').'&background=ede9fe&color=7c3aed' }}"
                         class="w-10 h-10 rounded-full object-cover">
                    <div>
                        <div class="text-sm font-medium text-gray-900">{{ $center->owner?->full_name }}</div>
                        <div class="text-xs text-gray-400">{{ $center->owner?->email }}</div>
                    </div>
                </div>
                <a href="{{ route('admin.users.show', $center->owner) }}"
                   class="text-xs text-lavender-600 font-medium hover:underline">
                    View user profile →
                </a>
            </div>

            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Subscription</h3>
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <span class="text-gray-500">Plan</span>
                        <span class="font-semibold">{{ $center->subscription?->plan?->name ?? 'Free' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Status</span>
                        <x-status-badge :status="$center->subscription?->status ?? 'inactive'" />
                    </div>
                    @if($center->subscription?->ends_at)
                    <div class="flex justify-between">
                        <span class="text-gray-500">Renews</span>
                        <span>{{ $center->subscription->ends_at->format('d M Y') }}</span>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        {{-- Retreats --}}
        <div class="col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="p-5 border-b border-gray-100">
                <h3 class="font-semibold text-gray-900">Retreats ({{ $center->experiences->count() }})</h3>
            </div>
            <div class="divide-y divide-gray-50 max-h-72 overflow-y-auto">
                @forelse($center->experiences as $exp)
                <div class="flex items-center gap-3 p-4">
                    <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium text-gray-900 truncate">{{ $exp->title }}</div>
                        <div class="text-xs text-gray-400">{{ $exp->duration_days }}d · ${{ number_format($exp->base_price,0) }}</div>
                    </div>
                    <x-status-badge :status="$exp->status" />
                </div>
                @empty
                <div class="p-8 text-center text-sm text-gray-400">No retreats created yet.</div>
                @endforelse
            </div>
        </div>
    </div>

    {{-- Suspend Modal --}}
    <x-modal id="suspend-modal" title="Suspend Center">
        <form method="POST" action="{{ route('admin.centers.suspend', $center) }}">
            @csrf @method('PATCH')
            <div class="space-y-4">
                <p class="text-sm text-gray-600">
                    Suspending <strong>{{ $center->name }}</strong> will prevent the owner from accessing their dashboard. The owner will be notified by email.
                </p>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Reason</label>
                    <textarea name="reason" rows="3" required
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-red-300 resize-none"
                        placeholder="e.g. Violation of terms of service..."></textarea>
                </div>
                <div class="flex justify-end gap-3">
                    <button type="button" @click="$dispatch('close-modal',{id:'suspend-modal'})"
                            class="px-4 py-2 text-sm border border-gray-200 rounded-xl hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-red-600 text-white text-sm font-semibold rounded-xl hover:bg-red-700">
                        Suspend Center
                    </button>
                </div>
            </div>
        </form>
    </x-modal>

</div>
@endsection
