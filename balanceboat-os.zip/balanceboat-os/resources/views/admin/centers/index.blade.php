@extends('layouts.app')

@section('title', 'All Centers')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-5">

    <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold text-gray-900">All Centers <span class="text-gray-400 font-normal text-base ml-1">({{ $centers->total() }})</span></h2>
        <nav class="flex gap-1 text-sm text-gray-400">
            <a href="{{ route('admin.dashboard') }}" class="hover:text-gray-600">Admin</a>
            <span>/</span>
            <span class="text-gray-700">Centers</span>
        </nav>
    </div>

    {{-- Filters --}}
    <form method="GET" action="{{ route('admin.centers.index') }}"
          class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-3 flex-wrap">
        <div class="relative flex-1 min-w-48">
            <svg class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"/>
            </svg>
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Search center name..."
                class="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
        </div>
        <select name="status" class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
            <option value="">All Statuses</option>
            @foreach(['active','suspended','pending'] as $s)
            <option value="{{ $s }}" {{ request('status') === $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
            @endforeach
        </select>
        <select name="plan" class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
            <option value="">All Plans</option>
            @foreach($plans as $plan)
            <option value="{{ $plan->id }}" {{ request('plan') == $plan->id ? 'selected' : '' }}>{{ $plan->name }}</option>
            @endforeach
        </select>
        <button type="submit" class="px-4 py-2 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700 transition-colors">
            Filter
        </button>
        @if(request()->hasAny(['search','status','plan']))
        <a href="{{ route('admin.centers.index') }}" class="text-sm text-gray-400 hover:text-gray-600">Clear</a>
        @endif
    </form>

    <x-alert />

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <x-data-table :columns="[
            ['key'=>'center','label'=>'Center'],
            ['key'=>'owner','label'=>'Owner'],
            ['key'=>'plan','label'=>'Plan'],
            ['key'=>'retreats','label'=>'Retreats'],
            ['key'=>'status','label'=>'Status'],
            ['key'=>'joined','label'=>'Joined'],
            ['key'=>'actions','label'=>''],
        ]">
            @forelse($centers as $center)
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-lavender-100 flex items-center justify-center text-xs font-bold text-lavender-700 shrink-0">
                            {{ strtoupper(substr($center->name,0,2)) }}
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $center->name }}</div>
                            <div class="text-xs text-gray-400">{{ $center->country }}</div>
                        </div>
                    </div>
                </td>
                <td class="px-5 py-3.5">
                    <div class="text-sm text-gray-700">{{ $center->owner?->full_name }}</div>
                    <div class="text-xs text-gray-400">{{ $center->owner?->email }}</div>
                </td>
                <td class="px-5 py-3.5">
                    <span class="text-xs bg-lavender-100 text-lavender-700 px-2 py-0.5 rounded-full font-medium">
                        {{ $center->subscription?->plan?->name ?? 'Free' }}
                    </span>
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-600">{{ $center->experiences_count ?? 0 }}</td>
                <td class="px-5 py-3.5"><x-status-badge :status="$center->status" /></td>
                <td class="px-5 py-3.5 text-sm text-gray-500">{{ $center->created_at->format('d M Y') }}</td>
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-1">
                        <a href="{{ route('admin.centers.show', $center) }}"
                           class="text-xs px-2.5 py-1.5 text-lavender-600 hover:bg-lavender-50 rounded-lg font-medium">
                            View
                        </a>
                        <form method="POST" action="{{ route('admin.centers.impersonate', $center) }}">
                            @csrf
                            <button type="submit" class="text-xs px-2.5 py-1.5 text-amber-600 hover:bg-amber-50 rounded-lg font-medium">
                                Login As
                            </button>
                        </form>
                        @if($center->status === 'active')
                        <form method="POST" action="{{ route('admin.centers.suspend', $center) }}" class="inline">
                            @csrf @method('PATCH')
                            <input type="hidden" name="reason" value="Admin action">
                            <button type="submit" onclick="return confirm('Suspend {{ $center->name }}?')"
                                    class="text-xs px-2.5 py-1.5 text-red-400 hover:bg-red-50 rounded-lg font-medium">
                                Suspend
                            </button>
                        </form>
                        @else
                        <form method="POST" action="{{ route('admin.centers.reinstate', $center) }}">
                            @csrf @method('PATCH')
                            <button type="submit" class="text-xs px-2.5 py-1.5 text-wellness-600 hover:bg-wellness-50 rounded-lg font-medium">
                                Reinstate
                            </button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="px-5 py-16 text-center">
                    <p class="text-gray-400 text-sm">No centers found.</p>
                </td>
            </tr>
            @endforelse
        </x-data-table>
        <div class="p-4 border-t border-gray-100">{{ $centers->links() }}</div>
    </div>

</div>
@endsection
