@extends('layouts.app')

@section('title', 'All Users')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-5">

    <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold text-gray-900">All Users <span class="text-gray-400 font-normal text-base ml-1">({{ $users->total() }})</span></h2>
    </div>

    <form method="GET" action="{{ route('admin.users.index') }}"
          class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-3 flex-wrap">
        <div class="relative flex-1 min-w-48">
            <svg class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"/>
            </svg>
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Name or email..."
                class="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
        </div>
        <select name="role" class="px-3.5 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 bg-white">
            <option value="">All Roles</option>
            @foreach($roles as $role)
            <option value="{{ $role->name }}" {{ request('role') === $role->name ? 'selected' : '' }}>
                {{ ucfirst(str_replace('-', ' ', $role->name)) }}
            </option>
            @endforeach
        </select>
        <button type="submit" class="px-4 py-2 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700">
            Filter
        </button>
        @if(request()->hasAny(['search','role']))
        <a href="{{ route('admin.users.index') }}" class="text-sm text-gray-400 hover:text-gray-600">Clear</a>
        @endif
    </form>

    <x-alert />

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <x-data-table :columns="[
            ['key'=>'user','label'=>'User'],
            ['key'=>'role','label'=>'Role'],
            ['key'=>'center','label'=>'Center'],
            ['key'=>'status','label'=>'Status'],
            ['key'=>'joined','label'=>'Joined'],
            ['key'=>'last_login','label'=>'Last Login'],
            ['key'=>'actions','label'=>''],
        ]">
            @forelse($users as $user)
            <tr class="hover:bg-gray-50 transition-colors {{ $user->banned_at ? 'opacity-60' : '' }}">
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-3">
                        <img src="{{ $user->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($user->full_name).'&background=ede9fe&color=7c3aed&size=40' }}"
                             class="w-9 h-9 rounded-full object-cover shrink-0">
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $user->full_name }}</div>
                            <div class="text-xs text-gray-400">{{ $user->email }}</div>
                        </div>
                    </div>
                </td>
                <td class="px-5 py-3.5">
                    <span class="text-xs bg-lavender-100 text-lavender-700 px-2 py-0.5 rounded-full font-medium capitalize">
                        {{ str_replace('-', ' ', $user->roles->first()?->name ?? 'user') }}
                    </span>
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-600">{{ $user->center?->name ?? '—' }}</td>
                <td class="px-5 py-3.5">
                    @if($user->banned_at)
                    <span class="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">Banned</span>
                    @elseif($user->email_verified_at)
                    <span class="text-xs bg-wellness-100 text-wellness-700 px-2 py-0.5 rounded-full font-medium">Active</span>
                    @else
                    <span class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">Unverified</span>
                    @endif
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-500">{{ $user->created_at->format('d M Y') }}</td>
                <td class="px-5 py-3.5 text-sm text-gray-500">{{ $user->last_login_at?->diffForHumans() ?? 'Never' }}</td>
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-1">
                        <a href="{{ route('admin.users.show', $user) }}"
                           class="text-xs px-2.5 py-1.5 text-lavender-600 hover:bg-lavender-50 rounded-lg font-medium">
                            View
                        </a>
                        @if($user->banned_at)
                        <form method="POST" action="{{ route('admin.users.unban', $user) }}">
                            @csrf @method('PATCH')
                            <button type="submit" class="text-xs px-2.5 py-1.5 text-wellness-600 hover:bg-wellness-50 rounded-lg font-medium">
                                Unban
                            </button>
                        </form>
                        @elseif($user->id !== auth()->id())
                        <form method="POST" action="{{ route('admin.users.ban', $user) }}">
                            @csrf @method('PATCH')
                            <input type="hidden" name="reason" value="Admin action">
                            <button type="submit" onclick="return confirm('Ban {{ $user->full_name }}?')"
                                    class="text-xs px-2.5 py-1.5 text-red-400 hover:bg-red-50 rounded-lg font-medium">
                                Ban
                            </button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="px-5 py-16 text-center text-gray-400 text-sm">No users found.</td>
            </tr>
            @endforelse
        </x-data-table>
        <div class="p-4 border-t border-gray-100">{{ $users->links() }}</div>
    </div>

</div>
@endsection
