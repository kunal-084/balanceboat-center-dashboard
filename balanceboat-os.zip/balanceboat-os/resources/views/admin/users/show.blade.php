@extends('layouts.app')

@section('title', $user->full_name . ' — Admin')
@section('page-title', 'Platform Admin')

@section('content')
<div class="space-y-6">

    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('admin.dashboard') }}" class="hover:text-gray-600">Admin</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
        <a href="{{ route('admin.users.index') }}" class="hover:text-gray-600">Users</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">{{ $user->full_name }}</span>
    </nav>

    <x-alert />

    <div class="grid grid-cols-3 gap-6">

        {{-- Profile Card --}}
        <div class="space-y-4">
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 text-center">
                <img src="{{ $user->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($user->full_name).'&background=ede9fe&color=7c3aed&size=80' }}"
                     class="w-20 h-20 rounded-full object-cover mx-auto mb-3">
                <h2 class="text-lg font-bold text-gray-900">{{ $user->full_name }}</h2>
                <p class="text-sm text-gray-500">{{ $user->email }}</p>
                @if($user->phone)
                <p class="text-xs text-gray-400 mt-1">{{ $user->phone }}</p>
                @endif
                <div class="mt-3 flex justify-center gap-2 flex-wrap">
                    @foreach($user->roles as $role)
                    <span class="text-xs bg-lavender-100 text-lavender-700 px-2 py-0.5 rounded-full font-medium capitalize">
                        {{ str_replace('-', ' ', $role->name) }}
                    </span>
                    @endforeach
                    @if($user->banned_at)
                    <span class="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">Banned</span>
                    @endif
                </div>
            </div>

            <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-5 space-y-2 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-500">Joined</span>
                    <span class="font-medium">{{ $user->created_at->format('d M Y') }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Last Login</span>
                    <span class="font-medium">{{ $user->last_login_at?->diffForHumans() ?? 'Never' }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Last IP</span>
                    <span class="font-medium font-mono text-xs">{{ $user->last_login_ip ?? '—' }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Email Verified</span>
                    <span class="{{ $user->email_verified_at ? 'text-wellness-600' : 'text-amber-600' }} font-medium">
                        {{ $user->email_verified_at ? 'Yes' : 'No' }}
                    </span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">2FA</span>
                    <span class="{{ $user->two_factor_enabled ? 'text-wellness-600' : 'text-gray-400' }} font-medium">
                        {{ $user->two_factor_enabled ? 'Enabled' : 'Disabled' }}
                    </span>
                </div>
            </div>

            {{-- Actions --}}
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 space-y-2">
                @if($user->banned_at)
                <form method="POST" action="{{ route('admin.users.unban', $user) }}">
                    @csrf @method('PATCH')
                    <button type="submit" class="w-full py-2 bg-wellness-600 text-white text-sm font-semibold rounded-xl hover:bg-wellness-700 transition-colors">
                        Unban User
                    </button>
                </form>
                @elseif($user->id !== auth()->id())
                <div x-data="{ showBan: false }" class="space-y-2">
                    <button @click="showBan = !showBan"
                            class="w-full py-2 border border-red-200 text-red-600 text-sm font-semibold rounded-xl hover:bg-red-50 transition-colors">
                        Ban User
                    </button>
                    <div x-show="showBan" x-transition>
                        <form method="POST" action="{{ route('admin.users.ban', $user) }}" class="space-y-2">
                            @csrf @method('PATCH')
                            <textarea name="reason" rows="2" required
                                class="w-full px-3 py-2 border border-gray-200 rounded-xl text-xs resize-none outline-none focus:border-red-300"
                                placeholder="Ban reason..."></textarea>
                            <button type="submit" class="w-full py-2 bg-red-600 text-white text-sm font-semibold rounded-xl hover:bg-red-700">
                                Confirm Ban
                            </button>
                        </form>
                    </div>
                </div>
                @endif
            </div>
        </div>

        {{-- Center & Recent Activity --}}
        <div class="col-span-2 space-y-4">
            @if($user->center)
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Associated Center</h3>
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-xl bg-lavender-100 flex items-center justify-center text-sm font-bold text-lavender-700">
                        {{ strtoupper(substr($user->center->name,0,2)) }}
                    </div>
                    <div class="flex-1">
                        <div class="text-sm font-semibold text-gray-900">{{ $user->center->name }}</div>
                        <div class="text-xs text-gray-400">{{ $user->center->country }} · <x-status-badge :status="$user->center->status" /></div>
                    </div>
                    <a href="{{ route('admin.centers.show', $user->center) }}"
                       class="text-sm text-lavender-600 font-medium hover:underline">
                        View Center →
                    </a>
                </div>
            </div>
            @endif

            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div class="p-5 border-b border-gray-100">
                    <h3 class="font-semibold text-gray-900">Recent Notifications</h3>
                </div>
                <div class="divide-y divide-gray-50 max-h-60 overflow-y-auto">
                    @forelse($user->notifications->take(10) as $notif)
                    <div class="flex items-start gap-3 p-4">
                        <span class="text-lg shrink-0">{{ $notif->data['icon'] ?? '🔔' }}</span>
                        <div class="flex-1">
                            <div class="text-sm text-gray-900">{{ $notif->data['title'] ?? 'Notification' }}</div>
                            <div class="text-xs text-gray-400">{{ $notif->created_at->diffForHumans() }}</div>
                        </div>
                        @if(!$notif->read_at)
                        <span class="w-2 h-2 rounded-full bg-lavender-500 shrink-0 mt-1.5"></span>
                        @endif
                    </div>
                    @empty
                    <div class="p-8 text-center text-sm text-gray-400">No notifications.</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
