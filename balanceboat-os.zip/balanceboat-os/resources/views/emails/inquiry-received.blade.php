<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>We received your inquiry – {{ $center->name }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', -apple-system, sans-serif; background: #fff7ed; color: #1f2937; line-height: 1.6; }
        .wrapper { max-width: 600px; margin: 32px auto; }
        .header { background: linear-gradient(135deg, #fb923c, #f97316); border-radius: 16px 16px 0 0; padding: 40px 32px; text-align: center; }
        .header .icon { font-size: 40px; margin-bottom: 12px; }
        .header h1 { color: #fff; font-size: 22px; font-weight: 700; margin-bottom: 6px; }
        .header p { color: rgba(255,255,255,.85); font-size: 14px; }
        .body { background: #fff; padding: 32px; }
        .greeting { font-size: 16px; margin-bottom: 16px; }
        .highlight-box { background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px; padding: 20px; margin: 20px 0; }
        .highlight-box .label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: #ea580c; margin-bottom: 10px; }
        .detail-row { display: flex; justify-content: space-between; padding: 7px 0; border-bottom: 1px solid #fed7aa; font-size: 14px; }
        .detail-row:last-child { border-bottom: none; }
        .detail-label { color: #6b7280; }
        .detail-value { font-weight: 600; }
        .retreat-card { background: #f5f3ff; border: 1px solid #ede9fe; border-radius: 12px; padding: 16px; margin: 20px 0; display: flex; gap: 14px; align-items: flex-start; }
        .retreat-icon { font-size: 32px; flex-shrink: 0; }
        .retreat-title { font-size: 15px; font-weight: 600; color: #7c3aed; margin-bottom: 4px; }
        .retreat-meta { font-size: 12px; color: #6b7280; }
        .timeline { margin: 24px 0; }
        .timeline-step { display: flex; gap: 14px; margin-bottom: 20px; }
        .timeline-step:last-child { margin-bottom: 0; }
        .timeline-dot { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
        .dot-active { background: #fef3c7; color: #d97706; }
        .dot-upcoming { background: #f3f4f6; color: #9ca3af; }
        .timeline-content { padding-top: 4px; }
        .timeline-content strong { font-size: 14px; color: #111827; display: block; }
        .timeline-content span { font-size: 12px; color: #6b7280; }
        .cta-section { background: #f5f3ff; border-radius: 12px; padding: 24px; margin: 24px 0; text-align: center; }
        .cta-section p { font-size: 13px; color: #6b7280; margin-bottom: 16px; }
        .btn { display: inline-block; background: #7c3aed; color: #fff; text-decoration: none; padding: 12px 28px; border-radius: 10px; font-size: 14px; font-weight: 600; }
        .social-proof { margin: 20px 0; padding: 16px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; font-size: 13px; color: #15803d; text-align: center; }
        .footer { background: #f9fafb; border-radius: 0 0 16px 16px; padding: 24px 32px; text-align: center; font-size: 12px; color: #9ca3af; }
        .footer a { color: #7c3aed; text-decoration: none; }
        @media (max-width: 600px) {
            .wrapper { margin: 0; }
            .header, .body, .footer { border-radius: 0; padding: 24px 20px; }
        }
    </style>
</head>
<body>
<div class="wrapper">

    {{-- Header --}}
    <div class="header">
        <div class="icon">🌿</div>
        <h1>We've received your inquiry!</h1>
        <p>Thank you for reaching out to {{ $center->name }}</p>
    </div>

    {{-- Body --}}
    <div class="body">
        <p class="greeting">Dear <strong>{{ $inquiry->guest_name }}</strong>,</p>
        <p style="font-size:14px; color:#4b5563; margin-bottom:20px;">
            Thank you for your interest! We're excited to hear from you and will personally review your
            inquiry within <strong>24–48 hours</strong>. In the meantime, here's a summary of what you sent us.
        </p>

        {{-- Inquiry Summary --}}
        <div class="highlight-box">
            <div class="label">Your Inquiry (Ref: #{{ $inquiry->id }})</div>
            @if($inquiry->experience)
            <div class="detail-row">
                <span class="detail-label">Retreat Interest</span>
                <span class="detail-value">{{ $inquiry->experience->title }}</span>
            </div>
            @endif
            @if($inquiry->preferred_dates)
            <div class="detail-row">
                <span class="detail-label">Preferred Dates</span>
                <span class="detail-value">{{ $inquiry->preferred_dates }}</span>
            </div>
            @endif
            @if($inquiry->participants)
            <div class="detail-row">
                <span class="detail-label">Participants</span>
                <span class="detail-value">{{ $inquiry->participants }}</span>
            </div>
            @endif
            <div class="detail-row">
                <span class="detail-label">Contact</span>
                <span class="detail-value">{{ $inquiry->guest_email }}</span>
            </div>
        </div>

        {{-- Their Message --}}
        <div style="background: #f9fafb; border-left: 3px solid #e5e7eb; padding: 14px 16px; border-radius: 0 8px 8px 0; margin: 20px 0; font-size: 13px; color: #4b5563; font-style: italic;">
            "{{ $inquiry->message }}"
        </div>

        {{-- Retreat Card --}}
        @if($inquiry->experience)
        <div class="retreat-card">
            <div class="retreat-icon">🧘</div>
            <div>
                <div class="retreat-title">{{ $inquiry->experience->title }}</div>
                <div class="retreat-meta">
                    📍 {{ $inquiry->experience->location_name }}
                    · {{ $inquiry->experience->duration_days }} days
                    · From ${{ number_format($inquiry->experience->base_price, 0) }} per person
                </div>
                @if($inquiry->experience->tagline)
                <div style="font-size: 12px; color: #7c3aed; margin-top: 6px;">{{ $inquiry->experience->tagline }}</div>
                @endif
            </div>
        </div>
        @endif

        {{-- What happens next --}}
        <div style="font-size: 13px; font-weight: 600; color: #374151; margin: 24px 0 14px;">What happens next?</div>
        <div class="timeline">
            <div class="timeline-step">
                <div class="timeline-dot dot-active">📬</div>
                <div class="timeline-content">
                    <strong>Inquiry received ✓</strong>
                    <span>Your message is in our inbox — right now!</span>
                </div>
            </div>
            <div class="timeline-step">
                <div class="timeline-dot dot-upcoming">💬</div>
                <div class="timeline-content">
                    <strong>Personal response (within 24–48 hrs)</strong>
                    <span>A member of our team will reply personally to answer all your questions.</span>
                </div>
            </div>
            <div class="timeline-step">
                <div class="timeline-dot dot-upcoming">📋</div>
                <div class="timeline-content">
                    <strong>Booking &amp; deposit</strong>
                    <span>When you're ready, we'll send a secure booking link to hold your spot.</span>
                </div>
            </div>
            <div class="timeline-step">
                <div class="timeline-dot dot-upcoming">🌿</div>
                <div class="timeline-content">
                    <strong>Your retreat begins!</strong>
                    <span>Arrive, breathe, and let the transformation begin.</span>
                </div>
            </div>
        </div>

        {{-- Social Proof --}}
        @if($center->avg_rating ?? false)
        <div class="social-proof">
            ⭐⭐⭐⭐⭐ Rated {{ number_format($center->avg_rating, 1) }}/5 by {{ $center->review_count }}+ guests
        </div>
        @endif

        {{-- CTA --}}
        @if($inquiry->experience)
        <div class="cta-section">
            <p>Want to explore the full retreat details while you wait?</p>
            <a href="{{ route('retreats.show', $inquiry->experience) }}" class="btn">
                View Retreat Details →
            </a>
        </div>
        @endif

        <hr style="border: none; border-top: 1px solid #f3f4f6; margin: 24px 0;">
        <p style="font-size: 13px; color: #6b7280;">
            Can't wait? Reach us directly:<br>
            <a href="mailto:{{ $center->email }}" style="color: #7c3aed;">{{ $center->email }}</a>
            @if($center->phone) · WhatsApp: <strong>{{ $center->phone }}</strong> @endif
        </p>
    </div>

    {{-- Footer --}}
    <div class="footer">
        <p>
            <strong>{{ $center->name }}</strong><br>
            {{ $center->address }}, {{ $center->city }}, {{ $center->country }}
        </p>
        @if($center->website)
        <p style="margin-top: 8px;"><a href="{{ $center->website }}">{{ $center->website }}</a></p>
        @endif
        <p style="margin-top: 12px;">
            <a href="{{ route('inquiries.unsubscribe', $inquiry->id) }}">Unsubscribe</a>
        </p>
    </div>
</div>
</body>
</html>
