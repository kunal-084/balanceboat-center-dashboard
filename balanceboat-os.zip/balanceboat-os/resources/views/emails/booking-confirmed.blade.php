<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed – {{ $booking->experience->title }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', -apple-system, sans-serif; background: #f5f3ff; color: #1f2937; line-height: 1.6; }
        .wrapper { max-width: 600px; margin: 32px auto; }
        .header { background: linear-gradient(135deg, #7c3aed, #8b5cf6); border-radius: 16px 16px 0 0; padding: 40px 32px; text-align: center; }
        .header .check { width: 56px; height: 56px; background: rgba(255,255,255,.2); border-radius: 50%; margin: 0 auto 16px; display: flex; align-items: center; justify-content: center; font-size: 28px; }
        .header h1 { color: #fff; font-size: 24px; font-weight: 700; margin-bottom: 6px; }
        .header p { color: rgba(255,255,255,.8); font-size: 14px; }
        .body { background: #fff; padding: 32px; }
        .greeting { font-size: 16px; margin-bottom: 20px; }
        .box { background: #f5f3ff; border: 1px solid #ede9fe; border-radius: 12px; padding: 20px; margin: 20px 0; }
        .box-title { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: #7c3aed; margin-bottom: 12px; }
        .detail-row { display: flex; justify-content: space-between; align-items: flex-start; padding: 8px 0; border-bottom: 1px solid #ede9fe; font-size: 14px; }
        .detail-row:last-child { border-bottom: none; }
        .detail-label { color: #6b7280; }
        .detail-value { font-weight: 600; text-align: right; max-width: 60%; }
        .amounts { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 20px; margin: 20px 0; }
        .amount-row { display: flex; justify-content: space-between; font-size: 14px; padding: 4px 0; }
        .amount-row.total { font-size: 16px; font-weight: 700; border-top: 1px solid #86efac; margin-top: 8px; padding-top: 12px; }
        .amount-paid { color: #16a34a; }
        .amount-due { color: #d97706; }
        .cta-section { text-align: center; margin: 28px 0; }
        .btn { display: inline-block; background: #7c3aed; color: #fff; text-decoration: none; padding: 14px 32px; border-radius: 10px; font-size: 15px; font-weight: 600; }
        .info-box { background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 16px; margin: 20px 0; font-size: 13px; color: #92400e; }
        .steps { margin: 24px 0; }
        .step { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 16px; }
        .step-num { width: 28px; height: 28px; background: #ede9fe; color: #7c3aed; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }
        .step-text { font-size: 13px; color: #374151; padding-top: 4px; }
        .footer { background: #f9fafb; border-radius: 0 0 16px 16px; padding: 24px 32px; text-align: center; font-size: 12px; color: #9ca3af; }
        .footer a { color: #7c3aed; text-decoration: none; }
        .social { margin: 12px 0; }
        .social a { color: #7c3aed; text-decoration: none; margin: 0 6px; font-size: 12px; }
        @media (max-width: 600px) {
            .wrapper { margin: 0; }
            .header, .body, .footer { border-radius: 0; padding: 24px 20px; }
            .detail-row { flex-direction: column; gap: 2px; }
            .detail-value { text-align: left; }
        }
    </style>
</head>
<body>
<div class="wrapper">

    {{-- Header --}}
    <div class="header">
        <div class="check">✓</div>
        <h1>You're confirmed! 🎉</h1>
        <p>Your retreat booking has been successfully confirmed.</p>
    </div>

    {{-- Body --}}
    <div class="body">
        <p class="greeting">Dear <strong>{{ $booking->guest_first_name }}</strong>,</p>
        <p style="font-size:14px; color:#4b5563; margin-bottom:20px;">
            We're thrilled to welcome you to <strong>{{ $booking->experience->title }}</strong>.
            Your spot is reserved and we can't wait to host you on this transformative journey.
        </p>

        {{-- Booking Details --}}
        <div class="box">
            <div class="box-title">Booking Details</div>
            <div class="detail-row">
                <span class="detail-label">Booking Reference</span>
                <span class="detail-value" style="font-family: monospace; color: #7c3aed;">#{{ $booking->booking_reference }}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Retreat</span>
                <span class="detail-value">{{ $booking->experience->title }}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Dates</span>
                <span class="detail-value">
                    {{ $booking->batch?->start_date->format('d M Y') }} –
                    {{ $booking->batch?->end_date->format('d M Y') }}
                </span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Duration</span>
                <span class="detail-value">{{ $booking->experience->duration_days }} days / {{ $booking->experience->duration_days - 1 }} nights</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Location</span>
                <span class="detail-value">{{ $booking->experience->location_name }}, {{ $booking->experience->country }}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Participants</span>
                <span class="detail-value">{{ $booking->participants }}</span>
            </div>
            @if($booking->room_type)
            <div class="detail-row">
                <span class="detail-label">Room Type</span>
                <span class="detail-value">{{ $booking->room_type->name }}</span>
            </div>
            @endif
        </div>

        {{-- Payment Summary --}}
        <div class="amounts">
            <div class="box-title" style="color: #16a34a;">Payment Summary</div>
            <div class="amount-row">
                <span>Retreat Price</span>
                <span>${{ number_format($booking->base_price, 2) }}</span>
            </div>
            @if($booking->discount_amount)
            <div class="amount-row">
                <span>Discount</span>
                <span style="color: #dc2626;">−${{ number_format($booking->discount_amount, 2) }}</span>
            </div>
            @endif
            <div class="amount-row total">
                <span>Total</span>
                <span>${{ number_format($booking->total_price, 2) }}</span>
            </div>
            <div class="amount-row" style="margin-top:8px;">
                <span>Paid</span>
                <span class="amount-paid">${{ number_format($booking->amount_paid, 2) }}</span>
            </div>
            @if($booking->balance_due > 0)
            <div class="amount-row">
                <span>Balance Due</span>
                <span class="amount-due">${{ number_format($booking->balance_due, 2) }}</span>
            </div>
            @endif
        </div>

        @if($booking->balance_due > 0)
        <div class="info-box">
            ⏰ <strong>Balance Due:</strong> Please complete payment of
            <strong>${{ number_format($booking->balance_due, 2) }}</strong>
            at least {{ config('booking.balance_due_days', 14) }} days before your retreat starts
            to secure your spot.
        </div>
        @endif

        {{-- CTA --}}
        <div class="cta-section">
            <a href="{{ route('bookings.guest-view', $booking->booking_reference) }}" class="btn">
                View Your Booking →
            </a>
        </div>

        {{-- What's Next --}}
        <div style="margin-top: 28px;">
            <div style="font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 16px;">What happens next?</div>
            <div class="steps">
                <div class="step">
                    <div class="step-num">1</div>
                    <div class="step-text">Check your email for a detailed pre-arrival information pack we'll send 7 days before your retreat.</div>
                </div>
                @if($booking->balance_due > 0)
                <div class="step">
                    <div class="step-num">2</div>
                    <div class="step-text">Complete your balance payment to confirm your accommodation preference.</div>
                </div>
                @endif
                <div class="step">
                    <div class="step-num">{{ $booking->balance_due > 0 ? 3 : 2 }}</div>
                    <div class="step-text">Reply to this email with any dietary requirements, health conditions, or special requests.</div>
                </div>
                <div class="step">
                    <div class="step-num">{{ $booking->balance_due > 0 ? 4 : 3 }}</div>
                    <div class="step-text">Pack your bags and get ready for a transformative experience! 🌿</div>
                </div>
            </div>
        </div>

        <hr style="border: none; border-top: 1px solid #f3f4f6; margin: 24px 0;">
        <p style="font-size: 13px; color: #6b7280;">
            Have questions? Contact us at
            <a href="mailto:{{ $center->email }}" style="color: #7c3aed;">{{ $center->email }}</a>
            @if($center->phone) or WhatsApp us at <strong>{{ $center->phone }}</strong> @endif.
        </p>
    </div>

    {{-- Footer --}}
    <div class="footer">
        <div class="social">
            @if($center->instagram)
            <a href="https://instagram.com/{{ ltrim($center->instagram, '@') }}">Instagram</a>
            @endif
            @if($center->website)
            <a href="{{ $center->website }}">Website</a>
            @endif
        </div>
        <p>{{ $center->name }} · {{ $center->address }}, {{ $center->city }}, {{ $center->country }}</p>
        <p style="margin-top: 8px;">
            <a href="{{ route('bookings.unsubscribe', $booking->booking_reference) }}">Unsubscribe</a>
            from booking notifications
        </p>
    </div>
</div>
</body>
</html>
