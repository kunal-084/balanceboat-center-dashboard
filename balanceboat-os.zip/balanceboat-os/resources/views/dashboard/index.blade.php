@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
<div class="space-y-6">

    {{-- Welcome Banner --}}
    <div class="glass-premium rounded-2xl p-6 flex items-center justify-between" style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(251,146,60,0.06)); border:1px solid rgba(139,92,246,0.15);">
        <div>
            <h2 class="font-serif text-2xl font-bold text-gray-900">
                Good {{ now()->format('G') < 12 ? 'morning' : (now()->format('G') < 17 ? 'afternoon' : 'evening') }},
                {{ auth()->user()->name }} 🌿
            </h2>
            <p class="text-gray-500 mt-1 text-sm">Here's what's happening at <strong>{{ auth()->user()->center?->name ?? 'your center' }}</strong> today.</p>
        </div>
        <div class="hidden sm:flex items-center gap-3">
            <a href="{{ route('retreats.create') }}"
               class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-medium hover:bg-lavender-700 transition-colors">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                New Retreat
            </a>
        </div>
    </div>

    {{-- KPI Cards --}}
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4" id="kpi-grid">
        @php
        $kpis = [
            ['label' => 'Total Revenue', 'value' => '$' . number_format($kpis['revenue'] ?? 0, 0), 'change' => '+12.4%', 'trend' => 'up', 'icon' => '💰', 'color' => 'lavender', 'sub' => 'This month'],
            ['label' => 'Active Bookings', 'value' => number_format($kpis['active_bookings'] ?? 0), 'change' => '+8.1%', 'trend' => 'up', 'icon' => '📅', 'color' => 'wellness', 'sub' => 'Confirmed'],
            ['label' => 'Occupancy Rate', 'value' => ($kpis['occupancy_rate'] ?? 0) . '%', 'change' => '+3.2%', 'trend' => 'up', 'icon' => '🏡', 'color' => 'peach', 'sub' => 'Last 30 days'],
            ['label' => 'New Inquiries', 'value' => number_format($kpis['new_inquiries'] ?? 0), 'change' => '-2.1%', 'trend' => 'down', 'icon' => '📩', 'color' => 'gray', 'sub' => 'This week'],
        ];
        @endphp

        @foreach($kpis as $kpi)
        <div class="bg-white rounded-2xl p-5 border border-gray-100 hover:shadow-lg hover:shadow-lavender-100/50 transition-all duration-300">
            <div class="flex items-start justify-between mb-3">
                <div class="text-2xl leading-none">{{ $kpi['icon'] }}</div>
                <span class="text-xs font-medium px-2 py-0.5 rounded-full {{ $kpi['trend'] === 'up' ? 'bg-wellness-50 text-wellness-600' : 'bg-red-50 text-red-600' }}">
                    {{ $kpi['trend'] === 'up' ? '↑' : '↓' }} {{ $kpi['change'] }}
                </span>
            </div>
            <div class="font-serif text-2xl font-bold text-gray-900 mb-0.5">{{ $kpi['value'] }}</div>
            <div class="text-xs text-gray-500">{{ $kpi['label'] }}</div>
            <div class="text-xs text-gray-400 mt-0.5">{{ $kpi['sub'] }}</div>
        </div>
        @endforeach
    </div>

    {{-- Charts Row --}}
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {{-- Revenue Chart --}}
        <div class="lg:col-span-2 bg-white rounded-2xl border border-gray-100 p-6">
            <div class="flex items-center justify-between mb-6">
                <h3 class="font-semibold text-gray-900">Revenue Overview</h3>
                <div class="flex items-center gap-2">
                    <button onclick="setRevenueRange('7d')" class="tab-btn active text-xs px-3 py-1.5 rounded-lg" data-range="7d">7D</button>
                    <button onclick="setRevenueRange('30d')" class="tab-btn text-xs px-3 py-1.5 rounded-lg" data-range="30d">30D</button>
                    <button onclick="setRevenueRange('90d')" class="tab-btn text-xs px-3 py-1.5 rounded-lg" data-range="90d">90D</button>
                </div>
            </div>
            <canvas id="revenueChart" height="220"></canvas>
        </div>

        {{-- Booking Status Donut --}}
        <div class="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 class="font-semibold text-gray-900 mb-4">Booking Status</h3>
            <canvas id="bookingStatusChart" height="180"></canvas>
            <div class="mt-4 space-y-2.5">
                @php
                $statusColors = ['Confirmed'=>'#8b5cf6','Pending'=>'#fb923c','Checked In'=>'#22c55e','Completed'=>'#6d28d9','Cancelled'=>'#ef4444'];
                $statusData   = $bookingsByStatus ?? ['Confirmed'=>0,'Pending'=>0,'Checked In'=>0,'Completed'=>0,'Cancelled'=>0];
                @endphp
                @foreach($statusColors as $status => $color)
                <div class="flex items-center justify-between text-sm">
                    <div class="flex items-center gap-2">
                        <span class="w-2.5 h-2.5 rounded-full flex-shrink-0" style="background:{{ $color }};"></span>
                        <span class="text-gray-600">{{ $status }}</span>
                    </div>
                    <span class="font-semibold text-gray-900">{{ $statusData[$status] ?? 0 }}</span>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    {{-- Recent Activity + Top Retreats --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {{-- Recent Bookings --}}
        <div class="bg-white rounded-2xl border border-gray-100">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-50">
                <h3 class="font-semibold text-gray-900">Recent Bookings</h3>
                <a href="{{ route('bookings.index') }}" class="text-sm text-lavender-600 font-medium hover:text-lavender-800">View all →</a>
            </div>
            <div class="divide-y divide-gray-50">
                @forelse($recentBookings ?? [] as $booking)
                <div class="flex items-center justify-between px-6 py-3.5">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 bg-lavender-50 rounded-full flex items-center justify-center text-sm font-bold text-lavender-700 flex-shrink-0">
                            {{ strtoupper(substr($booking->guest_name, 0, 1)) }}
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $booking->guest_name }}</div>
                            <div class="text-xs text-gray-500 truncate max-w-[150px]">{{ $booking->experience?->title }}</div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-sm font-semibold text-gray-900">${{ number_format($booking->total_amount, 0) }}</div>
                        <x-status-badge :status="$booking->status" size="xs" />
                    </div>
                </div>
                @empty
                <div class="px-6 py-8 text-center text-sm text-gray-400">No recent bookings</div>
                @endforelse
            </div>
        </div>

        {{-- Top Retreats + Quick Actions --}}
        <div class="space-y-6">
            {{-- Top Retreats --}}
            <div class="bg-white rounded-2xl border border-gray-100">
                <div class="flex items-center justify-between px-6 py-4 border-b border-gray-50">
                    <h3 class="font-semibold text-gray-900">Top Retreats</h3>
                    <a href="{{ route('analytics.retreats') }}" class="text-sm text-lavender-600 font-medium hover:text-lavender-800">Analytics →</a>
                </div>
                <div class="divide-y divide-gray-50">
                    @forelse($topRetreats ?? [] as $index => $retreat)
                    <div class="flex items-center justify-between px-6 py-3.5">
                        <div class="flex items-center gap-3">
                            <span class="text-lg font-bold text-lavender-200">{{ sprintf('%02d', $index + 1) }}</span>
                            <div>
                                <div class="text-sm font-medium text-gray-900 truncate max-w-[180px]">{{ $retreat->title }}</div>
                                <div class="text-xs text-gray-500">{{ $retreat->total_bookings ?? 0 }} bookings</div>
                            </div>
                        </div>
                        <div class="text-sm font-semibold text-wellness-600">${{ number_format($retreat->total_revenue ?? 0, 0) }}</div>
                    </div>
                    @empty
                    <div class="px-6 py-6 text-center text-sm text-gray-400">No retreat data yet</div>
                    @endforelse
                </div>
            </div>

            {{-- Quick Actions --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Quick Actions</h3>
                <div class="grid grid-cols-2 gap-3">
                    @php
                    $actions = [
                        ['href' => route('retreats.create'), 'icon' => '🧘', 'label' => 'Add Retreat'],
                        ['href' => route('bookings.create'), 'icon' => '📅', 'label' => 'New Booking'],
                        ['href' => route('media.index'), 'icon' => '🖼', 'label' => 'Upload Media'],
                        ['href' => route('ai.index'), 'icon' => '🤖', 'label' => 'AI Studio'],
                    ];
                    @endphp
                    @foreach($actions as $action)
                    <a href="{{ $action['href'] }}"
                       class="flex items-center gap-2.5 p-3 rounded-xl border border-gray-100 hover:border-lavender-200 hover:bg-lavender-50 transition-all text-sm font-medium text-gray-700 hover:text-lavender-700">
                        <span class="text-lg">{{ $action['icon'] }}</span>
                        {{ $action['label'] }}
                    </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    {{-- AI Recommendations Banner --}}
    @if(isset($aiRecommendations) && $aiRecommendations->count() > 0)
    <div class="bg-gradient-to-r from-lavender-600 to-lavender-700 rounded-2xl p-5 text-white flex items-center justify-between">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-white/15 rounded-xl flex items-center justify-center text-xl">🤖</div>
            <div>
                <div class="font-semibold">{{ $aiRecommendations->count() }} AI Recommendation{{ $aiRecommendations->count() > 1 ? 's' : '' }} Available</div>
                <div class="text-white/75 text-sm">{{ $aiRecommendations->first()->title }}</div>
            </div>
        </div>
        <a href="{{ route('ai.recommendations') }}"
           class="px-4 py-2 bg-white/15 hover:bg-white/25 rounded-xl text-sm font-medium transition-colors backdrop-blur-sm">
            View All
        </a>
    </div>
    @endif

</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// ---- Revenue Chart ----
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
const revenueData = @json($revenueChartData ?? ['labels' => [], 'data' => []]);

const revenueChart = new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: revenueData.labels,
        datasets: [{
            label: 'Revenue',
            data: revenueData.data,
            borderColor: '#8b5cf6',
            backgroundColor: 'rgba(139,92,246,0.07)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#8b5cf6',
            pointRadius: 4,
            pointHoverRadius: 6,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { grid: { color: '#f3f4f6' }, ticks: { color: '#9ca3af', callback: v => '$' + v.toLocaleString() } },
            x: { grid: { display: false }, ticks: { color: '#9ca3af' } }
        }
    }
});

// ---- Booking Status Donut ----
const statusCtx = document.getElementById('bookingStatusChart').getContext('2d');
const statusData = @json($bookingsByStatus ?? []);

new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: Object.keys(statusData),
        datasets: [{
            data: Object.values(statusData),
            backgroundColor: ['#8b5cf6','#fb923c','#22c55e','#6d28d9','#ef4444'],
            borderWidth: 0,
            hoverOffset: 4,
        }]
    },
    options: {
        responsive: true,
        cutout: '72%',
        plugins: { legend: { display: false } }
    }
});

// ---- Revenue Range Toggle ----
function setRevenueRange(range) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active', 'bg-lavender-50', 'text-lavender-700', 'font-semibold'));
    const btn = document.querySelector(`[data-range="${range}"]`);
    if (btn) btn.classList.add('active', 'bg-lavender-50', 'text-lavender-700', 'font-semibold');

    fetch(`{{ route('dashboard.charts') }}?range=${range}`)
        .then(r => r.json())
        .then(data => {
            revenueChart.data.labels  = data.labels;
            revenueChart.data.datasets[0].data = data.data;
            revenueChart.update();
        });
}

document.addEventListener('DOMContentLoaded', () => {
    const activeBtn = document.querySelector('[data-range="7d"]');
    if (activeBtn) activeBtn.classList.add('bg-lavender-50', 'text-lavender-700', 'font-semibold');
});
</script>
@endpush
