@extends('layouts.app')

@section('title', 'Automations')
@section('page-title', 'Automations')

@section('content')
<div class="space-y-6" x-data="automationsManager()">

    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Set up event-driven workflows — emails, WhatsApp, tasks, and more.</p>
        <button @click="showCreate = true"
                class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            New Automation
        </button>
    </div>

    <x-alert />

    {{-- Stats Row --}}
    <div class="grid grid-cols-4 gap-4">
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <div class="text-xs text-gray-400 mb-1">Active Rules</div>
            <div class="text-2xl font-bold text-gray-900">{{ $stats['active'] ?? 0 }}</div>
        </div>
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <div class="text-xs text-gray-400 mb-1">Fired This Month</div>
            <div class="text-2xl font-bold text-gray-900">{{ $stats['fired_month'] ?? 0 }}</div>
        </div>
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <div class="text-xs text-gray-400 mb-1">Success Rate</div>
            <div class="text-2xl font-bold text-wellness-600">{{ $stats['success_rate'] ?? 100 }}%</div>
        </div>
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <div class="text-xs text-gray-400 mb-1">Last Execution</div>
            <div class="text-sm font-semibold text-gray-900">{{ $stats['last_run'] ?? 'Never' }}</div>
        </div>
    </div>

    {{-- Rules List --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="p-5 border-b border-gray-100 flex items-center justify-between">
            <h2 class="font-semibold text-gray-900">Automation Rules</h2>
            <a href="{{ route('automations.executions') }}" class="text-sm text-lavender-600 font-medium hover:text-lavender-700">
                View Execution Log →
            </a>
        </div>

        @forelse($rules as $rule)
        <div class="border-b border-gray-50 last:border-0 p-5 hover:bg-gray-50/50 transition-colors">
            <div class="flex items-start gap-4">

                {{-- Toggle --}}
                <div class="pt-0.5">
                    <form method="POST" action="{{ route('automations.toggle', $rule) }}">
                        @csrf @method('PATCH')
                        <button type="submit"
                                class="relative inline-flex w-9 h-5 rounded-full transition-colors {{ $rule->is_active ? 'bg-wellness-500' : 'bg-gray-200' }}">
                            <span class="absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-transform {{ $rule->is_active ? 'translate-x-4' : '' }}"></span>
                        </button>
                    </form>
                </div>

                {{-- Content --}}
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <h3 class="text-sm font-semibold text-gray-900">{{ $rule->name }}</h3>
                        @if(!$rule->is_active)
                        <span class="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">Paused</span>
                        @endif
                    </div>

                    {{-- Rule Visual --}}
                    <div class="flex items-center gap-2 flex-wrap mt-2">
                        <span class="text-xs bg-amber-100 text-amber-700 px-2.5 py-1 rounded-lg font-medium">
                            🎯 {{ $rule->trigger_label }}
                        </span>
                        @foreach($rule->conditions as $cond)
                        <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-lg">
                            IF {{ $cond['field'] }} {{ $cond['operator'] }} {{ $cond['value'] }}
                        </span>
                        @endforeach
                        <svg class="w-3.5 h-3.5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"/>
                        </svg>
                        @foreach($rule->actions as $action)
                        <span class="text-xs bg-lavender-100 text-lavender-700 px-2.5 py-1 rounded-lg font-medium">
                            ⚡ {{ $action['type_label'] ?? $action['type'] }}
                        </span>
                        @endforeach
                    </div>

                    <div class="flex items-center gap-4 mt-2 text-xs text-gray-400">
                        <span>Fired {{ $rule->executions_count }} times</span>
                        @if($rule->last_run_at)
                        <span>Last run {{ $rule->last_run_at->diffForHumans() }}</span>
                        @endif
                        @if($rule->delay_minutes)
                        <span>⏱ {{ $rule->delay_minutes }}m delay</span>
                        @endif
                    </div>
                </div>

                {{-- Actions --}}
                <div class="flex items-center gap-1 shrink-0">
                    <button @click="editRule = {{ json_encode($rule) }}"
                            class="p-1.5 text-gray-400 hover:text-lavender-600 hover:bg-lavender-50 rounded-lg transition-colors">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125"/>
                        </svg>
                    </button>
                    <form method="POST" action="{{ route('automations.destroy', $rule) }}">
                        @csrf @method('DELETE')
                        <button type="submit" onclick="return confirm('Delete this automation?')"
                                class="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        @empty
        <div class="p-16 text-center">
            <div class="text-5xl mb-4">⚡</div>
            <p class="text-gray-400 text-sm font-medium">No automations configured yet.</p>
            <p class="text-gray-300 text-xs mt-1">Create your first rule to start automating guest communications.</p>
            <button @click="showCreate = true"
                    class="mt-4 px-4 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                Create First Automation
            </button>
        </div>
        @endforelse
    </div>

    {{-- Suggested Templates --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h2 class="font-semibold text-gray-900 mb-4">Suggested Automations</h2>
        <div class="grid grid-cols-3 gap-4">
            @foreach([
                ['icon'=>'📧','title'=>'Inquiry Auto-Reply','desc'=>'Send an instant reply when a new inquiry arrives','trigger'=>'inquiry.received'],
                ['icon'=>'🎉','title'=>'Booking Confirmation','desc'=>'Email + WhatsApp when a booking is confirmed','trigger'=>'booking.confirmed'],
                ['icon'=>'⏰','title'=>'Pre-Retreat Reminder','desc'=>'Send packing list 7 days before retreat start','trigger'=>'retreat.starts_in_7_days'],
                ['icon'=>'⭐','title'=>'Post-Retreat Review','desc'=>'Request a review 2 days after the retreat ends','trigger'=>'retreat.ended_2_days_ago'],
                ['icon'=>'💸','title'=>'Payment Reminder','desc'=>'Nudge guests with an outstanding balance 48h before due date','trigger'=>'payment.due_in_48h'],
                ['icon'=>'🔄','title'=>'Re-engagement','desc'=>'Reach out to past guests after 6 months of inactivity','trigger'=>'guest.inactive_6_months'],
            ] as $tpl)
            <button @click="createFromTemplate('{{ $tpl['trigger'] }}')"
                    class="text-left p-4 border border-gray-100 rounded-xl hover:border-lavender-200 hover:bg-lavender-50/50 transition-all group">
                <div class="text-2xl mb-2">{{ $tpl['icon'] }}</div>
                <div class="text-sm font-semibold text-gray-900 group-hover:text-lavender-700">{{ $tpl['title'] }}</div>
                <div class="text-xs text-gray-400 mt-0.5">{{ $tpl['desc'] }}</div>
            </button>
            @endforeach
        </div>
    </div>

    {{-- Create/Edit Modal --}}
    <div x-show="showCreate || editRule" x-cloak @click="showCreate=false; editRule=null"
         class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" style="display:none">
        <div @click.stop class="bg-white rounded-2xl p-6 w-full max-w-xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 class="font-semibold text-gray-900 mb-5" x-text="editRule ? 'Edit Automation' : 'New Automation'"></h3>

            <form method="POST"
                  :action="editRule ? `/automations/${editRule.id}` : '{{ route('automations.store') }}'"
                  class="space-y-4">
                @csrf
                <template x-if="editRule"><input type="hidden" name="_method" value="PUT"></template>

                <x-form-input name="name" label="Rule Name" required
                    placeholder="e.g. Welcome email on inquiry"
                    x-bind:value="editRule ? editRule.name : ''" />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Trigger Event</label>
                    <select name="trigger" x-model="trigger"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                        <optgroup label="Inquiries">
                            <option value="inquiry.received">Inquiry Received</option>
                            <option value="inquiry.converted">Inquiry Converted to Booking</option>
                        </optgroup>
                        <optgroup label="Bookings">
                            <option value="booking.created">Booking Created</option>
                            <option value="booking.confirmed">Booking Confirmed</option>
                            <option value="booking.cancelled">Booking Cancelled</option>
                            <option value="booking.completed">Booking Completed</option>
                        </optgroup>
                        <optgroup label="Payments">
                            <option value="payment.received">Payment Received</option>
                            <option value="payment.overdue">Payment Overdue</option>
                        </optgroup>
                        <optgroup label="Scheduled">
                            <option value="retreat.starts_in_7_days">7 Days Before Retreat</option>
                            <option value="retreat.starts_in_1_day">1 Day Before Retreat</option>
                            <option value="retreat.ended_2_days_ago">2 Days After Retreat</option>
                        </optgroup>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Action Type</label>
                        <select name="action_type"
                            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                            <option value="send_email">Send Email</option>
                            <option value="send_whatsapp">Send WhatsApp</option>
                            <option value="create_task">Create Task</option>
                            <option value="add_tag">Add Tag</option>
                            <option value="change_status">Change Status</option>
                        </select>
                    </div>
                    <x-form-input name="delay_minutes" label="Delay (minutes)" type="number" :value="0"
                        hint="0 = immediate" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Template</label>
                    <select name="email_template_id"
                        class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400">
                        <option value="">— Select template —</option>
                        @foreach($emailTemplates as $tpl)
                        <option value="{{ $tpl->id }}">{{ $tpl->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="flex items-center gap-2">
                    <input type="checkbox" name="is_active" value="1" checked
                        class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                    <label class="text-sm text-gray-700">Active immediately</label>
                </div>

                <div class="flex justify-end gap-3 pt-2">
                    <button type="button" @click="showCreate=false; editRule=null"
                            class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700">
                        Save Automation
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
function automationsManager() {
    return {
        showCreate: false,
        editRule: null,
        trigger: 'inquiry.received',

        createFromTemplate(trigger) {
            this.trigger = trigger;
            this.showCreate = true;
        },
    };
}
</script>
@endpush
