@extends('layouts.app')

@section('title', 'Execution Log')
@section('page-title', 'Automations')

@section('content')
<div class="space-y-6">

    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('automations.index') }}" class="hover:text-gray-600">Automations</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">Execution Log</span>
    </nav>

    <x-alert />

    {{-- Filters --}}
    <div class="flex items-center gap-3">
        <form method="GET" action="{{ route('automations.executions') }}" class="flex items-center gap-3 flex-wrap">
            <div class="relative">
                <select name="status" onchange="this.form.submit()"
                    class="pl-3.5 pr-8 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 appearance-none bg-white">
                    <option value="">All Statuses</option>
                    <option value="pending"   {{ request('status') === 'pending'   ? 'selected' : '' }}>Pending</option>
                    <option value="running"   {{ request('status') === 'running'   ? 'selected' : '' }}>Running</option>
                    <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Completed</option>
                    <option value="failed"    {{ request('status') === 'failed'    ? 'selected' : '' }}>Failed</option>
                    <option value="skipped"   {{ request('status') === 'skipped'   ? 'selected' : '' }}>Skipped</option>
                </select>
            </div>
            <div class="relative">
                <select name="rule_id" onchange="this.form.submit()"
                    class="pl-3.5 pr-8 py-2 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 appearance-none bg-white">
                    <option value="">All Rules</option>
                    @foreach($rules as $rule)
                    <option value="{{ $rule->id }}" {{ request('rule_id') == $rule->id ? 'selected' : '' }}>
                        {{ $rule->name }}
                    </option>
                    @endforeach
                </select>
            </div>
        </form>

        <div class="ml-auto flex items-center gap-3 text-xs text-gray-400">
            <span>{{ $executions->total() }} executions</span>
            <form method="POST" action="{{ route('automations.executions.clear') }}">
                @csrf
                <button type="submit" onclick="return confirm('Clear old execution logs?')"
                        class="text-red-400 hover:text-red-600 font-medium">
                    Clear Old Logs
                </button>
            </form>
        </div>
    </div>

    {{-- Summary Tiles --}}
    <div class="grid grid-cols-5 gap-4">
        @foreach([
            ['label'=>'Total','value'=>$summary['total'],'color'=>'gray'],
            ['label'=>'Completed','value'=>$summary['completed'],'color'=>'wellness'],
            ['label'=>'Failed','value'=>$summary['failed'],'color'=>'red'],
            ['label'=>'Pending','value'=>$summary['pending'],'color'=>'amber'],
            ['label'=>'Skipped','value'=>$summary['skipped'],'color'=>'gray'],
        ] as $tile)
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 text-center">
            <div class="text-xs text-gray-400 mb-1">{{ $tile['label'] }}</div>
            <div class="text-xl font-bold
                {{ $tile['color'] === 'wellness' ? 'text-wellness-600' :
                   ($tile['color'] === 'red' ? 'text-red-600' :
                   ($tile['color'] === 'amber' ? 'text-amber-600' : 'text-gray-900')) }}">
                {{ $tile['value'] }}
            </div>
        </div>
        @endforeach
    </div>

    {{-- Execution Table --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <x-data-table
            :columns="[
                ['key'=>'rule','label'=>'Rule'],
                ['key'=>'trigger','label'=>'Triggered By'],
                ['key'=>'action','label'=>'Action'],
                ['key'=>'target','label'=>'Target'],
                ['key'=>'status','label'=>'Status'],
                ['key'=>'duration','label'=>'Duration'],
                ['key'=>'at','label'=>'Executed At'],
                ['key'=>'actions','label'=>''],
            ]"
            empty-text="No executions recorded."
            empty-icon="⚡"
        >
            @forelse($executions as $exec)
            <tr class="hover:bg-gray-50 transition-colors {{ $exec->status === 'failed' ? 'bg-red-50/30' : '' }}">
                <td class="px-5 py-3.5">
                    <div class="text-sm font-medium text-gray-900">{{ $exec->rule?->name }}</div>
                    <div class="text-xs text-gray-400">{{ $exec->rule?->trigger_label }}</div>
                </td>
                <td class="px-5 py-3.5">
                    <span class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">
                        {{ $exec->trigger_event }}
                    </span>
                </td>
                <td class="px-5 py-3.5">
                    <span class="text-xs bg-lavender-100 text-lavender-700 px-2 py-0.5 rounded-full capitalize">
                        {{ str_replace('_', ' ', $exec->action_type) }}
                    </span>
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-600">
                    {{ $exec->target_label }}
                </td>
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-1.5">
                        @if($exec->status === 'completed')
                        <span class="w-1.5 h-1.5 rounded-full bg-wellness-500"></span>
                        @elseif($exec->status === 'failed')
                        <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                        @elseif($exec->status === 'pending')
                        <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                        @else
                        <span class="w-1.5 h-1.5 rounded-full bg-gray-300"></span>
                        @endif
                        <span class="text-xs font-medium capitalize {{ $exec->status === 'failed' ? 'text-red-600' : 'text-gray-700' }}">
                            {{ $exec->status }}
                        </span>
                    </div>
                    @if($exec->status === 'failed' && $exec->error_message)
                    <div class="text-[10px] text-red-400 mt-0.5 truncate max-w-[120px]" title="{{ $exec->error_message }}">
                        {{ $exec->error_message }}
                    </div>
                    @endif
                </td>
                <td class="px-5 py-3.5 text-xs text-gray-500">
                    {{ $exec->duration_ms ? $exec->duration_ms.'ms' : '—' }}
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-500">
                    {{ $exec->created_at->format('d M, H:i') }}
                </td>
                <td class="px-5 py-3.5">
                    @if($exec->status === 'failed')
                    <form method="POST" action="{{ route('automations.executions.retry', $exec) }}">
                        @csrf
                        <button type="submit"
                                class="text-xs px-2.5 py-1.5 text-lavender-600 hover:bg-lavender-50 rounded-lg font-medium transition-colors">
                            Retry
                        </button>
                    </form>
                    @endif
                    <button x-data @click="$dispatch('open-modal', { id: 'exec-detail-{{ $exec->id }}' })"
                            class="text-xs px-2.5 py-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg font-medium transition-colors">
                        Detail
                    </button>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="px-5 py-16 text-center">
                    <div class="text-4xl mb-3">⚡</div>
                    <p class="text-gray-400 text-sm">No executions yet. Automations fire when their trigger events occur.</p>
                </td>
            </tr>
            @endforelse
        </x-data-table>
        <div class="p-4 border-t border-gray-100">{{ $executions->links() }}</div>
    </div>

</div>
@endsection
