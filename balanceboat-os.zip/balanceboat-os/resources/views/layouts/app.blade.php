<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="{{ $metaDescription ?? 'BalanceBoat Center OS — Wellness Center Management Platform' }}">
    <title>{{ isset($title) ? $title . ' · ' : '' }}BalanceBoat Center OS</title>

    {{-- Preload fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    {{-- Tailwind + Vite --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    {{-- Alpine.js --}}
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    {{-- Chart.js --}}
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    {{-- Custom styles for luxury wellness aesthetic --}}
    <style>
        :root {
            --lavender-50: #f5f3ff; --lavender-100: #ede9fe; --lavender-200: #ddd6fe;
            --lavender-500: #8b5cf6; --lavender-600: #7c3aed; --lavender-700: #6d28d9;
            --peach-50: #fff7ed;    --peach-100: #ffedd5;   --peach-400: #fb923c;
            --wellness-50: #f0fdf4; --wellness-500: #22c55e;
            --gold: #d4af37;
        }
        body { font-family: 'Inter', sans-serif; }
        .font-serif { font-family: 'Playfair Display', serif; }
        .glass-premium {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.3);
        }
        .sidebar-item { @apply flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-150; }
        .sidebar-item:hover { @apply bg-violet-50 text-violet-700; }
        .sidebar-item.active { @apply bg-violet-100 text-violet-800 font-semibold; }
        .stat-card { @apply bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow; }
        .btn-primary { @apply bg-violet-600 hover:bg-violet-700 text-white font-medium px-5 py-2.5 rounded-xl text-sm transition-all active:scale-95; }
        .btn-secondary { @apply bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium px-5 py-2.5 rounded-xl text-sm transition-all; }
        .btn-danger { @apply bg-red-50 hover:bg-red-100 text-red-700 font-medium px-5 py-2.5 rounded-xl text-sm transition-all; }
        .badge { @apply inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium; }
        .badge-emerald { @apply bg-emerald-50 text-emerald-700; }
        .badge-amber { @apply bg-amber-50 text-amber-700; }
        .badge-slate { @apply bg-slate-100 text-slate-600; }
        .badge-red { @apply bg-red-50 text-red-700; }
        .badge-blue { @apply bg-blue-50 text-blue-700; }
        .badge-purple { @apply bg-purple-50 text-purple-700; }
        .badge-orange { @apply bg-orange-50 text-orange-700; }
        .table-header { @apply px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider; }
        .table-cell { @apply px-4 py-3 text-sm text-slate-700; }
        .form-label { @apply block text-sm font-medium text-slate-700 mb-1.5; }
        .form-input { @apply w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-slate-800 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all; }
        .form-select { @apply w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-slate-800 focus:ring-2 focus:ring-violet-500 focus:border-transparent bg-white; }
        .form-textarea { @apply w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-slate-800 focus:ring-2 focus:ring-violet-500 focus:border-transparent resize-y; }
        .card { @apply bg-white rounded-2xl border border-slate-100 shadow-sm; }
        .trend-up { @apply text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg text-xs font-medium; }
        .trend-down { @apply text-red-500 bg-red-50 px-2 py-0.5 rounded-lg text-xs font-medium; }
        [x-cloak] { display: none !important; }
    </style>

    @stack('head')
</head>

<body class="h-full bg-slate-50 antialiased" x-data="{ sidebarOpen: false, notificationsOpen: false }">

{{-- ─── Mobile Sidebar Overlay ─────────────────────────────────────────────── --}}
<div x-show="sidebarOpen" x-cloak
     x-transition:enter="transition-opacity ease-linear duration-200"
     x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
     x-transition:leave="transition-opacity ease-linear duration-200"
     x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
     @click="sidebarOpen = false"
     class="fixed inset-0 z-40 bg-slate-900/50 lg:hidden">
</div>

{{-- ─── Sidebar ─────────────────────────────────────────────────────────────── --}}
<aside class="fixed inset-y-0 left-0 z-50 flex w-64 flex-col bg-white border-r border-slate-100 shadow-sm transition-transform duration-200 lg:translate-x-0"
       :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'">

    {{-- Logo --}}
    <div class="flex h-16 items-center px-6 border-b border-slate-100">
        <div class="flex items-center gap-2.5">
            <div class="h-8 w-8 rounded-xl bg-gradient-to-br from-violet-500 to-violet-700 flex items-center justify-center">
                <svg class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                </svg>
            </div>
            <span class="font-serif font-semibold text-slate-800 text-lg leading-tight">BalanceBoat</span>
        </div>
        <button @click="sidebarOpen = false" class="ml-auto lg:hidden text-slate-400 hover:text-slate-600">
            <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
    </div>

    {{-- Center info --}}
    @auth
    <div class="px-4 py-3 border-b border-slate-100 bg-violet-50/50">
        <p class="text-xs font-medium text-violet-700 truncate">{{ auth()->user()->center?->name ?? 'BalanceBoat Admin' }}</p>
        <p class="text-xs text-slate-500 capitalize">{{ auth()->user()->center_role ?? 'Admin' }}</p>
    </div>
    @endauth

    {{-- Navigation --}}
    <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-0.5 custom-scrollbar">
        <a href="{{ route('dashboard') }}"
           class="sidebar-item {{ request()->routeIs('dashboard') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
            Dashboard
        </a>

        <div class="pt-4 pb-1 px-2">
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-widest">Retreats</p>
        </div>

        <a href="{{ route('retreats.index') }}"
           class="sidebar-item {{ request()->routeIs('retreats.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>
            Retreats
        </a>

        <a href="{{ route('bookings.index') }}"
           class="sidebar-item {{ request()->routeIs('bookings.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            Bookings
            @php($pending = auth()->user()->center_id ? \App\Models\Booking::forCenter(auth()->user()->center_id)->inStage('confirmed')->count() : 0)
            @if($pending > 0)
                <span class="ml-auto badge badge-violet bg-violet-100 text-violet-700">{{ $pending }}</span>
            @endif
        </a>

        <a href="{{ route('inquiries.index') }}"
           class="sidebar-item {{ request()->routeIs('inquiries.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
            Inquiries
        </a>

        <div class="pt-4 pb-1 px-2">
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-widest">Operations</p>
        </div>

        <a href="{{ route('teachers.index') }}"
           class="sidebar-item {{ request()->routeIs('teachers.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            Teachers
        </a>

        <a href="{{ route('media.index') }}"
           class="sidebar-item {{ request()->routeIs('media.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            Media Library
        </a>

        <a href="{{ route('reviews.index') }}"
           class="sidebar-item {{ request()->routeIs('reviews.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
            Reviews
        </a>

        <div class="pt-4 pb-1 px-2">
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-widest">Revenue</p>
        </div>

        <a href="{{ route('pricing.rules') }}"
           class="sidebar-item {{ request()->routeIs('pricing.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
            Pricing Engine
        </a>

        <a href="{{ route('finance.index') }}"
           class="sidebar-item {{ request()->routeIs('finance.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            Finance
        </a>

        <a href="{{ route('analytics.index') }}"
           class="sidebar-item {{ request()->routeIs('analytics.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
            Analytics
        </a>

        <div class="pt-4 pb-1 px-2">
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-widest">Intelligence</p>
        </div>

        <a href="{{ route('ai.index') }}"
           class="sidebar-item {{ request()->routeIs('ai.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
            AI Studio
        </a>

        <a href="{{ route('automations.index') }}"
           class="sidebar-item {{ request()->routeIs('automations.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            Automations
        </a>

        <div class="pt-4 pb-1 px-2">
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-widest">Settings</p>
        </div>

        <a href="{{ route('settings.center-profile') }}"
           class="sidebar-item {{ request()->routeIs('settings.*') ? 'active' : 'text-slate-600' }}">
            <svg class="h-4 w-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            Center Settings
        </a>
    </nav>

    {{-- User menu at bottom --}}
    @auth
    <div class="border-t border-slate-100 p-4">
        <div class="flex items-center gap-3">
            <img src="{{ auth()->user()->avatar_url }}" alt="{{ auth()->user()->full_name }}"
                 class="h-8 w-8 rounded-full object-cover ring-2 ring-violet-100">
            <div class="min-w-0 flex-1">
                <p class="text-sm font-medium text-slate-700 truncate">{{ auth()->user()->full_name }}</p>
                <p class="text-xs text-slate-400 truncate capitalize">{{ auth()->user()->center_role ?? 'Admin' }}</p>
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="text-slate-400 hover:text-red-500 transition-colors" title="Sign out">
                    <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                </button>
            </form>
        </div>
    </div>
    @endauth
</aside>

{{-- ─── Main Content Area ─────────────────────────────────────────────────── --}}
<div class="lg:pl-64 flex flex-col min-h-screen">

    {{-- Top Header --}}
    <header class="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-slate-100 bg-white/95 backdrop-blur-sm px-4 lg:px-8">
        <button @click="sidebarOpen = true" class="lg:hidden text-slate-500 hover:text-slate-700 p-1">
            <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>

        {{-- Breadcrumbs --}}
        <div class="flex-1 min-w-0">
            @isset($title)
                <h1 class="text-lg font-semibold text-slate-800 truncate">{{ $title }}</h1>
            @endisset
            @hasSection('breadcrumbs')
                <nav class="flex items-center gap-1 text-xs text-slate-400">
                    @yield('breadcrumbs')
                </nav>
            @endif
        </div>

        {{-- Header Actions --}}
        <div class="flex items-center gap-3">

            {{-- Global search --}}
            <div class="hidden lg:flex relative" x-data="{ searchOpen: false }">
                <button @click="searchOpen = true" class="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-50 text-slate-400 hover:bg-slate-100 text-sm transition-colors">
                    <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <span class="hidden md:block">Search...</span>
                    <kbd class="hidden md:inline-flex h-5 items-center gap-1 rounded border border-slate-200 bg-white px-1.5 font-mono text-xs text-slate-400">⌘K</kbd>
                </button>
            </div>

            {{-- Notifications bell --}}
            <div class="relative" x-data="{ open: false }">
                <button @click="open = !open"
                        class="relative p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                    @php($unreadCount = auth()->user()?->unreadNotifications()->count() ?? 0)
                    @if($unreadCount > 0)
                        <span class="absolute top-1 right-1 h-4 w-4 rounded-full bg-violet-600 text-white text-xs flex items-center justify-center font-medium">{{ $unreadCount > 9 ? '9+' : $unreadCount }}</span>
                    @endif
                </button>

                <div x-show="open" x-cloak @click.outside="open = false"
                     x-transition:enter="transition ease-out duration-150"
                     x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
                     class="absolute right-0 top-12 w-80 bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden z-50">
                    <div class="p-4 border-b border-slate-100 flex items-center justify-between">
                        <h3 class="font-semibold text-slate-800 text-sm">Notifications</h3>
                        @if($unreadCount > 0)
                            <a href="{{ route('notifications.mark-all-read') }}" class="text-xs text-violet-600 hover:underline">Mark all read</a>
                        @endif
                    </div>
                    <div class="max-h-80 overflow-y-auto divide-y divide-slate-50">
                        @forelse(auth()->user()?->unreadNotifications()->limit(8)->get() ?? [] as $notification)
                            <a href="{{ $notification->data['url'] ?? '#' }}"
                               class="flex items-start gap-3 p-4 hover:bg-slate-50 transition-colors">
                                <div class="h-8 w-8 rounded-full bg-{{ $notification->data['color'] ?? 'slate' }}-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <div class="h-2 w-2 rounded-full bg-{{ $notification->data['color'] ?? 'slate' }}-500"></div>
                                </div>
                                <div class="min-w-0">
                                    <p class="text-sm text-slate-700 leading-snug">{{ $notification->data['message'] ?? '' }}</p>
                                    <p class="text-xs text-slate-400 mt-1">{{ $notification->created_at->diffForHumans() }}</p>
                                </div>
                            </a>
                        @empty
                            <div class="p-8 text-center text-sm text-slate-400">All caught up! 🎉</div>
                        @endforelse
                    </div>
                </div>
            </div>

            {{-- User avatar --}}
            @auth
            <div class="relative" x-data="{ open: false }">
                <button @click="open = !open" class="flex items-center gap-2">
                    <img src="{{ auth()->user()->avatar_url }}" alt="{{ auth()->user()->full_name }}"
                         class="h-8 w-8 rounded-full object-cover ring-2 ring-violet-100">
                </button>
                <div x-show="open" x-cloak @click.outside="open = false"
                     class="absolute right-0 top-12 w-52 bg-white rounded-2xl shadow-xl border border-slate-100 py-1 z-50">
                    <div class="px-4 py-3 border-b border-slate-100">
                        <p class="text-sm font-medium text-slate-800">{{ auth()->user()->full_name }}</p>
                        <p class="text-xs text-slate-500">{{ auth()->user()->email }}</p>
                    </div>
                    <a href="{{ route('settings.center-profile') }}" class="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">
                        <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                        Profile Settings
                    </a>
                    <a href="{{ route('settings.subscription') }}" class="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">
                        <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                        Subscription
                    </a>
                    <div class="border-t border-slate-100 mt-1">
                        <form action="{{ route('logout') }}" method="POST">
                            @csrf
                            <button type="submit" class="flex items-center gap-2 w-full px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 text-left">
                                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                                Sign Out
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            @endauth
        </div>
    </header>

    {{-- Flash Messages --}}
    @if(session('success'))
        <div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)"
             x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 translate-y-0" x-transition:leave-end="opacity-0 -translate-y-2"
             class="mx-4 lg:mx-8 mt-4 flex items-center gap-3 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-800">
            <svg class="h-4 w-4 flex-shrink-0 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            {{ session('success') }}
            <button @click="show = false" class="ml-auto text-emerald-600 hover:text-emerald-800">
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
    @endif

    @if(session('error'))
        <div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 8000)"
             class="mx-4 lg:mx-8 mt-4 flex items-center gap-3 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-800">
            <svg class="h-4 w-4 flex-shrink-0 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            {{ session('error') }}
        </div>
    @endif

    @if($errors->any())
        <div class="mx-4 lg:mx-8 mt-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3">
            <p class="text-sm font-medium text-red-800 mb-2">Please fix the following errors:</p>
            <ul class="space-y-1">
                @foreach($errors->all() as $error)
                    <li class="text-sm text-red-700 flex items-center gap-2">
                        <span class="h-1 w-1 rounded-full bg-red-500 flex-shrink-0"></span>
                        {{ $error }}
                    </li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- Main Page Content --}}
    <main class="flex-1 px-4 lg:px-8 py-8">
        {{ $slot }}
    </main>

    {{-- Footer --}}
    <footer class="border-t border-slate-100 px-8 py-4 flex items-center justify-between">
        <p class="text-xs text-slate-400">© {{ date('Y') }} BalanceBoat Center OS. All rights reserved.</p>
        <p class="text-xs text-slate-400">v2.0.0 · <span class="text-violet-600">Laravel 12</span></p>
    </footer>
</div>

@stack('scripts')
</body>
</html>
