@extends('layouts.app')

@section('title', 'Analytics')
@section('page-title', 'Analytics')

@section('content')
<div class="space-y-6">

    {{-- Date Range Selector --}}
    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Deep insights into your center's performance</p>
        <form method="GET" action="{{ route('analytics.index') }}" class="flex items-center gap-2">
            <select name="period" class="px-3 py-2 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600" onchange="this.form.submit()">
                <option value="7"  {{ request('period','30') == '7'  ? 'selected' : '' }}>Last 7 days</option>
                <option value="30" {{ request('period','30') == '30' ? 'selected' : '' }}>Last 30 days</option>
                <option value="90" {{ request('period','30') == '90' ? 'selected' : '' }}>Last 90 days</option>
                <option value="365"{{ request('period','30') == '365'? 'selected' : '' }}>Last 12 months</option>
            </select>
        </form>
    </div>

    {{-- KPI Cards --}}
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        @php
        $kpiCards = [
            ['label'=>'Total Revenue', 'value'=>'$'.number_format($analytics['revenue']??0,0), 'change'=>($analytics['revenue_change']??0).'%', 'trend'=>($analytics['revenue_change']??0)>=0?'up':'down', 'icon'=>'💰'],
            ['label'=>'Bookings', 'value'=>number_format($analytics['bookings']??0), 'change'=>($analytics['bookings_change']??0).'%', 'trend'=>($analytics['bookings_change']??0)>=0?'up':'down', 'icon'=>'📅'],
            ['label'=>'Occupancy Rate', 'value'=>($analytics['occupancy']??0).'%', 'change'=>($analytics['occupancy_change']??0).'%', 'trend'=>($analytics['occupancy_change']??0)>=0?'up':'down', 'icon'=>'🏠'],
            ['label'=>'Avg Booking Value', 'value'=>'$'.number_format($analytics['avg_value']??0,0), 'change'=>($analytics['avg_value_change']??0).'%', 'trend'=>($analytics['avg_value_change']??0)>=0?'up':'down', 'icon'=>'📈'],
        ];
        @endphp
        @foreach($kpiCards as $card)
        <x-stat-card
            label="{{ $card['label'] }}"
            value="{{ $card['value'] }}"
            icon="{{ $card['icon'] }}"
            change="{{ $card['change'] }}"
            trend="{{ $card['trend'] }}"
        />
        @endforeach
    </div>

    {{-- Revenue + Bookings Charts --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 class="font-semibold text-gray-900 mb-4">Revenue Over Time</h3>
            <canvas id="revenueChart" height="200"></canvas>
        </div>
        <div class="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 class="font-semibold text-gray-900 mb-4">Bookings Over Time</h3>
            <canvas id="bookingsChart" height="200"></canvas>
        </div>
    </div>

    {{-- Top Retreats + Category Breakdown --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {{-- Top Retreats --}}
        <div class="bg-white rounded-2xl border border-gray-100">
            <div class="px-5 py-4 border-b border-gray-50">
                <h3 class="font-semibold text-gray-900">Top Retreats</h3>
            </div>
            <div class="divide-y divide-gray-50">
                @foreach($topRetreats ?? [] as $i => $retreat)
                <div class="px-5 py-3.5 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <span class="text-xl font-bold text-lavender-200 w-6">{{ $i+1 }}</span>
                        <div>
                            <div class="text-sm font-medium text-gray-900 truncate max-w-[180px]">{{ $retreat->title }}</div>
                            <div class="text-xs text-gray-400">{{ $retreat->bookings_count }} bookings</div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-sm font-semibold text-wellness-600">${{ number_format($retreat->revenue,0) }}</div>
                        <div class="text-xs text-gray-400">{{ $retreat->occupancy_rate ?? 0 }}% occ.</div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Category Breakdown --}}
        <div class="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 class="font-semibold text-gray-900 mb-4">Revenue by Category</h3>
            <canvas id="categoryChart" height="220"></canvas>
        </div>
    </div>

    {{-- Geographic + Source Breakdown --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 class="font-semibold text-gray-900 mb-4">Top Guest Countries</h3>
            <div class="space-y-3">
                @foreach($topCountries ?? [] as $country)
                <div class="flex items-center gap-3">
                    <div class="w-24 text-xs text-gray-600">{{ $country->country }}</div>
                    <div class="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div class="h-full bg-lavender-500 rounded-full"
                             style="width:{{ $country->pct ?? 0 }}%"></div>
                    </div>
                    <div class="w-16 text-right text-xs font-medium text-gray-700">{{ $country->pct ?? 0 }}%</div>
                </div>
                @endforeach
            </div>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 class="font-semibold text-gray-900 mb-4">Booking Sources</h3>
            <canvas id="sourceChart" height="180"></canvas>
            <div class="mt-3 space-y-2">
                @foreach($bookingSources ?? ['Direct Website'=>40,'Social Media'=>25,'Referral'=>20,'Email Campaign'=>15] as $source => $pct)
                <div class="flex items-center justify-between text-sm">
                    <span class="text-gray-600">{{ $source }}</span>
                    <span class="font-medium text-gray-900">{{ $pct }}%</span>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    {{-- Guest Cohort Retention --}}
    <div class="bg-white rounded-2xl border border-gray-100 p-5">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-semibold text-gray-900">Monthly Cohort Retention</h3>
            <span class="text-xs text-gray-400">% of guests who returned</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead>
                    <tr class="border-b border-gray-100">
                        <th class="text-left pb-2 text-gray-500 font-medium">Cohort</th>
                        @for($m = 0; $m < 6; $m++)
                        <th class="pb-2 text-gray-500 font-medium text-center">M+{{ $m }}</th>
                        @endfor
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    @foreach($cohortData ?? [] as $row)
                    <tr>
                        <td class="py-2 text-gray-600 font-medium">{{ $row['month'] }}</td>
                        @foreach($row['retention'] as $pct)
                        @php
                        $bg = $pct >= 80 ? 'bg-wellness-500' : ($pct >= 50 ? 'bg-lavender-400' : ($pct >= 30 ? 'bg-lavender-200' : 'bg-gray-100'));
                        $text = $pct >= 50 ? 'text-white' : 'text-gray-700';
                        @endphp
                        <td class="py-2 text-center">
                            @if($pct !== null)
                            <span class="inline-block px-2.5 py-0.5 rounded-md {{ $bg }} {{ $text }} font-medium">{{ $pct }}%</span>
                            @else
                            <span class="text-gray-200">—</span>
                            @endif
                        </td>
                        @endforeach
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    {{-- Export --}}
    <div class="flex justify-end gap-3">
        <a href="{{ route('analytics.export', ['format'=>'csv','period'=>request('period',30)]) }}"
           class="flex items-center gap-2 px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
            📥 Export CSV
        </a>
        <a href="{{ route('analytics.export', ['format'=>'pdf','period'=>request('period',30)]) }}"
           class="flex items-center gap-2 px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
            📄 Export PDF
        </a>
    </div>

</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const chartDefaults = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
        y: { grid: { color: '#f3f4f6' }, ticks: { color: '#9ca3af' } },
        x: { grid: { display: false }, ticks: { color: '#9ca3af' } }
    }
};

// Revenue
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: @json($revenueChart['labels'] ?? []),
        datasets: [{ data: @json($revenueChart['data'] ?? []), borderColor:'#8b5cf6', backgroundColor:'rgba(139,92,246,0.06)', fill:true, tension:0.4, borderWidth:2.5, pointBackgroundColor:'#8b5cf6', pointRadius:3 }]
    },
    options: { ...chartDefaults, scales: { ...chartDefaults.scales, y: { ...chartDefaults.scales.y, ticks: { callback: v => '$'+v.toLocaleString(), color:'#9ca3af' } } } }
});

// Bookings
new Chart(document.getElementById('bookingsChart'), {
    type: 'bar',
    data: {
        labels: @json($bookingsChart['labels'] ?? []),
        datasets: [{ data: @json($bookingsChart['data'] ?? []), backgroundColor:'rgba(139,92,246,0.75)', borderRadius:6, borderSkipped:false }]
    },
    options: chartDefaults
});

// Category
new Chart(document.getElementById('categoryChart'), {
    type: 'doughnut',
    data: {
        labels: @json(array_keys($categoryBreakdown ?? [])),
        datasets: [{ data: @json(array_values($categoryBreakdown ?? [])), backgroundColor:['#8b5cf6','#fb923c','#22c55e','#6d28d9','#f97316','#06b6d4'], borderWidth:0, hoverOffset:4 }]
    },
    options: { responsive:true, cutout:'70%', plugins:{ legend:{ position:'bottom', labels:{ padding:12, font:{ size:11 } } } } }
});

// Source
new Chart(document.getElementById('sourceChart'), {
    type: 'doughnut',
    data: {
        labels: @json(array_keys($bookingSources ?? ['Direct'=>40,'Social'=>25,'Referral'=>20,'Email'=>15])),
        datasets: [{ data: @json(array_values($bookingSources ?? [40,25,20,15])), backgroundColor:['#8b5cf6','#fb923c','#22c55e','#f97316'], borderWidth:0, hoverOffset:4 }]
    },
    options: { responsive:true, cutout:'65%', plugins:{ legend:{ display:false } } }
});
</script>
@endpush
