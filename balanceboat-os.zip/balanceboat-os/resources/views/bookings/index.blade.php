@extends('layouts.app')

@section('title', 'Bookings')
@section('page-title', 'Bookings')

@section('content')
<div class="space-y-6" x-data="{ view: 'list' }">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Manage and track all retreat bookings</p>
        <div class="flex items-center gap-3">
            {{-- View Toggle --}}
            <div class="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                <button @click="view = 'list'" :class="view === 'list' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'"
                        class="p-1.5 rounded-md transition-all">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zM3.75 12h.007v.008H3.75V12zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm-.375 5.25h.007v.008H3.75v-.008zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"/>
                    </svg>
                </button>
                <button @click="view = 'kanban'" :class="view === 'kanban' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'"
                        class="p-1.5 rounded-md transition-all">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 4.5v15m6-15v15m-10.875 0h15.75c.621 0 1.125-.504 1.125-1.125V5.625c0-.621-.504-1.125-1.125-1.125H4.125C3.504 4.5 3 5.004 3 5.625v12.75c0 .621.504 1.125 1.125 1.125z"/>
                    </svg>
                </button>
            </div>

            <a href="{{ route('bookings.create') }}"
               class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-semibold hover:bg-lavender-700 transition-colors">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                </svg>
                Add Booking
            </a>
        </div>
    </div>

    <x-alert />

    {{-- Filters --}}
    <form method="GET" action="{{ route('bookings.index') }}" class="flex items-center gap-3 flex-wrap">
        <div class="relative flex-1 min-w-[200px]">
            <input type="text" name="search" value="{{ request('search') }}"
                placeholder="Search guest, ref, retreat..."
                class="w-full pl-9 pr-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 bg-white">
            <svg class="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 15.803 7.5 7.5 0 0016.803 15.803z"/>
            </svg>
        </div>

        <select name="status" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="">All Statuses</option>
            @foreach(['pending','confirmed','checked_in','completed','cancelled','refunded'] as $status)
            <option value="{{ $status }}" {{ request('status') === $status ? 'selected' : '' }}>{{ ucfirst(str_replace('_',' ',$status)) }}</option>
            @endforeach
        </select>

        <select name="retreat_id" class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-600">
            <option value="">All Retreats</option>
            @foreach($retreats ?? [] as $retreat)
            <option value="{{ $retreat->id }}" {{ request('retreat_id') == $retreat->id ? 'selected' : '' }}>{{ Str::limit($retreat->title, 30) }}</option>
            @endforeach
        </select>

        <input type="date" name="date_from" value="{{ request('date_from') }}"
            class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-500">
        <input type="date" name="date_to" value="{{ request('date_to') }}"
            class="px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 bg-white text-gray-500">

        <button type="submit" class="px-4 py-2.5 bg-lavender-600 text-white text-sm font-medium rounded-xl hover:bg-lavender-700">Filter</button>
        @if(request()->hasAny(['search','status','retreat_id','date_from','date_to']))
        <a href="{{ route('bookings.index') }}" class="px-3 py-2.5 text-sm text-gray-500 hover:text-gray-700 border border-gray-200 rounded-xl bg-white">Clear</a>
        @endif
    </form>

    {{-- LIST VIEW --}}
    <div x-show="view === 'list'">
        <x-data-table
            :columns="[
                ['key'=>'ref','label'=>'Reference','sortable'=>true],
                ['key'=>'guest','label'=>'Guest'],
                ['key'=>'retreat','label'=>'Retreat'],
                ['key'=>'dates','label'=>'Check-in'],
                ['key'=>'guests','label'=>'Guests'],
                ['key'=>'amount','label'=>'Amount'],
                ['key'=>'status','label'=>'Status'],
                ['key'=>'actions','label'=>''],
            ]"
            empty-text="No bookings found."
            empty-icon="📅"
        >
            @forelse($bookings as $booking)
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="px-5 py-3.5">
                    <a href="{{ route('bookings.show', $booking) }}" class="text-sm font-mono font-medium text-lavender-700 hover:text-lavender-900">
                        {{ $booking->reference_number }}
                    </a>
                </td>
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 bg-lavender-50 rounded-full flex items-center justify-center text-xs font-bold text-lavender-700 flex-shrink-0">
                            {{ strtoupper(substr($booking->guest_name, 0, 1)) }}
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-900">{{ $booking->guest_name }}</div>
                            <div class="text-xs text-gray-400">{{ $booking->guest_email }}</div>
                        </div>
                    </div>
                </td>
                <td class="px-5 py-3.5">
                    <div class="text-sm text-gray-700 max-w-[160px] truncate">{{ $booking->experience?->title }}</div>
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-600 whitespace-nowrap">
                    {{ $booking->check_in_date?->format('d M Y') }}
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-600">{{ $booking->number_of_guests }}</td>
                <td class="px-5 py-3.5">
                    <div class="text-sm font-semibold text-gray-900">${{ number_format($booking->total_amount, 0) }}</div>
                    @if($booking->paid_amount < $booking->total_amount)
                    <div class="text-xs text-amber-600">Partial: ${{ number_format($booking->paid_amount, 0) }}</div>
                    @endif
                </td>
                <td class="px-5 py-3.5"><x-status-badge :status="$booking->status" /></td>
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-1">
                        <a href="{{ route('bookings.show', $booking) }}" class="p-1.5 text-gray-400 hover:text-lavender-600 hover:bg-lavender-50 rounded-lg transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                        </a>
                        <a href="{{ route('bookings.edit', $booking) }}" class="p-1.5 text-gray-400 hover:text-lavender-600 hover:bg-lavender-50 rounded-lg transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931z"/>
                            </svg>
                        </a>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="px-5 py-16 text-center">
                    <div class="text-4xl mb-3">📅</div>
                    <p class="text-gray-400 text-sm">No bookings found matching your filters.</p>
                </td>
            </tr>
            @endforelse

            @slot('pagination')
            {{ $bookings->withQueryString()->links() }}
            @endslot
        </x-data-table>
    </div>

    {{-- KANBAN VIEW --}}
    <div x-show="view === 'kanban'" class="overflow-x-auto pb-4">
        <div class="flex gap-4 min-w-max">
            @php
            $columns = [
                'pending'    => ['label' => 'Pending',    'color' => 'bg-amber-50 border-amber-200',    'dot' => 'bg-amber-400'],
                'confirmed'  => ['label' => 'Confirmed',  'color' => 'bg-lavender-50 border-lavender-200','dot' => 'bg-lavender-500'],
                'checked_in' => ['label' => 'Checked In', 'color' => 'bg-wellness-50 border-wellness-200','dot' => 'bg-wellness-500'],
                'completed'  => ['label' => 'Completed',  'color' => 'bg-indigo-50 border-indigo-200',  'dot' => 'bg-indigo-500'],
                'cancelled'  => ['label' => 'Cancelled',  'color' => 'bg-red-50 border-red-200',        'dot' => 'bg-red-400'],
            ];
            @endphp
            @foreach($columns as $status => $col)
            <div class="w-72 flex-shrink-0">
                <div class="flex items-center gap-2 mb-3">
                    <span class="w-2 h-2 rounded-full {{ $col['dot'] }}"></span>
                    <span class="text-sm font-semibold text-gray-700">{{ $col['label'] }}</span>
                    <span class="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full ml-auto">
                        {{ $bookingsByStatus[$status]?->count() ?? 0 }}
                    </span>
                </div>
                <div class="space-y-3">
                    @foreach($bookingsByStatus[$status] ?? [] as $booking)
                    <a href="{{ route('bookings.show', $booking) }}"
                       class="block bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md hover:border-lavender-200 transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-mono text-lavender-600 font-medium">{{ $booking->reference_number }}</span>
                            <span class="text-xs text-gray-400">{{ $booking->check_in_date?->format('d M') }}</span>
                        </div>
                        <div class="text-sm font-medium text-gray-900 mb-1">{{ $booking->guest_name }}</div>
                        <div class="text-xs text-gray-400 truncate mb-2">{{ $booking->experience?->title }}</div>
                        <div class="flex items-center justify-between text-xs">
                            <span class="text-gray-500">{{ $booking->number_of_guests }} guest{{ $booking->number_of_guests !== 1 ? 's' : '' }}</span>
                            <span class="font-semibold text-gray-900">${{ number_format($booking->total_amount, 0) }}</span>
                        </div>
                    </a>
                    @endforeach
                </div>
            </div>
            @endforeach
        </div>
    </div>

</div>
@endsection
