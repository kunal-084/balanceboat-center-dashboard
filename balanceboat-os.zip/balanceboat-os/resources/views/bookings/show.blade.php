@extends('layouts.app')

@section('title', 'Booking ' . $booking->reference_number)
@section('page-title', 'Booking Detail')

@section('content')
<div class="space-y-6">

    {{-- Header --}}
    <div class="flex items-start justify-between">
        <div class="flex items-center gap-3">
            <a href="{{ route('bookings.index') }}" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <span class="font-mono text-sm text-lavender-700 font-semibold">{{ $booking->reference_number }}</span>
                    <x-status-badge :status="$booking->status" />
                </div>
                <p class="text-sm text-gray-400">Created {{ $booking->created_at->diffForHumans() }} · {{ $booking->created_at->format('d M Y, H:i') }}</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <a href="{{ route('bookings.edit', $booking) }}" class="px-3 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                Edit
            </a>
            {{-- Status Transition Actions --}}
            @if($booking->status === 'pending')
            <form method="POST" action="{{ route('bookings.confirm', $booking) }}">
                @csrf @method('PATCH')
                <button type="submit" class="px-4 py-2 text-sm font-semibold bg-lavender-600 text-white rounded-xl hover:bg-lavender-700 transition-colors">Confirm</button>
            </form>
            @elseif($booking->status === 'confirmed')
            <form method="POST" action="{{ route('bookings.checkin', $booking) }}">
                @csrf @method('PATCH')
                <button type="submit" class="px-4 py-2 text-sm font-semibold bg-wellness-500 text-white rounded-xl hover:bg-wellness-600 transition-colors">Check In</button>
            </form>
            @elseif($booking->status === 'checked_in')
            <form method="POST" action="{{ route('bookings.complete', $booking) }}">
                @csrf @method('PATCH')
                <button type="submit" class="px-4 py-2 text-sm font-semibold bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors">Complete</button>
            </form>
            @endif

            @if(!in_array($booking->status, ['cancelled','completed','refunded']))
            <form method="POST" action="{{ route('bookings.cancel', $booking) }}">
                @csrf @method('PATCH')
                <button type="submit" onclick="return confirm('Cancel this booking?')"
                        class="px-4 py-2 text-sm text-red-600 border border-red-200 rounded-xl hover:bg-red-50 transition-colors">Cancel</button>
            </form>
            @endif
        </div>
    </div>

    <x-alert />

    {{-- Status Pipeline --}}
    <div class="bg-white rounded-2xl border border-gray-100 p-5">
        <div class="flex items-center justify-between">
            @php
            $pipeline = ['pending','confirmed','checked_in','completed'];
            $currentIdx = array_search($booking->status, $pipeline) ?? -1;
            @endphp
            @foreach($pipeline as $i => $step)
            <div class="flex items-center {{ $i < count($pipeline) - 1 ? 'flex-1' : '' }}">
                <div class="flex flex-col items-center">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all
                        {{ $i <= $currentIdx ? 'bg-lavender-600 border-lavender-600 text-white' : ($booking->status === 'cancelled' && $i > 0 ? 'bg-gray-100 border-gray-200 text-gray-300' : 'border-gray-200 text-gray-300') }}">
                        @if($i < $currentIdx)
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                        </svg>
                        @else
                        <span class="text-xs font-bold">{{ $i + 1 }}</span>
                        @endif
                    </div>
                    <span class="text-xs mt-1.5 font-medium {{ $i <= $currentIdx ? 'text-lavender-700' : 'text-gray-400' }}">
                        {{ ucfirst(str_replace('_',' ',$step)) }}
                    </span>
                </div>
                @if($i < count($pipeline) - 1)
                <div class="flex-1 h-0.5 mx-2 {{ $i < $currentIdx ? 'bg-lavender-500' : 'bg-gray-100' }}"></div>
                @endif
            </div>
            @endforeach
        </div>
    </div>

    {{-- Main Content --}}
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {{-- Left: Guest + Retreat --}}
        <div class="lg:col-span-2 space-y-5">

            {{-- Guest Info --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Guest Information</h3>
                <div class="flex items-start gap-4">
                    <div class="w-14 h-14 bg-lavender-100 rounded-2xl flex items-center justify-center text-xl font-bold text-lavender-700 flex-shrink-0">
                        {{ strtoupper(substr($booking->guest_name, 0, 1)) }}
                    </div>
                    <div class="flex-1 grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Full Name</p>
                            <p class="font-medium text-gray-900">{{ $booking->guest_name }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Email</p>
                            <a href="mailto:{{ $booking->guest_email }}" class="font-medium text-lavender-700 hover:underline">{{ $booking->guest_email }}</a>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Phone</p>
                            <p class="font-medium text-gray-900">{{ $booking->guest_phone ?? '—' }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Nationality</p>
                            <p class="font-medium text-gray-900">{{ $booking->guest_nationality ?? '—' }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Number of Guests</p>
                            <p class="font-medium text-gray-900">{{ $booking->number_of_guests }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Accommodation</p>
                            <p class="font-medium text-gray-900">{{ $booking->accommodation?->name ?? '—' }}</p>
                        </div>
                    </div>
                </div>
                @if($booking->special_requests)
                <div class="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-100">
                    <p class="text-xs font-medium text-amber-800 mb-1">Special Requests</p>
                    <p class="text-sm text-amber-700">{{ $booking->special_requests }}</p>
                </div>
                @endif
            </div>

            {{-- Retreat Info --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Retreat Details</h3>
                <div class="flex items-start gap-4">
                    @if($booking->experience?->cover_image_url)
                    <img src="{{ $booking->experience->cover_image_url }}" alt="" class="w-20 h-20 object-cover rounded-xl flex-shrink-0">
                    @else
                    <div class="w-20 h-20 bg-lavender-50 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">🧘</div>
                    @endif
                    <div class="flex-1 grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Retreat</p>
                            <a href="{{ route('retreats.show', $booking->experience) }}" class="font-medium text-lavender-700 hover:underline">
                                {{ $booking->experience?->title }}
                            </a>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Location</p>
                            <p class="font-medium text-gray-900">{{ $booking->experience?->city }}, {{ $booking->experience?->country }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Check-in</p>
                            <p class="font-medium text-gray-900">{{ $booking->check_in_date?->format('d M Y') }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-400 mb-0.5">Check-out</p>
                            <p class="font-medium text-gray-900">{{ $booking->check_out_date?->format('d M Y') }}</p>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Notes --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="font-semibold text-gray-900">Internal Notes</h3>
                    <button type="button" onclick="document.getElementById('note-form').classList.toggle('hidden')"
                            class="text-xs text-lavender-600 font-medium hover:text-lavender-800">
                        + Add Note
                    </button>
                </div>

                <form id="note-form" method="POST" action="{{ route('bookings.notes.store', $booking) }}" class="hidden mb-4">
                    @csrf
                    <textarea name="content" rows="3" placeholder="Add an internal note..."
                        class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-lavender-400 resize-none mb-2"></textarea>
                    <button type="submit" class="px-4 py-1.5 bg-lavender-600 text-white text-xs font-medium rounded-lg hover:bg-lavender-700">
                        Save Note
                    </button>
                </form>

                @forelse($booking->notes ?? [] as $note)
                <div class="flex gap-2.5 py-2.5 border-b border-gray-50 last:border-0">
                    <div class="w-7 h-7 bg-lavender-100 rounded-full flex items-center justify-center text-xs font-bold text-lavender-700 flex-shrink-0">
                        {{ strtoupper(substr($note->author?->name ?? 'S', 0, 1)) }}
                    </div>
                    <div class="flex-1">
                        <div class="flex items-center gap-2 mb-0.5">
                            <span class="text-xs font-medium text-gray-700">{{ $note->author?->name ?? 'Staff' }}</span>
                            <span class="text-xs text-gray-400">{{ $note->created_at->diffForHumans() }}</span>
                        </div>
                        <p class="text-sm text-gray-600">{{ $note->content }}</p>
                    </div>
                </div>
                @empty
                <p class="text-sm text-gray-400 text-center py-4">No notes yet.</p>
                @endforelse
            </div>
        </div>

        {{-- Right Sidebar --}}
        <div class="space-y-5">

            {{-- Payment Summary --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Payment</h3>
                <div class="space-y-2 text-sm mb-4">
                    <div class="flex justify-between"><span class="text-gray-500">Base Price</span><span>${{ number_format($booking->base_price, 2) }}</span></div>
                    @if($booking->discount_amount > 0)
                    <div class="flex justify-between text-wellness-600"><span>Discount</span><span>-${{ number_format($booking->discount_amount, 2) }}</span></div>
                    @endif
                    @if($booking->tax_amount > 0)
                    <div class="flex justify-between"><span class="text-gray-500">Tax</span><span>${{ number_format($booking->tax_amount, 2) }}</span></div>
                    @endif
                    <div class="flex justify-between font-bold text-gray-900 pt-2 border-t border-gray-100">
                        <span>Total</span><span>${{ number_format($booking->total_amount, 2) }}</span>
                    </div>
                    <div class="flex justify-between text-wellness-600">
                        <span>Paid</span><span>${{ number_format($booking->paid_amount, 2) }}</span>
                    </div>
                    @if($booking->total_amount > $booking->paid_amount)
                    <div class="flex justify-between text-amber-600 font-medium">
                        <span>Balance Due</span><span>${{ number_format($booking->total_amount - $booking->paid_amount, 2) }}</span>
                    </div>
                    @endif
                </div>

                @if($booking->promo_code)
                <div class="text-xs bg-lavender-50 text-lavender-700 px-3 py-2 rounded-lg mb-3">
                    Promo: <strong>{{ $booking->promo_code }}</strong>
                </div>
                @endif

                @can('process-payouts')
                <form method="POST" action="{{ route('bookings.record-payment', $booking) }}" class="border-t border-gray-50 pt-4">
                    @csrf
                    <div class="flex gap-2">
                        <input type="number" name="amount" placeholder="Amount" step="0.01" min="0"
                            class="flex-1 px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:border-lavender-400">
                        <button type="submit" class="px-3 py-2 bg-lavender-600 text-white text-xs font-medium rounded-lg hover:bg-lavender-700">
                            Record
                        </button>
                    </div>
                </form>
                @endcan
            </div>

            {{-- Timeline --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-4">Activity Timeline</h3>
                <div class="space-y-3">
                    @forelse($booking->auditLogs ?? [] as $log)
                    <div class="flex gap-2.5">
                        <div class="w-2 h-2 bg-lavender-300 rounded-full mt-1.5 flex-shrink-0"></div>
                        <div>
                            <p class="text-xs text-gray-600">{{ $log->description }}</p>
                            <p class="text-xs text-gray-400 mt-0.5">{{ $log->created_at->format('d M Y, H:i') }}</p>
                        </div>
                    </div>
                    @empty
                    <p class="text-xs text-gray-400 text-center py-2">No activity logged.</p>
                    @endforelse
                </div>
            </div>

            {{-- Quick Actions --}}
            <div class="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Actions</h3>
                <div class="space-y-2">
                    <a href="mailto:{{ $booking->guest_email }}" class="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-gray-600 hover:bg-lavender-50 hover:text-lavender-700 transition-colors">
                        📧 Email Guest
                    </a>
                    <form method="POST" action="{{ route('bookings.send-confirmation', $booking) }}" class="inline w-full">
                        @csrf
                        <button type="submit" class="flex items-center gap-2.5 w-full px-3 py-2.5 rounded-xl text-sm text-gray-600 hover:bg-lavender-50 hover:text-lavender-700 transition-colors text-left">
                            📩 Resend Confirmation
                        </button>
                    </form>
                    <a href="{{ route('bookings.invoice', $booking) }}" target="_blank" class="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-gray-600 hover:bg-lavender-50 hover:text-lavender-700 transition-colors">
                        📄 Download Invoice
                    </a>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
