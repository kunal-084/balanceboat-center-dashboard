@extends('layouts.app')

@section('title', 'Edit Booking')
@section('page-title', 'Bookings')

@section('content')
<div class="space-y-6">

    {{-- Breadcrumb --}}
    <nav class="flex items-center gap-2 text-sm text-gray-400">
        <a href="{{ route('bookings.index') }}" class="hover:text-gray-600">Bookings</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <a href="{{ route('bookings.show', $booking) }}" class="hover:text-gray-600">#{{ $booking->booking_reference }}</a>
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <span class="text-gray-700 font-medium">Edit</span>
    </nav>

    <x-alert />

    <div class="grid grid-cols-3 gap-6">
        {{-- Main Form --}}
        <div class="col-span-2">
            <form method="POST" action="{{ route('bookings.update', $booking) }}" class="space-y-5">
                @csrf
                @method('PUT')

                {{-- Guest Info --}}
                <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                    <h2 class="font-semibold text-gray-900 mb-5">Guest Information</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <x-form-input name="guest_first_name" label="First Name" required
                            :value="old('guest_first_name', $booking->guest_first_name ?? $booking->user?->first_name)" />
                        <x-form-input name="guest_last_name" label="Last Name"
                            :value="old('guest_last_name', $booking->guest_last_name ?? $booking->user?->last_name)" />
                        <x-form-input name="guest_email" label="Email" type="email" required
                            :value="old('guest_email', $booking->guest_email ?? $booking->user?->email)" />
                        <x-form-input name="guest_phone" label="Phone"
                            :value="old('guest_phone', $booking->guest_phone ?? $booking->user?->phone)" />
                        <x-form-input name="guest_country" label="Country"
                            :value="old('guest_country', $booking->guest_country)" />
                        <x-form-input name="participants" label="Number of Participants" type="number" required
                            :value="old('participants', $booking->participants)" />
                    </div>
                </div>

                {{-- Booking Details --}}
                <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                    <h2 class="font-semibold text-gray-900 mb-5">Booking Details</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                            <select name="status"
                                class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100">
                                @foreach(['pending','confirmed','waitlisted','cancelled','completed','no_show'] as $s)
                                <option value="{{ $s }}" {{ old('status', $booking->status) === $s ? 'selected' : '' }}>
                                    {{ ucwords(str_replace('_', ' ', $s)) }}
                                </option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">Room Type</label>
                            <select name="room_type_id"
                                class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100">
                                <option value="">— No Room Selected —</option>
                                @foreach($roomTypes as $room)
                                <option value="{{ $room->id }}"
                                    {{ old('room_type_id', $booking->room_type_id) == $room->id ? 'selected' : '' }}>
                                    {{ $room->name }} (+${{ number_format($room->price_addon, 0) }})
                                </option>
                                @endforeach
                            </select>
                        </div>

                        <x-form-input name="dietary_requirements" label="Dietary Requirements"
                            :value="old('dietary_requirements', $booking->dietary_requirements)"
                            placeholder="Vegan, Gluten-free, etc." />

                        <x-form-input name="arrival_date" label="Arrival Date" type="date"
                            :value="old('arrival_date', $booking->arrival_date?->format('Y-m-d'))" />

                        <div class="col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">Special Requests</label>
                            <textarea name="special_requests" rows="3"
                                class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-none">{{ old('special_requests', $booking->special_requests) }}</textarea>
                        </div>

                        <div class="col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">Internal Notes (not visible to guest)</label>
                            <textarea name="admin_notes" rows="3"
                                class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-none bg-amber-50">{{ old('admin_notes', $booking->admin_notes) }}</textarea>
                        </div>
                    </div>
                </div>

                {{-- Payment Override --}}
                <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                    <h2 class="font-semibold text-gray-900 mb-5">Payment Adjustment</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <x-form-input name="total_price" label="Total Price ($)" type="number"
                            :value="old('total_price', $booking->total_price)"
                            hint="Override the calculated price" />
                        <x-form-input name="amount_paid" label="Amount Paid ($)" type="number"
                            :value="old('amount_paid', $booking->amount_paid)" />
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">Payment Status</label>
                            <select name="payment_status"
                                class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100">
                                @foreach(['pending','deposit_paid','paid','refunded','partially_refunded'] as $s)
                                <option value="{{ $s }}" {{ old('payment_status', $booking->payment_status) === $s ? 'selected' : '' }}>
                                    {{ ucwords(str_replace('_', ' ', $s)) }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <x-form-input name="discount_amount" label="Manual Discount ($)" type="number"
                            :value="old('discount_amount', $booking->discount_amount ?? 0)" />
                    </div>
                    <div class="mt-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Payment Notes</label>
                        <textarea name="payment_notes" rows="2"
                            class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 resize-none">{{ old('payment_notes', $booking->payment_notes) }}</textarea>
                    </div>
                </div>

                <div class="flex justify-between items-center">
                    <a href="{{ route('bookings.show', $booking) }}"
                       class="px-4 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit"
                            class="px-6 py-2.5 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700 transition-colors">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>

        {{-- Right: Booking Summary --}}
        <div class="space-y-4">
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Booking Summary</h3>
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <span class="text-gray-500">Reference</span>
                        <span class="font-mono font-semibold text-gray-900">#{{ $booking->booking_reference }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Retreat</span>
                        <a href="{{ route('retreats.show', $booking->experience) }}" class="text-lavender-600 hover:underline truncate ml-2 max-w-[160px]">
                            {{ $booking->experience->title }}
                        </a>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Dates</span>
                        <span class="text-gray-900">
                            {{ $booking->batch?->start_date->format('d M') }} –
                            {{ $booking->batch?->end_date->format('d M Y') }}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Created</span>
                        <span class="text-gray-900">{{ $booking->created_at->format('d M Y') }}</span>
                    </div>
                    <hr class="border-gray-100 my-2">
                    <div class="flex justify-between">
                        <span class="text-gray-500">Total</span>
                        <span class="font-semibold text-gray-900">${{ number_format($booking->total_price, 0) }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Paid</span>
                        <span class="font-semibold text-wellness-600">${{ number_format($booking->amount_paid, 0) }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500">Balance</span>
                        <span class="font-semibold text-amber-600">${{ number_format($booking->total_price - $booking->amount_paid, 0) }}</span>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 class="font-semibold text-gray-900 mb-3">Quick Actions</h3>
                <div class="space-y-2">
                    <form method="POST" action="{{ route('bookings.send-confirmation', $booking) }}">
                        @csrf
                        <button type="submit" class="w-full text-left text-sm text-lavender-600 px-3 py-2.5 hover:bg-lavender-50 rounded-xl transition-colors font-medium">
                            📧 Resend Confirmation Email
                        </button>
                    </form>
                    <form method="POST" action="{{ route('bookings.send-whatsapp', $booking) }}">
                        @csrf
                        <button type="submit" class="w-full text-left text-sm text-wellness-600 px-3 py-2.5 hover:bg-wellness-50 rounded-xl transition-colors font-medium">
                            💬 Send WhatsApp Update
                        </button>
                    </form>
                    <a href="{{ route('bookings.show', $booking) }}"
                       class="block text-sm text-gray-600 px-3 py-2.5 hover:bg-gray-50 rounded-xl transition-colors font-medium">
                        👁 View Full Booking
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
