@extends('layouts.app')

@section('title', 'Promo Codes')
@section('page-title', 'Pricing')

@section('content')
<div class="space-y-6" x-data="{ showCreate: false }">

    {{-- Sub-nav --}}
    <div class="flex items-center gap-1 bg-gray-100/70 rounded-xl p-1 w-fit">
        <a href="{{ route('pricing.index') }}"
           class="px-3.5 py-1.5 rounded-lg text-sm font-medium text-gray-500 hover:text-gray-700">
            Pricing Rules
        </a>
        <a href="{{ route('pricing.promo-codes') }}"
           class="px-3.5 py-1.5 rounded-lg text-sm font-medium bg-white text-lavender-700 shadow-sm">
            Promo Codes
        </a>
    </div>

    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Create discount codes for marketing campaigns</p>
        <button @click="showCreate = !showCreate"
                class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-semibold hover:bg-lavender-700 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            New Promo Code
        </button>
    </div>

    <x-alert />

    {{-- Create Promo Code --}}
    <div x-show="showCreate" x-transition class="bg-peach-50 border border-peach-200 rounded-2xl p-5">
        <h3 class="font-semibold text-gray-900 mb-4">Create Promo Code</h3>
        <form method="POST" action="{{ route('pricing.promo-codes.store') }}" class="grid grid-cols-3 gap-4">
            @csrf
            <x-form-input name="code" label="Code" required placeholder="WELLNESS20"
                hint="Guests enter this code at checkout" />
            <x-form-input name="discount_type" label="Discount Type" type="select" required
                :options="['percentage'=>'Percentage (%)','fixed'=>'Fixed Amount ($)']" />
            <x-form-input name="discount_value" label="Discount Value" type="number" required placeholder="20" />

            <x-form-input name="min_amount" label="Minimum Order ($)" type="number" placeholder="500"
                hint="Minimum booking value to apply" />
            <x-form-input name="max_uses" label="Max Total Uses" type="number" placeholder="100"
                hint="Leave blank for unlimited" />
            <x-form-input name="max_uses_per_user" label="Max Per User" type="number" :value="old('max_uses_per_user',1)" />

            <x-form-input name="valid_from" label="Valid From" type="date" />
            <x-form-input name="valid_until" label="Valid Until" type="date" />

            <div class="flex flex-col justify-end gap-2">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" checked
                        class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                    <span class="text-sm text-gray-700">Active immediately</span>
                </label>
            </div>

            <div class="col-span-3 flex justify-end gap-3">
                <button type="button" @click="showCreate = false" class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-white">Cancel</button>
                <button type="submit" class="px-5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700">Create Code</button>
            </div>
        </form>
    </div>

    {{-- Promo Codes Table --}}
    <x-data-table
        :columns="[
            ['key'=>'code','label'=>'Code'],
            ['key'=>'discount','label'=>'Discount'],
            ['key'=>'usage','label'=>'Usage'],
            ['key'=>'min_amount','label'=>'Min. Order'],
            ['key'=>'valid','label'=>'Valid Period'],
            ['key'=>'status','label'=>'Status'],
            ['key'=>'revenue','label'=>'Revenue Saved'],
            ['key'=>'actions','label'=>''],
        ]"
        empty-text="No promo codes yet."
        empty-icon="🏷️"
    >
        @forelse($promoCodes as $code)
        <tr class="hover:bg-gray-50 transition-colors">
            <td class="px-5 py-3.5">
                <div class="font-mono text-sm font-bold text-lavender-700 bg-lavender-50 px-2.5 py-1 rounded-lg inline-block">
                    {{ $code->code }}
                </div>
            </td>
            <td class="px-5 py-3.5 text-sm font-semibold text-gray-900">
                {{ $code->discount_type === 'percentage' ? $code->discount_value.'%' : '$'.number_format($code->discount_value,2) }} off
            </td>
            <td class="px-5 py-3.5">
                <div class="text-sm text-gray-900">{{ $code->used_count }} / {{ $code->max_uses ?? '∞' }}</div>
                @if($code->max_uses)
                <div class="w-24 bg-gray-100 rounded-full h-1.5 mt-1 overflow-hidden">
                    <div class="h-full bg-lavender-500 rounded-full" style="width:{{ min(100, ($code->used_count / $code->max_uses) * 100) }}%"></div>
                </div>
                @endif
            </td>
            <td class="px-5 py-3.5 text-sm text-gray-600">
                {{ $code->min_amount ? '$'.number_format($code->min_amount,0) : '—' }}
            </td>
            <td class="px-5 py-3.5 text-xs text-gray-500">
                @if($code->valid_from || $code->valid_until)
                    {{ $code->valid_from?->format('d M Y') ?? '—' }} to {{ $code->valid_until?->format('d M Y') ?? '—' }}
                @else
                    Always valid
                @endif
            </td>
            <td class="px-5 py-3.5"><x-status-badge :status="$code->is_active ? 'active' : 'inactive'" /></td>
            <td class="px-5 py-3.5 text-sm font-medium text-wellness-600">
                ${{ number_format($code->total_discount_given ?? 0, 0) }}
            </td>
            <td class="px-5 py-3.5">
                <div class="flex items-center gap-1">
                    <form method="POST" action="{{ route('pricing.promo-codes.toggle', $code) }}">
                        @csrf @method('PATCH')
                        <button class="text-xs px-2.5 py-1.5 {{ $code->is_active ? 'text-amber-600 hover:bg-amber-50' : 'text-wellness-600 hover:bg-wellness-50' }} rounded-lg transition-colors font-medium">
                            {{ $code->is_active ? 'Disable' : 'Enable' }}
                        </button>
                    </form>
                    <form method="POST" action="{{ route('pricing.promo-codes.destroy', $code) }}">
                        @csrf @method('DELETE')
                        <button type="submit" onclick="return confirm('Delete promo code {{ $code->code }}?')"
                                class="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="8" class="px-5 py-16 text-center">
                <div class="text-4xl mb-3">🏷️</div>
                <p class="text-gray-400 text-sm">No promo codes yet. Create your first one above.</p>
            </td>
        </tr>
        @endforelse
    </x-data-table>

</div>
@endsection
