@extends('layouts.app')

@section('title', 'Pricing Rules')
@section('page-title', 'Pricing')

@section('content')
<div class="space-y-6" x-data="{ showCreate: false }">

    {{-- Sub-nav --}}
    <div class="flex items-center gap-1 bg-gray-100/70 rounded-xl p-1 w-fit">
        <a href="{{ route('pricing.index') }}"
           class="px-3.5 py-1.5 rounded-lg text-sm font-medium {{ request()->routeIs('pricing.index') ? 'bg-white text-lavender-700 shadow-sm' : 'text-gray-500 hover:text-gray-700' }}">
            Pricing Rules
        </a>
        <a href="{{ route('pricing.promo-codes') }}"
           class="px-3.5 py-1.5 rounded-lg text-sm font-medium {{ request()->routeIs('pricing.promo-codes') ? 'bg-white text-lavender-700 shadow-sm' : 'text-gray-500 hover:text-gray-700' }}">
            Promo Codes
        </a>
    </div>

    <div class="flex items-center justify-between">
        <p class="text-gray-500 text-sm">Rules are applied in priority order. Higher priority overrides lower.</p>
        <button @click="showCreate = !showCreate"
                class="flex items-center gap-2 px-4 py-2.5 bg-lavender-600 text-white rounded-xl text-sm font-semibold hover:bg-lavender-700 transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            Add Rule
        </button>
    </div>

    <x-alert />

    {{-- Create Rule Form --}}
    <div x-show="showCreate" x-transition class="bg-lavender-50 border border-lavender-200 rounded-2xl p-5">
        <h3 class="font-semibold text-gray-900 mb-4">New Pricing Rule</h3>
        <form method="POST" action="{{ route('pricing.store') }}" class="grid grid-cols-2 gap-4">
            @csrf
            <x-form-input name="name" label="Rule Name" required placeholder="Early Bird Discount" />
            <x-form-input name="type" label="Rule Type" type="select" required
                :options="['percentage_discount'=>'Percentage Discount','fixed_discount'=>'Fixed Discount','percentage_surcharge'=>'Percentage Surcharge','fixed_surcharge'=>'Fixed Surcharge']"
                placeholder="Select type" />
            <x-form-input name="value" label="Value" type="number" required placeholder="15"
                hint="Percentage (%) or fixed amount ($)" />
            <x-form-input name="priority" label="Priority" type="number" :value="old('priority',10)"
                hint="Higher = applied first" />

            <x-form-input name="applies_to" label="Applies To" type="select"
                :options="['all'=>'All Retreats','retreat'=>'Specific Retreat','category'=>'Category']"
                :selected="old('applies_to','all')" />
            <x-form-input name="retreat_id" label="Specific Retreat (optional)" type="select"
                :options="$retreats->pluck('title','id')->toArray()"
                placeholder="All retreats" />

            <x-form-input name="condition_type" label="Condition Type" type="select"
                :options="['always'=>'Always Active','date_range'=>'Date Range','advance_days'=>'Advance Booking Days','guest_count'=>'Guest Count']"
                :selected="old('condition_type','always')" />

            <div class="grid grid-cols-2 gap-3">
                <x-form-input name="valid_from" label="Valid From" type="date" />
                <x-form-input name="valid_until" label="Valid Until" type="date" />
            </div>

            <div class="col-span-2 flex items-center gap-4">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_stackable" value="1" {{ old('is_stackable') ? 'checked' : '' }}
                        class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                    <span class="text-sm text-gray-700">Stackable (can combine with other rules)</span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" checked
                        class="w-4 h-4 text-lavender-600 rounded border-gray-300">
                    <span class="text-sm text-gray-700">Active immediately</span>
                </label>
            </div>

            <div class="col-span-2 flex justify-end gap-3">
                <button type="button" @click="showCreate = false" class="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-xl hover:bg-white">Cancel</button>
                <button type="submit" class="px-5 py-2 bg-lavender-600 text-white text-sm font-semibold rounded-xl hover:bg-lavender-700">Create Rule</button>
            </div>
        </form>
    </div>

    {{-- Rules Table --}}
    <x-data-table
        :columns="[
            ['key'=>'priority','label'=>'Priority','sortable'=>true],
            ['key'=>'name','label'=>'Rule Name'],
            ['key'=>'type','label'=>'Type'],
            ['key'=>'value','label'=>'Value'],
            ['key'=>'applies_to','label'=>'Applies To'],
            ['key'=>'condition','label'=>'Condition'],
            ['key'=>'status','label'=>'Status'],
            ['key'=>'actions','label'=>''],
        ]"
        empty-text="No pricing rules configured."
        empty-icon="💰"
    >
        @forelse($rules as $rule)
        <tr class="hover:bg-gray-50 transition-colors">
            <td class="px-5 py-3.5">
                <span class="w-8 h-8 bg-lavender-100 text-lavender-700 rounded-lg flex items-center justify-center text-sm font-bold">
                    {{ $rule->priority }}
                </span>
            </td>
            <td class="px-5 py-3.5">
                <div class="text-sm font-medium text-gray-900">{{ $rule->name }}</div>
                @if($rule->is_stackable)
                <span class="text-xs text-lavender-600">Stackable</span>
                @endif
            </td>
            <td class="px-5 py-3.5">
                <span class="text-sm text-gray-600">{{ ucwords(str_replace('_',' ',$rule->type)) }}</span>
            </td>
            <td class="px-5 py-3.5">
                <span class="text-sm font-semibold text-gray-900">
                    @if(str_contains($rule->type, 'percentage'))
                        {{ $rule->value }}%
                    @else
                        ${{ number_format($rule->value, 2) }}
                    @endif
                </span>
            </td>
            <td class="px-5 py-3.5 text-sm text-gray-600">
                {{ $rule->experience ? Str::limit($rule->experience->title, 25) : 'All Retreats' }}
            </td>
            <td class="px-5 py-3.5 text-sm text-gray-500">
                @if($rule->valid_from && $rule->valid_until)
                    {{ $rule->valid_from->format('d M') }} – {{ $rule->valid_until->format('d M Y') }}
                @else
                    Always
                @endif
            </td>
            <td class="px-5 py-3.5">
                <x-status-badge :status="$rule->is_active ? 'active' : 'inactive'" />
            </td>
            <td class="px-5 py-3.5">
                <div class="flex items-center gap-1">
                    <form method="POST" action="{{ route('pricing.toggle', $rule) }}">
                        @csrf @method('PATCH')
                        <button type="submit" class="p-1.5 text-xs {{ $rule->is_active ? 'text-amber-500 hover:bg-amber-50' : 'text-wellness-500 hover:bg-wellness-50' }} rounded-lg transition-colors">
                            {{ $rule->is_active ? 'Disable' : 'Enable' }}
                        </button>
                    </form>
                    <form method="POST" action="{{ route('pricing.destroy', $rule) }}">
                        @csrf @method('DELETE')
                        <button type="submit" onclick="return confirm('Delete this rule?')"
                                class="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="8" class="px-5 py-16 text-center">
                <div class="text-4xl mb-3">💰</div>
                <p class="text-gray-400 text-sm">No pricing rules yet. Create your first rule above.</p>
            </td>
        </tr>
        @endforelse
    </x-data-table>

</div>
@endsection
