<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password — {{ config('app.name', 'BalanceBoat') }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .input-field { width:100%; padding:0.75rem 1rem; border:1px solid #e5e7eb; border-radius:0.5rem; font-size:0.9375rem; outline:none; transition:all 0.2s; }
        .input-field:focus { border-color:#8b5cf6; box-shadow:0 0 0 3px rgba(139,92,246,0.12); }
        .btn-primary { width:100%; padding:0.875rem; background:linear-gradient(135deg,#8b5cf6,#7c3aed); color:white; border-radius:0.625rem; font-size:0.9375rem; font-weight:600; cursor:pointer; border:none; transition:all 0.2s; }
        .btn-primary:hover { transform:translateY(-1px); box-shadow:0 8px 25px rgba(124,58,237,0.35); }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4" style="background:#f5f3ff;">
<div class="w-full max-w-md">

    {{-- Back Link --}}
    <a href="{{ route('login') }}" class="flex items-center gap-2 text-sm text-gray-500 hover:text-lavender-700 mb-6 w-fit">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
        </svg>
        Back to sign in
    </a>

    <div class="bg-white rounded-3xl shadow-xl shadow-lavender-100/50 overflow-hidden">
        <div style="background:linear-gradient(135deg,#8b5cf6,#7c3aed);" class="px-8 py-8 text-center text-white">
            <div class="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z"/>
                </svg>
            </div>
            <h1 style="font-family:'Playfair Display',serif;" class="text-2xl font-bold mb-1">Reset Password</h1>
            <p class="text-white/75 text-sm">We'll email you a secure reset link</p>
        </div>

        <div class="px-8 py-8">
            @if (session('status'))
            <div class="bg-wellness-50 border border-wellness-200 text-wellness-700 rounded-xl p-4 mb-6 text-sm flex items-start gap-2.5">
                <svg class="w-5 h-5 text-wellness-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                {{ session('status') }}
            </div>
            @endif

            @if ($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-600 rounded-xl p-3 mb-5 text-sm">{{ $errors->first() }}</div>
            @endif

            <p class="text-sm text-gray-600 mb-6">
                Enter the email address associated with your BalanceBoat account and we'll send you a link to reset your password.
            </p>

            <form method="POST" action="{{ route('password.email') }}">
                @csrf
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1.5">Email address</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}"
                        class="input-field @error('email') border-red-400 @enderror"
                        placeholder="you@retreatcenter.com" required autocomplete="email">
                </div>
                <button type="submit" class="btn-primary">Send Reset Link</button>
            </form>

            <div class="mt-6 pt-5 border-t border-gray-100 text-center text-sm text-gray-500">
                Remember your password?
                <a href="{{ route('login') }}" class="text-lavender-600 font-medium hover:text-lavender-800 ml-1">Sign in</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
