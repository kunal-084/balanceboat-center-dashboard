<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In — {{ config('app.name', 'BalanceBoat') }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { serif: ['Playfair Display', 'Georgia', 'serif'], sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        lavender: { 50:'#f5f3ff',100:'#ede9fe',200:'#ddd6fe',300:'#c4b5fd',400:'#a78bfa',500:'#8b5cf6',600:'#7c3aed',700:'#6d28d9',800:'#5b21b6',900:'#4c1d95' },
                        peach: { 50:'#fff7ed',100:'#ffedd5',200:'#fed7aa',300:'#fdba74',400:'#fb923c',500:'#f97316' },
                        wellness: { 50:'#f0fdf4',500:'#22c55e',600:'#16a34a' },
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .font-serif { font-family: 'Playfair Display', serif; }
        .glass { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); }
        .hero-bg {
            background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 30%, #6d28d9 60%, #4c1d95 100%);
            position: relative;
            overflow: hidden;
        }
        .hero-bg::before {
            content: '';
            position: absolute;
            inset: 0;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'%3E%3Ccircle cx='200' cy='200' r='180' fill='none' stroke='rgba(255,255,255,0.07)' stroke-width='1'/%3E%3Ccircle cx='200' cy='200' r='130' fill='none' stroke='rgba(255,255,255,0.05)' stroke-width='1'/%3E%3Ccircle cx='200' cy='200' r='80' fill='none' stroke='rgba(255,255,255,0.08)' stroke-width='1'/%3E%3C/svg%3E") center/cover no-repeat;
        }
        .input-field {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            font-size: 0.9375rem;
            outline: none;
            transition: all 0.2s;
            background: white;
        }
        .input-field:focus { border-color: #8b5cf6; box-shadow: 0 0 0 3px rgba(139,92,246,0.12); }
        .btn-primary {
            width: 100%;
            padding: 0.875rem;
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            color: white;
            border-radius: 0.625rem;
            font-size: 0.9375rem;
            font-weight: 600;
            letter-spacing: 0.01em;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 8px 25px rgba(124,58,237,0.4); }
        .btn-google {
            width: 100%;
            padding: 0.8125rem;
            background: white;
            color: #374151;
            border-radius: 0.625rem;
            font-size: 0.9375rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: 1.5px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.625rem;
        }
        .btn-google:hover { background: #f9f8ff; border-color: #8b5cf6; }
        .divider { display: flex; align-items: center; gap: 1rem; color: #9ca3af; font-size: 0.8125rem; }
        .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: #e5e7eb; }
        .error-msg { background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; padding: 0.75rem 1rem; border-radius: 0.5rem; font-size: 0.875rem; }
    </style>
</head>
<body class="h-full bg-lavender-50">
<div class="min-h-screen flex">

    {{-- LEFT: Branding Panel --}}
    <div class="hidden lg:flex lg:w-1/2 hero-bg flex-col justify-between p-12 text-white relative z-10">
        {{-- Logo --}}
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <svg viewBox="0 0 24 24" fill="none" class="w-6 h-6 text-white" stroke="currentColor" stroke-width="1.5">
                    <path d="M12 3C7 3 3 7 3 12s4 9 9 9 9-4 9-9-4-9-9-9z" stroke-linecap="round"/>
                    <path d="M12 8v8M8 12h8" stroke-linecap="round"/>
                </svg>
            </div>
            <span class="font-serif text-xl font-semibold">BalanceBoat</span>
        </div>

        {{-- Hero Copy --}}
        <div>
            <h1 class="font-serif text-5xl font-bold leading-tight mb-6">
                The Complete OS for<br>
                <span class="text-peach-300">Wellness Centers</span>
            </h1>
            <p class="text-white/75 text-lg leading-relaxed mb-10 max-w-sm">
                Manage retreats, bookings, teachers, and guests — all from one beautifully designed platform.
            </p>

            {{-- Feature Tiles --}}
            <div class="grid grid-cols-2 gap-3">
                @foreach([
                    ['🧘', 'Retreat Builder'],
                    ['📅', 'Smart Scheduling'],
                    ['💰', 'Dynamic Pricing'],
                    ['🤖', 'AI Studio'],
                    ['📊', 'Live Analytics'],
                    ['⚡', 'Automations'],
                ] as [$icon, $label])
                <div class="bg-white/10 backdrop-blur-sm rounded-xl p-3 flex items-center gap-2.5 text-sm text-white/90">
                    <span>{{ $icon }}</span>
                    <span>{{ $label }}</span>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Testimonial --}}
        <div class="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
            <p class="text-white/90 text-sm italic leading-relaxed mb-3">
                "BalanceBoat transformed how we manage our center. Bookings doubled and admin time halved."
            </p>
            <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 bg-peach-400 rounded-full flex items-center justify-center text-white text-xs font-bold">A</div>
                <div>
                    <div class="text-white text-sm font-medium">Ananya Krishnan</div>
                    <div class="text-white/60 text-xs">Founder, Ananda Retreat Center</div>
                </div>
            </div>
        </div>
    </div>

    {{-- RIGHT: Login Form --}}
    <div class="w-full lg:w-1/2 flex items-center justify-center p-6 lg:p-16">
        <div class="w-full max-w-md">

            {{-- Mobile Logo --}}
            <div class="lg:hidden flex items-center gap-2 mb-8">
                <div class="w-9 h-9 bg-lavender-600 rounded-xl flex items-center justify-center">
                    <svg viewBox="0 0 24 24" fill="none" class="w-5 h-5 text-white" stroke="currentColor" stroke-width="1.5">
                        <path d="M12 3C7 3 3 7 3 12s4 9 9 9 9-4 9-9-4-9-9-9z" stroke-linecap="round"/>
                        <path d="M12 8v8M8 12h8" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="font-serif text-lg font-semibold text-gray-900">BalanceBoat</span>
            </div>

            <h2 class="font-serif text-3xl font-bold text-gray-900 mb-1">Welcome back</h2>
            <p class="text-gray-500 text-sm mb-8">Sign in to your wellness platform</p>

            {{-- Errors --}}
            @if ($errors->any())
            <div class="error-msg mb-5">
                {{ $errors->first() }}
            </div>
            @endif

            @if (session('status'))
            <div class="bg-wellness-50 border border-wellness-500/30 text-wellness-600 rounded-lg p-3 mb-5 text-sm">
                {{ session('status') }}
            </div>
            @endif

            {{-- Form --}}
            <form method="POST" action="{{ route('login.submit') }}" class="space-y-4">
                @csrf

                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1.5">Email address</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}"
                        class="input-field @error('email') border-red-400 @enderror"
                        placeholder="you@retreatcenter.com"
                        autocomplete="email" required>
                </div>

                <div>
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                        <a href="{{ route('password.request') }}" class="text-xs text-lavender-600 hover:text-lavender-800 font-medium">
                            Forgot password?
                        </a>
                    </div>
                    <div class="relative">
                        <input type="password" id="password" name="password"
                            class="input-field pr-10 @error('password') border-red-400 @enderror"
                            placeholder="••••••••"
                            autocomplete="current-password" required>
                        <button type="button" onclick="togglePassword()"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <svg id="eye-show" xmlns="http://www.w3.org/2000/svg" class="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <input type="checkbox" id="remember" name="remember" class="w-4 h-4 text-lavender-600 rounded border-gray-300 focus:ring-lavender-500">
                    <label for="remember" class="text-sm text-gray-600">Remember me for 30 days</label>
                </div>

                <button type="submit" class="btn-primary mt-2">Sign In</button>
            </form>

            <div class="divider my-5">or continue with</div>

            {{-- Google OAuth --}}
            <a href="{{ route('auth.google') }}" class="btn-google">
                <svg class="w-5 h-5" viewBox="0 0 48 48">
                    <path fill="#4285F4" d="M47.5 24.6c0-1.6-.1-3.1-.4-4.6H24v8.7h13.1c-.6 3-2.4 5.6-5.1 7.3v6.1h8.2c4.8-4.4 7.3-10.9 7.3-17.5z"/>
                    <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-8.2-6.1c-2.1 1.4-4.7 2.2-7.7 2.2-5.9 0-10.9-4-12.7-9.3H2.9v6.3C6.9 42.8 14.8 48 24 48z"/>
                    <path fill="#FBBC05" d="M11.3 29c-.5-1.4-.7-2.9-.7-4.5s.3-3.1.7-4.5v-6.3H2.9C1 17.4 0 20.6 0 24s1 6.6 2.9 9.3l8.4-6.3z"/>
                    <path fill="#EA4335" d="M24 9.5c3.3 0 6.2 1.1 8.5 3.3l6.4-6.4C34.9 2.4 29.5 0 24 0 14.8 0 6.9 5.2 2.9 13l8.4 6.3C13.1 13.5 18.1 9.5 24 9.5z"/>
                </svg>
                Sign in with Google
            </a>

            {{-- OTP login link --}}
            <p class="text-center text-sm text-gray-500 mt-5">
                Prefer passwordless?
                <a href="{{ route('login.otp') }}" class="text-lavender-600 font-medium hover:text-lavender-800 ml-1">Sign in with OTP</a>
            </p>

            <p class="text-center text-xs text-gray-400 mt-6">
                By signing in you agree to our
                <a href="#" class="underline hover:text-gray-600">Terms</a> and
                <a href="#" class="underline hover:text-gray-600">Privacy Policy</a>.
            </p>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    const pwd = document.getElementById('password');
    pwd.type = pwd.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
