<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Login — {{ config('app.name', 'BalanceBoat') }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .otp-input {
            width: 3.25rem;
            height: 3.5rem;
            text-align: center;
            font-size: 1.5rem;
            font-weight: 700;
            border: 2px solid #e5e7eb;
            border-radius: 0.75rem;
            outline: none;
            transition: all 0.2s;
            background: white;
        }
        .otp-input:focus { border-color: #8b5cf6; box-shadow: 0 0 0 3px rgba(139,92,246,0.12); }
        .otp-input.filled { border-color: #8b5cf6; background: #f5f3ff; }
        .btn-primary { width:100%; padding:0.875rem; background:linear-gradient(135deg,#8b5cf6,#7c3aed); color:white; border-radius:0.625rem; font-size:0.9375rem; font-weight:600; cursor:pointer; border:none; transition:all 0.2s; }
        .btn-primary:hover { transform:translateY(-1px); box-shadow:0 8px 25px rgba(124,58,237,0.35); }
        .btn-primary:disabled { opacity:0.5; cursor:not-allowed; transform:none; box-shadow:none; }
        .input-field { width:100%; padding:0.75rem 1rem; border:1px solid #e5e7eb; border-radius:0.5rem; font-size:0.9375rem; outline:none; transition:all 0.2s; }
        .input-field:focus { border-color:#8b5cf6; box-shadow:0 0 0 3px rgba(139,92,246,0.12); }
    </style>
</head>
<body class="min-h-screen bg-lavender-50 flex items-center justify-center p-4" style="background:#f5f3ff;">
<div class="w-full max-w-md">
    {{-- Card --}}
    <div class="bg-white rounded-3xl shadow-xl shadow-lavender-100/50 overflow-hidden">
        {{-- Header --}}
        <div style="background:linear-gradient(135deg,#8b5cf6,#7c3aed);" class="px-8 py-8 text-center text-white">
            <div class="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 8.25h3"/>
                </svg>
            </div>
            <h1 style="font-family:'Playfair Display',serif;" class="text-2xl font-bold mb-1">Passwordless Sign In</h1>
            <p class="text-white/75 text-sm">We'll send a 6-digit code to your phone or email</p>
        </div>

        <div class="px-8 py-8" x-data="otpFlow()" x-init="init()">
            @if ($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-600 rounded-lg p-3 mb-5 text-sm">{{ $errors->first() }}</div>
            @endif

            {{-- Step 1: Enter contact --}}
            <div x-show="step === 1">
                <p class="text-sm text-gray-600 mb-5">Enter your registered email or mobile number.</p>
                <form method="POST" action="{{ route('login.otp.send') }}">
                    @csrf
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Email or Mobile</label>
                        <input type="text" name="contact" value="{{ old('contact') }}"
                            class="input-field"
                            placeholder="+91 98765 43210 or you@email.com"
                            required>
                    </div>
                    <button type="submit" class="btn-primary">Send OTP</button>
                </form>
            </div>

            {{-- Step 2: Enter OTP (rendered server-side after send) --}}
            @if(session('otp_sent'))
            <div>
                <p class="text-sm text-gray-600 mb-2">Enter the 6-digit code sent to</p>
                <p class="font-semibold text-gray-900 mb-6">{{ session('otp_contact') }}</p>

                <form method="POST" action="{{ route('login.otp.verify') }}" id="otp-form">
                    @csrf
                    <input type="hidden" name="contact" value="{{ session('otp_contact') }}">

                    <div class="flex gap-2.5 justify-center mb-6">
                        @for ($i = 1; $i <= 6; $i++)
                        <input type="text" maxlength="1" inputmode="numeric"
                            class="otp-input"
                            id="otp-{{ $i }}"
                            data-index="{{ $i }}"
                            onkeyup="handleOtp(event, {{ $i }})">
                        @endfor
                        <input type="hidden" name="otp" id="otp-combined">
                    </div>

                    {{-- Countdown --}}
                    <p class="text-center text-sm text-gray-500 mb-4">
                        Code expires in <span id="countdown" class="font-semibold text-lavender-700">05:00</span>
                    </p>

                    <button type="submit" class="btn-primary" id="verify-btn" disabled>Verify & Sign In</button>
                </form>

                <div class="text-center mt-4">
                    <form method="POST" action="{{ route('login.otp.send') }}" class="inline">
                        @csrf
                        <input type="hidden" name="contact" value="{{ session('otp_contact') }}">
                        <button type="submit" class="text-sm text-lavender-600 font-medium hover:text-lavender-800">Resend OTP</button>
                    </form>
                </div>
            </div>
            @endif

            <div class="mt-6 pt-5 border-t border-gray-100 text-center">
                <a href="{{ route('login') }}" class="text-sm text-gray-500 hover:text-lavender-700">
                    ← Back to email login
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function handleOtp(event, index) {
    const input  = document.getElementById('otp-' + index);
    const next   = document.getElementById('otp-' + (index + 1));
    const prev   = document.getElementById('otp-' + (index - 1));

    if (event.key === 'Backspace' && !input.value && prev) {
        prev.focus();
    } else if (input.value && next) {
        next.focus();
    }

    input.classList.toggle('filled', !!input.value);

    // Combine OTP digits
    let otp = '';
    for (let i = 1; i <= 6; i++) {
        otp += document.getElementById('otp-' + i)?.value || '';
    }
    document.getElementById('otp-combined').value = otp;
    document.getElementById('verify-btn').disabled = otp.length < 6;
}

// Countdown timer
(function() {
    const el = document.getElementById('countdown');
    if (!el) return;
    let seconds = 300;
    const timer = setInterval(() => {
        seconds--;
        if (seconds <= 0) { clearInterval(timer); el.textContent = 'Expired'; return; }
        const m = Math.floor(seconds / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        el.textContent = m + ':' + s;
    }, 1000);
})();

function otpFlow() { return { step: 1, init() {} }; }
</script>
</body>
</html>
