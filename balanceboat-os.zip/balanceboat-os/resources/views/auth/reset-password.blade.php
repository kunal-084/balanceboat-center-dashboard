@extends('layouts.auth')

@section('title', 'Set New Password')

@section('content')
<div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-lavender-50 via-white to-peach-50 px-4">
    <div class="w-full max-w-md">

        {{-- Logo --}}
        <div class="text-center mb-8">
            <a href="{{ route('login') }}" class="inline-flex items-center gap-2.5">
                <span class="text-3xl">🌿</span>
                <span class="text-xl font-bold text-gray-900">BalanceBoat</span>
            </a>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">

            <div class="text-center mb-7">
                <div class="w-14 h-14 bg-lavender-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <svg class="w-7 h-7 text-lavender-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z"/>
                    </svg>
                </div>
                <h1 class="text-2xl font-bold text-gray-900">Set new password</h1>
                <p class="text-gray-500 text-sm mt-1">Choose a strong password for your account.</p>
            </div>

            @if (session('status'))
            <div class="mb-4 p-3.5 bg-wellness-50 border border-wellness-200 rounded-xl text-sm text-wellness-700">
                {{ session('status') }}
            </div>
            @endif

            <form method="POST" action="{{ route('password.update') }}" class="space-y-5">
                @csrf

                <input type="hidden" name="token" value="{{ $token }}">

                {{-- Email --}}
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                    <input
                        id="email"
                        type="email"
                        name="email"
                        value="{{ old('email', $email) }}"
                        required
                        autocomplete="email"
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none
                               focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 transition-all
                               @error('email') border-red-400 bg-red-50 @enderror"
                        placeholder="you@example.com"
                    >
                    @error('email')
                    <p class="mt-1.5 text-xs text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                {{-- Password --}}
                <div x-data="{ show: false }">
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1.5">New Password</label>
                    <div class="relative">
                        <input
                            id="password"
                            :type="show ? 'text' : 'password'"
                            name="password"
                            required
                            autocomplete="new-password"
                            class="w-full px-4 py-3 pr-11 border border-gray-200 rounded-xl text-sm outline-none
                                   focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 transition-all
                                   @error('password') border-red-400 bg-red-50 @enderror"
                            placeholder="At least 8 characters"
                        >
                        <button type="button" @click="show = !show"
                                class="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <svg x-show="!show" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                            <svg x-show="show" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"/>
                            </svg>
                        </button>
                    </div>
                    @error('password')
                    <p class="mt-1.5 text-xs text-red-500">{{ $message }}</p>
                    @enderror

                    {{-- Strength indicator --}}
                    <div class="mt-2 flex gap-1.5" x-data="passwordStrength()">
                        <input type="hidden" :value="strength" @input.window="check($event.target.value)">
                        @foreach([1,2,3,4] as $i)
                        <div class="flex-1 h-1 rounded-full transition-colors duration-300"
                             :class="strength >= {{ $i }}
                                 ? (strength === 1 ? 'bg-red-400' : strength === 2 ? 'bg-amber-400' : strength === 3 ? 'bg-blue-400' : 'bg-wellness-500')
                                 : 'bg-gray-100'"></div>
                        @endforeach
                    </div>
                    <p class="text-[10px] text-gray-400 mt-1">Min 8 characters, uppercase, number recommended</p>
                </div>

                {{-- Confirm Password --}}
                <div>
                    <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
                    <input
                        id="password_confirmation"
                        type="password"
                        name="password_confirmation"
                        required
                        autocomplete="new-password"
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none
                               focus:border-lavender-400 focus:ring-2 focus:ring-lavender-100 transition-all"
                        placeholder="Repeat your new password"
                    >
                </div>

                <button type="submit"
                        class="w-full py-3.5 bg-gradient-to-r from-lavender-600 to-violet-600 text-white text-sm font-semibold rounded-xl
                               hover:from-lavender-700 hover:to-violet-700 transition-all shadow-lg shadow-lavender-200">
                    Reset Password
                </button>
            </form>

            <p class="mt-5 text-center text-sm text-gray-400">
                Remembered your password?
                <a href="{{ route('login') }}" class="text-lavender-600 font-medium hover:text-lavender-700">Sign in</a>
            </p>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function passwordStrength() {
    return {
        strength: 0,
        check(val) {
            let s = 0;
            if (val.length >= 8) s++;
            if (/[A-Z]/.test(val)) s++;
            if (/[0-9]/.test(val)) s++;
            if (/[^A-Za-z0-9]/.test(val)) s++;
            this.strength = s;
        }
    };
}
document.getElementById('password').addEventListener('input', function() {
    window.dispatchEvent(new CustomEvent('input', { detail: this.value, target: this }));
});
</script>
@endpush
