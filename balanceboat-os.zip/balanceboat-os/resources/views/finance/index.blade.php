@extends('layouts.app')

@section('title', 'Finance')
@section('page-title', 'Finance')

@section('content')
<div class="space-y-6" x-data="{ tab: 'overview' }">

    {{-- Sub-nav --}}
    <div class="flex items-center gap-1 bg-gray-100/70 rounded-xl p-1 w-fit">
        @foreach(['overview'=>'Overview','transactions'=>'Transactions','payouts'=>'Payouts','invoices'=>'Invoices'] as $key=>$label)
        <button @click="tab = '{{ $key }}'"
                :class="tab === '{{ $key }}' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'"
                class="px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all">
            {{ $label }}
        </button>
        @endforeach
    </div>

    <x-alert />

    {{-- ======= OVERVIEW ======= --}}
    <div x-show="tab === 'overview'">

        {{-- Stat Cards --}}
        <div class="grid grid-cols-4 gap-5 mb-6">
            <x-stat-card
                label="Revenue This Month"
                :value="'$'.number_format($stats['revenue_month'] ?? 0, 0)"
                trend="+{{ $stats['revenue_growth'] ?? 0 }}%"
                trend-positive
                icon="💰" />
            <x-stat-card
                label="Revenue YTD"
                :value="'$'.number_format($stats['revenue_ytd'] ?? 0, 0)"
                icon="📈" />
            <x-stat-card
                label="Pending Payouts"
                :value="'$'.number_format($stats['pending_payouts'] ?? 0, 0)"
                icon="⏳" />
            <x-stat-card
                label="Outstanding Balance"
                :value="'$'.number_format($stats['outstanding'] ?? 0, 0)"
                icon="📋" />
        </div>

        {{-- Revenue Chart placeholder --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-5">
            <div class="flex items-center justify-between mb-4">
                <h2 class="font-semibold text-gray-900">Revenue Overview</h2>
                <div class="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                    @foreach(['3m'=>'3M','6m'=>'6M','12m'=>'1Y'] as $k=>$l)
                    <button class="px-2.5 py-1 text-xs font-medium text-gray-500 hover:text-gray-900 rounded-md transition-colors">{{ $l }}</button>
                    @endforeach
                </div>
            </div>
            <div class="h-48 flex items-end gap-2">
                @foreach($monthlyRevenue as $month)
                @php $h = $maxRevenue > 0 ? ($month['amount'] / $maxRevenue) * 100 : 0; @endphp
                <div class="flex-1 flex flex-col items-center gap-1">
                    <div class="w-full bg-lavender-500 rounded-t-lg hover:bg-lavender-600 transition-colors cursor-pointer relative group"
                         style="height: {{ max(4, $h) }}%">
                        <div class="absolute -top-7 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs rounded px-1.5 py-0.5 opacity-0 group-hover:opacity-100 whitespace-nowrap">
                            ${{ number_format($month['amount'], 0) }}
                        </div>
                    </div>
                    <span class="text-[10px] text-gray-400">{{ $month['label'] }}</span>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Revenue by Retreat --}}
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 class="font-semibold text-gray-900 mb-4">Revenue by Retreat</h2>
            <div class="space-y-3">
                @foreach($revenueByRetreat as $row)
                <div class="flex items-center gap-4">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between mb-1">
                            <span class="text-sm font-medium text-gray-900 truncate">{{ $row['title'] }}</span>
                            <span class="text-sm font-semibold text-gray-900 ml-2">${{ number_format($row['amount'], 0) }}</span>
                        </div>
                        <div class="w-full bg-gray-100 rounded-full h-1.5">
                            <div class="h-1.5 bg-lavender-500 rounded-full" style="width: {{ $row['percent'] }}%"></div>
                        </div>
                    </div>
                    <span class="text-xs text-gray-400 w-8 text-right">{{ $row['percent'] }}%</span>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    {{-- ======= TRANSACTIONS ======= --}}
    <div x-show="tab === 'transactions'">
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="p-5 border-b border-gray-100 flex items-center justify-between">
                <h2 class="font-semibold text-gray-900">All Transactions</h2>
                <a href="{{ route('finance.export') }}"
                   class="text-sm text-lavender-600 font-medium hover:text-lavender-700">
                    Export CSV →
                </a>
            </div>
            <x-data-table
                :columns="[
                    ['key'=>'date','label'=>'Date'],
                    ['key'=>'type','label'=>'Type'],
                    ['key'=>'guest','label'=>'Guest'],
                    ['key'=>'retreat','label'=>'Retreat'],
                    ['key'=>'amount','label'=>'Amount'],
                    ['key'=>'method','label'=>'Method'],
                    ['key'=>'status','label'=>'Status'],
                ]"
                empty-text="No transactions yet."
                empty-icon="💳"
            >
                @forelse($transactions as $txn)
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-5 py-3.5 text-sm text-gray-600">{{ $txn->created_at->format('d M Y') }}</td>
                    <td class="px-5 py-3.5">
                        <span class="text-xs font-medium px-2 py-0.5 rounded-full
                            {{ $txn->type === 'payment' ? 'bg-wellness-100 text-wellness-700' :
                               ($txn->type === 'refund' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600') }}">
                            {{ ucfirst($txn->type) }}
                        </span>
                    </td>
                    <td class="px-5 py-3.5 text-sm text-gray-900">{{ $txn->booking?->guest_name }}</td>
                    <td class="px-5 py-3.5 text-sm text-gray-600 max-w-[180px] truncate">{{ $txn->booking?->experience?->title }}</td>
                    <td class="px-5 py-3.5">
                        <span class="text-sm font-semibold {{ $txn->type === 'refund' ? 'text-red-600' : 'text-gray-900' }}">
                            {{ $txn->type === 'refund' ? '−' : '+' }}${{ number_format($txn->amount, 2) }}
                        </span>
                    </td>
                    <td class="px-5 py-3.5 text-sm text-gray-500 capitalize">{{ $txn->payment_method ?? '—' }}</td>
                    <td class="px-5 py-3.5"><x-status-badge :status="$txn->status" /></td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="px-5 py-16 text-center">
                        <div class="text-4xl mb-3">💳</div>
                        <p class="text-gray-400 text-sm">No transactions recorded yet.</p>
                    </td>
                </tr>
                @endforelse
            </x-data-table>
            <div class="p-4 border-t border-gray-100">{{ $transactions->links() }}</div>
        </div>
    </div>

    {{-- ======= PAYOUTS ======= --}}
    <div x-show="tab === 'payouts'">
        <div class="grid grid-cols-3 gap-5 mb-5">
            <div class="bg-wellness-50 border border-wellness-200 rounded-2xl p-5">
                <div class="text-sm text-wellness-600 font-medium mb-1">Available for Payout</div>
                <div class="text-2xl font-bold text-gray-900">${{ number_format($payoutSummary['available'] ?? 0, 0) }}</div>
                <button class="mt-3 text-sm text-wellness-600 font-medium hover:underline">Request Payout →</button>
            </div>
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-5">
                <div class="text-sm text-amber-600 font-medium mb-1">Pending Processing</div>
                <div class="text-2xl font-bold text-gray-900">${{ number_format($payoutSummary['pending'] ?? 0, 0) }}</div>
            </div>
            <div class="bg-gray-50 border border-gray-200 rounded-2xl p-5">
                <div class="text-sm text-gray-500 font-medium mb-1">Total Paid Out</div>
                <div class="text-2xl font-bold text-gray-900">${{ number_format($payoutSummary['paid'] ?? 0, 0) }}</div>
            </div>
        </div>

        <x-data-table
            :columns="[
                ['key'=>'requested','label'=>'Requested'],
                ['key'=>'amount','label'=>'Amount'],
                ['key'=>'method','label'=>'Method'],
                ['key'=>'status','label'=>'Status'],
                ['key'=>'processed','label'=>'Processed'],
            ]"
            empty-text="No payouts yet."
            empty-icon="💸"
        >
            @forelse($payouts as $payout)
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="px-5 py-3.5 text-sm text-gray-600">{{ $payout->created_at->format('d M Y') }}</td>
                <td class="px-5 py-3.5 text-sm font-semibold text-gray-900">${{ number_format($payout->amount, 2) }}</td>
                <td class="px-5 py-3.5 text-sm text-gray-500 capitalize">{{ $payout->method }}</td>
                <td class="px-5 py-3.5"><x-status-badge :status="$payout->status" /></td>
                <td class="px-5 py-3.5 text-sm text-gray-500">
                    {{ $payout->processed_at?->format('d M Y') ?? '—' }}
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="px-5 py-16 text-center">
                    <div class="text-4xl mb-3">💸</div>
                    <p class="text-gray-400 text-sm">No payouts requested yet.</p>
                </td>
            </tr>
            @endforelse
        </x-data-table>
    </div>

    {{-- ======= INVOICES ======= --}}
    <div x-show="tab === 'invoices'">
        <x-data-table
            :columns="[
                ['key'=>'invoice','label'=>'Invoice #'],
                ['key'=>'guest','label'=>'Guest'],
                ['key'=>'retreat','label'=>'Retreat'],
                ['key'=>'issued','label'=>'Issued'],
                ['key'=>'due','label'=>'Due'],
                ['key'=>'amount','label'=>'Amount'],
                ['key'=>'status','label'=>'Status'],
                ['key'=>'actions','label'=>''],
            ]"
            empty-text="No invoices generated."
            empty-icon="🧾"
        >
            @forelse($invoices as $invoice)
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="px-5 py-3.5">
                    <span class="font-mono text-sm text-lavender-700">{{ $invoice->invoice_number }}</span>
                </td>
                <td class="px-5 py-3.5 text-sm text-gray-900">{{ $invoice->booking?->guest_name }}</td>
                <td class="px-5 py-3.5 text-sm text-gray-600 max-w-[150px] truncate">{{ $invoice->booking?->experience?->title }}</td>
                <td class="px-5 py-3.5 text-sm text-gray-500">{{ $invoice->created_at->format('d M Y') }}</td>
                <td class="px-5 py-3.5 text-sm {{ $invoice->due_date?->isPast() && $invoice->status !== 'paid' ? 'text-red-600 font-medium' : 'text-gray-500' }}">
                    {{ $invoice->due_date?->format('d M Y') ?? '—' }}
                </td>
                <td class="px-5 py-3.5 text-sm font-semibold text-gray-900">${{ number_format($invoice->total, 2) }}</td>
                <td class="px-5 py-3.5"><x-status-badge :status="$invoice->status" /></td>
                <td class="px-5 py-3.5">
                    <div class="flex items-center gap-1">
                        <a href="{{ route('finance.invoices.show', $invoice) }}"
                           class="text-xs px-2 py-1.5 text-lavender-600 hover:bg-lavender-50 rounded-lg transition-colors font-medium">
                            View
                        </a>
                        <a href="{{ route('finance.invoices.download', $invoice) }}"
                           class="text-xs px-2 py-1.5 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors font-medium">
                            PDF
                        </a>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="px-5 py-16 text-center">
                    <div class="text-4xl mb-3">🧾</div>
                    <p class="text-gray-400 text-sm">Invoices are generated automatically with each booking.</p>
                </td>
            </tr>
            @endforelse
        </x-data-table>
        <div class="mt-4">{{ $invoices->links() }}</div>
    </div>

</div>
@endsection
