<?php

namespace Database\Factories;

use App\Models\Inquiry;
use App\Models\Experience;
use App\Models\Center;
use Illuminate\Database\Eloquent\Factories\Factory;

class InquiryFactory extends Factory
{
    protected $model = Inquiry::class;

    public function definition(): array
    {
        $statuses = ['new', 'new', 'contacted', 'qualified', 'converted', 'lost'];

        return [
            'center_id'          => Center::factory(),
            'experience_id'      => null,
            'name'               => $this->faker->name(),
            'email'              => $this->faker->safeEmail(),
            'phone'              => $this->faker->phoneNumber(),
            'country'            => $this->faker->country(),
            'message'            => $this->faker->paragraphs(2, true),
            'preferred_dates'    => now()->addDays($this->faker->numberBetween(7, 90))->format('Y-m-d'),
            'group_size'         => $this->faker->numberBetween(1, 6),
            'budget'             => $this->faker->randomElement([null, '500-1000', '1000-2000', '2000-5000', '5000+']),
            'status'             => $this->faker->randomElement($statuses),
            'source'             => $this->faker->randomElement(['website', 'google', 'instagram', 'referral', 'direct']),
            'assigned_to'        => null,
            'notes'              => null,
            'created_at'         => $this->faker->dateTimeBetween('-90 days', 'now'),
        ];
    }

    public function new(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'new']);
    }

    public function qualified(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'qualified']);
    }

    public function converted(): static
    {
        return $this->state(fn(array $attrs) => ['status' => 'converted']);
    }
}
