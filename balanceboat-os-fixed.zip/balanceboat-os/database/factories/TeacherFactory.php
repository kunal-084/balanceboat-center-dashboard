<?php

namespace Database\Factories;

use App\Models\Inquiry;
use App\Models\Experience;
use App\Models\Center;
use Illuminate\Database\Eloquent\Factories\Factory;

class TeacherFactory extends Factory
{
    protected $model = Teacher::class;

    public function definition(): array
    {
        $name = $this->faker->name();

        $specializations = [
            'Hatha Yoga', 'Vinyasa Flow', 'Ashtanga Yoga', 'Yin Yoga',
            'Ayurvedic Medicine', 'Sound Healing', 'Vipassana Meditation',
            'Breathwork & Pranayama', 'Trauma-Informed Yoga', 'Restorative Yoga',
        ];

        return [
            'center_id'           => Center::factory(),
            'name'                => $name,
            'slug'                => Str::slug($name) . '-' . $this->faker->randomNumber(4),
            'email'               => $this->faker->safeEmail(),
            'phone'               => $this->faker->phoneNumber(),
            'bio'                 => $this->faker->paragraphs(3, true),
            'short_bio'           => $this->faker->paragraph(2),
            'specialization'      => $this->faker->randomElement($specializations),
            'years_of_experience' => $this->faker->numberBetween(1, 30),
            'nationality'         => $this->faker->country(),
            'languages'           => json_encode(['English', $this->faker->randomElement(['Hindi', 'Spanish', 'French', 'German'])]),
            'is_active'           => true,
            'is_featured'         => $this->faker->boolean(25),
            'rating'              => $this->faker->randomFloat(1, 3.5, 5.0),
            'total_reviews'       => $this->faker->numberBetween(0, 100),
            'instagram_url'       => 'https://instagram.com/' . Str::slug($name),
            'website_url'         => null,
            'created_at'          => now()->subDays($this->faker->numberBetween(30, 365)),
        ];
    }

    public function featured(): static
    {
        return $this->state(fn(array $attrs) => ['is_featured' => true]);
    }
}
