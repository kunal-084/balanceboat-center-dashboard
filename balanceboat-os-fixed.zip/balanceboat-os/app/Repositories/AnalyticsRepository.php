<?php

namespace App\Repositories;

use App\Models\Booking;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class AnalyticsRepository
{
    public function inquiriesBySource(int $centerId, string $from, string $to): array
    {
        return \App\Models\Inquiry::where('center_id', $centerId)
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->selectRaw('COALESCE(source, "direct") as source, COUNT(*) as count')
            ->groupBy('source')
            ->orderByDesc('count')
            ->get()
            ->toArray();
    }

    public function inquiriesByBudget(int $centerId, string $from, string $to): array
    {
        return \App\Models\Inquiry::where('center_id', $centerId)
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->whereNotNull('budget')
            ->selectRaw('budget, COUNT(*) as count')
            ->groupBy('budget')
            ->orderByDesc('count')
            ->get()
            ->toArray();
    }

    public function revenueByRetreat(int $centerId, string $from, string $to): array
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed','checked_in','completed'])
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->join('experiences', 'bookings.experience_id', '=', 'experiences.id')
            ->selectRaw('experiences.name, SUM(bookings.pay_amount) as revenue, COUNT(bookings.id) as bookings')
            ->groupBy('experiences.id', 'experiences.name')
            ->orderByDesc('revenue')
            ->limit(10)
            ->get()
            ->toArray();
    }

    public function bookingsByGuestCountry(int $centerId, string $from, string $to): array
    {
        return Booking::forCenter($centerId)
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"])
            ->join('booking_transaction_address_info as bta', 'bookings.id', '=', 'bta.booking_id')
            ->selectRaw('bta.billing_country as country, COUNT(*) as count')
            ->whereNotNull('bta.billing_country')
            ->groupBy('bta.billing_country')
            ->orderByDesc('count')
            ->limit(15)
            ->get()
            ->toArray();
    }

    public function occupancyHeatmap(int $centerId, string $year): array
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed','checked_in','completed'])
            ->whereYear('arrival_date', $year)
            ->selectRaw('arrival_date, SUM(guest_count) as guests')
            ->groupBy('arrival_date')
            ->orderBy('arrival_date')
            ->get()
            ->map(fn($r) => ['date' => $r->arrival_date->format('Y-m-d'), 'value' => $r->guests])
            ->toArray();
    }
}
