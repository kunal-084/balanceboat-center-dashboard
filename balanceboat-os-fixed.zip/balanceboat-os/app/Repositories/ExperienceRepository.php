<?php

namespace App\Repositories;

use App\Models\Booking;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class ExperienceRepository
{
    public function findById(int $id): ?\App\Models\Experience
    {
        return \App\Models\Experience::with([
            'center', 'categories', 'teachers',
            'accommodations', 'faqs', 'benefits',
            'itineraryDays.sessions', 'imageGallery',
            'pricingRules', 'seoMetadata',
        ])->find($id);
    }

    public function paginateForCenter(
        int    $centerId,
        array  $filters = [],
        int    $perPage = 15,
        string $sortBy  = 'created_at',
        string $sortDir = 'desc'
    ): LengthAwarePaginator {
        return \App\Models\Experience::forCenter($centerId)
            ->when($filters['status'] ?? null, function ($q, $status) {
                match ($status) {
                    'published' => $q->published(),
                    'draft'     => $q->draft(),
                    default     => $q->where('publish_status', $status),
                };
            })
            ->when($filters['search'] ?? null, fn($q, $term) => $q->search($term))
            ->when($filters['category_id'] ?? null, fn($q, $id) => $q->byCategory((int)$id))
            ->when($filters['featured'] ?? null, fn($q) => $q->featured())
            ->with(['categories', 'teachers', 'imageGallery' => fn($q) => $q->limit(1)])
            ->withCount(['bookings as active_bookings' => fn($q) => $q->whereIn('stage', ['confirmed','checked_in'])])
            ->orderBy($sortBy, $sortDir)
            ->paginate($perPage)
            ->withQueryString();
    }

    public function getPublishedForCenter(int $centerId): Collection
    {
        return \App\Models\Experience::forCenter($centerId)
            ->published()
            ->with(['categories', 'teachers'])
            ->orderByDesc('created_at')
            ->get();
    }

    public function getTemplates(int $centerId): Collection
    {
        return \App\Models\Experience::forCenter($centerId)
            ->where('is_draft', true)
            ->whereIn('tags', ['%template%'])
            ->orderByDesc('created_at')
            ->get();
    }

    public function create(array $data): \App\Models\Experience
    {
        return \App\Models\Experience::create($data);
    }

    public function update(\App\Models\Experience $experience, array $data): \App\Models\Experience
    {
        $experience->update($data);
        return $experience->fresh();
    }

    public function delete(\App\Models\Experience $experience): bool
    {
        return $experience->delete();
    }
}
