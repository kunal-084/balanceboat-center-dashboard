<?php

namespace App\Repositories;

use App\Models\Booking;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class CenterRepository
{
    public function findById(int $id): ?\App\Models\Center
    {
        return \App\Models\Center::with([
            'owner', 'activeSubscription.plan',
            'staff', 'reviews',
        ])->find($id);
    }

    public function findByUserId(int $userId): ?\App\Models\Center
    {
        return \App\Models\Center::where('user_id', $userId)->first();
    }

    public function update(\App\Models\Center $center, array $data): \App\Models\Center
    {
        $center->update($data);
        return $center->fresh();
    }

    public function getStaff(int $centerId): Collection
    {
        return \App\Models\User::where('center_id', $centerId)
            ->with('roles')
            ->orderBy('first_name')
            ->get();
    }

    public function getDashboardSummary(int $centerId): array
    {
        $center = \App\Models\Center::find($centerId);

        return [
            'total_retreats'   => \App\Models\Experience::forCenter($centerId)->count(),
            'published_retreats'=> \App\Models\Experience::forCenter($centerId)->published()->count(),
            'total_bookings'   => Booking::forCenter($centerId)->count(),
            'total_inquiries'  => \App\Models\Inquiry::where('center_id', $centerId)->count(),
            'total_revenue'    => Booking::forCenter($centerId)->whereIn('stage', ['confirmed','checked_in','completed'])->sum('pay_amount'),
            'pending_reviews'  => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'pending')->count(),
        ];
    }
}
