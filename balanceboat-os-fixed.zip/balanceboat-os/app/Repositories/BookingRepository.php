<?php

namespace App\Repositories;

use App\Models\Booking;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class BookingRepository
{
    public function findById(int $id): ?Booking
    {
        return Booking::with([
            'experience.center',
            'userInfo',
            'experienceInfo',
            'transactionInfo',
            'addressInfo',
            'promoCode',
            'assignedStaff',
        ])->find($id);
    }

    public function findByReference(string $ref): ?Booking
    {
        return Booking::where('booking_reference', $ref)
            ->with(['experience', 'userInfo', 'experienceInfo'])
            ->first();
    }

    public function paginateForCenter(
        int    $centerId,
        array  $filters   = [],
        int    $perPage   = 20,
        string $sortBy    = 'created_at',
        string $sortDir   = 'desc'
    ): LengthAwarePaginator {
        return Booking::forCenter($centerId)
            ->when($filters['stage'] ?? null, fn($q, $stage) => $q->inStage($stage))
            ->when($filters['search'] ?? null, fn($q, $term) => $q->search($term))
            ->when($filters['date_from'] ?? null, fn($q, $from) => $q->where('arrival_date', '>=', $from))
            ->when($filters['date_to'] ?? null, fn($q, $to) => $q->where('arrival_date', '<=', $to))
            ->when($filters['assigned_to'] ?? null, fn($q, $id) => $q->where('assigned_staff_id', $id))
            ->when($filters['experience_id'] ?? null, fn($q, $id) => $q->where('experience_id', $id))
            ->with(['experience', 'userInfo', 'assignedStaff'])
            ->orderBy($sortBy, $sortDir)
            ->paginate($perPage)
            ->withQueryString();
    }

    public function todayCheckIns(int $centerId): Collection
    {
        return Booking::forCenter($centerId)
            ->inStage('confirmed')
            ->where('arrival_date', today())
            ->with(['experience', 'userInfo'])
            ->orderBy('arrival_date')
            ->get();
    }

    public function currentGuests(int $centerId): Collection
    {
        return Booking::forCenter($centerId)
            ->inStage('checked_in')
            ->with(['experience', 'userInfo', 'accommodation'])
            ->orderBy('check_in_at')
            ->get();
    }

    public function upcomingForCenter(int $centerId, int $days = 30): Collection
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed'])
            ->whereBetween('arrival_date', [today(), today()->addDays($days)])
            ->with(['experience', 'userInfo'])
            ->orderBy('arrival_date')
            ->get();
    }

    public function revenueByMonth(int $centerId, int $months = 12): array
    {
        return Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->where('created_at', '>=', now()->subMonths($months))
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(pay_amount) as revenue, COUNT(*) as count")
            ->groupBy('month')
            ->orderBy('month')
            ->get()
            ->toArray();
    }

    public function stageCountsForCenter(int $centerId): array
    {
        return Booking::forCenter($centerId)
            ->selectRaw('stage, COUNT(*) as count')
            ->groupBy('stage')
            ->pluck('count', 'stage')
            ->toArray();
    }

    public function delete(Booking $booking): bool
    {
        return $booking->delete();
    }
}
