<?php

namespace App\Actions\Retreat;

use App\DTOs\RetreatDTO;
use App\Models\Experience;
use App\Services\RetreatService;

class UpdateRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(Experience $experience, array $data): Experience
    {
        return $this->retreatService->update($experience, $data);
    }
}
