<?php

namespace App\Actions\Retreat;

use App\DTOs\RetreatDTO;
use App\Models\Experience;
use App\Services\RetreatService;

class CreateRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(RetreatDTO $dto): Experience
    {
        return $this->retreatService->create($dto);
    }
}
