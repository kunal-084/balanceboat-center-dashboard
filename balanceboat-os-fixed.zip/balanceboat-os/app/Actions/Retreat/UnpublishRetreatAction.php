<?php

namespace App\Actions\Retreat;

use App\DTOs\RetreatDTO;
use App\Models\Experience;
use App\Services\RetreatService;

class UnpublishRetreatAction
{
    public function __construct(private readonly RetreatService $retreatService) {}

    public function handle(Experience $experience): Experience
    {
        return $this->retreatService->unpublish($experience);
    }
}
