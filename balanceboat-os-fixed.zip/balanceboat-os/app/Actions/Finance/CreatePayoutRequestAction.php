<?php

namespace App\Actions\Finance;

use App\Models\{Center, PayoutRequest, Booking};
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class CreatePayoutRequestAction
{
    public function handle(Center $center, string $from, string $to): PayoutRequest
    {
        return DB::transaction(function () use ($center, $from, $to) {
            $plan           = $center->subscriptionPlan;
            $commissionRate = $plan?->commission_rate ?? 10;

            $bookings = Booking::forCenter($center->id)
                ->where('stage', 'completed')
                ->whereBetween('arrival_date', [$from, $to])
                ->whereNull('deleted_at')
                ->get();

            $grossAmount      = $bookings->sum('pay_amount');
            $commissionAmount = round($grossAmount * ($commissionRate / 100), 2);
            $taxAmount        = 0;
            $netPayout        = $grossAmount - $commissionAmount - $taxAmount;

            return PayoutRequest::create([
                'center_id'           => $center->id,
                'reference'           => 'PAY-' . strtoupper(Str::random(10)),
                'gross_amount'        => $grossAmount,
                'commission_deducted' => $commissionAmount,
                'tax_deducted'        => $taxAmount,
                'net_payout'          => $netPayout,
                'currency'            => $center->currency_code ?? 'USD',
                'status'              => 'pending',
                'period_from'         => $from,
                'period_to'           => $to,
                'included_booking_ids'=> $bookings->pluck('id')->toArray(),
                'requested_at'        => now(),
            ]);
        });
    }
}
