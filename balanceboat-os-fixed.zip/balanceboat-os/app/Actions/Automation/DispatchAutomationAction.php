<?php

namespace App\Actions\Automation;

use App\Models\{AutomationRule, AutomationExecution};
use App\Services\{EmailService, WhatsAppService};
use Illuminate\Support\Facades\{Log, Mail};

class DispatchAutomationAction
{
    public function __construct(
        private readonly EmailService     $emailService,
        private readonly WhatsAppService  $whatsAppService,
    ) {}

    public function handle(AutomationRule $rule, array $triggerData): AutomationExecution
    {
        $execution = AutomationExecution::create([
            'automation_rule_id' => $rule->id,
            'trigger_event'      => $rule->trigger_event,
            'trigger_data'       => $triggerData,
            'status'             => 'running',
            'executed_at'        => now(),
        ]);

        try {
            match ($rule->action_type) {
                'email'     => $this->executeEmailAction($rule, $triggerData),
                'whatsapp'  => $this->executeWhatsAppAction($rule, $triggerData),
                'webhook'   => $this->executeWebhookAction($rule, $triggerData),
                'internal_task' => $this->executeTaskAction($rule, $triggerData),
                default     => null,
            };

            $execution->update(['status' => 'completed', 'result_data' => ['message' => 'Executed successfully']]);
            $rule->increment('execution_count');
            $rule->update(['last_executed_at' => now()]);
        } catch (\Throwable $e) {
            $execution->update(['status' => 'failed', 'error_message' => $e->getMessage()]);
            Log::error("Automation execution failed", ['rule_id' => $rule->id, 'error' => $e->getMessage()]);
        }

        return $execution->fresh();
    }

    protected function executeEmailAction(AutomationRule $rule, array $data): void
    {
        $template = $rule->emailTemplate;
        if (! $template) return;

        $recipient = $data['guest_email'] ?? $data['email'] ?? null;
        if (! $recipient) return;

        $this->emailService->sendTemplate($template, $recipient, $data);
    }

    protected function executeWhatsAppAction(AutomationRule $rule, array $data): void
    {
        $config = $rule->action_config ?? [];
        $phone  = $data['guest_phone'] ?? $data['phone'] ?? null;
        if (! $phone) return;

        $this->whatsAppService->send($phone, $data['message'] ?? '', $config);
    }

    protected function executeWebhookAction(AutomationRule $rule, array $data): void
    {
        $config = $rule->action_config ?? [];
        $url    = $config['webhook_url'] ?? null;
        if (! $url) return;

        \Illuminate\Support\Facades\Http::post($url, array_merge($data, [
            'trigger_event' => $rule->trigger_event,
            'timestamp'     => now()->toIso8601String(),
        ]));
    }

    protected function executeTaskAction(AutomationRule $rule, array $data): void
    {
        // Create internal task / notification for staff
        $config = $rule->action_config ?? [];
        Log::info("Internal task triggered", ['rule' => $rule->name, 'config' => $config]);
    }
}
