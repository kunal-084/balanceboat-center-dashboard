<?php

namespace App\Actions\AI;

use App\DTOs\AiContentDTO;
use App\Models\{Experience, Center, AiRecommendation};
use App\Services\AiService;

class GenerateContentAction
{
    public function __construct(private readonly AiService $aiService) {}

    public function handle(AiContentDTO $dto): string
    {
        return $this->aiService->generateContent($dto);
    }
}
