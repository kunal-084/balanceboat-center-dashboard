<?php

namespace App\Actions\AI;

use App\DTOs\AiContentDTO;
use App\Models\{Experience, Center, AiRecommendation};
use App\Services\AiService;

class ApplyAiRecommendationAction
{
    public function handle(AiRecommendation $recommendation): void
    {
        $recommendation->apply(auth()->id());

        // Execute the recommendation's action payload if present
        $payload = $recommendation->action_payload;
        if (! $payload) return;

        match ($recommendation->type) {
            'pricing' => $this->applyPricingRecommendation($recommendation, $payload),
            default   => null,
        };
    }

    protected function applyPricingRecommendation(AiRecommendation $rec, array $payload): void
    {
        if (isset($payload['create_pricing_rule'])) {
            \App\Models\PricingRule::create(array_merge(
                $payload['create_pricing_rule'],
                ['center_id' => $rec->center_id, 'experience_id' => $rec->experience_id]
            ));
        }
    }
}
