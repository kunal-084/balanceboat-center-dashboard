<?php

namespace App\Actions\AI;

use App\DTOs\AiContentDTO;
use App\Models\{Experience, Center, AiRecommendation};
use App\Services\AiService;

class GenerateSeoMetadataAction
{
    public function __construct(private readonly AiService $aiService) {}

    public function handle(Experience $experience): array
    {
        return $this->aiService->generateSeoMetadata($experience);
    }
}
