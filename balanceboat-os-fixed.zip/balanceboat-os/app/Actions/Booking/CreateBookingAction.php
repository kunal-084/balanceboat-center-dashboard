<?php

namespace App\Actions\Booking;

use App\DTOs\BookingDTO;
use App\Models\Booking;
use App\Services\BookingService;

class CreateBookingAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(BookingDTO $dto): Booking
    {
        return $this->bookingService->create($dto);
    }
}
