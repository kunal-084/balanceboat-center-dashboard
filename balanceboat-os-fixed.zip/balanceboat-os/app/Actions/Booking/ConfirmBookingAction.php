<?php

namespace App\Actions\Booking;

use App\DTOs\BookingDTO;
use App\Models\Booking;
use App\Services\BookingService;

class ConfirmBookingAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking): Booking
    {
        return $this->bookingService->confirm($booking);
    }
}
