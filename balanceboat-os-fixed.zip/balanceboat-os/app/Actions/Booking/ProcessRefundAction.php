<?php

namespace App\Actions\Booking;

use App\DTOs\BookingDTO;
use App\Models\Booking;
use App\Services\BookingService;

class ProcessRefundAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking, float $amount, string $reason = ''): bool
    {
        return $this->bookingService->processRefund($booking, $amount, $reason);
    }
}
