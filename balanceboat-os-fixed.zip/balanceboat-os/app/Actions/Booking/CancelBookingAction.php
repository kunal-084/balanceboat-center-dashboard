<?php

namespace App\Actions\Booking;

use App\DTOs\BookingDTO;
use App\Models\Booking;
use App\Services\BookingService;

class CancelBookingAction
{
    public function __construct(private readonly BookingService $bookingService) {}

    public function handle(Booking $booking, string $reason = '', bool $processRefund = false): Booking
    {
        return $this->bookingService->cancel($booking, $reason, $processRefund);
    }
}
