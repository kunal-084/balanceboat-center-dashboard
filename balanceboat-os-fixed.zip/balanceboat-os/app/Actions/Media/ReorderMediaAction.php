<?php

namespace App\Actions\Media;

use App\DTOs\MediaUploadDTO;
use App\Models\MediaAsset;
use App\Services\MediaService;
use Illuminate\Http\UploadedFile;

class ReorderMediaAction
{
    public function __construct(private readonly MediaService $mediaService) {}

    public function handle(array $orderedIds): void
    {
        $this->mediaService->reorder($orderedIds);
    }
}
