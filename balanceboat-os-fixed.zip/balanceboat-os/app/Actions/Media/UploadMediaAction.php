<?php

namespace App\Actions\Media;

use App\DTOs\MediaUploadDTO;
use App\Models\MediaAsset;
use App\Services\MediaService;
use Illuminate\Http\UploadedFile;

class UploadMediaAction
{
    public function __construct(private readonly MediaService $mediaService) {}

    public function handle(UploadedFile $file, MediaUploadDTO $dto): MediaAsset
    {
        return $this->mediaService->upload($file, $dto);
    }
}
