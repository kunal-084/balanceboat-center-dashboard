<?php

namespace App\Actions\Media;

use App\DTOs\MediaUploadDTO;
use App\Models\MediaAsset;
use App\Services\MediaService;
use Illuminate\Http\UploadedFile;

class DeleteMediaAction
{
    public function __construct(private readonly MediaService $mediaService) {}

    public function handle(MediaAsset $asset): void
    {
        $this->mediaService->delete($asset);
    }
}
