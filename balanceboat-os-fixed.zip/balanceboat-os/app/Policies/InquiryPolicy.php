<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class InquiryPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, Inquiry $inquiry): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $inquiry->center_id === $user->center_id
            || $inquiry->experience?->center_id === $user->center_id;
    }

    public function update(User $user, Inquiry $inquiry): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return ($inquiry->center_id === $user->center_id || $inquiry->experience?->center_id === $user->center_id)
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function delete(User $user, Inquiry $inquiry): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return ($inquiry->center_id === $user->center_id)
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }
}
