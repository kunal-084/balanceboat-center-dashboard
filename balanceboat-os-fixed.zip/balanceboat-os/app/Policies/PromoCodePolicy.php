<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class PromoCodePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'accountant']);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function update(User $user, PromoCode $promo): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $promo->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function delete(User $user, PromoCode $promo): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $promo->center_id === $user->center_id && $user->hasRole('center-owner');
    }
}
