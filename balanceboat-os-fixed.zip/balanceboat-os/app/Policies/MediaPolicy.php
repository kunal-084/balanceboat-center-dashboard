<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class MediaPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, MediaAsset $asset): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $asset->center_id === $user->center_id;
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function update(User $user, MediaAsset $asset): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $asset->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function delete(User $user, MediaAsset $asset): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $asset->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }
}
