<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class TeacherPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, Teacher $teacher): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $teacher->centers()->where('centers.id', $user->center_id)->exists();
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function update(User $user, Teacher $teacher): bool
    {
        if ($user->hasRole('super-admin')) return true;
        // Teacher can edit own profile
        if ($user->hasRole('teacher') && $teacher->user_id === $user->id) return true;
        return $teacher->centers()->where('centers.id', $user->center_id)->exists()
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function delete(User $user, Teacher $teacher): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $teacher->centers()->where('centers.id', $user->center_id)->exists()
            && $user->hasRole('center-owner');
    }
}
