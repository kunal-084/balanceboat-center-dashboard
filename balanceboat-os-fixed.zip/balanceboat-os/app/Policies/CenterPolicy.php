<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class CenterPolicy
{
    public function view(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id;
    }

    public function update(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function manageSubscription(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id && $user->hasRole('center-owner');
    }

    public function viewFinance(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'accountant']);
    }

    public function manageStaff(User $user, Center $center): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $center->id === $user->center_id && $user->hasRole('center-owner');
    }
}
