<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class ExperiencePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function view(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id;
    }

    public function create(User $user): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function update(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function delete(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function publish(User $user, Experience $experience): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $experience->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function duplicate(User $user, Experience $experience): bool
    {
        return $this->view($user, $experience) && $this->create($user);
    }
}
