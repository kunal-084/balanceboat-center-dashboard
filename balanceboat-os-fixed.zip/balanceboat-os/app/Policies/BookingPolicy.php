<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class BookingPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'center-manager', 'staff', 'accountant']);
    }

    public function view(User $user, Booking $booking): bool
    {
        if ($user->hasRole('super-admin')) return true;
        $centerIds = $booking->experience?->center_id;
        return $centerIds === $user->center_id;
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function update(User $user, Booking $booking): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $booking->experience?->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager', 'staff']);
    }

    public function cancel(User $user, Booking $booking): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $booking->experience?->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function checkIn(User $user, Booking $booking): bool
    {
        return $this->update($user, $booking);
    }

    public function checkOut(User $user, Booking $booking): bool
    {
        return $this->update($user, $booking);
    }

    public function delete(User $user, Booking $booking): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner']);
    }
}
