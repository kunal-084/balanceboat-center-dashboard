<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class PayoutPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin', 'center-owner', 'accountant']);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'accountant']);
    }

    public function process(User $user, PayoutRequest $payout): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin']);
    }
}
