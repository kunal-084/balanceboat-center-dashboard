<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class ReviewPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager', 'staff']);
    }

    public function approve(User $user, CenterReview $review): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $review->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function respond(User $user, CenterReview $review): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $review->center_id === $user->center_id;
    }

    public function delete(User $user, CenterReview $review): bool
    {
        return $user->hasAnyRole(['super-admin', 'balanceboat-admin']);
    }
}
