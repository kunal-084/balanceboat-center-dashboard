<?php

namespace App\Policies;

use App\Models\{User, Experience, Booking, Center, Teacher, Inquiry, PromoCode, PricingRule, CenterReview, MediaAsset, AutomationRule, PayoutRequest};

class AutomationPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function create(User $user): bool
    {
        if (! $user->center?->canUseFeature('automation')) return false;
        return $user->hasAnyRole(['super-admin', 'center-owner', 'center-manager']);
    }

    public function update(User $user, AutomationRule $rule): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $rule->center_id === $user->center_id
            && $user->hasAnyRole(['center-owner', 'center-manager']);
    }

    public function delete(User $user, AutomationRule $rule): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $rule->center_id === $user->center_id && $user->hasRole('center-owner');
    }
}
