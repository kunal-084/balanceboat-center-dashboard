<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class SendBookingConfirmationWhatsApp implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(BookingConfirmed $event): void
    {
        $booking = $event->booking->load(['userInfo', 'experience']);

        if (! $booking->userInfo?->phone) return;

        SendWhatsAppJob::dispatch(
            phone:    $booking->userInfo->phone,
            template: 'booking_confirmed',
            params:   [
                $booking->userInfo->firstname,
                $booking->experience?->name,
                $booking->booking_reference,
                $booking->arrival_date?->format('d M Y'),
            ]
        )->onQueue('notifications');
    }
}
