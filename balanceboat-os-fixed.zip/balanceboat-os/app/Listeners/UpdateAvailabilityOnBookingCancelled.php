<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class UpdateAvailabilityOnBookingCancelled implements ShouldQueue
{
    public function handle(BookingCancelled $event): void
    {
        $booking = $event->booking;

        if (! $booking->experience_id || ! $booking->arrival_date) return;

        AvailabilityCalendar::where('experience_id', $booking->experience_id)
            ->where('calendar_date', $booking->arrival_date->format('Y-m-d'))
            ->update([
                'booked_units'    => \DB::raw('GREATEST(0, booked_units - ' . $booking->guest_count . ')'),
                'available_units' => \DB::raw('available_units + ' . $booking->guest_count),
                'status'          => 'open',
            ]);
    }
}
