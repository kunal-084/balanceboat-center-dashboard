<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class LogAuditEvent
{
    public function handle(mixed $event): void
    {
        if (! auth()->check()) return;

        $user     = auth()->user();
        $className= class_basename($event);

        $modelMap = [
            'BookingConfirmed'  => [$event->booking, 'stage_changed'],
            'BookingCancelled'  => [$event->booking, 'cancelled'],
            'BookingCheckedIn'  => [$event->booking, 'checked_in'],
            'BookingCompleted'  => [$event->booking, 'completed'],
            'RetreatPublished'  => [$event->experience, 'published'],
            'InquiryReceived'   => [$event->inquiry, 'received'],
            'ReviewSubmitted'   => [$event->review, 'submitted'],
        ];

        [$model, $eventName] = $modelMap[$className] ?? [null, $className];

        if (! $model) return;

        AuditLog::create([
            'user_id'        => $user->id,
            'user_name'      => $user->full_name,
            'user_email'     => $user->email,
            'event'          => $eventName,
            'auditable_type' => get_class($model),
            'auditable_id'   => $model->id,
            'center_id'      => $user->center_id,
            'ip_address'     => request()->ip(),
            'user_agent'     => request()->userAgent(),
            'url'            => request()->fullUrl(),
            'http_method'    => request()->method(),
        ]);
    }
}
