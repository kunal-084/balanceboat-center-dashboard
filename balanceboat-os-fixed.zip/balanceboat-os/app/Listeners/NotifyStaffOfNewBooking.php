<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyStaffOfNewBooking implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(BookingConfirmed $event): void
    {
        $booking = $event->booking->load(['experience.center.staff']);

        $managers = $booking->experience?->center?->staff()
            ->whereIn('center_role', ['owner', 'manager'])
            ->get() ?? collect();

        foreach ($managers as $manager) {
            $manager->notify(new BookingConfirmedNotification($booking));
        }
    }
}
