<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class SendReviewRequestAfterCompletion implements ShouldQueue
{
    public string $queue = 'emails';

    public function handle(BookingCompleted $event): void
    {
        $booking = $event->booking->load(['userInfo', 'experience']);

        if (! $booking->userInfo?->email) return;

        // Delay 2 days after completion
        SendEmailJob::dispatch(
            to:       $booking->userInfo->email,
            name:     $booking->userInfo->firstname,
            template: 'review_request',
            data:     [
                'guest_name'   => $booking->userInfo->firstname,
                'retreat_name' => $booking->experience?->name,
                'booking_ref'  => $booking->booking_reference,
                'review_url'   => config('app.url') . '/reviews/submit/' . $booking->booking_reference,
            ]
        )->delay(now()->addDays(2))->onQueue('emails');
    }
}
