<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class SendCheckInNotification implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(BookingCheckedIn $event): void
    {
        $booking = $event->booking->load(['experience.center.staff', 'userInfo']);

        // Notify center staff
        $staff = $booking->experience?->center?->staff()
            ->whereIn('center_role', ['owner', 'manager', 'staff'])
            ->get() ?? collect();

        foreach ($staff as $member) {
            $member->notify(new \App\Notifications\GuestCheckedInNotification($booking));
        }
    }
}
