<?php

namespace App\Listeners;

use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class SendInquiryReceivedNotifications implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(InquiryReceived $event): void
    {
        $inquiry = $event->inquiry->load(['experience.center.staff']);

        // Notify the inquiry submitter
        SendEmailJob::dispatch(
            to:       $inquiry->email,
            name:     $inquiry->name,
            template: 'inquiry_received',
            data:     [
                'name'         => $inquiry->name,
                'retreat_name' => $inquiry->experience?->name ?? 'our retreats',
            ]
        )->onQueue('emails');

        // Notify center staff
        $centerId = $inquiry->center_id ?? $inquiry->experience?->center_id;
        if (! $centerId) return;

        $managers = \App\Models\User::where('center_id', $centerId)
            ->whereIn('center_role', ['owner', 'manager'])
            ->get();

        foreach ($managers as $manager) {
            $manager->notify(new InquiryReceivedNotification($inquiry));
        }

        // Trigger automation rules
        $rules = AutomationRule::active()
            ->where('center_id', $centerId)
            ->forEvent('inquiry.received')
            ->get();

        foreach ($rules as $rule) {
            ProcessAutomationJob::dispatch($rule, [
                'inquiry_id'   => $inquiry->id,
                'guest_name'   => $inquiry->full_name,
                'guest_email'  => $inquiry->email,
                'guest_phone'  => $inquiry->phone,
                'retreat_name' => $inquiry->experience?->name,
                'budget'       => $inquiry->budget,
                'retreat_type' => $inquiry->retreat_type,
            ])->delay(now()->addMinutes($rule->delay_in_minutes))->onQueue('automations');
        }
    }
}
