<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\{ExperienceResource, BookingResource, CenterResource, TeacherResource, InquiryResource};
use App\Models\{Experience, Booking, Center, Teacher, Inquiry};
use App\Repositories\{ExperienceRepository, BookingRepository};
use App\Services\{BookingService, PricingService};
use Illuminate\Http\{JsonResponse, Request};

class ApiPricingController extends Controller
{
    public function __construct(private readonly PricingService $pricingService) {}

    public function calculate(Request $request): JsonResponse
    {
        $request->validate([
            'experience_id'  => ['required', 'integer', 'exists:experiences,id'],
            'base_price'     => ['required', 'numeric', 'min:0'],
            'currency'       => ['required', 'string', 'size:3'],
            'guest_count'    => ['nullable', 'integer', 'min:1'],
            'arrival_date'   => ['nullable', 'date'],
            'duration_nights'=> ['nullable', 'integer', 'min:1'],
            'promo_code'     => ['nullable', 'string', 'max:50'],
        ]);

        $experience = Experience::findOrFail($request->experience_id);

        $dto = new \App\DTOs\PricingDTO(
            experienceId:  $experience->id,
            basePrice:     (float) $request->base_price * ($request->guest_count ?? 1),
            currency:      $request->currency,
            guestCount:    (int) $request->get('guest_count', 1),
            durationNights:(int) $request->get('duration_nights', 1),
            occupancyRate: $experience->occupancy_rate,
            daysUntilStart:$request->arrival_date ? now()->diffInDays($request->arrival_date) : null,
            startDate:     $request->arrival_date ? \Carbon\Carbon::parse($request->arrival_date) : null,
            promoCode:     $request->promo_code,
        );

        return response()->json($this->pricingService->calculatePrice($dto));
    }

    public function validatePromoCode(Request $request): JsonResponse
    {
        $request->validate([
            'code'          => ['required', 'string', 'max:50'],
            'amount'        => ['required', 'numeric', 'min:0'],
            'experience_id' => ['required', 'integer', 'exists:experiences,id'],
        ]);

        $result = $this->pricingService->validatePromoCode(
            $request->code,
            (float) $request->amount,
            (int) $request->experience_id
        );

        return response()->json($result);
    }
}
