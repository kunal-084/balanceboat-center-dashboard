<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\{ExperienceResource, BookingResource, CenterResource, TeacherResource, InquiryResource};
use App\Models\{Experience, Booking, Center, Teacher, Inquiry};
use App\Repositories\{ExperienceRepository, BookingRepository};
use App\Services\{BookingService, PricingService};
use Illuminate\Http\{JsonResponse, Request};

class ApiAnalyticsController extends Controller
{
    public function __construct(private readonly \App\Services\AnalyticsService $analyticsService) {}

    public function kpis(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $period   = $request->get('period', '30d');

        return response()->json($this->analyticsService->getDashboardKpis($centerId, $period));
    }

    public function revenue(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $from     = $request->get('from', now()->subMonths(3)->toDateString());
        $to       = $request->get('to', today()->toDateString());
        $group    = $request->get('group', 'day');

        return response()->json($this->analyticsService->getRevenueChart($centerId, $from, $to, $group));
    }

    public function occupancy(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $months   = (int) $request->get('months', 6);

        return response()->json($this->analyticsService->getOccupancyByMonth($centerId, $months));
    }

    public function topRetreats(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $limit    = (int) $request->get('limit', 5);
        $orderBy  = $request->get('order_by', 'revenue');

        return response()->json($this->analyticsService->getTopRetreats($centerId, $limit, $orderBy));
    }
}
