<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\{ExperienceResource, BookingResource, CenterResource, TeacherResource, InquiryResource};
use App\Models\{Experience, Booking, Center, Teacher, Inquiry};
use App\Repositories\{ExperienceRepository, BookingRepository};
use App\Services\{BookingService, PricingService};
use Illuminate\Http\{JsonResponse, Request};

class ApiBookingController extends Controller
{
    public function __construct(
        private readonly BookingRepository $repository,
        private readonly BookingService    $bookingService,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $bookings = $this->repository->paginateForCenter(
            centerId: auth()->user()->center_id,
            filters:  $request->only(['stage', 'search', 'date_from', 'date_to']),
            perPage:  $request->get('per_page', 20),
        );

        return response()->json([
            'data' => BookingResource::collection($bookings->items()),
            'meta' => ['total' => $bookings->total(), 'current_page' => $bookings->currentPage(), 'last_page' => $bookings->lastPage()],
        ]);
    }

    public function show(Booking $booking): JsonResponse
    {
        $this->authorize('view', $booking);

        $booking->load(['experience', 'userInfo', 'experienceInfo', 'transactionInfo', 'assignedStaff', 'promoCode']);

        return response()->json(new BookingResource($booking));
    }

    public function store(\App\Http\Requests\Booking\StoreBookingRequest $request): JsonResponse
    {
        $dto     = \App\DTOs\BookingDTO::fromRequest($request, auth()->user()->center_id);
        $booking = $this->bookingService->create($dto);

        return response()->json(new BookingResource($booking), 201);
    }

    public function update(\App\Http\Requests\Booking\UpdateBookingRequest $request, Booking $booking): JsonResponse
    {
        $this->authorize('update', $booking);

        $booking->update($request->validated());

        return response()->json(new BookingResource($booking->fresh()));
    }

    public function checkIn(Booking $booking): JsonResponse
    {
        $this->authorize('checkIn', $booking);

        $this->bookingService->checkIn($booking);

        return response()->json(new BookingResource($booking->fresh()));
    }

    public function checkOut(Booking $booking): JsonResponse
    {
        $this->authorize('checkOut', $booking);

        $this->bookingService->checkOut($booking);

        return response()->json(new BookingResource($booking->fresh()));
    }

    public function cancel(\App\Http\Requests\Booking\CancelBookingRequest $request, Booking $booking): JsonResponse
    {
        $this->authorize('cancel', $booking);

        $this->bookingService->cancel($booking, $request->reason, $request->boolean('process_refund'));

        return response()->json(new BookingResource($booking->fresh()));
    }
}
