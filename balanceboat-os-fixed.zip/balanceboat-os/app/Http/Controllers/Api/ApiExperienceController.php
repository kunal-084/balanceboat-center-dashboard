<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\{ExperienceResource, BookingResource, CenterResource, TeacherResource, InquiryResource};
use App\Models\{Experience, Booking, Center, Teacher, Inquiry};
use App\Repositories\{ExperienceRepository, BookingRepository};
use App\Services\{BookingService, PricingService};
use Illuminate\Http\{JsonResponse, Request};

class ApiExperienceController extends Controller
{
    public function __construct(private readonly ExperienceRepository $repository) {}

    public function index(Request $request): JsonResponse
    {
        $centerId  = auth()->user()->center_id;
        $retreats  = $this->repository->paginateForCenter(
            centerId: $centerId,
            filters:  $request->only(['status', 'search', 'category_id']),
            perPage:  $request->get('per_page', 15),
        );

        return response()->json([
            'data' => ExperienceResource::collection($retreats->items()),
            'meta' => [
                'current_page' => $retreats->currentPage(),
                'last_page'    => $retreats->lastPage(),
                'total'        => $retreats->total(),
                'per_page'     => $retreats->perPage(),
            ],
        ]);
    }

    public function show(Experience $experience): JsonResponse
    {
        $this->authorize('view', $experience);

        $experience->load(['center', 'categories', 'teachers', 'accommodations', 'faqs', 'benefits', 'itineraryDays.sessions', 'pricingRules']);

        return response()->json(new ExperienceResource($experience));
    }

    public function store(\App\Http\Requests\Retreat\StoreRetreatRequest $request): JsonResponse
    {
        $dto      = \App\DTOs\RetreatDTO::fromRequest($request, auth()->user()->center_id);
        $retreat  = app(\App\Actions\Retreat\CreateRetreatAction::class)->handle($dto);

        return response()->json(new ExperienceResource($retreat), 201);
    }

    public function update(\App\Http\Requests\Retreat\UpdateRetreatRequest $request, Experience $experience): JsonResponse
    {
        $this->authorize('update', $experience);

        app(\App\Actions\Retreat\UpdateRetreatAction::class)->handle($experience, $request->validated());

        return response()->json(new ExperienceResource($experience->fresh(['categories', 'teachers'])));
    }

    public function destroy(Experience $experience): JsonResponse
    {
        $this->authorize('delete', $experience);

        $experience->delete();

        return response()->json(['message' => 'Retreat deleted successfully.']);
    }
}
