<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\{ExperienceResource, BookingResource, CenterResource, TeacherResource, InquiryResource};
use App\Models\{Experience, Booking, Center, Teacher, Inquiry};
use App\Repositories\{ExperienceRepository, BookingRepository};
use App\Services\{BookingService, PricingService};
use Illuminate\Http\{JsonResponse, Request};

class ApiMediaController extends Controller
{
    public function __construct(private readonly \App\Services\MediaService $mediaService) {}

    public function index(Request $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;

        $assets = \App\Models\MediaAsset::where('center_id', $centerId)
            ->when($request->mediable_type, fn($q, $type) => $q->where('mediable_type', $type))
            ->when($request->mediable_id, fn($q, $id) => $q->where('mediable_id', $id))
            ->when($request->collection, fn($q, $col) => $q->where('collection', $col))
            ->when($request->type, fn($q, $type) => $q->where('media_type', $type))
            ->orderBy('sort_order')
            ->orderByDesc('created_at')
            ->paginate($request->get('per_page', 30));

        return response()->json([
            'data' => $assets->items(),
            'meta' => ['total' => $assets->total()],
        ]);
    }

    public function store(\App\Http\Requests\Media\StoreMediaRequest $request): JsonResponse
    {
        $centerId = auth()->user()->center_id;
        $uploaded = [];

        $dto = new \App\DTOs\MediaUploadDTO(
            centerId:     $centerId,
            disk:         config('filesystems.default', 's3'),
            collection:   $request->get('collection', 'default'),
            folderId:     $request->folder_id,
            mediableType: $request->mediable_type,
            mediableId:   $request->mediable_id ? (int) $request->mediable_id : null,
        );

        foreach ($request->file('files') as $file) {
            $uploaded[] = $this->mediaService->upload($file, $dto);
        }

        return response()->json(['success' => true, 'assets' => $uploaded], 201);
    }

    public function destroy(\App\Models\MediaAsset $asset): JsonResponse
    {
        $this->authorize('delete', $asset);

        $this->mediaService->delete($asset);

        return response()->json(['message' => 'Asset deleted.']);
    }
}
