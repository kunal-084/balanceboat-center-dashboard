<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class FinanceController extends Controller
{
    public function index(Request $request): View
    {
        $centerId = auth()->user()->center_id;

        $bookings = \App\Models\Booking::forCenter($centerId)
            ->where('stage', 'completed')
            ->when($request->from, fn($q, $from) => $q->where('arrival_date', '>=', $from))
            ->when($request->to, fn($q, $to) => $q->where('arrival_date', '<=', $to))
            ->with(['experience', 'userInfo'])
            ->latest()
            ->paginate(25)
            ->withQueryString();

        $summary = [
            'gross_revenue'    => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('booking_amount'),
            'total_discounts'  => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('discount_amount'),
            'platform_commission' => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('commission_amount'),
            'net_revenue'      => \App\Models\Booking::forCenter($centerId)->where('stage', 'completed')->sum('pay_amount'),
        ];

        $payouts = \App\Models\PayoutRequest::where('center_id', $centerId)
            ->latest()
            ->limit(10)
            ->get();

        return view('finance.index', compact('bookings', 'summary', 'payouts'));
    }

    public function requestPayout(Request $request): RedirectResponse
    {
        $request->validate([
            'period_from' => ['required', 'date'],
            'period_to'   => ['required', 'date', 'after_or_equal:period_from'],
        ]);

        $center = auth()->user()->center;
        $payout = app(\App\Actions\Finance\CreatePayoutRequestAction::class)
            ->handle($center, $request->period_from, $request->period_to);

        return redirect()->route('finance.index')->with('success', "Payout request {$payout->reference} submitted.");
    }
}
