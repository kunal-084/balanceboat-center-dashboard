<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminUserController extends Controller
{
    public function index(Request $request)
    {
        $users = User::with('roles', 'center')
            ->when($request->search, fn($q) => $q->where(fn($q) =>
                $q->where('first_name', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%")
            ))
            ->when($request->role, fn($q) => $q->whereHas('roles', fn($r) => $r->where('name', $request->role)))
            ->latest()
            ->paginate(25)
            ->withQueryString();

        $roles = Role::all();

        return view('admin.users.index', compact('users', 'roles'));
    }

    public function show(User $user)
    {
        $user->load(['roles', 'center', 'notifications']);
        return view('admin.users.show', compact('user'));
    }

    public function ban(Request $request, User $user)
    {
        $user->update(['banned_at' => now(), 'ban_reason' => $request->reason]);
        return back()->with('success', 'User banned.');
    }

    public function unban(User $user)
    {
        $user->update(['banned_at' => null, 'ban_reason' => null]);
        return back()->with('success', 'User unbanned.');
    }
}
