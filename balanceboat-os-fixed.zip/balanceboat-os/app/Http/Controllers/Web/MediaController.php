<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class MediaController extends Controller
{
    public function __construct(private readonly \App\Services\MediaService $mediaService) {}

    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\MediaAsset::class);

        $centerId = auth()->user()->center_id;

        $assets = \App\Models\MediaAsset::where('center_id', $centerId)
            ->when($request->folder_id, fn($q, $id) => $q->where('folder_id', $id))
            ->when($request->type, fn($q, $type) => $q->where('media_type', $type))
            ->when($request->search, fn($q, $term) => $q->where('original_filename', 'like', "%{$term}%"))
            ->when($request->collection, fn($q, $col) => $q->where('collection', $col))
            ->orderBy('sort_order')
            ->orderByDesc('created_at')
            ->paginate(30)
            ->withQueryString();

        $folders = \App\Models\MediaFolder::where('center_id', $centerId)
            ->whereNull('parent_id')
            ->orderBy('name')
            ->get();

        $stats = [
            'total'    => \App\Models\MediaAsset::where('center_id', $centerId)->count(),
            'images'   => \App\Models\MediaAsset::where('center_id', $centerId)->where('media_type', 'image')->count(),
            'videos'   => \App\Models\MediaAsset::where('center_id', $centerId)->where('media_type', 'video')->count(),
            'total_mb' => round(\App\Models\MediaAsset::where('center_id', $centerId)->sum('size_bytes') / 1048576, 1),
        ];

        return view('media.index', compact('assets', 'folders', 'stats'));
    }

    public function store(\App\Http\Requests\Media\StoreMediaRequest $request): \Illuminate\Http\JsonResponse
    {
        $this->authorize('create', \App\Models\MediaAsset::class);

        $centerId = auth()->user()->center_id;
        $uploaded = [];

        $dto = new \App\DTOs\MediaUploadDTO(
            centerId:     $centerId,
            disk:         config('filesystems.default', 's3'),
            collection:   $request->get('collection', 'default'),
            folderId:     $request->folder_id,
            mediableType: $request->mediable_type,
            mediableId:   $request->mediable_id ? (int) $request->mediable_id : null,
            altText:      $request->alt_text,
            caption:      $request->caption,
            category:     $request->category,
        );

        foreach ($request->file('files') as $file) {
            $uploaded[] = $this->mediaService->upload($file, $dto);
        }

        return response()->json([
            'success' => true,
            'assets'  => $uploaded,
            'count'   => count($uploaded),
        ]);
    }

    public function update(\App\Http\Requests\Media\UpdateMediaRequest $request, \App\Models\MediaAsset $asset): \Illuminate\Http\JsonResponse
    {
        $this->authorize('update', $asset);

        $asset->update($request->validated());

        return response()->json(['success' => true, 'asset' => $asset->fresh()]);
    }

    public function destroy(\App\Models\MediaAsset $asset): \Illuminate\Http\JsonResponse
    {
        $this->authorize('delete', $asset);

        $this->mediaService->delete($asset);

        return response()->json(['success' => true]);
    }

    public function reorder(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate(['ids' => ['required', 'array'], 'ids.*' => ['integer']]);

        $this->mediaService->reorder($request->ids);

        return response()->json(['success' => true]);
    }
}
