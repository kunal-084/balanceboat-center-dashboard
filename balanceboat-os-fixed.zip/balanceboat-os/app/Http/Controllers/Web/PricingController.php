<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class PricingController extends Controller
{
    public function __construct(private readonly \App\Services\PricingService $pricingService) {}

    public function rules(Request $request): View
    {
        $centerId = auth()->user()->center_id;
        $rules    = \App\Models\PricingRule::where('center_id', $centerId)
            ->when($request->experience_id, fn($q, $id) => $q->where('experience_id', $id))
            ->when($request->type, fn($q, $t) => $q->where('rule_type', $t))
            ->with('experience')
            ->orderByDesc('priority')
            ->paginate(20)
            ->withQueryString();

        $experiences = Experience::forCenter($centerId)->published()->orderBy('name')->get(['id', 'name']);

        return view('pricing.rules', compact('rules', 'experiences'));
    }

    public function storeRule(\App\Http\Requests\Pricing\StorePricingRuleRequest $request): RedirectResponse
    {
        $data              = $request->validated();
        $data['center_id'] = auth()->user()->center_id;

        \App\Models\PricingRule::create($data);

        return back()->with('success', 'Pricing rule created successfully.');
    }

    public function updateRule(\App\Http\Requests\Pricing\UpdatePricingRuleRequest $request, \App\Models\PricingRule $rule): RedirectResponse
    {
        $rule->update($request->validated());
        return back()->with('success', 'Pricing rule updated.');
    }

    public function destroyRule(\App\Models\PricingRule $rule): RedirectResponse
    {
        $rule->delete();
        return back()->with('success', 'Pricing rule deleted.');
    }

    public function promoCodes(Request $request): View
    {
        $centerId   = auth()->user()->center_id;
        $promoCodes = \App\Models\PromoCode::where('center_id', $centerId)
            ->when($request->search, fn($q, $term) => $q->where('code', 'like', "%{$term}%"))
            ->withCount('redemptions')
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $experiences = Experience::forCenter($centerId)->published()->orderBy('name')->get(['id','name']);

        return view('pricing.promo-codes', compact('promoCodes', 'experiences'));
    }

    public function storePromoCode(\App\Http\Requests\PromoCode\StorePromoCodeRequest $request): RedirectResponse
    {
        $data              = $request->validated();
        $data['center_id'] = auth()->user()->center_id;
        $data['code']      = strtoupper($data['code']);

        \App\Models\PromoCode::create($data);

        return back()->with('success', "Promo code {$data['code']} created successfully.");
    }

    public function updatePromoCode(\App\Http\Requests\PromoCode\UpdatePromoCodeRequest $request, \App\Models\PromoCode $promoCode): RedirectResponse
    {
        $promoCode->update($request->validated());
        return back()->with('success', 'Promo code updated.');
    }

    public function destroyPromoCode(\App\Models\PromoCode $promoCode): RedirectResponse
    {
        $promoCode->delete();
        return back()->with('success', 'Promo code deleted.');
    }

    public function calculatePrice(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'experience_id'  => ['required', 'integer', 'exists:experiences,id'],
            'base_price'     => ['required', 'numeric', 'min:0'],
            'currency'       => ['required', 'string'],
            'guest_count'    => ['nullable', 'integer', 'min:1'],
            'arrival_date'   => ['nullable', 'date'],
            'promo_code'     => ['nullable', 'string'],
        ]);

        $experience = Experience::findOrFail($request->experience_id);
        $dto        = new \App\DTOs\PricingDTO(
            experienceId:  $experience->id,
            basePrice:     (float) $request->base_price,
            currency:      $request->currency,
            guestCount:    (int) $request->get('guest_count', 1),
            occupancyRate: $experience->occupancy_rate,
            daysUntilStart:$request->arrival_date ? now()->diffInDays($request->arrival_date) : null,
            startDate:     $request->arrival_date ? \Carbon\Carbon::parse($request->arrival_date) : null,
            promoCode:     $request->promo_code,
        );

        return response()->json($this->pricingService->calculatePrice($dto));
    }
}
