<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class AiController extends Controller
{
    public function __construct(private readonly \App\Services\AiService $aiService) {}

    public function index(): View
    {
        $centerId = auth()->user()->center_id;
        $recs     = \App\Models\AiRecommendation::forCenter($centerId)
            ->active()
            ->with('experience')
            ->latest()
            ->paginate(20);

        return view('ai.index', compact('recs'));
    }

    public function generateContent(Request $request): \Illuminate\Http\JsonResponse
    {
        abort_unless(auth()->user()->center?->canUseFeature('ai'), 403, 'AI module not available on your plan.');

        $request->validate([
            'type'            => ['required', 'in:title,summary,description,seo_title,seo_desc,faqs,benefits,itinerary'],
            'retreat_type'    => ['required', 'string', 'max:100'],
            'experience_id'   => ['nullable', 'integer', 'exists:experiences,id'],
            'location'        => ['nullable', 'string', 'max:200'],
            'duration_nights' => ['nullable', 'integer'],
            'target_audience' => ['nullable', 'string', 'max:200'],
            'tone'            => ['nullable', 'in:luxury,spiritual,scientific,holistic,adventurous'],
        ]);

        $dto = new \App\DTOs\AiContentDTO(
            type:             $request->type,
            retreatType:      $request->retreat_type,
            centerId:         auth()->user()->center_id,
            experienceId:     $request->experience_id,
            location:         $request->location,
            durationNights:   $request->duration_nights,
            targetAudience:   $request->target_audience,
            tone:             $request->get('tone', 'luxury'),
        );

        $content = $this->aiService->generateContent($dto);

        return response()->json(['success' => true, 'content' => $content]);
    }

    public function generateSeo(Request $request): \Illuminate\Http\JsonResponse
    {
        abort_unless(auth()->user()->center?->canUseFeature('ai'), 403);

        $request->validate(['experience_id' => ['required', 'integer', 'exists:experiences,id']]);

        $experience = Experience::findOrFail($request->experience_id);
        $seo        = $this->aiService->generateSeoMetadata($experience);

        return response()->json(['success' => true, 'seo' => $seo]);
    }

    public function applyRecommendation(\App\Models\AiRecommendation $recommendation): RedirectResponse
    {
        app(\App\Actions\AI\ApplyAiRecommendationAction::class)->handle($recommendation);

        return back()->with('success', 'AI recommendation applied successfully.');
    }

    public function dismissRecommendation(\App\Models\AiRecommendation $recommendation): RedirectResponse
    {
        $recommendation->dismiss(auth()->id());
        return back()->with('success', 'Recommendation dismissed.');
    }
}
