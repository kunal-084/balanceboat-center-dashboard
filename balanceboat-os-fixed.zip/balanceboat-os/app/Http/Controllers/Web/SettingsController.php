<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class SettingsController extends Controller
{
    public function centerProfile(): View
    {
        $center = auth()->user()->center;
        $this->authorize('update', $center);

        $centerTypes  = \App\Models\CenterType::orderBy('name')->get();
        $certificates = \App\Models\Certificate::orderBy('name')->get();
        $amenities    = \App\Models\Amenities::orderBy('name')->get();

        return view('settings.center-profile', compact('center', 'centerTypes', 'certificates', 'amenities'));
    }

    public function updateCenterProfile(\App\Http\Requests\Center\UpdateCenterRequest $request): RedirectResponse
    {
        $center = auth()->user()->center;
        $this->authorize('update', $center);

        $center->update($request->validated());

        return back()->with('success', 'Center profile updated successfully.');
    }

    public function team(): View
    {
        $center = auth()->user()->center;
        $staff  = \App\Models\User::where('center_id', $center->id)->with('roles')->orderBy('first_name')->get();

        return view('settings.team', compact('center', 'staff'));
    }

    public function emailTemplates(): View
    {
        $centerId  = auth()->user()->center_id;
        $templates = \App\Models\EmailTemplate::where(fn($q) => $q->where('center_id', $centerId)->orWhereNull('center_id'))
            ->orderBy('name')
            ->get();

        return view('settings.email-templates', compact('templates'));
    }

    public function preferences(): View
    {
        $prefs = auth()->user()->preferences ?? new \App\Models\UserPreference();
        return view('settings.preferences', compact('prefs'));
    }

    public function updatePreferences(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'timezone'              => ['required', 'string', 'timezone'],
            'locale'                => ['required', 'string'],
            'currency'              => ['required', 'string', 'size:3'],
            'email_notifications'   => ['boolean'],
            'whatsapp_notifications'=> ['boolean'],
            'browser_notifications' => ['boolean'],
        ]);

        auth()->user()->preferences()->updateOrCreate(
            ['user_id' => auth()->id()],
            $data
        );

        return back()->with('success', 'Preferences saved.');
    }

    public function subscription(): View
    {
        $center = auth()->user()->center;
        $plans  = \App\Models\SubscriptionPlan::where('is_active', true)->orderBy('sort_order')->get();

        return view('settings.subscription', compact('center', 'plans'));
    }
}
