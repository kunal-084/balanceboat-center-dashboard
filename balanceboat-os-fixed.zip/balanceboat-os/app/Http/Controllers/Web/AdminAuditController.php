<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminAuditController extends Controller
{
    public function index(Request $request)
    {
        $logs = DB::table('audit_logs')
            ->join('users', 'audit_logs.user_id', '=', 'users.id')
            ->select('audit_logs.*', DB::raw("CONCAT(users.first_name, ' ', users.last_name) as user_name"), 'users.email')
            ->when($request->event,   fn($q) => $q->where('audit_logs.event', $request->event))
            ->when($request->user_id, fn($q) => $q->where('audit_logs.user_id', $request->user_id))
            ->latest('audit_logs.created_at')
            ->paginate(50)
            ->withQueryString();

        return view('admin.audit.index', compact('logs'));
    }
}
