<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminPlanController extends Controller
{
    public function index()
    {
        $plans = SubscriptionPlan::withCount('activeSubscriptions')->get();
        return view('admin.plans.index', compact('plans'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'          => ['required', 'string', 'max:50'],
            'slug'          => ['required', 'string', 'unique:subscription_plans'],
            'price'         => ['required', 'numeric', 'min:0'],
            'billing_cycle' => ['required', 'in:monthly,annually'],
            'features'      => ['required', 'array'],
            'limits'        => ['required', 'array'],
            'is_active'     => ['boolean'],
        ]);

        SubscriptionPlan::create($data);

        return back()->with('success', 'Plan created.');
    }

    public function update(Request $request, SubscriptionPlan $plan)
    {
        $plan->update($request->validate([
            'name'      => ['required', 'string'],
            'price'     => ['required', 'numeric'],
            'features'  => ['nullable', 'array'],
            'limits'    => ['nullable', 'array'],
            'is_active' => ['boolean'],
        ]));

        return back()->with('success', 'Plan updated.');
    }
}
