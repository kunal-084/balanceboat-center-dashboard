<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __construct(
        private readonly \App\Services\AnalyticsService $analyticsService,
        private readonly \App\Repositories\BookingRepository $bookingRepo,
        private readonly \App\Services\AiService $aiService,
    ) {}

    public function index(Request $request): View
    {
        $user     = auth()->user();
        $center   = $user->center;
        $centerId = $user->center_id;
        $period   = $request->get('period', '30d');

        $kpis           = $this->analyticsService->getDashboardKpis($centerId, $period);
        $revenueChart   = $this->analyticsService->getRevenueChart($centerId, now()->subDays(30)->toDateString(), today()->toDateString());
        $topRetreats    = $this->analyticsService->getTopRetreats($centerId, 5);
        $todayCheckIns  = $this->bookingRepo->todayCheckIns($centerId);
        $currentGuests  = $this->bookingRepo->currentGuests($centerId);
        $upcomingBookings = $this->bookingRepo->upcomingForCenter($centerId, 7);
        $aiRecs         = \App\Models\AiRecommendation::forCenter($centerId)->active()->latest()->limit(3)->get();
        $pendingReviews = \App\Models\CenterReview::where('center_id', $centerId)->pending()->count();
        $recentInquiries= \App\Models\Inquiry::where('center_id', $centerId)->latest()->limit(5)->get();
        $bookingFunnel  = $this->analyticsService->getBookingFunnel($centerId, now()->subDays(30)->toDateString(), today()->toDateString());

        return view('dashboard.index', compact(
            'center', 'kpis', 'revenueChart', 'topRetreats',
            'todayCheckIns', 'currentGuests', 'upcomingBookings',
            'aiRecs', 'pendingReviews', 'recentInquiries', 'bookingFunnel', 'period'
        ));
    }
}
