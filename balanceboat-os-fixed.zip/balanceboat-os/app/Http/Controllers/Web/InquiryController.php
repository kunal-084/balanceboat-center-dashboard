<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class InquiryController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\Inquiry::class);

        $centerId = auth()->user()->center_id;

        $inquiries = \App\Models\Inquiry::where('center_id', $centerId)
            ->when($request->stage, fn($q, $s) => $q->forStage($s))
            ->when($request->search, fn($q, $term) =>
                $q->where('name', 'like', "%{$term}%")
                  ->orWhere('email', 'like', "%{$term}%")
                  ->orWhere('phone', 'like', "%{$term}%")
            )
            ->when($request->assigned_to, fn($q, $id) => $q->where('assigned_to', $id))
            ->with(['experience', 'assignedTo'])
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $stageCounts = \App\Models\Inquiry::where('center_id', $centerId)
            ->selectRaw('pipeline_stage as stage, COUNT(*) as count')
            ->groupBy('pipeline_stage')
            ->pluck('count', 'stage')
            ->toArray();

        $staff = \App\Models\User::where('center_id', $centerId)->get(['id', 'first_name', 'last_name']);

        return view('inquiries.index', compact('inquiries', 'stageCounts', 'staff'));
    }

    public function show(\App\Models\Inquiry $inquiry): View
    {
        $this->authorize('view', $inquiry);

        $inquiry->load(['experience', 'assignedTo', 'convertedBooking', 'center']);
        $messages = \App\Models\InquiryMessage::where('conversation_id', $inquiry->conversation_id)
            ->orderBy('created_at')
            ->get();

        return view('inquiries.show', compact('inquiry', 'messages'));
    }

    public function update(\App\Http\Requests\Inquiry\UpdateInquiryRequest $request, \App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('update', $inquiry);

        $data = $request->validated();

        if (isset($data['pipeline_stage']) && $data['pipeline_stage'] !== $inquiry->pipeline_stage) {
            $data['last_contacted_at'] = now();
            if ($data['pipeline_stage'] !== 'new') {
                $data['contact_attempts'] = $inquiry->contact_attempts + 1;
            }
        }

        $inquiry->update($data);

        return back()->with('success', 'Inquiry updated.');
    }

    public function reply(Request $request, \App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('update', $inquiry);
        $request->validate([
            'message' => ['required', 'string', 'min:1', 'max:5000'],
            'channel' => ['required', 'in:email,whatsapp,sms,internal_note'],
        ]);

        \App\Models\InquiryMessage::create([
            'inquiry_id'      => $inquiry->id,
            'conversation_id' => $inquiry->conversation_id,
            'sender_id'       => auth()->id(),
            'center_id'       => auth()->user()->center_id,
            'channel'         => $request->channel,
            'direction'       => 'outbound',
            'message'         => $request->message,
        ]);

        $inquiry->update(['last_contacted_at' => now()]);

        if ($request->channel === 'email') {
            \App\Jobs\SendEmailJob::dispatch(
                to:       $inquiry->email,
                name:     $inquiry->name,
                template: 'inquiry_reply',
                data:     ['name' => $inquiry->name, 'message' => $request->message]
            )->onQueue('emails');
        } elseif ($request->channel === 'whatsapp' && $inquiry->phone) {
            \App\Jobs\SendWhatsAppJob::dispatch(
                phone:    $inquiry->phone,
                template: 'inquiry_reply',
                params:   [$inquiry->name, $request->message]
            )->onQueue('notifications');
        }

        return back()->with('success', 'Reply sent successfully.');
    }

    public function destroy(\App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('delete', $inquiry);
        $inquiry->delete();
        return redirect()->route('inquiries.index')->with('success', 'Inquiry deleted.');
    }

    public function convert(\App\Models\Inquiry $inquiry): RedirectResponse
    {
        $this->authorize('update', $inquiry);
        return redirect()->route('bookings.create', ['inquiry_id' => $inquiry->id]);
    }
}
