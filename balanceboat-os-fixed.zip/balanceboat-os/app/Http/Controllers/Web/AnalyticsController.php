<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class AnalyticsController extends Controller
{
    public function __construct(
        private readonly \App\Services\AnalyticsService  $analyticsService,
        private readonly \App\Repositories\AnalyticsRepository $analyticsRepo,
    ) {}

    public function index(Request $request): View
    {
        $centerId = auth()->user()->center_id;
        $from     = $request->get('from', now()->startOfMonth()->toDateString());
        $to       = $request->get('to', today()->toDateString());
        $group    = $request->get('group', 'day');

        $kpis          = $this->analyticsService->getDashboardKpis($centerId, '30d');
        $revenueChart  = $this->analyticsService->getRevenueChart($centerId, $from, $to, $group);
        $bookingFunnel = $this->analyticsService->getBookingFunnel($centerId, $from, $to);
        $topRetreats   = $this->analyticsService->getTopRetreats($centerId, 10);
        $occupancyData = $this->analyticsService->getOccupancyByMonth($centerId, 6);
        $inquiriesBySource = $this->analyticsRepo->inquiriesBySource($centerId, $from, $to);
        $inquiriesByBudget = $this->analyticsRepo->inquiriesByBudget($centerId, $from, $to);
        $revenueByRetreat  = $this->analyticsRepo->revenueByRetreat($centerId, $from, $to);
        $guestCountries    = $this->analyticsRepo->bookingsByGuestCountry($centerId, $from, $to);

        return view('analytics.index', compact(
            'kpis', 'revenueChart', 'bookingFunnel', 'topRetreats',
            'occupancyData', 'inquiriesBySource', 'inquiriesByBudget',
            'revenueByRetreat', 'guestCountries', 'from', 'to', 'group'
        ));
    }
}
