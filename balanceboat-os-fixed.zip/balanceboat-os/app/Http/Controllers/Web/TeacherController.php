<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class TeacherController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\Teacher::class);

        $teachers = \App\Models\Teacher::whereHas('centers', fn($q) => $q->where('centers.id', auth()->user()->center_id))
            ->when($request->search, fn($q, $term) => $q->where('name', 'like', "%{$term}%"))
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->with(['imageGallery' => fn($q) => $q->limit(1)])
            ->withCount('experiences')
            ->orderBy('name')
            ->paginate(15)
            ->withQueryString();

        return view('teachers.index', compact('teachers'));
    }

    public function create(): View
    {
        $this->authorize('create', \App\Models\Teacher::class);

        $expertises   = \App\Models\Expertise::orderBy('name')->get();
        $certificates = \App\Models\Certificate::orderBy('name')->get();

        return view('teachers.create', compact('expertises', 'certificates'));
    }

    public function store(\App\Http\Requests\Teacher\StoreTeacherRequest $request): RedirectResponse
    {
        $data    = $request->validated();
        $teacher = \App\Models\Teacher::create($data);

        $teacher->centers()->attach(auth()->user()->center_id);

        return redirect()->route('teachers.show', $teacher)->with('success', 'Teacher profile created.');
    }

    public function show(\App\Models\Teacher $teacher): View
    {
        $this->authorize('view', $teacher);

        $teacher->load(['imageGallery', 'experiences' => fn($q) => $q->forCenter(auth()->user()->center_id), 'centers']);

        return view('teachers.show', compact('teacher'));
    }

    public function edit(\App\Models\Teacher $teacher): View
    {
        $this->authorize('update', $teacher);

        $expertises   = \App\Models\Expertise::orderBy('name')->get();
        $certificates = \App\Models\Certificate::orderBy('name')->get();

        return view('teachers.edit', compact('teacher', 'expertises', 'certificates'));
    }

    public function update(\App\Http\Requests\Teacher\UpdateTeacherRequest $request, \App\Models\Teacher $teacher): RedirectResponse
    {
        $this->authorize('update', $teacher);

        $teacher->update($request->validated());

        return redirect()->route('teachers.show', $teacher)->with('success', 'Teacher profile updated.');
    }

    public function destroy(\App\Models\Teacher $teacher): RedirectResponse
    {
        $this->authorize('delete', $teacher);

        $teacher->centers()->detach(auth()->user()->center_id);

        return redirect()->route('teachers.index')->with('success', 'Teacher removed from your center.');
    }
}
