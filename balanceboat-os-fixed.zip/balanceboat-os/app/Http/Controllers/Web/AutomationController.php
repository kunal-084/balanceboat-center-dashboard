<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class AutomationController extends Controller
{
    public function index(): View
    {
        $this->authorize('viewAny', \App\Models\AutomationRule::class);

        $centerId = auth()->user()->center_id;

        $rules = \App\Models\AutomationRule::where('center_id', $centerId)
            ->with(['emailTemplate', 'executions' => fn($q) => $q->latest()->limit(1)])
            ->withCount(['executions', 'executions as failed_count' => fn($q) => $q->where('status', 'failed')])
            ->orderByDesc('created_at')
            ->paginate(20);

        $emailTemplates   = \App\Models\EmailTemplate::where('center_id', $centerId)->where('is_active', true)->get();
        $triggerEvents    = $this->getTriggerEvents();

        return view('automations.index', compact('rules', 'emailTemplates', 'triggerEvents'));
    }

    public function store(\App\Http\Requests\Automation\StoreAutomationRuleRequest $request): RedirectResponse
    {
        $this->authorize('create', \App\Models\AutomationRule::class);

        $data              = $request->validated();
        $data['center_id'] = auth()->user()->center_id;

        \App\Models\AutomationRule::create($data);

        return back()->with('success', 'Automation rule created.');
    }

    public function update(\App\Http\Requests\Automation\UpdateAutomationRuleRequest $request, \App\Models\AutomationRule $automationRule): RedirectResponse
    {
        $this->authorize('update', $automationRule);

        $automationRule->update($request->validated());

        return back()->with('success', 'Automation rule updated.');
    }

    public function toggle(\App\Models\AutomationRule $automationRule): RedirectResponse
    {
        $this->authorize('update', $automationRule);

        $automationRule->update(['is_active' => ! $automationRule->is_active]);

        $status = $automationRule->fresh()->is_active ? 'enabled' : 'disabled';
        return back()->with('success', "Automation rule {$status}.");
    }

    public function destroy(\App\Models\AutomationRule $automationRule): RedirectResponse
    {
        $this->authorize('delete', $automationRule);

        $automationRule->delete();
        return back()->with('success', 'Automation rule deleted.');
    }

    public function executions(\App\Models\AutomationRule $automationRule): View
    {
        $executions = $automationRule->executions()->latest()->paginate(30);
        return view('automations.executions', compact('automationRule', 'executions'));
    }

    protected function getTriggerEvents(): array
    {
        return [
            'booking.confirmed'    => 'When a Booking is Confirmed',
            'booking.cancelled'    => 'When a Booking is Cancelled',
            'booking.checked_in'   => 'When a Guest Checks In',
            'booking.completed'    => 'When a Guest Checks Out',
            'booking.upcoming_3d'  => '3 Days Before Retreat Starts',
            'booking.upcoming_7d'  => '7 Days Before Retreat Starts',
            'inquiry.received'     => 'When a New Inquiry is Received',
            'inquiry.no_reply_24h' => 'When an Inquiry Has No Reply for 24h',
            'review.submitted'     => 'When a Review is Submitted',
        ];
    }
}
