<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_centers'      => Center::count(),
            'active_centers'     => Center::where('status', 'active')->count(),
            'total_users'        => User::count(),
            'mrr'                => DB::table('center_subscriptions')
                                     ->join('subscription_plans', 'center_subscriptions.plan_id', '=', 'subscription_plans.id')
                                     ->where('center_subscriptions.status', 'active')
                                     ->sum('subscription_plans.price'),
            'new_centers_month'  => Center::whereBetween('created_at', [now()->startOfMonth(), now()])->count(),
            'churned_month'      => Center::whereBetween('cancelled_at', [now()->startOfMonth(), now()])->count(),
        ];

        $recentCenters    = Center::with('owner', 'subscription.plan')->latest()->take(5)->get();
        $recentUsers      = User::latest()->take(5)->get();
        $planDistribution = DB::table('center_subscriptions')
            ->join('subscription_plans', 'center_subscriptions.plan_id', '=', 'subscription_plans.id')
            ->where('center_subscriptions.status', 'active')
            ->select('subscription_plans.name', DB::raw('count(*) as count'))
            ->groupBy('subscription_plans.id', 'subscription_plans.name')
            ->get();

        return view('admin.dashboard', compact('stats', 'recentCenters', 'recentUsers', 'planDistribution'));
    }
}
