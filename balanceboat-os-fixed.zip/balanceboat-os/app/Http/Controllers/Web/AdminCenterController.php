<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminCenterController extends Controller
{
    public function index(Request $request)
    {
        $centers = Center::with('owner', 'subscription.plan')
            ->when($request->search, fn($q) => $q->where('name', 'like', "%{$request->search}%"))
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->plan,   fn($q) => $q->whereHas('subscription', fn($s) => $s->where('plan_id', $request->plan)))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $plans = SubscriptionPlan::all();

        return view('admin.centers.index', compact('centers', 'plans'));
    }

    public function show(Center $center)
    {
        $center->load(['owner', 'subscription.plan', 'experiences', 'users']);

        $stats = [
            'bookings'  => $center->bookings()->count(),
            'revenue'   => $center->bookings()->sum('total_price'),
            'retreats'  => $center->experiences()->count(),
        ];

        return view('admin.centers.show', compact('center', 'stats'));
    }

    public function suspend(Request $request, Center $center)
    {
        $center->update(['status' => 'suspended', 'suspended_at' => now(), 'suspend_reason' => $request->reason]);

        // Notify owner
        $center->owner->notify(new \App\Notifications\CenterSuspendedNotification($request->reason));

        return back()->with('success', "Center '{$center->name}' suspended.");
    }

    public function reinstate(Center $center)
    {
        $center->update(['status' => 'active', 'suspended_at' => null, 'suspend_reason' => null]);

        return back()->with('success', "Center '{$center->name}' reinstated.");
    }

    public function impersonate(Center $center)
    {
        session(['impersonating' => auth()->id()]);
        auth()->login($center->owner);

        return redirect()->route('dashboard');
    }
}
