<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminSettingsController extends Controller
{
    public function index()
    {
        $settings = DB::table('system_settings')->pluck('value', 'key');
        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        foreach ($request->except('_token', '_method') as $key => $value) {
            DB::table('system_settings')
                ->updateOrInsert(['key' => $key], ['value' => $value, 'updated_at' => now()]);
        }

        return back()->with('success', 'Platform settings saved.');
    }
}
