<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class ReviewController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\CenterReview::class);

        $centerId = auth()->user()->center_id;
        $reviews  = \App\Models\CenterReview::where('center_id', $centerId)
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->rating, fn($q, $r) => $q->where('overall_rating', '>=', $r))
            ->with(['experience', 'response', 'user'])
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $stats = [
            'avg_rating'   => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'approved')->avg('overall_rating') ?? 0,
            'total'        => \App\Models\CenterReview::where('center_id', $centerId)->count(),
            'pending'      => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'pending')->count(),
            'approved'     => \App\Models\CenterReview::where('center_id', $centerId)->where('status', 'approved')->count(),
        ];

        return view('reviews.index', compact('reviews', 'stats'));
    }

    public function approve(\App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('approve', $review);

        $review->approve(auth()->id());

        return back()->with('success', 'Review approved and published.');
    }

    public function reject(Request $request, \App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('approve', $review);
        $request->validate(['reason' => ['required', 'string', 'min:5', 'max:500']]);

        $review->reject($request->reason, auth()->id());

        return back()->with('success', 'Review rejected.');
    }

    public function respond(Request $request, \App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('respond', $review);
        $request->validate(['response' => ['required', 'string', 'min:10', 'max:2000']]);

        \App\Models\ReviewResponse::updateOrCreate(
            ['review_id' => $review->id],
            ['responded_by' => auth()->id(), 'response' => $request->response, 'responded_at' => now()]
        );

        return back()->with('success', 'Response published.');
    }

    public function destroy(\App\Models\CenterReview $review): RedirectResponse
    {
        $this->authorize('delete', $review);

        $review->delete();
        return back()->with('success', 'Review deleted.');
    }
}
