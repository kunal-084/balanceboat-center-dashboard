<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class BookingController extends Controller
{
    public function __construct(
        private readonly \App\Repositories\BookingRepository $repository,
        private readonly \App\Services\BookingService        $bookingService,
        private readonly \App\Actions\Booking\ConfirmBookingAction $confirmAction,
        private readonly \App\Actions\Booking\CancelBookingAction  $cancelAction,
        private readonly \App\Actions\Booking\CheckInGuestAction   $checkInAction,
        private readonly \App\Actions\Booking\CheckOutGuestAction  $checkOutAction,
    ) {}

    public function index(Request $request): View
    {
        $this->authorize('viewAny', \App\Models\Booking::class);

        $centerId = auth()->user()->center_id;
        $bookings = $this->repository->paginateForCenter(
            centerId: $centerId,
            filters:  $request->only(['stage', 'search', 'date_from', 'date_to', 'assigned_to', 'experience_id']),
            sortBy:   $request->get('sort', 'created_at'),
            sortDir:  $request->get('dir', 'desc'),
        );

        $stageCounts = $this->repository->stageCountsForCenter($centerId);
        $experiences = Experience::forCenter($centerId)->published()->orderBy('name')->get(['id', 'name']);
        $staff       = \App\Models\User::where('center_id', $centerId)->whereIn('center_role', ['owner','manager','staff'])->get(['id', 'first_name', 'last_name']);

        return view('bookings.index', compact('bookings', 'stageCounts', 'experiences', 'staff'));
    }

    public function show(\App\Models\Booking $booking): View
    {
        $this->authorize('view', $booking);

        $booking->load([
            'experience.center', 'userInfo', 'experienceInfo',
            'transactionInfo', 'addressInfo', 'promoCode',
            'assignedStaff', 'accommodation', 'couponRedemption',
        ]);

        $auditLogs = \App\Models\AuditLog::where('auditable_type', get_class($booking))
            ->where('auditable_id', $booking->id)
            ->latest()
            ->limit(20)
            ->get();

        return view('bookings.show', compact('booking', 'auditLogs'));
    }

    public function edit(\App\Models\Booking $booking): View
    {
        $this->authorize('update', $booking);

        $booking->load(['experience', 'userInfo', 'assignedStaff']);
        $staff = \App\Models\User::where('center_id', auth()->user()->center_id)->get(['id', 'first_name', 'last_name', 'center_role']);

        return view('bookings.edit', compact('booking', 'staff'));
    }

    public function update(\App\Http\Requests\Booking\UpdateBookingRequest $request, \App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $booking->update($request->validated());

        return back()->with('success', 'Booking updated successfully.');
    }

    public function confirm(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);

        $this->confirmAction->handle($booking);

        return back()->with('success', "Booking {$booking->booking_reference} confirmed.");
    }

    public function checkIn(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('checkIn', $booking);

        $this->checkInAction->handle($booking);

        return back()->with('success', "Guest {$booking->guest_name} checked in successfully.");
    }

    public function checkOut(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('checkOut', $booking);

        $this->checkOutAction->handle($booking);

        return back()->with('success', "Guest {$booking->guest_name} checked out. Stay complete.");
    }

    public function cancel(\App\Http\Requests\Booking\CancelBookingRequest $request, \App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('cancel', $booking);

        $this->cancelAction->handle($booking, $request->reason, $request->boolean('process_refund'));

        return back()->with('success', "Booking {$booking->booking_reference} has been cancelled.");
    }

    public function assign(Request $request, \App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('update', $booking);
        $request->validate(['staff_id' => ['required', 'integer', 'exists:users,id']]);

        $this->bookingService->assignToStaff($booking, $request->staff_id);

        return back()->with('success', 'Booking assigned successfully.');
    }

    public function destroy(\App\Models\Booking $booking): RedirectResponse
    {
        $this->authorize('delete', $booking);
        $booking->delete();
        return redirect()->route('bookings.index')->with('success', 'Booking deleted.');
    }
}
