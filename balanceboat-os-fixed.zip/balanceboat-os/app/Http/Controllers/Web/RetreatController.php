<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Retreat\{StoreRetreatRequest, UpdateRetreatRequest};
use App\Actions\Retreat\{CreateRetreatAction, UpdateRetreatAction, PublishRetreatAction, UnpublishRetreatAction, DuplicateRetreatAction};
use App\DTOs\RetreatDTO;
use App\Models\{Experience, Category, Teacher, Accomodation};
use App\Repositories\ExperienceRepository;
use App\Services\{RetreatService, AvailabilityService};
use Illuminate\Http\{Request, RedirectResponse};
use Illuminate\View\View;

class RetreatController extends Controller
{
    public function __construct(
        private readonly ExperienceRepository  $repository,
        private readonly CreateRetreatAction   $createAction,
        private readonly UpdateRetreatAction   $updateAction,
        private readonly PublishRetreatAction  $publishAction,
        private readonly UnpublishRetreatAction $unpublishAction,
        private readonly DuplicateRetreatAction $duplicateAction,
        private readonly AvailabilityService   $availabilityService,
    ) {}

    public function index(Request $request): View
    {
        $this->authorize('viewAny', Experience::class);

        $retreats = $this->repository->paginateForCenter(
            centerId: auth()->user()->center_id,
            filters:  $request->only(['status', 'search', 'category_id', 'featured']),
            sortBy:   $request->get('sort', 'created_at'),
            sortDir:  $request->get('dir', 'desc'),
        );

        $categories = Category::where('type', 0)->orderBy('name')->get();
        $stats      = app(RetreatService::class)->getStats(auth()->user()->center_id);

        return view('retreats.index', compact('retreats', 'categories', 'stats'));
    }

    public function create(): View
    {
        $this->authorize('create', Experience::class);

        $categories     = Category::where('type', 0)->orderBy('name')->get();
        $teachers       = Teacher::forCenter(auth()->user()->center_id)->active()->orderBy('name')->get();
        $accommodations = Accomodation::all();

        return view('retreats.create', compact('categories', 'teachers', 'accommodations'));
    }

    public function store(StoreRetreatRequest $request): RedirectResponse
    {
        $dto     = RetreatDTO::fromRequest($request, auth()->user()->center_id);
        $retreat = $this->createAction->handle($dto);

        // Queue availability calendar generation
        \App\Jobs\RefreshAvailabilityCalendarJob::dispatch($retreat)->onQueue('default');

        return redirect()
            ->route('retreats.show', $retreat)
            ->with('success', "Retreat \"{$retreat->name}\" created successfully.");
    }

    public function show(Experience $retreat): View
    {
        $this->authorize('view', $retreat);

        $retreat->load([
            'center', 'categories', 'teachers', 'accommodations.prices',
            'faqs', 'benefits', 'itineraryDays.sessions', 'imageGallery',
            'pricingRules', 'seoMetadata', 'aiRecommendations',
        ]);

        $recentBookings = \App\Models\Booking::where('experience_id', $retreat->id)
            ->with('userInfo')
            ->latest()
            ->limit(10)
            ->get();

        $availability = $this->availabilityService->getCalendar(
            $retreat->id,
            now(),
            now()->addMonths(3)
        );

        $reviewStats = [
            'avg'   => $retreat->computed_average_rating,
            'total' => $retreat->review_count,
        ];

        return view('retreats.show', compact('retreat', 'recentBookings', 'availability', 'reviewStats'));
    }

    public function edit(Experience $retreat): View
    {
        $this->authorize('update', $retreat);

        $retreat->load(['categories', 'teachers', 'accommodations', 'faqs', 'benefits', 'itineraryDays.sessions']);

        $categories     = Category::where('type', 0)->orderBy('name')->get();
        $teachers       = Teacher::forCenter(auth()->user()->center_id)->active()->orderBy('name')->get();
        $accommodations = Accomodation::all();

        return view('retreats.edit', compact('retreat', 'categories', 'teachers', 'accommodations'));
    }

    public function update(UpdateRetreatRequest $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);

        $this->updateAction->handle($retreat, $request->validated());

        return redirect()
            ->route('retreats.show', $retreat)
            ->with('success', 'Retreat updated successfully.');
    }

    public function destroy(Experience $retreat): RedirectResponse
    {
        $this->authorize('delete', $retreat);

        $name = $retreat->name;
        $retreat->delete();

        return redirect()
            ->route('retreats.index')
            ->with('success', "\"{$name}\" has been archived.");
    }

    public function publish(Experience $retreat): RedirectResponse
    {
        $this->authorize('publish', $retreat);

        $this->publishAction->handle($retreat);

        return back()->with('success', 'Retreat is now live and accepting bookings.');
    }

    public function unpublish(Experience $retreat): RedirectResponse
    {
        $this->authorize('publish', $retreat);

        $this->unpublishAction->handle($retreat);

        return back()->with('success', 'Retreat has been unpublished.');
    }

    public function duplicate(Experience $retreat): RedirectResponse
    {
        $this->authorize('duplicate', $retreat);

        $clone = $this->duplicateAction->handle($retreat);

        return redirect()
            ->route('retreats.edit', $clone)
            ->with('success', 'Retreat duplicated successfully. Please review and update the copy.');
    }

    public function availability(Request $request, Experience $retreat): View
    {
        $this->authorize('view', $retreat);

        $from = $request->get('from', now()->startOfMonth()->toDateString());
        $to   = $request->get('to', now()->addMonths(3)->endOfMonth()->toDateString());

        $calendar = $this->availabilityService->getCalendar($retreat->id, \Carbon\Carbon::parse($from), \Carbon\Carbon::parse($to));

        return view('retreats.availability', compact('retreat', 'calendar', 'from', 'to'));
    }

    public function blockDates(Request $request, Experience $retreat): RedirectResponse
    {
        $this->authorize('update', $retreat);
        $request->validate([
            'dates'  => ['required', 'array', 'min:1'],
            'dates.*'=> ['date'],
            'reason' => ['nullable', 'string', 'max:255'],
        ]);

        $this->availabilityService->blockDates($retreat->id, $request->dates, $request->reason ?? '');

        return back()->with('success', count($request->dates) . ' date(s) blocked successfully.');
    }
}
