<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class AccommodationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                    => $this->id,
            'title'                 => $this->title ?? $this->when($this->accomodation, $this->accomodation?->name),
            'about'                 => $this->about,
            'max_guests'            => $this->max_guest_in_room,
            'is_default'            => (bool) $this->accomodation_default,
            'price_per_night'       => (float) $this->price_per_night_per_guest,
            'currency'              => $this->currency,
            'price_single_occupancy'=> (float) ($this->price_single_occupancy ?? 0),
            'price_double_occupancy'=> (float) ($this->price_double_occupancy ?? 0),
            'price_twin_sharing'    => (float) ($this->price_twin_sharing ?? 0),
        ];
    }
}
