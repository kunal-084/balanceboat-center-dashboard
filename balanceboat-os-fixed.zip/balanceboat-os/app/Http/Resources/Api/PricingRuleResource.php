<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class PricingRuleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'type'          => $this->rule_type,
            'discount_type' => $this->discount_type,
            'discount_value'=> (float) $this->discount_value,
            'is_stackable'  => $this->is_stackable,
            'priority'      => $this->priority,
            'start_date'    => $this->start_date?->toDateString(),
            'end_date'      => $this->end_date?->toDateString(),
            'is_active'     => $this->is_active,
        ];
    }
}
