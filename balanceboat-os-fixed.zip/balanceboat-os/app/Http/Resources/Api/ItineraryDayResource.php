<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class ItineraryDayResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'day_number' => $this->day_number,
            'title'      => $this->title,
            'description'=> $this->description,
            'theme'      => $this->theme,
            'sessions'   => $this->whenLoaded('sessions', fn() => $this->sessions->map(fn($s) => [
                'id'          => $s->id,
                'start_time'  => $s->start_time,
                'end_time'    => $s->end_time,
                'activity'    => $s->activity,
                'description' => $s->description,
                'type'        => $s->session_type,
                'location'    => $s->location,
                'is_optional' => $s->is_optional,
            ])),
        ];
    }
}
