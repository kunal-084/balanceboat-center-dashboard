<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class InquiryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'             => $this->id,
            'name'           => $this->full_name,
            'email'          => $this->email,
            'phone'          => $this->phone,
            'whatsapp'       => $this->whatsapp,
            'message'        => $this->message,
            'retreat_type'   => $this->retreat_type,
            'destination'    => $this->destination,
            'budget'         => $this->budget,
            'timeline'       => $this->timeline,
            'pipeline_stage' => $this->pipeline_stage,
            'stage_color'    => $this->stage_color,
            'follow_up_at'   => $this->follow_up_at?->toIso8601String(),
            'created_at'     => $this->created_at->toIso8601String(),
            'experience'     => $this->whenLoaded('experience', fn() => ['id' => $this->experience->id, 'name' => $this->experience->name]),
        ];
    }
}
