<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class CenterResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'name'            => $this->name,
            'slug'            => $this->slug,
            'status'          => $this->status,
            'about'           => $this->about_center,
            'philosophy'      => $this->our_philosophy,
            'location'        => $this->location,
            'city'            => $this->city,
            'country'         => $this->country,
            'gps'             => $this->gps,
            'latitude'        => $this->latitude,
            'longitude'       => $this->longitude,
            'email'           => $this->email_address,
            'phone'           => $this->contact_number,
            'whatsapp'        => $this->whatsapp_number,
            'website'         => $this->website,
            'banner_image_url'=> $this->banner_image_url,
            'video_url'       => $this->video_url,
            'have_accommodation'=> $this->have_accomodation,
            'average_rating'  => $this->average_rating,
            'is_verified'     => $this->is_verified,
            'is_featured'     => $this->is_featured,
            'social'          => [
                'facebook'  => $this->facebook_url,
                'instagram' => $this->instagram_url,
                'youtube'   => $this->youtube_url,
                'twitter'   => $this->twitter_url,
            ],
            'meta_title'      => $this->meta_title,
            'meta_description'=> $this->meta_description,
            'created_at'      => $this->created_at?->toIso8601String(),
        ];
    }
}
