<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class TeacherResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'name'            => $this->name,
            'slug'            => $this->slug,
            'short_bio'       => $this->short_description,
            'teaching_since'  => $this->teaching_since,
            'years_experience'=> $this->full_years_experience,
            'languages'       => $this->languages,
            'nationality'     => $this->nationality,
            'status'          => $this->status,
            'is_featured'     => $this->is_featured,
            'is_verified'     => $this->is_verified,
            'average_rating'  => (float) $this->average_rating,
            'total_reviews'   => $this->total_reviews,
            'profile_image_url'=> $this->profile_image_url,
            'social'          => [
                'website'   => $this->website_url,
                'instagram' => $this->instagram_url,
                'facebook'  => $this->facebook_url,
                'youtube'   => $this->youtube_url,
            ],
            'created_at'      => $this->created_at?->toIso8601String(),
        ];
    }
}
