<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                => $this->id,
            'reference'         => $this->booking_reference,
            'stage'             => $this->stage,
            'stage_label'       => $this->stage_label,
            'stage_color'       => $this->stage_color,
            'guest_count'       => $this->guest_count,
            'arrival_date'      => $this->arrival_date?->toDateString(),
            'start_date_time'   => $this->start_date_time?->toIso8601String(),
            'end_date_time'     => $this->end_date_time?->toIso8601String(),
            'check_in_at'       => $this->check_in_at?->toIso8601String(),
            'check_out_at'      => $this->check_out_at?->toIso8601String(),
            'currency'          => $this->currency,
            'booking_amount'    => (float) $this->booking_amount,
            'discount_amount'   => (float) $this->discount_amount,
            'commission_amount' => (float) $this->commission_amount,
            'pay_amount'        => (float) $this->pay_amount,
            'net_amount'        => $this->net_amount,
            'payment_status'    => $this->payment_status,
            'order_status'      => $this->order_status,
            'internal_notes'    => $this->when($request->user()?->center_id, $this->internal_notes),
            'allowed_transitions'=> \App\Models\Booking::ALLOWED_TRANSITIONS[$this->stage] ?? [],
            'experience'        => $this->whenLoaded('experience', fn() => new ExperienceResource($this->experience)),
            'guest'             => $this->whenLoaded('userInfo', fn() => [
                'name'    => $this->userInfo->firstname . ' ' . $this->userInfo->lastname,
                'email'   => $this->userInfo->email,
                'phone'   => $this->userInfo->phone,
                'message' => $this->userInfo->message,
            ]),
            'assigned_staff'    => $this->whenLoaded('assignedStaff', fn() => [
                'id'   => $this->assignedStaff->id,
                'name' => $this->assignedStaff->full_name,
            ]),
            'created_at'        => $this->created_at->toIso8601String(),
        ];
    }
}
