<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class ExperienceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'name'            => $this->name,
            'slug'            => $this->slug,
            'status'          => $this->status_label,
            'publish_status'  => $this->publish_status,
            'summary'         => $this->experience_summary,
            'price_per_person'=> (float) $this->price_per_person,
            'currency'        => $this->currency,
            'duration_nights' => $this->duration_nights,
            'batch_size'      => $this->batch_size,
            'occupancy_rate'  => $this->occupancy_rate,
            'average_rating'  => (float) $this->average_rating,
            'review_count'    => $this->review_count,
            'is_bookable'     => $this->is_bookable,
            'is_featured'     => $this->is_featured,
            'start_date_time' => $this->start_date_time?->toIso8601String(),
            'end_date_time'   => $this->end_date_time?->toIso8601String(),
            'food'            => $this->food,
            'skill_level'     => $this->skill_level,
            'language_spoken' => $this->language_spoken,
            'banner_image_url'=> $this->banner_image_url,
            'thumbnail_image_url'=> $this->thumbnail_image_url,
            'video_url'       => $this->video_url,
            'has_early_bird'  => $this->has_early_bird,
            'early_bird_deadline' => $this->early_bird_deadline?->toDateString(),
            'early_bird_discount' => $this->eirly_bird_discount,
            'gps'             => $this->gps,
            'meta_title'      => $this->meta_title,
            'meta_description'=> $this->meta_description,
            'center'          => $this->whenLoaded('center', fn() => new CenterResource($this->center)),
            'categories'      => $this->whenLoaded('categories', fn() => CategoryResource::collection($this->categories)),
            'teachers'        => $this->whenLoaded('teachers', fn() => TeacherResource::collection($this->teachers)),
            'accommodations'  => $this->whenLoaded('accommodations', fn() => AccommodationResource::collection($this->accommodations)),
            'faqs'            => $this->whenLoaded('faqs', fn() => FaqResource::collection($this->faqs)),
            'benefits'        => $this->whenLoaded('benefits', fn() => $this->benefits->pluck('benefit')),
            'itinerary_days'  => $this->whenLoaded('itineraryDays', fn() => ItineraryDayResource::collection($this->itineraryDays)),
            'image_gallery'   => $this->whenLoaded('imageGallery', fn() => $this->imageGallery->map(fn($img) => ['url' => $img->image_url, 'title' => $img->image_title])),
            'pricing_rules'   => $this->whenLoaded('pricingRules', fn() => PricingRuleResource::collection($this->pricingRules)),
            'created_at'      => $this->created_at->toIso8601String(),
            'updated_at'      => $this->updated_at->toIso8601String(),
        ];
    }
}
