<?php

namespace App\Http\Requests\Teacher;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTeacherRequest extends StoreTeacherRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('teacher'));
    }

    public function rules(): array
    {
        $teacherId = $this->route('teacher')?->id;
        $rules     = parent::rules();
        $rules['name']  = ['sometimes', 'string', 'max:200'];
        $rules['slug']  = ['nullable', 'string', 'max:220', "unique:teachers,slug,{$teacherId}"];
        return $rules;
    }
}
