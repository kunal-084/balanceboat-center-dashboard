<?php

namespace App\Http\Requests\Teacher;

use Illuminate\Foundation\Http\FormRequest;

class StoreTeacherRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', \App\Models\Teacher::class);
    }

    public function rules(): array
    {
        return [
            'name'               => ['required', 'string', 'max:200'],
            'slug'               => ['nullable', 'string', 'max:220', 'unique:teachers,slug'],
            'short_description'  => ['nullable', 'string', 'max:500'],
            'complete_bio'       => ['nullable', 'string'],
            'currently_working_with' => ['nullable', 'string'],
            'expertise_id'       => ['nullable', 'string'],
            'certificate_id'     => ['nullable', 'string'],
            'teaching_since'     => ['nullable', 'integer', 'min:1950', 'max:' . date('Y')],
            'languages'          => ['nullable', 'array'],
            'languages.*'        => ['string', 'max:50'],
            'nationality'        => ['nullable', 'string', 'max:100'],
            'hourly_rate'        => ['nullable', 'numeric', 'min:0'],
            'rate_currency'      => ['nullable', 'string', 'size:3'],
            'website_url'        => ['nullable', 'url', 'max:250'],
            'instagram_url'      => ['nullable', 'url', 'max:250'],
            'facebook_url'       => ['nullable', 'url', 'max:250'],
            'youtube_url'        => ['nullable', 'url', 'max:250'],
            'status'             => ['nullable', 'in:active,inactive,pending,suspended'],
            'is_featured'        => ['boolean'],
            'meta_title'         => ['nullable', 'string', 'max:255'],
            'meta_description'   => ['nullable', 'string', 'max:320'],
            'keywords'           => ['nullable', 'string'],
        ];
    }
}
