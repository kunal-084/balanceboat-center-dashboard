<?php

namespace App\Http\Requests\Media;

use Illuminate\Foundation\Http\FormRequest;

class StoreMediaRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'files'            => ['required', 'array', 'min:1', 'max:20'],
            'files.*'          => ['required', 'file', 'max:102400', 'mimes:jpg,jpeg,png,webp,gif,mp4,mov,pdf,doc,docx'],
            'folder_id'        => ['nullable', 'integer', 'exists:media_folders,id'],
            'collection'       => ['nullable', 'string', 'max:100'],
            'mediable_type'    => ['nullable', 'string', 'max:200'],
            'mediable_id'      => ['nullable', 'integer'],
            'alt_text'         => ['nullable', 'string', 'max:500'],
            'caption'          => ['nullable', 'string', 'max:1000'],
            'category'         => ['nullable', 'string', 'max:100'],
        ];
    }
}
