<?php

namespace App\Http\Requests\Media;

use Illuminate\Foundation\Http\FormRequest;

class UpdateMediaRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'alt_text'    => ['nullable', 'string', 'max:500'],
            'caption'     => ['nullable', 'string', 'max:1000'],
            'category'    => ['nullable', 'string', 'max:100'],
            'is_featured' => ['boolean'],
            'sort_order'  => ['nullable', 'integer', 'min:0'],
        ];
    }
}
