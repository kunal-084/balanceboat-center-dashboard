<?php

namespace App\Http\Requests\Pricing;

use Illuminate\Foundation\Http\FormRequest;

class StorePricingRuleRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'                    => ['required', 'string', 'max:200'],
            'description'             => ['nullable', 'string', 'max:500'],
            'experience_id'           => ['nullable', 'integer', 'exists:experiences,id'],
            'rule_type'               => ['required', 'in:early_bird,last_minute,seasonal_peak,seasonal_off,occupancy_based,duration_based,group_discount,repeat_guest,custom'],
            'discount_type'           => ['required', 'in:percentage,fixed'],
            'discount_value'          => ['required', 'numeric', 'min:0.01'],
            'min_price_cap'           => ['nullable', 'numeric', 'min:0'],
            'days_before'             => ['nullable', 'integer', 'min:1', 'required_if:rule_type,early_bird', 'required_if:rule_type,last_minute'],
            'occupancy_threshold_pct' => ['nullable', 'integer', 'min:1', 'max:100', 'required_if:rule_type,occupancy_based'],
            'min_duration_nights'     => ['nullable', 'integer', 'min:1', 'required_if:rule_type,duration_based'],
            'min_group_size'          => ['nullable', 'integer', 'min:2', 'required_if:rule_type,group_discount'],
            'start_date'              => ['nullable', 'date', 'required_if:rule_type,seasonal_peak', 'required_if:rule_type,seasonal_off'],
            'end_date'                => ['nullable', 'date', 'after_or_equal:start_date'],
            'priority'                => ['integer', 'min:0', 'max:100'],
            'is_stackable'            => ['boolean'],
            'is_active'               => ['boolean'],
        ];
    }
}
