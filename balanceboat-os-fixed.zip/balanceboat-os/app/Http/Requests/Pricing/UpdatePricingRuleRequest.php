<?php

namespace App\Http\Requests\Pricing;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePricingRuleRequest extends StorePricingRuleRequest
{
    public function rules(): array
    {
        $rules = parent::rules();
        $rules['name']         = ['sometimes', 'string', 'max:200'];
        $rules['rule_type']    = ['sometimes', 'in:early_bird,last_minute,seasonal_peak,seasonal_off,occupancy_based,duration_based,group_discount,repeat_guest,custom'];
        $rules['discount_type']  = ['sometimes', 'in:percentage,fixed'];
        $rules['discount_value'] = ['sometimes', 'numeric', 'min:0.01'];
        return $rules;
    }
}
