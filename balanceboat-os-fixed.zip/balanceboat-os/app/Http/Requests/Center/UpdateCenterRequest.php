<?php

namespace App\Http\Requests\Center;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCenterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('center') ?? auth()->user()->center);
    }

    public function rules(): array
    {
        return [
            'name'                         => ['sometimes', 'string', 'max:100'],
            'meta_title'                   => ['nullable', 'string', 'max:255'],
            'keywords'                     => ['nullable', 'string'],
            'meta_description'             => ['nullable', 'string', 'max:500'],
            'gps'                          => ['nullable', 'string', 'max:80'],
            'location'                     => ['nullable', 'string', 'max:255'],
            'speciality_id'                => ['nullable', 'string'],
            'year_of_foundation'           => ['nullable', 'integer', 'min:1800', 'max:' . date('Y')],
            'founders'                     => ['nullable', 'string', 'max:255'],
            'about_center'                 => ['nullable', 'string'],
            'what_sets_us_apart'           => ['nullable', 'string'],
            'our_philosophy'               => ['nullable', 'string'],
            'our_mission'                  => ['nullable', 'string'],
            'center_highlights'            => ['nullable', 'string'],
            'video_url'                    => ['nullable', 'url', 'max:255'],
            'website'                      => ['nullable', 'url', 'max:250'],
            'address_of_center'            => ['nullable', 'string', 'max:255'],
            'city'                         => ['nullable', 'string', 'max:60'],
            'state'                        => ['nullable', 'string', 'max:100'],
            'country'                      => ['nullable', 'string', 'max:200'],
            'postal_code'                  => ['nullable', 'string', 'max:20'],
            'email_address'                => ['nullable', 'email', 'max:255'],
            'contact_number'               => ['nullable', 'string', 'max:100'],
            'whatsapp_number'              => ['nullable', 'string', 'max:100'],
            'facebook_url'                 => ['nullable', 'url', 'max:250'],
            'instagram_url'                => ['nullable', 'url', 'max:250'],
            'twitter_url'                  => ['nullable', 'url', 'max:250'],
            'youtube_url'                  => ['nullable', 'url', 'max:250'],
            'linkedin_url'                 => ['nullable', 'url', 'max:250'],
            'have_accomodation'            => ['nullable', 'in:Yes,No'],
            'accomodation_overview'        => ['nullable', 'string'],
            'how_to_get_there'             => ['nullable', 'string'],
            'things_to_do_around_the_center'=>['nullable', 'string'],
            'amenities'                    => ['nullable', 'string'],
            'airport_name'                 => ['nullable', 'string', 'max:255'],
            'pickup_drop_cost'             => ['nullable', 'numeric', 'min:0'],
            'timezone'                     => ['nullable', 'string', 'max:100'],
            'currency_code'                => ['nullable', 'string', 'size:3'],
            'operating_hours'              => ['nullable', 'array'],
            'tags'                         => ['nullable', 'string', 'max:500'],
            'latitude'                     => ['nullable', 'numeric', 'between:-90,90'],
            'longitude'                    => ['nullable', 'numeric', 'between:-180,180'],
        ];
    }
}
