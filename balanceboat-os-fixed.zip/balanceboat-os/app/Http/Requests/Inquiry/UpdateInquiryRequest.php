<?php

namespace App\Http\Requests\Inquiry;

use Illuminate\Foundation\Http\FormRequest;

class UpdateInquiryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('inquiry'));
    }

    public function rules(): array
    {
        return [
            'pipeline_stage'  => ['sometimes', 'in:new,contacted,qualified,proposal,negotiating,won,lost'],
            'assigned_to'     => ['nullable', 'integer', 'exists:users,id'],
            'note'            => ['nullable', 'string', 'max:5000'],
            'follow_up_at'    => ['nullable', 'date'],
            'lost_reason'     => ['nullable', 'string', 'max:500'],
        ];
    }
}
