<?php

namespace App\Http\Requests\Inquiry;

use Illuminate\Foundation\Http\FormRequest;

class StoreInquiryRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'         => ['required', 'string', 'max:191'],
            'lastname'     => ['nullable', 'string', 'max:191'],
            'email'        => ['required', 'email', 'max:191'],
            'country_code' => ['nullable', 'integer'],
            'phone'        => ['nullable', 'string', 'max:20'],
            'whatsapp'     => ['boolean'],
            'message'      => ['nullable', 'string', 'max:5000'],
            'retreat_type' => ['nullable', 'string', 'max:255'],
            'destination'  => ['nullable', 'string', 'max:255'],
            'budget'       => ['nullable', 'string', 'max:255'],
            'timeline'     => ['nullable', 'string', 'max:255'],
            'experience_id'=> ['nullable', 'integer', 'exists:experiences,id'],
            'source'       => ['nullable', 'string', 'max:100'],
            'ref_url'      => ['nullable', 'url', 'max:500'],
            'group_size'   => ['nullable', 'integer', 'min:1', 'max:500'],
        ];
    }
}
