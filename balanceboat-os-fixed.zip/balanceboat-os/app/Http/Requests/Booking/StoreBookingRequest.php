<?php

namespace App\Http\Requests\Booking;

use Illuminate\Foundation\Http\FormRequest;

class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'experience_id'            => ['required', 'integer', 'exists:experiences,id'],
            'experience_accomodation_id'=> ['nullable', 'integer', 'exists:experience_accomodations,id'],
            'guest_count'              => ['required', 'integer', 'min:1', 'max:50'],
            'arrival_date'             => ['required', 'date', 'after_or_equal:today'],
            'start_date_time'          => ['nullable', 'date'],
            'end_date_time'            => ['nullable', 'date', 'after_or_equal:start_date_time'],
            'currency'                 => ['nullable', 'string', 'size:3'],
            'promo_code'               => ['nullable', 'string', 'max:50'],
            'guest_info'               => ['required', 'array'],
            'guest_info.firstname'     => ['required', 'string', 'max:100'],
            'guest_info.lastname'      => ['required', 'string', 'max:100'],
            'guest_info.email'         => ['required', 'email', 'max:191'],
            'guest_info.phone'         => ['required', 'string', 'max:30'],
            'guest_info.message'       => ['nullable', 'string', 'max:2000'],
            'billing_name'             => ['nullable', 'string', 'max:100'],
            'billing_address'          => ['nullable', 'string', 'max:150'],
            'billing_city'             => ['nullable', 'string', 'max:30'],
            'billing_country'          => ['nullable', 'string', 'max:20'],
            'billing_zip'              => ['nullable', 'string', 'max:10'],
            'billing_email'            => ['nullable', 'email', 'max:100'],
            'billing_tel'              => ['nullable', 'string', 'max:20'],
        ];
    }
}
