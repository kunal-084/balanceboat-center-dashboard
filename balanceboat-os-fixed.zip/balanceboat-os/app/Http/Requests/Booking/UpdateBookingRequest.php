<?php

namespace App\Http\Requests\Booking;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('booking'));
    }

    public function rules(): array
    {
        return [
            'stage'              => ['sometimes', 'in:inquiry,qualified,proposal_sent,confirmed,checked_in,completed,cancelled,refunded'],
            'assigned_staff_id'  => ['nullable', 'integer', 'exists:users,id'],
            'internal_notes'     => ['nullable', 'string', 'max:5000'],
            'cancellation_reason'=> ['nullable', 'string', 'max:500'],
            'arrival_date'       => ['sometimes', 'date'],
            'guest_count'        => ['sometimes', 'integer', 'min:1'],
        ];
    }
}
