<?php

namespace App\Http\Requests\Booking;

use Illuminate\Foundation\Http\FormRequest;

class CancelBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('cancel', $this->route('booking'));
    }

    public function rules(): array
    {
        return [
            'reason'         => ['required', 'string', 'min:10', 'max:500'],
            'process_refund' => ['boolean'],
            'refund_amount'  => ['nullable', 'numeric', 'min:0.01', 'required_if:process_refund,true'],
        ];
    }
}
