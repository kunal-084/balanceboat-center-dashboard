<?php

namespace App\Http\Requests\PromoCode;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePromoCodeRequest extends StorePromoCodeRequest
{
    public function rules(): array
    {
        $id    = $this->route('promo_code')?->id;
        $rules = parent::rules();
        $rules['code'] = ['sometimes', 'string', 'max:50', "unique:promo_codes,code,{$id}", 'regex:/^[A-Z0-9\-_]+$/'];
        $rules['discount_type']  = ['sometimes', 'in:percentage,fixed'];
        $rules['discount_value'] = ['sometimes', 'numeric', 'min:0.01'];
        return $rules;
    }
}
