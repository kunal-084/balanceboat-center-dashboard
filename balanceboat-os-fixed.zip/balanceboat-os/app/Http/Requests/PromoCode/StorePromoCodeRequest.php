<?php

namespace App\Http\Requests\PromoCode;

use Illuminate\Foundation\Http\FormRequest;

class StorePromoCodeRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'code'                       => ['required', 'string', 'max:50', 'unique:promo_codes,code', 'regex:/^[A-Z0-9\-_]+$/'],
            'description'                => ['nullable', 'string', 'max:255'],
            'discount_type'              => ['required', 'in:percentage,fixed'],
            'discount_value'             => ['required', 'numeric', 'min:0.01'],
            'min_booking_amount'         => ['nullable', 'numeric', 'min:0'],
            'max_discount_cap'           => ['nullable', 'numeric', 'min:0'],
            'max_uses'                   => ['nullable', 'integer', 'min:1'],
            'max_uses_per_user'          => ['required', 'integer', 'min:1', 'max:100'],
            'valid_from'                 => ['nullable', 'date'],
            'valid_until'                => ['nullable', 'date', 'after_or_equal:valid_from'],
            'applies_to_all'             => ['boolean'],
            'applicable_experience_ids'  => ['nullable', 'array', 'required_if:applies_to_all,false'],
            'applicable_experience_ids.*'=> ['integer', 'exists:experiences,id'],
            'is_active'                  => ['boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'code.regex' => 'Code must contain only uppercase letters, numbers, hyphens, or underscores.',
            'applicable_experience_ids.required_if' => 'Please select at least one retreat when not applying to all.',
        ];
    }
}
