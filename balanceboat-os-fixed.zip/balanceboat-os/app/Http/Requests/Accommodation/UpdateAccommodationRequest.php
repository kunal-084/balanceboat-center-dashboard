<?php

namespace App\Http\Requests\Accommodation;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAccommodationRequest extends StoreAccommodationRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('accommodation'));
    }

    public function rules(): array
    {
        $rules = parent::rules();
        $rules['name'] = ['sometimes', 'string', 'max:200'];
        return $rules;
    }
}
