<?php

namespace App\Http\Requests\Accommodation;

use Illuminate\Foundation\Http\FormRequest;

class StoreAccommodationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', \App\Models\Accomodation::class);
    }

    public function rules(): array
    {
        return [
            'name'                    => ['required', 'string', 'max:200'],
            'description'             => ['nullable', 'string'],
            'max_guest_in_room'       => ['nullable', 'integer', 'min:1', 'max:20'],
            'banner_image_title'      => ['nullable', 'string', 'max:255'],
            'banner_image_url'        => ['nullable', 'string', 'max:500'],
            'banner_image_path'       => ['nullable', 'string', 'max:500'],
        ];
    }
}
