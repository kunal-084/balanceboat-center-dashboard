<?php

namespace App\Http\Requests\Retreat;

use Illuminate\Foundation\Http\FormRequest;

class StoreRetreatRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', \App\Models\Experience::class);
    }

    public function rules(): array
    {
        return [
            'name'                          => ['required', 'string', 'max:200'],
            'slug'                          => ['nullable', 'string', 'max:220', 'unique:experiences,slug'],
            'experience_category'           => ['nullable', 'string', 'max:255'],
            'category_ids'                  => ['nullable', 'array'],
            'category_ids.*'                => ['integer', 'exists:category,id'],
            'teacher_ids'                   => ['nullable', 'array'],
            'teacher_ids.*'                 => ['integer', 'exists:teachers,id'],
            'price_per_person'              => ['required', 'numeric', 'min:0'],
            'currency'                      => ['required', 'string', 'size:3'],
            'avg_price'                     => ['nullable', 'numeric', 'min:0'],
            'price_shared'                  => ['nullable', 'numeric', 'min:0'],
            'price_private'                 => ['nullable', 'numeric', 'min:0'],
            'batch_size'                    => ['nullable', 'integer', 'min:1', 'max:500'],
            'duration'                      => ['nullable', 'string', 'max:100'],
            'duration_nights'               => ['nullable', 'integer', 'min:1', 'max:365'],
            'start_date_time'               => ['nullable', 'date'],
            'end_date_time'                 => ['nullable', 'date', 'after_or_equal:start_date_time'],
            'is_full_day_event'             => ['boolean'],
            'is_recurring'                  => ['boolean'],
            'experience_summary'            => ['nullable', 'string', 'max:2000'],
            'experience_overview'           => ['nullable', 'string'],
            'experience_details'            => ['nullable', 'string'],
            'experience_highlights'         => ['nullable', 'string'],
            'language_spoken'               => ['nullable', 'string', 'max:100'],
            'skill_level'                   => ['nullable', 'string', 'max:100'],
            'food'                          => ['nullable', 'string', 'max:100'],
            'food_overview'                 => ['nullable', 'string'],
            'schedule'                      => ['nullable', 'string'],
            'styles_taught'                 => ['nullable', 'string', 'max:255'],
            'area'                          => ['nullable', 'string', 'max:255'],
            'atmosphere'                    => ['nullable', 'string', 'max:255'],
            'what_is_included'              => ['nullable', 'string'],
            'what_is_not_included'          => ['nullable', 'string'],
            'how_to_get_here'               => ['nullable', 'string'],
            'booking_info'                  => ['nullable', 'string'],
            'cancellation_policy'           => ['nullable', 'string'],
            'deposit_policy'                => ['boolean'],
            'deposit_amount'                => ['nullable', 'numeric', 'min:0', 'required_if:deposit_policy,true'],
            'cancellation_policy_condition' => ['boolean'],
            'cancellation_policy_days'      => ['nullable', 'integer', 'min:1', 'required_if:cancellation_policy_condition,true'],
            'rest_of_payment'               => ['boolean'],
            'rest_of_payment_days'          => ['nullable', 'integer', 'min:1'],
            'commission'                    => ['nullable', 'numeric', 'min:0', 'max:100'],
            'tax'                           => ['nullable', 'string', 'max:100'],
            'is_bookable'                   => ['boolean'],
            'is_draft'                      => ['boolean'],
            'display_on_home'               => ['boolean'],
            'featured_experiences'          => ['boolean'],
            'luxury_retreats'               => ['boolean'],
            'weekend_retreats'              => ['boolean'],
            'couple_retreats'               => ['boolean'],
            'budget_retreats'               => ['boolean'],
            'eirly_bird_before_days'        => ['nullable', 'integer', 'min:1', 'max:365'],
            'eirly_bird_discount'           => ['nullable', 'numeric', 'min:0', 'max:100'],
            'eirly_bird_discount_type'      => ['nullable', 'in:percentage,fixed'],
            'offer_start_date'              => ['nullable', 'date'],
            'offer_end_date'                => ['nullable', 'date', 'after_or_equal:offer_start_date'],
            'offer_discount'                => ['nullable', 'numeric', 'min:0', 'max:100'],
            'offer_discount_type'           => ['nullable', 'in:percentage,fixed'],
            'meta_title'                    => ['nullable', 'string', 'max:160'],
            'meta_description'              => ['nullable', 'string', 'max:320'],
            'keywords'                      => ['nullable', 'string'],
            'tags'                          => ['nullable', 'string', 'max:500'],
            'video_url'                     => ['nullable', 'url', 'max:500'],
            'website'                       => ['nullable', 'url', 'max:250'],
            'ref_link'                      => ['nullable', 'url', 'max:250'],
        ];
    }

    public function messages(): array
    {
        return [
            'deposit_amount.required_if'         => 'Deposit amount is required when deposit policy is enabled.',
            'cancellation_policy_days.required_if'=> 'Cancellation days is required when cancellation policy is enabled.',
            'end_date_time.after_or_equal'        => 'End date must be after or equal to start date.',
        ];
    }
}
