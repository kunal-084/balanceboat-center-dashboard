<?php

namespace App\Http\Requests\Retreat;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRetreatRequest extends StoreRetreatRequest
{
    public function authorize(): bool
    {
        $experience = $this->route('retreat');
        return $this->user()->can('update', $experience);
    }

    public function rules(): array
    {
        $experienceId = $this->route('retreat')?->id;
        $rules        = parent::rules();

        $rules['name']                = ['sometimes', 'string', 'max:200'];
        $rules['price_per_person']    = ['sometimes', 'numeric', 'min:0'];
        $rules['currency']            = ['sometimes', 'string', 'size:3'];
        $rules['slug']                = ['nullable', 'string', 'max:220', "unique:experiences,slug,{$experienceId}"];

        return $rules;
    }
}
