<?php

namespace App\Http\Requests\Automation;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAutomationRuleRequest extends StoreAutomationRuleRequest
{
    public function rules(): array
    {
        $rules = parent::rules();
        $rules['name']           = ['sometimes', 'string', 'max:200'];
        $rules['trigger_event']  = ['sometimes', 'string', 'max:200'];
        $rules['action_type']    = ['sometimes', 'in:email,whatsapp,sms,webhook,internal_task'];
        $rules['delay_unit']     = ['sometimes', 'in:minutes,hours,days'];
        $rules['delay_value']    = ['sometimes', 'integer', 'min:0'];
        return $rules;
    }
}
