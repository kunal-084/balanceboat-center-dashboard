<?php

namespace App\Http\Requests\Automation;

use Illuminate\Foundation\Http\FormRequest;

class StoreAutomationRuleRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'                  => ['required', 'string', 'max:200'],
            'description'           => ['nullable', 'string', 'max:500'],
            'trigger_event'         => ['required', 'string', 'max:200'],
            'trigger_conditions'    => ['nullable', 'array'],
            'action_type'           => ['required', 'in:email,whatsapp,sms,webhook,internal_task'],
            'email_template_id'     => ['nullable', 'integer', 'exists:email_templates,id'],
            'whatsapp_template_id'  => ['nullable', 'integer', 'exists:whatsapp_templates,id'],
            'action_config'         => ['nullable', 'array'],
            'delay_unit'            => ['required', 'in:minutes,hours,days'],
            'delay_value'           => ['required', 'integer', 'min:0'],
            'is_active'             => ['boolean'],
        ];
    }
}
