<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

final class PricingDTO
{
    public function __construct(
        public readonly int     $experienceId,
        public readonly float   $basePrice,
        public readonly string  $currency,
        public readonly int     $guestCount        = 1,
        public readonly int     $durationNights    = 1,
        public readonly float   $occupancyRate     = 0,
        public readonly ?int    $daysUntilStart    = null,
        public readonly ?Carbon $startDate         = null,
        public readonly ?string $promoCode         = null,
        public readonly ?int    $accommodationId   = null,
    ) {}

    public static function fromBookingDTO(BookingDTO $booking, float $occupancyRate = 0): self
    {
        return new self(
            experienceId:  $booking->experienceId,
            basePrice:     $booking->basePrice,
            currency:      $booking->currency,
            guestCount:    $booking->guestCount,
            occupancyRate: $occupancyRate,
            daysUntilStart:$booking->getDaysUntilStart(),
            startDate:     Carbon::parse($booking->arrivalDate),
            promoCode:     $booking->promoCode,
            accommodationId: $booking->accommodationId,
        );
    }
}
