<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

final class RetreatDTO
{
    public function __construct(
        public readonly int    $centerId,
        public readonly string $name,
        public readonly string $currency,
        public readonly float  $pricePerPerson,
        public readonly ?string $slug             = null,
        public readonly ?string $summary          = null,
        public readonly ?string $overview         = null,
        public readonly ?string $details          = null,
        public readonly ?int    $batchSize        = null,
        public readonly ?int    $durationNights   = null,
        public readonly ?string $startDateTime    = null,
        public readonly ?string $endDateTime      = null,
        public readonly array  $categoryIds       = [],
        public readonly array  $teacherIds        = [],
        public readonly bool   $isDraft           = true,
        public readonly ?string $food             = null,
        public readonly ?string $skillLevel       = null,
        public readonly ?string $language         = 'English',
        public readonly array  $tags             = [],
        public readonly ?string $cancellationPolicy = null,
        public readonly bool   $depositPolicy     = false,
        public readonly ?float $depositAmount     = null,
        public readonly ?int   $earlyBirdDays     = null,
        public readonly ?float $earlyBirdDiscount = null,
        public readonly ?string $earlyBirdDiscountType = null,
    ) {}

    public static function fromRequest(Request $request, int $centerId): self
    {
        return new self(
            centerId:          $centerId,
            name:              $request->name,
            currency:          $request->currency ?? 'USD',
            pricePerPerson:    (float) $request->price_per_person,
            slug:              $request->slug,
            summary:           $request->experience_summary,
            overview:          $request->experience_overview,
            details:           $request->experience_details,
            batchSize:         $request->batch_size ? (int) $request->batch_size : null,
            durationNights:    $request->duration_nights ? (int) $request->duration_nights : null,
            startDateTime:     $request->start_date_time,
            endDateTime:       $request->end_date_time,
            categoryIds:       $request->category_ids ?? [],
            teacherIds:        $request->teacher_ids ?? [],
            isDraft:           (bool) $request->boolean('is_draft', true),
            food:              $request->food,
            skillLevel:        $request->skill_level,
            language:          $request->language_spoken ?? 'English',
            tags:              $request->tags ?? [],
            cancellationPolicy:$request->cancellation_policy,
            depositPolicy:     $request->boolean('deposit_policy', false),
            depositAmount:     $request->deposit_amount ? (float) $request->deposit_amount : null,
            earlyBirdDays:     $request->eirly_bird_before_days ? (int) $request->eirly_bird_before_days : null,
            earlyBirdDiscount: $request->eirly_bird_discount ? (float) $request->eirly_bird_discount : null,
            earlyBirdDiscountType: $request->eirly_bird_discount_type,
        );
    }

    public function toArray(): array
    {
        return [
            'center_id'            => $this->centerId,
            'name'                 => $this->name,
            'currency'             => $this->currency,
            'price_per_person'     => $this->pricePerPerson,
            'slug'                 => $this->slug,
            'experience_summary'   => $this->summary,
            'experience_overview'  => $this->overview,
            'experience_details'   => $this->details,
            'batch_size'           => $this->batchSize,
            'duration_nights'      => $this->durationNights,
            'duration'             => $this->durationNights ? "{$this->durationNights} nights" : null,
            'start_date_time'      => $this->startDateTime,
            'end_date_time'        => $this->endDateTime,
            'is_draft'             => $this->isDraft,
            'publish_status'       => $this->isDraft ? 'draft' : 'published',
            'food'                 => $this->food,
            'skill_level'          => $this->skillLevel,
            'language_spoken'      => $this->language,
            'tags'                 => implode(',', $this->tags),
            'cancellation_policy'  => $this->cancellationPolicy,
            'deposit_policy'       => $this->depositPolicy,
            'deposit_amount'       => $this->depositAmount,
            'eirly_bird_before_days' => $this->earlyBirdDays,
            'eirly_bird_discount'  => $this->earlyBirdDiscount,
            'eirly_bird_discount_type' => $this->earlyBirdDiscountType,
        ];
    }
}
