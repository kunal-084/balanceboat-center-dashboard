<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

final class BookingDTO
{
    public function __construct(
        public readonly int    $experienceId,
        public readonly int    $centerId,
        public readonly int    $guestCount,
        public readonly string $arrivalDate,
        public readonly string $currency,
        public readonly float  $basePrice,
        public readonly ?int   $accommodationId = null,
        public readonly ?int   $userId          = null,
        public readonly ?string $promoCode       = null,
        public readonly ?string $startDateTime   = null,
        public readonly ?string $endDateTime      = null,
        public readonly array  $guestInfo        = [],
    ) {}

    public static function fromRequest(Request $request, int $centerId): self
    {
        return new self(
            experienceId:   (int) $request->experience_id,
            centerId:       $centerId,
            guestCount:     (int) $request->guest_count,
            arrivalDate:    $request->arrival_date,
            currency:       $request->currency ?? 'USD',
            basePrice:      (float) $request->base_price,
            accommodationId:$request->accommodation_id ? (int) $request->accommodation_id : null,
            userId:         auth()->id(),
            promoCode:      $request->promo_code,
            startDateTime:  $request->start_date_time,
            endDateTime:    $request->end_date_time,
            guestInfo:      $request->guest_info ?? [],
        );
    }

    public function getDaysUntilStart(): int
    {
        return Carbon::parse($this->arrivalDate)->diffInDays(now());
    }
}
