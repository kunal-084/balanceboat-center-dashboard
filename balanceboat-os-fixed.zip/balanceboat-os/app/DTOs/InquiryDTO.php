<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

final class InquiryDTO
{
    public function __construct(
        public readonly string  $name,
        public readonly string  $email,
        public readonly ?string $lastname     = null,
        public readonly ?string $phone        = null,
        public readonly bool    $whatsapp     = false,
        public readonly ?string $message      = null,
        public readonly ?string $retreatType  = null,
        public readonly ?string $destination  = null,
        public readonly ?string $budget       = null,
        public readonly ?string $timeline     = null,
        public readonly ?int    $experienceId = null,
        public readonly ?int    $centerId     = null,
        public readonly ?string $source       = null,
        public readonly ?string $refUrl       = null,
        public readonly ?string $utmSource    = null,
        public readonly ?string $utmMedium    = null,
        public readonly ?string $utmCampaign  = null,
        public readonly ?int    $groupSize    = null,
    ) {}

    public static function fromRequest(Request $request): self
    {
        return new self(
            name:         $request->name,
            email:        $request->email,
            lastname:     $request->lastname,
            phone:        $request->phone,
            whatsapp:     $request->boolean('whatsapp', false),
            message:      $request->message,
            retreatType:  $request->retreat_type,
            destination:  $request->destination,
            budget:       $request->budget,
            timeline:     $request->timeline,
            experienceId: $request->experience_id ? (int) $request->experience_id : null,
            centerId:     $request->center_id ? (int) $request->center_id : null,
            source:       $request->source,
            refUrl:       $request->ref_url ?? $request->header('Referer'),
            utmSource:    $request->utm_source,
            utmMedium:    $request->utm_medium,
            utmCampaign:  $request->utm_campaign,
            groupSize:    $request->group_size ? (int) $request->group_size : null,
        );
    }
}
