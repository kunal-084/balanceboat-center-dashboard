<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

final class AiContentDTO
{
    public function __construct(
        public readonly string $type,
        public readonly string $retreatType,
        public readonly int    $centerId,
        public readonly ?int   $experienceId  = null,
        public readonly ?string $location     = null,
        public readonly ?int   $durationNights= null,
        public readonly ?string $targetAudience= null,
        public readonly ?string $additionalContext = null,
        public readonly string $language      = 'en',
        public readonly string $tone          = 'luxury',
    ) {}
}
