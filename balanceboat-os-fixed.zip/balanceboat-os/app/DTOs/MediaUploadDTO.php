<?php

namespace App\DTOs;

use Carbon\Carbon;
use Illuminate\Http\Request;

final class MediaUploadDTO
{
    public function __construct(
        public readonly int    $centerId,
        public readonly string $disk,
        public readonly string $collection,
        public readonly ?int   $folderId          = null,
        public readonly ?string $mediableType     = null,
        public readonly ?int   $mediableId        = null,
        public readonly ?string $altText          = null,
        public readonly ?string $caption          = null,
        public readonly ?string $category         = null,
        public readonly bool   $generateThumbs    = true,
    ) {}
}
