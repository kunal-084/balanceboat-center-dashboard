<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class EmailTemplate extends Model
{
    protected $fillable = [
        'center_id', 'name', 'slug', 'subject', 'body_html', 'body_text',
        'variables', 'category', 'is_active', 'is_system',
    ];
    protected $casts = ['variables' => 'array', 'is_active' => 'boolean', 'is_system' => 'boolean'];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function render(array $data): string
    {
        $html = $this->body_html;
        foreach ($data as $key => $value) {
            $html = str_replace("{{$key}}", $value, $html);
        }
        return $html;
    }
}
