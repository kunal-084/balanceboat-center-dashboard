<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class ReviewResponse extends Model
{
    protected $fillable = ['review_id', 'responded_by', 'response', 'responded_at'];
    protected $casts = ['responded_at' => 'datetime'];
    public function review(): BelongsTo { return $this->belongsTo(CenterReview::class, 'review_id'); }
}
