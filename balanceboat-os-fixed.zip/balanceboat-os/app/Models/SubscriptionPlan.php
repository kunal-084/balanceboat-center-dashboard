<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class SubscriptionPlan extends Model
{
    protected $fillable = [
        'name', 'slug', 'description', 'monthly_price', 'annual_price',
        'commission_rate', 'max_retreats', 'max_staff', 'max_accommodations',
        'ai_enabled', 'analytics_enabled', 'automation_enabled',
        'whatsapp_enabled', 'api_access', 'custom_domain', 'priority_support',
        'features', 'trial_days', 'is_active', 'sort_order',
    ];
    protected $casts = [
        'features'           => 'array',
        'ai_enabled'         => 'boolean',
        'analytics_enabled'  => 'boolean',
        'automation_enabled' => 'boolean',
        'whatsapp_enabled'   => 'boolean',
        'api_access'         => 'boolean',
        'custom_domain'      => 'boolean',
        'priority_support'   => 'boolean',
        'is_active'          => 'boolean',
        'monthly_price'      => 'decimal:2',
        'annual_price'       => 'decimal:2',
        'commission_rate'    => 'decimal:2',
    ];
    public function centers(): HasMany { return $this->hasMany(Center::class, 'subscription_plan_id'); }
}
