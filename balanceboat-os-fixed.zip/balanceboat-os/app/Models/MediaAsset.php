<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class MediaAsset extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'center_id', 'folder_id', 'uploaded_by', 'mediable_type', 'mediable_id',
        'collection', 'filename', 'original_filename', 'disk', 'path', 'url', 'cdn_url',
        'mime_type', 'media_type', 'size_bytes', 'width', 'height', 'duration_seconds',
        'alt_text', 'caption', 'category', 'sort_order', 'is_featured',
        'metadata', 'thumbnails',
    ];
    protected $casts = [
        'is_featured' => 'boolean',
        'metadata'    => 'array',
        'thumbnails'  => 'array',
        'deleted_at'  => 'datetime',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function getPublicUrlAttribute(): string { return $this->cdn_url ?? $this->url ?? ''; }
    public function getThumbnailUrlAttribute(): string
    {
        $thumbs = $this->thumbnails ?? [];
        return $thumbs['medium'] ?? $thumbs['small'] ?? $this->public_url;
    }
    public function scopeImages($query) { return $query->where('media_type', 'image'); }
    public function scopeVideos($query) { return $query->where('media_type', 'video'); }
    public function scopeFeatured($query) { return $query->where('is_featured', true); }
}
