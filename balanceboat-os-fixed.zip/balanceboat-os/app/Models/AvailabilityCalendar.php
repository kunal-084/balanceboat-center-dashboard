<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class AvailabilityCalendar extends Model
{
    protected $fillable = [
        'experience_id', 'accommodation_id', 'calendar_date',
        'total_units', 'available_units', 'booked_units', 'blocked_units',
        'status', 'override_price', 'block_reason',
    ];
    protected $casts = [
        'calendar_date'  => 'date',
        'override_price' => 'decimal:2',
    ];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function scopeAvailable($query) { return $query->where('status', 'open')->where('available_units', '>', 0); }
    public function scopeForDateRange($query, string $from, string $to) { return $query->whereBetween('calendar_date', [$from, $to]); }
}
