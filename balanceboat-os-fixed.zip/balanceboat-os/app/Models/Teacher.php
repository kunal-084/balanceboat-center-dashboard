<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Teacher extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id', 'name', 'slug', 'meta_title', 'keywords', 'meta_description',
        'short_description', 'expertise_id', 'certificate_id', 'teaching_since',
        'complete_bio', 'currently_working_with',
        'hourly_rate', 'rate_currency', 'languages', 'nationality',
        'website_url', 'instagram_url', 'facebook_url', 'youtube_url',
        'status', 'is_featured', 'is_verified', 'verified_at',
        'average_rating', 'total_reviews',
        'profile_image_title', 'profile_image_url', 'profile_image_path',
        'image_gallery',
    ];

    protected $casts = [
        'languages'    => 'array',
        'is_featured'  => 'boolean',
        'is_verified'  => 'boolean',
        'verified_at'  => 'datetime',
        'deleted_at'   => 'datetime',
        'hourly_rate'  => 'decimal:2',
        'average_rating' => 'decimal:1',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->slug ??= Teacher::generateUniqueSlug($m->name));
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function imageGallery(): HasMany
    {
        return $this->hasMany(TeacherImageGallery::class, 'teacher_id');
    }

    public function experiences(): BelongsToMany
    {
        return $this->belongsToMany(Experience::class, 'experience_teachers', 'teacher_id', 'experience_id')
                    ->withTimestamps();
    }

    public function centers(): BelongsToMany
    {
        return $this->belongsToMany(Center::class, 'center_teachers', 'teacher_id', 'center_id')
                    ->withTimestamps();
    }

    public function mediaAssets(): MorphMany
    {
        return $this->morphMany(MediaAsset::class, 'mediable');
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }
    public function scopeFeatured($query) { return $query->where('is_featured', true); }
    public function scopeVerified($query) { return $query->where('is_verified', true); }

    public function getFullYearsExperienceAttribute(): int
    {
        return $this->teaching_since ? now()->year - $this->teaching_since : 0;
    }

    public static function generateUniqueSlug(string $name): string
    {
        $base = Str::slug($name); $slug = $base; $i = 1;
        while (static::where('slug', $slug)->exists()) { $slug = "{$base}-{$i}"; $i++; }
        return $slug;
    }
}
