<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class RetreatFaq extends Model
{
    protected $fillable = ['experience_id', 'question', 'answer', 'sort_order', 'is_published'];
    protected $casts = ['is_published' => 'boolean'];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
}
