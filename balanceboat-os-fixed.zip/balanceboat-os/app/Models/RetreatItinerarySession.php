<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class RetreatItinerarySession extends Model
{
    protected $fillable = [
        'day_id', 'start_time', 'end_time', 'activity', 'description',
        'session_type', 'location', 'facilitator', 'is_optional', 'sort_order',
    ];
    protected $casts = ['is_optional' => 'boolean'];
    public function day(): BelongsTo { return $this->belongsTo(RetreatItineraryDay::class, 'day_id'); }
}
