<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class AiRecommendation extends Model
{
    use HasFactory;

    protected $fillable = [
        'center_id', 'experience_id', 'type', 'title', 'recommendation',
        'confidence_score', 'estimated_impact_pct', 'supporting_data',
        'action_payload', 'status', 'applied_at', 'applied_by',
        'dismissed_at', 'dismissed_by', 'expires_at', 'ai_model',
    ];

    protected $casts = [
        'supporting_data'     => 'array',
        'action_payload'      => 'array',
        'applied_at'          => 'datetime',
        'dismissed_at'        => 'datetime',
        'expires_at'          => 'datetime',
        'confidence_score'    => 'decimal:2',
        'estimated_impact_pct'=> 'decimal:2',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }

    public function scopeActive($query) { return $query->where('status', 'active')->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now())); }
    public function scopeForCenter($query, int $centerId) { return $query->where('center_id', $centerId); }
    public function scopeOfType($query, string $type) { return $query->where('type', $type); }

    public function apply(int $userId): void
    {
        $this->update(['status' => 'applied', 'applied_at' => now(), 'applied_by' => $userId]);
    }

    public function dismiss(int $userId): void
    {
        $this->update(['status' => 'dismissed', 'dismissed_at' => now(), 'dismissed_by' => $userId]);
    }
}
