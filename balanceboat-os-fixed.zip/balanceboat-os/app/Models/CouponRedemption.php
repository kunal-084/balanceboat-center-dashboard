<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class CouponRedemption extends Model
{
    protected $fillable = ['promo_code_id', 'booking_id', 'user_id', 'original_amount', 'discount_applied', 'final_amount'];
    protected $casts = ['original_amount' => 'decimal:2', 'discount_applied' => 'decimal:2', 'final_amount' => 'decimal:2'];
    public function promoCode(): BelongsTo { return $this->belongsTo(PromoCode::class); }
    public function booking(): BelongsTo { return $this->belongsTo(Booking::class); }
}
