<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class PayoutRequest extends Model
{
    protected $fillable = [
        'center_id', 'reference', 'gross_amount', 'commission_deducted',
        'tax_deducted', 'net_payout', 'currency', 'status', 'payment_method',
        'bank_details', 'transaction_reference', 'admin_notes', 'processed_by',
        'requested_at', 'processed_at', 'paid_at', 'period_from', 'period_to',
        'included_booking_ids',
    ];
    protected $casts = [
        'bank_details'        => 'array',
        'included_booking_ids'=> 'array',
        'gross_amount'        => 'decimal:2',
        'commission_deducted' => 'decimal:2',
        'tax_deducted'        => 'decimal:2',
        'net_payout'          => 'decimal:2',
        'requested_at'        => 'datetime',
        'processed_at'        => 'datetime',
        'paid_at'             => 'datetime',
        'period_from'         => 'date',
        'period_to'           => 'date',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function scopePending($query) { return $query->where('status', 'pending'); }
}
