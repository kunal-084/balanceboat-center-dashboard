<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class RetreatBenefit extends Model
{
    protected $fillable = ['experience_id', 'benefit', 'icon', 'category', 'sort_order'];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
}
