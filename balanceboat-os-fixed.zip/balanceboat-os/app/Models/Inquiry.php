<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Inquiry extends Model
{
    use HasFactory, SoftDeletes;

    const PIPELINE_STAGES = ['new', 'contacted', 'qualified', 'proposal', 'negotiating', 'won', 'lost'];

    const STAGE_COLORS = [
        'new'         => 'slate',
        'contacted'   => 'blue',
        'qualified'   => 'indigo',
        'proposal'    => 'amber',
        'negotiating' => 'orange',
        'won'         => 'emerald',
        'lost'        => 'red',
    ];

    protected $fillable = [
        'name', 'lastname', 'email', 'country_code', 'phone',
        'message', 'retreat_type', 'destination', 'budget', 'timeline',
        'whatsapp', 'conversation_id', 'source', 'experience_id', 'ref_url', 'note',
        'whatsapp_verified', 'email_verified', 'instagram_verified',
        'pipeline_stage', 'assigned_to', 'center_id', 'converted_booking_id',
        'follow_up_at', 'lost_reason', 'last_contacted_at', 'contact_attempts',
        'group_size', 'utm_source', 'utm_medium', 'utm_campaign',
    ];

    protected $casts = [
        'whatsapp'       => 'boolean',
        'follow_up_at'   => 'datetime',
        'last_contacted_at' => 'datetime',
        'deleted_at'     => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->conversation_id ??= (string) Str::uuid());
    }

    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function assignedTo(): BelongsTo { return $this->belongsTo(User::class, 'assigned_to'); }
    public function convertedBooking(): BelongsTo { return $this->belongsTo(Booking::class, 'converted_booking_id'); }

    public function scopeForStage($query, string $stage) { return $query->where('pipeline_stage', $stage); }
    public function scopeForCenter($query, int $centerId) { return $query->where('center_id', $centerId); }
    public function scopeOpen($query) { return $query->whereNotIn('pipeline_stage', ['won', 'lost']); }

    public function getFullNameAttribute(): string { return trim("{$this->name} {$this->lastname}"); }
    public function getStageColorAttribute(): string { return self::STAGE_COLORS[$this->pipeline_stage] ?? 'slate'; }
    public function getIsConvertedAttribute(): bool { return $this->pipeline_stage === 'won' && $this->converted_booking_id; }

    public function advancePipeline(): bool
    {
        $index = array_search($this->pipeline_stage, self::PIPELINE_STAGES);
        if ($index === false || $index >= count(self::PIPELINE_STAGES) - 3) {
            return false;
        }
        $this->update([
            'pipeline_stage'   => self::PIPELINE_STAGES[$index + 1],
            'last_contacted_at'=> now(),
            'contact_attempts' => $this->contact_attempts + 1,
        ]);
        return true;
    }
}
