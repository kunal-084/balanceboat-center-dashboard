<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class PromoCode extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'center_id', 'created_by', 'code', 'description',
        'discount_type', 'discount_value', 'min_booking_amount', 'max_discount_cap',
        'max_uses', 'max_uses_per_user', 'used_count',
        'valid_from', 'valid_until',
        'applies_to_all', 'applicable_experience_ids', 'applicable_category_ids',
        'is_active',
    ];

    protected $casts = [
        'valid_from'               => 'date',
        'valid_until'              => 'date',
        'applies_to_all'           => 'boolean',
        'is_active'                => 'boolean',
        'applicable_experience_ids'=> 'array',
        'applicable_category_ids'  => 'array',
        'discount_value'           => 'decimal:2',
        'min_booking_amount'       => 'decimal:2',
        'max_discount_cap'         => 'decimal:2',
        'deleted_at'               => 'datetime',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function redemptions(): HasMany { return $this->hasMany(CouponRedemption::class, 'promo_code_id'); }

    public function scopeActive($query)
    {
        return $query->where('is_active', true)
            ->where(fn($q) => $q->whereNull('valid_from')->orWhere('valid_from', '<=', today()))
            ->where(fn($q) => $q->whereNull('valid_until')->orWhere('valid_until', '>=', today()));
    }

    public function getIsExpiredAttribute(): bool
    {
        return $this->valid_until && $this->valid_until->isPast();
    }

    public function getIsExhaustedAttribute(): bool
    {
        return $this->max_uses && $this->used_count >= $this->max_uses;
    }

    public function getIsUsableAttribute(): bool
    {
        return $this->is_active && ! $this->is_expired && ! $this->is_exhausted;
    }

    public function calculateDiscount(float $amount): float
    {
        if (! $this->is_usable) return 0;
        if ($this->min_booking_amount && $amount < $this->min_booking_amount) return 0;

        $discount = $this->discount_type === 'percentage'
            ? $amount * ($this->discount_value / 100)
            : $this->discount_value;

        if ($this->max_discount_cap) {
            $discount = min($discount, (float) $this->max_discount_cap);
        }

        return min($discount, $amount);
    }

    public function incrementUsage(): void
    {
        $this->increment('used_count');
    }
}
