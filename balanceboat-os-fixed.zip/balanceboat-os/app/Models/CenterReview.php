<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class CenterReview extends Model
{
    protected $fillable = [
        'center_id', 'experience_id', 'booking_id', 'user_id',
        'reviewer_name', 'reviewer_email', 'reviewer_country',
        'overall_rating', 'accommodation_rating', 'food_rating',
        'teacher_rating', 'value_rating', 'cleanliness_rating',
        'title', 'body', 'status', 'rejection_reason',
        'source', 'external_id', 'reviewed_at', 'approved_at', 'approved_by',
        'is_verified_guest', 'is_featured',
    ];
    protected $casts = [
        'overall_rating'      => 'decimal:1',
        'accommodation_rating'=> 'decimal:1',
        'food_rating'         => 'decimal:1',
        'teacher_rating'      => 'decimal:1',
        'value_rating'        => 'decimal:1',
        'cleanliness_rating'  => 'decimal:1',
        'is_verified_guest'   => 'boolean',
        'is_featured'         => 'boolean',
        'reviewed_at'         => 'datetime',
        'approved_at'         => 'datetime',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function response(): HasOne { return $this->hasOne(ReviewResponse::class, 'review_id'); }
    public function scopeApproved($query) { return $query->where('status', 'approved'); }
    public function scopePending($query) { return $query->where('status', 'pending'); }
    public function approve(int $userId): void { $this->update(['status' => 'approved', 'approved_at' => now(), 'approved_by' => $userId]); }
    public function reject(string $reason, int $userId): void { $this->update(['status' => 'rejected', 'rejection_reason' => $reason, 'approved_by' => $userId]); }
}
