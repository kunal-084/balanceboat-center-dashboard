<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class AutomationExecution extends Model
{
    protected $fillable = [
        'automation_rule_id', 'trigger_event', 'trigger_data',
        'status', 'error_message', 'result_data', 'scheduled_at', 'executed_at',
    ];
    protected $casts = [
        'trigger_data'  => 'array',
        'result_data'   => 'array',
        'scheduled_at'  => 'datetime',
        'executed_at'   => 'datetime',
    ];
    public function rule(): BelongsTo { return $this->belongsTo(AutomationRule::class, 'automation_rule_id'); }
}
