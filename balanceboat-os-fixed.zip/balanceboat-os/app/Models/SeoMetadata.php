<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class SeoMetadata extends Model
{
    protected $fillable = [
        'seoable_type', 'seoable_id', 'title', 'description', 'keywords',
        'og_title', 'og_description', 'og_image',
        'twitter_title', 'twitter_description', 'twitter_image',
        'canonical_url', 'robots', 'schema_org',
    ];
    protected $casts = ['schema_org' => 'array'];
}
