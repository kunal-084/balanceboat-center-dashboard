<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class RetreatItineraryDay extends Model
{
    protected $fillable = ['experience_id', 'day_number', 'title', 'description', 'theme'];
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }
    public function sessions(): HasMany { return $this->hasMany(RetreatItinerarySession::class, 'day_id')->orderBy('sort_order'); }
}
