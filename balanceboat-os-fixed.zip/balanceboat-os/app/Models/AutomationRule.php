<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class AutomationRule extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'center_id', 'name', 'description', 'trigger_event',
        'trigger_conditions', 'action_type', 'email_template_id',
        'whatsapp_template_id', 'action_config', 'delay_unit', 'delay_value',
        'is_active', 'execution_count', 'last_executed_at',
    ];

    protected $casts = [
        'trigger_conditions' => 'array',
        'action_config'      => 'array',
        'is_active'          => 'boolean',
        'last_executed_at'   => 'datetime',
        'deleted_at'         => 'datetime',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function emailTemplate(): BelongsTo { return $this->belongsTo(EmailTemplate::class); }
    public function executions(): HasMany { return $this->hasMany(AutomationExecution::class); }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeForEvent($query, string $event) { return $query->where('trigger_event', $event); }

    public function getDelayInMinutesAttribute(): int
    {
        return match ($this->delay_unit) {
            'minutes' => (int) $this->delay_value,
            'hours'   => (int) $this->delay_value * 60,
            'days'    => (int) $this->delay_value * 1440,
            default   => 0,
        };
    }
}
