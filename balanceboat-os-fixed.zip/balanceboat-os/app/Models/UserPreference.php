<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class UserPreference extends Model
{
    protected $fillable = [
        'user_id', 'timezone', 'locale', 'currency', 'date_format',
        'email_notifications', 'whatsapp_notifications', 'sms_notifications', 'browser_notifications',
        'notification_types', 'dashboard_widgets', 'table_columns',
    ];
    protected $casts = [
        'email_notifications'   => 'boolean',
        'whatsapp_notifications'=> 'boolean',
        'sms_notifications'     => 'boolean',
        'browser_notifications' => 'boolean',
        'notification_types'    => 'array',
        'dashboard_widgets'     => 'array',
        'table_columns'         => 'array',
    ];
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
