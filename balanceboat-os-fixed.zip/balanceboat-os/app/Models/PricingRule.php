<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class PricingRule extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'center_id', 'experience_id', 'accommodation_id', 'name', 'description',
        'rule_type', 'discount_type', 'discount_value', 'min_price_cap',
        'days_before', 'occupancy_threshold_pct', 'min_duration_nights', 'min_group_size',
        'start_date', 'end_date', 'priority', 'is_stackable', 'is_active',
    ];

    protected $casts = [
        'start_date'     => 'date',
        'end_date'       => 'date',
        'is_stackable'   => 'boolean',
        'is_active'      => 'boolean',
        'discount_value' => 'decimal:2',
        'min_price_cap'  => 'decimal:2',
        'deleted_at'     => 'datetime',
    ];

    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function experience(): BelongsTo { return $this->belongsTo(Experience::class); }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeHighPriority($query) { return $query->orderBy('priority', 'desc'); }

    public function appliesToDate(\Carbon\Carbon $date): bool
    {
        if ($this->start_date && $date->lt($this->start_date)) return false;
        if ($this->end_date && $date->gt($this->end_date)) return false;
        return true;
    }

    public function appliesToOccupancy(float $occupancyPct): bool
    {
        if ($this->rule_type !== 'occupancy_based') return true;
        return $occupancyPct >= (int) $this->occupancy_threshold_pct;
    }

    public function appliesToBookingLeadTime(int $daysBeforeStart): bool
    {
        return match ($this->rule_type) {
            'early_bird'  => $daysBeforeStart >= (int) $this->days_before,
            'last_minute' => $daysBeforeStart <= (int) $this->days_before,
            default       => true,
        };
    }

    public function calculateDiscount(float $basePrice): float
    {
        $discount = $this->discount_type === 'percentage'
            ? $basePrice * ($this->discount_value / 100)
            : (float) $this->discount_value;

        if ($this->min_price_cap) {
            $discount = min($discount, $basePrice - (float) $this->min_price_cap);
        }

        return max(0, $discount);
    }
}
