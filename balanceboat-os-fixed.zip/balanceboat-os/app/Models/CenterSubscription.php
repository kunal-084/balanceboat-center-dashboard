<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, HasMany, MorphMany};
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class CenterSubscription extends Model
{
    protected $fillable = [
        'center_id', 'plan_id', 'status', 'billing_cycle',
        'trial_ends_at', 'current_period_start', 'current_period_end', 'cancelled_at',
        'stripe_subscription_id', 'stripe_customer_id', 'amount_paid', 'currency', 'metadata',
    ];
    protected $casts = [
        'trial_ends_at'        => 'datetime',
        'current_period_start' => 'datetime',
        'current_period_end'   => 'datetime',
        'cancelled_at'         => 'datetime',
        'metadata'             => 'array',
        'amount_paid'          => 'decimal:2',
    ];
    public function center(): BelongsTo { return $this->belongsTo(Center::class); }
    public function plan(): BelongsTo { return $this->belongsTo(SubscriptionPlan::class, 'plan_id'); }
    public function getIsTrialingAttribute(): bool { return $this->status === 'trialing'; }
    public function getIsActiveAttribute(): bool { return in_array($this->status, ['trialing', 'active']); }
}
