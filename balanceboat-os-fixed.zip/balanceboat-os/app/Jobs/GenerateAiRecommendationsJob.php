<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class GenerateAiRecommendationsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue   = 'ai';
    public int    $timeout = 300;

    public function __construct(public readonly Center $center) {}

    public function handle(AiService $aiService): void
    {
        $aiService->generateRecommendations($this->center);
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("GenerateAiRecommendationsJob failed", ['center_id' => $this->center->id, 'error' => $exception->getMessage()]);
    }
}
