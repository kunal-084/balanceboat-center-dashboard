<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class RefreshAvailabilityCalendarJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'default';

    public function __construct(public readonly Experience $experience, public readonly int $days = 90) {}

    public function handle(\App\Services\AvailabilityService $service): void
    {
        $service->refreshCalendarForExperience($this->experience, $this->days);
    }
}
