<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class SendWhatsAppJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int    $tries    = 3;
    public int    $backoff  = 120;
    public string $queue    = 'notifications';

    public function __construct(
        public readonly string $phone,
        public readonly string $template,
        public readonly array  $params = [],
        public readonly string $languageCode = 'en'
    ) {}

    public function handle(): void
    {
        $accessToken = config('services.whatsapp.access_token');
        $phoneId     = config('services.whatsapp.phone_number_id');

        if (! $accessToken || ! $phoneId) {
            Log::warning('WhatsApp credentials not configured.');
            return;
        }

        $response = \Illuminate\Support\Facades\Http::withToken($accessToken)
            ->post("https://graph.facebook.com/v18.0/{$phoneId}/messages", [
                'messaging_product' => 'whatsapp',
                'to'                => $this->normalizePhone($this->phone),
                'type'              => 'template',
                'template'          => [
                    'name'     => $this->template,
                    'language' => ['code' => $this->languageCode],
                    'components' => ! empty($this->params)
                        ? [[
                            'type'       => 'body',
                            'parameters' => array_map(fn($p) => ['type' => 'text', 'text' => (string)$p], $this->params),
                        ]]
                        : [],
                ],
            ]);

        if (! $response->successful()) {
            Log::error('WhatsApp send failed', [
                'phone'    => $this->phone,
                'template' => $this->template,
                'response' => $response->json(),
            ]);
            throw new \RuntimeException('WhatsApp API returned: ' . $response->status());
        }
    }

    protected function normalizePhone(string $phone): string
    {
        return preg_replace('/[^0-9]/', '', $phone);
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("SendWhatsAppJob failed", ['phone' => $this->phone, 'error' => $exception->getMessage()]);
    }
}
