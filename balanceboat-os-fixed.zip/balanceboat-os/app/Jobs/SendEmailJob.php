<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class SendEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries    = 3;
    public int $backoff  = 60;
    public string $queue = 'emails';

    public function __construct(
        public readonly string $to,
        public readonly string $name,
        public readonly string $template,
        public readonly array  $data = []
    ) {}

    public function handle(): void
    {
        // Load template from DB first, fall back to blade view
        $emailTemplate = \App\Models\EmailTemplate::where('slug', $this->template)
            ->where('is_active', true)
            ->first();

        if ($emailTemplate) {
            $htmlBody = $emailTemplate->render($this->data);
            $subject  = $this->renderString($emailTemplate->subject, $this->data);

            Mail::html($htmlBody, function ($message) use ($subject) {
                $message->to($this->to, $this->name)
                        ->subject($subject)
                        ->from(config('mail.from.address'), config('mail.from.name'));
            });
        } else {
            // Fallback to Mailable class
            $mailableClass = 'App\\Mail\\' . str_replace(' ', '', ucwords(str_replace('_', ' ', $this->template))) . 'Mail';
            if (class_exists($mailableClass)) {
                Mail::to($this->to)->send(new $mailableClass($this->data));
            } else {
                Log::warning("Email template not found: {$this->template}");
            }
        }
    }

    protected function renderString(string $template, array $data): string
    {
        foreach ($data as $key => $value) {
            $template = str_replace("{{$key}}", $value, $template);
        }
        return $template;
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("SendEmailJob failed", [
            'to'       => $this->to,
            'template' => $this->template,
            'error'    => $exception->getMessage(),
        ]);
    }
}
