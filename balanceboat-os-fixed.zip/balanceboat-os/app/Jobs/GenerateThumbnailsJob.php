<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class GenerateThumbnailsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'media';

    public function __construct(public readonly MediaAsset $asset) {}

    public function handle(): void
    {
        if ($this->asset->media_type !== 'image') return;

        $content = Storage::disk($this->asset->disk)->get($this->asset->path);
        if (! $content) {
            Log::warning("GenerateThumbnailsJob: Could not read file", ['path' => $this->asset->path]);
            return;
        }

        $image     = imagecreatefromstring($content);
        if (! $image) return;

        $thumbSizes = ['small' => 150, 'medium' => 400, 'large' => 800];
        $thumbnails = [];

        foreach ($thumbSizes as $size => $maxWidth) {
            [$thumbContent, $thumbPath] = $this->resizeImage(
                $image, $content, $maxWidth, $size, $this->asset
            );

            if ($thumbContent) {
                Storage::disk($this->asset->disk)->put($thumbPath, $thumbContent);
                $thumbnails[$size] = Storage::disk($this->asset->disk)->url($thumbPath);
            }
        }

        imagedestroy($image);

        $this->asset->update(['thumbnails' => $thumbnails]);
    }

    protected function resizeImage($image, string $content, int $maxWidth, string $size, MediaAsset $asset): array
    {
        $origWidth  = imagesx($image);
        $origHeight = imagesy($image);

        if ($origWidth <= $maxWidth) {
            $thumbPath = str_replace('/uploads/', "/thumbs/{$size}/", $asset->path);
            return [$content, $thumbPath];
        }

        $ratio     = $maxWidth / $origWidth;
        $newWidth  = $maxWidth;
        $newHeight = (int) ($origHeight * $ratio);

        $thumb = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($thumb, $image, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        ob_start();
        imagejpeg($thumb, null, 85);
        $thumbContent = ob_get_clean();
        imagedestroy($thumb);

        $thumbPath = str_replace('/uploads/', "/thumbs/{$size}/", $asset->path);
        $thumbPath = preg_replace('/\.[^.]+$/', '.jpg', $thumbPath);

        return [$thumbContent, $thumbPath];
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("GenerateThumbnailsJob failed", ['asset_id' => $this->asset->id, 'error' => $exception->getMessage()]);
    }
}
