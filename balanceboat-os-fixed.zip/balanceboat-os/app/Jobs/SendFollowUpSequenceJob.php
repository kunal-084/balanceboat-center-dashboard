<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class SendFollowUpSequenceJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'emails';
    public int    $tries = 2;

    public function __construct(
        public readonly \App\Models\Inquiry $inquiry,
        public readonly int                 $sequenceStep = 1
    ) {}

    public function handle(): void
    {
        if ($inquiry = $this->inquiry->fresh()) {
            // Don't follow up on converted or lost inquiries
            if (in_array($inquiry->pipeline_stage, ['won', 'lost'])) return;

            $templates = [
                1 => 'inquiry_follow_up_1',
                2 => 'inquiry_follow_up_2',
                3 => 'inquiry_follow_up_3',
            ];

            $template = $templates[$this->sequenceStep] ?? null;
            if (! $template || ! $inquiry->email) return;

            SendEmailJob::dispatch(
                to:       $inquiry->email,
                name:     $inquiry->name,
                template: $template,
                data:     [
                    'name'         => $inquiry->name,
                    'retreat_name' => $inquiry->experience?->name,
                ]
            )->onQueue('emails');

            $inquiry->update([
                'last_contacted_at' => now(),
                'contact_attempts'  => $inquiry->contact_attempts + 1,
            ]);

            // Queue next step if applicable
            if ($this->sequenceStep < 3) {
                self::dispatch($inquiry, $this->sequenceStep + 1)
                    ->delay(now()->addDays(3))
                    ->onQueue('emails');
            }
        }
    }
}
