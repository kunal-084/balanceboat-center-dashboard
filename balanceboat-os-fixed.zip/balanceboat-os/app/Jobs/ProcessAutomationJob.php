<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class ProcessAutomationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int    $tries    = 2;
    public string $queue    = 'automations';
    public int    $backoff  = 300;

    public function __construct(
        public readonly AutomationRule $rule,
        public readonly array          $triggerData = []
    ) {}

    public function handle(\App\Actions\Automation\DispatchAutomationAction $action): void
    {
        if (! $this->rule->is_active) {
            return;
        }

        $action->handle($this->rule, $this->triggerData);
    }

    public function failed(\Throwable $exception): void
    {
        Log::error("ProcessAutomationJob failed", [
            'rule_id' => $this->rule->id,
            'error'   => $exception->getMessage(),
        ]);
    }
}
