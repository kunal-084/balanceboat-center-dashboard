<?php

namespace App\Jobs;

use App\Models\{AutomationRule, Center, Experience, MediaAsset};
use App\Services\AiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Log, Mail, Storage};

class ProcessPayoutJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $queue = 'finance';

    public function __construct(public readonly \App\Models\PayoutRequest $payout) {}

    public function handle(): void
    {
        // Integrate with Wise / Stripe Connect for actual transfers
        // For now: mark as processing and notify admin
        $this->payout->update([
            'status'       => 'processing',
            'processed_at' => now(),
        ]);

        // Notify center owner
        $owner = $this->payout->center->owner;
        if ($owner) {
            $owner->notify(new \App\Notifications\PayoutProcessedNotification($this->payout));
        }

        Log::info("Payout processed", ['reference' => $this->payout->reference, 'amount' => $this->payout->net_payout]);
    }

    public function failed(\Throwable $exception): void
    {
        $this->payout->update(['status' => 'failed']);
        Log::error("ProcessPayoutJob failed", ['payout_id' => $this->payout->id, 'error' => $exception->getMessage()]);
    }
}
