<?php

namespace App\Events;

use App\Models\Center;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class TeamMemberInvited
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public readonly Center $center,
        public readonly string $email,
        public readonly string $role,
    ) {}
}
