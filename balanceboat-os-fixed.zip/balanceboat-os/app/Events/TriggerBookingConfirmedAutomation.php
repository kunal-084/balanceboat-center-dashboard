<?php

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class TriggerBookingConfirmedAutomation implements ShouldQueue
{
    public string $queue = 'automations';

    public function handle(BookingConfirmed $event): void
    {
        $booking  = $event->booking->load(['experience']);
        $centerId = $booking->experience?->center_id;

        if (! $centerId) return;

        $rules = AutomationRule::active()
            ->where('center_id', $centerId)
            ->forEvent('booking.confirmed')
            ->get();

        foreach ($rules as $rule) {
            ProcessAutomationJob::dispatch($rule, [
                'booking_id'       => $booking->id,
                'booking_reference'=> $booking->booking_reference,
                'guest_name'       => $booking->guest_name,
                'guest_email'      => $booking->guest_email,
                'retreat_name'     => $booking->experience?->name,
                'arrival_date'     => $booking->arrival_date?->format('Y-m-d'),
                'guest_count'      => $booking->guest_count,
                'total_amount'     => $booking->pay_amount,
                'currency'         => $booking->currency,
            ])->delay(now()->addMinutes($rule->delay_in_minutes))->onQueue('automations');
        }
    }
}
