<?php

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class SendBookingConfirmationEmail implements ShouldQueue
{
    public string $queue = 'emails';

    public function handle(BookingConfirmed $event): void
    {
        $booking = $event->booking->load(['experience.center', 'userInfo']);

        if (! $booking->userInfo?->email) return;

        SendEmailJob::dispatch(
            to:       $booking->userInfo->email,
            name:     $booking->userInfo->firstname . ' ' . $booking->userInfo->lastname,
            template: 'booking_confirmed',
            data:     [
                'booking_reference'    => $booking->booking_reference,
                'retreat_name'         => $booking->experience?->name,
                'arrival_date'         => $booking->arrival_date?->format('d M Y'),
                'guest_count'          => $booking->guest_count,
                'total_amount'         => number_format($booking->pay_amount, 2) . ' ' . $booking->currency,
                'center_name'          => $booking->experience?->center?->name,
                'center_email'         => $booking->experience?->center?->email_address,
                'center_phone'         => $booking->experience?->center?->contact_number,
                'cancellation_policy'  => $booking->experienceInfo?->cancellation_policy_days,
            ]
        )->onQueue('emails');
    }
}
