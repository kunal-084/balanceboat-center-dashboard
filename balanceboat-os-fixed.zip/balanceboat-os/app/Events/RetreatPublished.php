<?php

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RetreatPublished
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Experience $experience) {}
}
