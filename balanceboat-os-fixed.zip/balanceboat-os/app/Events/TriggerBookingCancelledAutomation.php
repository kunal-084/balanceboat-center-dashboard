<?php

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class TriggerBookingCancelledAutomation implements ShouldQueue
{
    public string $queue = 'automations';

    public function handle(BookingCancelled $event): void
    {
        $booking  = $event->booking->load(['experience']);
        $centerId = $booking->experience?->center_id;
        if (! $centerId) return;

        $rules = AutomationRule::active()
            ->where('center_id', $centerId)
            ->forEvent('booking.cancelled')
            ->get();

        foreach ($rules as $rule) {
            ProcessAutomationJob::dispatch($rule, [
                'booking_reference' => $booking->booking_reference,
                'guest_name'        => $booking->guest_name,
                'guest_email'       => $booking->guest_email,
                'retreat_name'      => $booking->experience?->name,
                'cancellation_reason' => $event->reason,
            ])->delay(now()->addMinutes($rule->delay_in_minutes))->onQueue('automations');
        }
    }
}
