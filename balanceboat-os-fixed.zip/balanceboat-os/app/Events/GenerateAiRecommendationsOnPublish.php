<?php

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class GenerateAiRecommendationsOnPublish implements ShouldQueue
{
    public string $queue = 'ai';

    public function handle(RetreatPublished $event): void
    {
        $experience = $event->experience->load('center');

        if ($experience->center?->canUseFeature('ai')) {
            GenerateAiRecommendationsJob::dispatch($experience->center)->onQueue('ai');
        }
    }
}
