<?php

namespace App\Events;

use App\Models\{Booking, Experience, Inquiry, CenterReview};
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Events\{BookingConfirmed, BookingCancelled, BookingCheckedIn, BookingCompleted, InquiryReceived, ReviewSubmitted, RetreatPublished};
use App\Jobs\{SendEmailJob, SendWhatsAppJob, ProcessAutomationJob, GenerateAiRecommendationsJob};
use App\Models\{AuditLog, AutomationRule, AvailabilityCalendar};
use App\Notifications\{BookingConfirmedNotification, InquiryReceivedNotification};
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyReviewSubmitted implements ShouldQueue
{
    public string $queue = 'notifications';

    public function handle(ReviewSubmitted $event): void
    {
        $review = $event->review->load(['center.staff']);

        $managers = $review->center?->staff()
            ->whereIn('center_role', ['owner', 'manager'])
            ->get() ?? collect();

        foreach ($managers as $manager) {
            $manager->notify(new \App\Notifications\ReviewSubmittedNotification($review));
        }
    }
}
