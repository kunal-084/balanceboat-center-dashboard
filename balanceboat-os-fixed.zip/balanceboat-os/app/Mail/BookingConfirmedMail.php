<?php

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\{Content, Envelope, Address};
use Illuminate\Queue\SerializesModels;

class BookingConfirmedMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly Booking $booking,
        public readonly string  $guestEmail,
        public readonly string  $guestName
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            from: new Address(config('mail.from.address'), config('mail.from.name')),
            to:   [new Address($this->guestEmail, $this->guestName)],
            subject: "Your Retreat Booking is Confirmed — {$this->booking->booking_reference}",
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.booking-confirmed',
            with: [
                'booking'         => $this->booking,
                'guestName'       => $this->guestName,
                'experience'      => $this->booking->experience,
                'center'          => $this->booking->experience?->center,
                'arrivalDate'     => $this->booking->arrival_date?->format('d F Y'),
                'totalAmount'     => number_format($this->booking->pay_amount, 2) . ' ' . $this->booking->currency,
                'bookingRef'      => $this->booking->booking_reference,
                'supportEmail'    => $this->booking->experience?->center?->email_address ?? config('mail.from.address'),
            ]
        );
    }

    public function attachments(): array { return []; }
}
