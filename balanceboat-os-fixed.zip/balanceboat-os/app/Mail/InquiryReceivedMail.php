<?php

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\{Content, Envelope, Address};
use Illuminate\Queue\SerializesModels;

class InquiryReceivedMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(public readonly \App\Models\Inquiry $inquiry) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            from:    new Address(config('mail.from.address'), 'BalanceBoat'),
            to:      [new Address($this->inquiry->email, $this->inquiry->name)],
            subject: 'We Received Your Retreat Inquiry — BalanceBoat'
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.inquiry-received',
            with: [
                'inquiry'      => $this->inquiry,
                'guestName'    => $this->inquiry->name,
                'retreatName'  => $this->inquiry->experience?->name ?? 'our wellness retreats',
            ]
        );
    }

    public function attachments(): array { return []; }
}
