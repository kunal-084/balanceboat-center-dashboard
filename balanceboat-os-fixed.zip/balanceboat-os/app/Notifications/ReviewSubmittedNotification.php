<?php

namespace App\Notifications;

use App\Models\{Booking, Inquiry, CenterReview, PayoutRequest};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\{Notification, Messages\MailMessage};

class ReviewSubmittedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly CenterReview $review) {}

    public function via(object $notifiable): array { return ['database', 'mail']; }

    public function toMail(object $notifiable): MailMessage
    {
        $stars = str_repeat('⭐', (int) $this->review->overall_rating);
        return (new MailMessage)
            ->subject("New {$this->review->overall_rating}★ Review Received")
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("You've received a new review: {$stars}")
            ->line("**Reviewer:** {$this->review->reviewer_name}")
            ->line("**Title:** {$this->review->title}")
            ->line("\"" . substr($this->review->body, 0, 300) . "...\"")
            ->action('View & Respond', route('reviews.index'))
            ->line('Please review and respond within 48 hours.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'          => 'review_submitted',
            'review_id'     => $this->review->id,
            'reviewer_name' => $this->review->reviewer_name,
            'rating'        => $this->review->overall_rating,
            'title'         => $this->review->title,
            'message'       => "New {$this->review->overall_rating}★ review from {$this->review->reviewer_name}.",
            'url'           => route('reviews.index'),
            'icon'          => 'star',
            'color'         => 'amber',
        ];
    }
}
