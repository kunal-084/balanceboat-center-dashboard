<?php

namespace App\Notifications;

use App\Models\{Booking, Inquiry, CenterReview, PayoutRequest};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\{Notification, Messages\MailMessage};

class GuestCheckedInNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Booking $booking) {}

    public function via(object $notifiable): array { return ['database']; }

    public function toArray(object $notifiable): array
    {
        return [
            'type'        => 'guest_checked_in',
            'booking_id'  => $this->booking->id,
            'guest_name'  => $this->booking->guest_name,
            'retreat_name'=> $this->booking->experience?->name,
            'message'     => "{$this->booking->guest_name} has checked in for {$this->booking->experience?->name}.",
            'url'         => route('bookings.show', $this->booking),
            'icon'        => 'log-in',
            'color'       => 'purple',
        ];
    }
}
