<?php

namespace App\Notifications;

use App\Models\{Booking, Inquiry, CenterReview, PayoutRequest};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\{Notification, Messages\MailMessage};

class PayoutProcessedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly PayoutRequest $payout) {}

    public function via(object $notifiable): array { return ['database', 'mail']; }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("Payout {$this->payout->reference} Processed — {$this->payout->currency} " . number_format($this->payout->net_payout, 2))
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("Your payout request has been processed.")
            ->line("**Reference:** {$this->payout->reference}")
            ->line("**Gross Amount:** {$this->payout->currency} " . number_format($this->payout->gross_amount, 2))
            ->line("**Commission:** {$this->payout->currency} " . number_format($this->payout->commission_deducted, 2))
            ->line("**Net Payout:** {$this->payout->currency} " . number_format($this->payout->net_payout, 2))
            ->line("**Period:** {$this->payout->period_from} to {$this->payout->period_to}")
            ->action('View Finance', route('finance.index'))
            ->line('Funds should arrive within 3-5 business days.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'      => 'payout_processed',
            'payout_id' => $this->payout->id,
            'reference' => $this->payout->reference,
            'amount'    => $this->payout->net_payout,
            'currency'  => $this->payout->currency,
            'message'   => "Payout {$this->payout->reference} of {$this->payout->currency} " . number_format($this->payout->net_payout, 2) . " has been processed.",
            'url'       => route('finance.index'),
            'icon'      => 'credit-card',
            'color'     => 'green',
        ];
    }
}
