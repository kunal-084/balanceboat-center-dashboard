<?php

namespace App\Notifications;

use App\Models\{Booking, Inquiry, CenterReview, PayoutRequest};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\{Notification, Messages\MailMessage};

class BookingConfirmedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Booking $booking) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("New Booking Confirmed — {$this->booking->booking_reference}")
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("A new booking has been confirmed for {$this->booking->experience?->name}.")
            ->line("**Booking Reference:** {$this->booking->booking_reference}")
            ->line("**Guest:** {$this->booking->guest_name}")
            ->line("**Arrival Date:** {$this->booking->arrival_date?->format('d M Y')}")
            ->line("**Guests:** {$this->booking->guest_count}")
            ->line("**Total:** {$this->booking->currency} " . number_format($this->booking->pay_amount, 2))
            ->action('View Booking', route('bookings.show', $this->booking))
            ->line('Thank you for using BalanceBoat Center OS.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'              => 'booking_confirmed',
            'booking_id'        => $this->booking->id,
            'booking_reference' => $this->booking->booking_reference,
            'guest_name'        => $this->booking->guest_name,
            'retreat_name'      => $this->booking->experience?->name,
            'arrival_date'      => $this->booking->arrival_date?->format('Y-m-d'),
            'amount'            => $this->booking->pay_amount,
            'currency'          => $this->booking->currency,
            'message'           => "New booking {$this->booking->booking_reference} confirmed for {$this->booking->experience?->name}.",
            'url'               => route('bookings.show', $this->booking),
            'icon'              => 'calendar-check',
            'color'             => 'emerald',
        ];
    }
}
