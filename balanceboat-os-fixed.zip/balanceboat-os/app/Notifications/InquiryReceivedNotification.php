<?php

namespace App\Notifications;

use App\Models\{Booking, Inquiry, CenterReview, PayoutRequest};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\{Notification, Messages\MailMessage};

class InquiryReceivedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Inquiry $inquiry) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("New Inquiry from {$this->inquiry->full_name}")
            ->greeting("Hello {$notifiable->first_name}!")
            ->line("You've received a new inquiry from **{$this->inquiry->full_name}**.")
            ->line("**Email:** {$this->inquiry->email}")
            ->line("**Retreat Type:** " . ($this->inquiry->retreat_type ?? 'Not specified'))
            ->line("**Budget:** " . ($this->inquiry->budget ?? 'Not specified'))
            ->line("**Message:** " . ($this->inquiry->message ? substr($this->inquiry->message, 0, 200) . '...' : 'No message'))
            ->action('View Inquiry', route('inquiries.show', $this->inquiry))
            ->line('Respond within 24 hours to improve your conversion rate.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'        => 'inquiry_received',
            'inquiry_id'  => $this->inquiry->id,
            'guest_name'  => $this->inquiry->full_name,
            'guest_email' => $this->inquiry->email,
            'retreat_type'=> $this->inquiry->retreat_type,
            'budget'      => $this->inquiry->budget,
            'message'     => "New inquiry from {$this->inquiry->full_name}.",
            'url'         => route('inquiries.show', $this->inquiry),
            'icon'        => 'mail',
            'color'       => 'blue',
        ];
    }
}
