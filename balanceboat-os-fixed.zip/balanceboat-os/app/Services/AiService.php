<?php

namespace App\Services;

use App\DTOs\{RetreatDTO, PricingDTO, MediaUploadDTO, AiContentDTO};
use App\Models\{
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{DB, Http, Log, Storage};
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AiService
{
    private string $model;

    public function __construct()
    {
        $this->model = config('services.openai.model', 'gpt-4o');
    }

    public function generateContent(AiContentDTO $dto): string
    {
        $prompts = [
            'title'       => "Write a compelling, SEO-optimized retreat title for a {type} retreat ({duration} nights) at {location}. Maximum 80 characters. Tone: {tone}.",
            'summary'     => "Write a 60-word retreat summary for a {type} retreat at {location}. Include the core transformation and key benefits. Tone: {tone}.",
            'description' => "Write a rich, immersive 300-word retreat description for a {type} retreat at {location} lasting {duration} nights. Include transformation benefits, unique elements, and sensory language. Audience: {audience}. Tone: {tone}.",
            'seo_title'   => "Write an SEO title (max 60 chars) for a {type} retreat at {location}.",
            'seo_desc'    => "Write an SEO meta description (max 155 chars) for a {type} retreat at {location}. Include keywords and a call to action.",
            'faqs'        => "Generate 5 frequently asked questions with concise answers for a {type} retreat at {location}. Return as JSON: [{\"question\":\"\",\"answer\":\"\"}]",
            'benefits'    => "List 8 key transformation benefits of a {type} retreat at {location}. Return as JSON array of strings.",
            'itinerary'   => "Create a sample daily schedule for a {type} retreat. Return as JSON: [{\"time\":\"06:00\",\"activity\":\"\",\"type\":\"yoga\"}]",
        ];

        $prompt = str_replace(
            ['{type}', '{location}', '{duration}', '{audience}', '{tone}'],
            [$dto->retreatType, $dto->location ?? 'a luxury wellness sanctuary', $dto->durationNights ?? 7, $dto->targetAudience ?? 'wellness seekers', $dto->tone],
            $prompts[$dto->type] ?? $prompts['description']
        );

        if ($dto->additionalContext) {
            $prompt .= "\n\nAdditional context: {$dto->additionalContext}";
        }

        return $this->callOpenAi($prompt, $dto->language);
    }

    public function generatePricingRecommendations(Experience $experience, PricingService $pricingService): array
    {
        return $pricingService->getPricingRecommendations($experience);
    }

    public function generateSeoMetadata(Experience $experience): array
    {
        $dto = new AiContentDTO(
            type:         'seo_title',
            retreatType:  $experience->experience_category ?? 'wellness',
            centerId:     $experience->center_id,
            experienceId: $experience->id,
            location:     $experience->center?->city . ', ' . $experience->center?->country,
            durationNights: (int) $experience->duration_nights,
        );

        $title = $this->generateContent($dto);
        $desc  = $this->generateContent(new AiContentDTO(...array_merge((array)$dto, ['type' => 'seo_desc'])));

        return [
            'meta_title'       => $title,
            'meta_description' => $desc,
            'keywords'         => $this->extractKeywords($experience),
        ];
    }

    public function generateRecommendations(Center $center): void
    {
        $pricingService = app(PricingService::class);

        foreach ($center->publishedExperiences as $experience) {
            $recs = $pricingService->getPricingRecommendations($experience);

            foreach ($recs as $rec) {
                AiRecommendation::updateOrCreate(
                    ['center_id' => $center->id, 'experience_id' => $experience->id, 'type' => 'pricing', 'status' => 'active'],
                    [
                        'title'           => "Pricing Recommendation: " . ucwords(str_replace('_', ' ', $rec['type'])),
                        'recommendation'  => $rec['suggestion'],
                        'confidence_score'=> 80.0,
                        'supporting_data' => ['impact' => $rec['impact'], 'priority' => $rec['priority']],
                        'expires_at'      => now()->addDays(7),
                        'ai_model'        => 'rule-engine',
                    ]
                );
            }
        }
    }

    protected function callOpenAi(string $prompt, string $language = 'en'): string
    {
        $apiKey = config('services.openai.key');

        if (! $apiKey) {
            return '[AI generation disabled. Configure OPENAI_API_KEY to enable.]';
        }

        try {
            $response = Http::withToken($apiKey)
                ->timeout(45)
                ->post('https://api.openai.com/v1/chat/completions', [
                    'model'      => $this->model,
                    'max_tokens' => 1500,
                    'messages'   => [
                        [
                            'role'    => 'system',
                            'content' => "You are an expert luxury wellness retreat copywriter. Write compelling, authentic content in {$language}. Respond only with the requested content, no preamble.",
                        ],
                        ['role' => 'user', 'content' => $prompt],
                    ],
                ]);

            return $response->json('choices.0.message.content', '');
        } catch (\Throwable $e) {
            Log::error('OpenAI API error', ['message' => $e->getMessage()]);
            return '';
        }
    }

    protected function extractKeywords(Experience $experience): string
    {
        $keywords = array_filter([
            $experience->name,
            $experience->experience_category,
            $experience->center?->city,
            $experience->center?->country,
            $experience->duration_nights ? "{$experience->duration_nights} night retreat" : null,
            $experience->food,
        ]);

        return implode(', ', $keywords);
    }
}
