<?php

namespace App\Services;

use App\DTOs\{RetreatDTO, PricingDTO, MediaUploadDTO, AiContentDTO};
use App\Models\{
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{DB, Http, Log, Storage};
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class RetreatService
{
    public function create(RetreatDTO $dto): Experience
    {
        return DB::transaction(function () use ($dto) {
            $data = $dto->toArray();
            $data['slug'] = $data['slug'] ?? Experience::generateUniqueSlug($dto->name);

            $experience = Experience::create($data);

            if ($dto->categoryIds) {
                $experience->categories()->sync($dto->categoryIds);
            }

            if ($dto->teacherIds) {
                $experience->teachers()->sync($dto->teacherIds);
            }

            return $experience->load(['categories', 'teachers']);
        });
    }

    public function update(Experience $experience, array $data): Experience
    {
        return DB::transaction(function () use ($experience, $data) {
            $categoryIds = $data['category_ids'] ?? null;
            $teacherIds  = $data['teacher_ids'] ?? null;

            unset($data['category_ids'], $data['teacher_ids']);

            $experience->update($data);

            if ($categoryIds !== null) {
                $experience->categories()->sync($categoryIds);
            }

            if ($teacherIds !== null) {
                $experience->teachers()->sync($teacherIds);
            }

            return $experience->fresh(['categories', 'teachers']);
        });
    }

    public function publish(Experience $experience): Experience
    {
        $this->assertPublishable($experience);
        $experience->publish();

        event(new \App\Events\RetreatPublished($experience));

        return $experience->fresh();
    }

    public function unpublish(Experience $experience): Experience
    {
        $experience->update([
            'is_draft'       => true,
            'is_bookable'    => false,
            'publish_status' => 'draft',
        ]);

        return $experience->fresh();
    }

    public function duplicate(Experience $experience): Experience
    {
        return $experience->duplicate();
    }

    public function getStats(int $centerId): array
    {
        return [
            'total'          => Experience::forCenter($centerId)->count(),
            'published'      => Experience::forCenter($centerId)->published()->count(),
            'draft'          => Experience::forCenter($centerId)->draft()->count(),
            'upcoming'       => Experience::forCenter($centerId)->published()->upcoming()->count(),
            'avg_occupancy'  => $this->calculateAvgOccupancy($centerId),
            'total_bookings' => \App\Models\Booking::forCenter($centerId)->count(),
        ];
    }

    protected function assertPublishable(Experience $experience): void
    {
        $errors = [];

        if (empty($experience->name))              $errors[] = 'Retreat name is required.';
        if (empty($experience->experience_summary)) $errors[] = 'Retreat summary is required.';
        if (! $experience->price_per_person)       $errors[] = 'Price per person is required.';
        if (! $experience->batch_size)             $errors[] = 'Maximum capacity is required.';
        if (! $experience->banner_image_url)       $errors[] = 'Banner image is required.';
        if ($experience->categories()->count() === 0) $errors[] = 'At least one category is required.';

        if (! empty($errors)) {
            throw ValidationException::withMessages(['publish' => $errors]);
        }
    }

    protected function calculateAvgOccupancy(int $centerId): float
    {
        $experiences = Experience::forCenter($centerId)->published()->get();

        if ($experiences->isEmpty()) return 0;

        $rates = $experiences->map(fn($e) => $e->occupancy_rate);

        return round($rates->avg(), 1);
    }
}
