<?php

namespace App\Services;

use App\DTOs\{RetreatDTO, PricingDTO, MediaUploadDTO, AiContentDTO};
use App\Models\{
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{DB, Http, Log, Storage};
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AnalyticsService
{
    public function getDashboardKpis(int $centerId, string $period = '30d'): array
    {
        $days    = (int) rtrim($period, 'd');
        $from    = now()->subDays($days);
        $prevFrom= now()->subDays($days * 2);
        $prevTo  = now()->subDays($days);

        $bookings      = fn() => \App\Models\Booking::forCenter($centerId);
        $paidBookings  = fn() => $bookings()->whereIn('stage', ['confirmed', 'checked_in', 'completed']);

        $currentRevenue = $paidBookings()->where('created_at', '>=', $from)->sum('pay_amount');
        $prevRevenue    = $paidBookings()->whereBetween('created_at', [$prevFrom, $prevTo])->sum('pay_amount');

        $currentBookings= $bookings()->where('created_at', '>=', $from)->count();
        $prevBookings   = $bookings()->whereBetween('created_at', [$prevFrom, $prevTo])->count();

        $currentInquiries = \App\Models\Inquiry::where('center_id', $centerId)->where('created_at', '>=', $from)->count();
        $prevInquiries    = \App\Models\Inquiry::where('center_id', $centerId)->whereBetween('created_at', [$prevFrom, $prevTo])->count();

        $wonInquiries     = \App\Models\Inquiry::where('center_id', $centerId)->where('pipeline_stage', 'won')->where('created_at', '>=', $from)->count();
        $conversionRate   = $currentInquiries > 0 ? round(($wonInquiries / $currentInquiries) * 100, 1) : 0;

        return [
            'revenue'         => ['current' => (float)$currentRevenue, 'previous' => (float)$prevRevenue, 'change_pct' => $this->changePct($prevRevenue, $currentRevenue)],
            'bookings'        => ['current' => $currentBookings, 'previous' => $prevBookings, 'change_pct' => $this->changePct($prevBookings, $currentBookings)],
            'inquiries'       => ['current' => $currentInquiries, 'previous' => $prevInquiries, 'change_pct' => $this->changePct($prevInquiries, $currentInquiries)],
            'conversion_rate' => ['current' => $conversionRate, 'won' => $wonInquiries],
            'avg_booking_value'=> round((float)$paidBookings()->where('created_at', '>=', $from)->avg('pay_amount'), 2),
            'occupancy_rate'  => $this->getCenterOccupancyRate($centerId),
            'today_checkins'  => $bookings()->inStage('confirmed')->where('arrival_date', today())->count(),
            'current_guests'  => $bookings()->inStage('checked_in')->count(),
        ];
    }

    public function getRevenueChart(int $centerId, string $from, string $to, string $group = 'day'): array
    {
        $query = \App\Models\Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
            ->whereBetween('created_at', [$from, "{$to} 23:59:59"]);

        $format = match ($group) {
            'week'  => '%Y-%u',
            'month' => '%Y-%m',
            default => '%Y-%m-%d',
        };

        return $query->selectRaw("DATE_FORMAT(created_at, '{$format}') as period, SUM(pay_amount) as revenue, COUNT(*) as bookings")
            ->groupBy('period')
            ->orderBy('period')
            ->get()
            ->map(fn($row) => ['period' => $row->period, 'revenue' => (float)$row->revenue, 'bookings' => $row->bookings])
            ->toArray();
    }

    public function getBookingFunnel(int $centerId, string $from, string $to): array
    {
        $inquiries = \App\Models\Inquiry::where('center_id', $centerId)->whereBetween('created_at', [$from, $to]);

        $total      = (clone $inquiries)->count();
        $contacted  = (clone $inquiries)->whereNotIn('pipeline_stage', ['new'])->count();
        $qualified  = (clone $inquiries)->whereIn('pipeline_stage', ['qualified','proposal','negotiating','won'])->count();
        $proposed   = (clone $inquiries)->whereIn('pipeline_stage', ['proposal','negotiating','won'])->count();
        $won        = (clone $inquiries)->where('pipeline_stage', 'won')->count();

        return [
            ['stage' => 'Inquiries',   'count' => $total,     'pct' => 100],
            ['stage' => 'Contacted',   'count' => $contacted,  'pct' => $total > 0 ? round($contacted/$total*100,1) : 0],
            ['stage' => 'Qualified',   'count' => $qualified,  'pct' => $total > 0 ? round($qualified/$total*100,1) : 0],
            ['stage' => 'Proposals',   'count' => $proposed,   'pct' => $total > 0 ? round($proposed/$total*100,1) : 0],
            ['stage' => 'Converted',   'count' => $won,        'pct' => $total > 0 ? round($won/$total*100,1) : 0],
        ];
    }

    public function getTopRetreats(int $centerId, int $limit = 5, string $orderBy = 'revenue'): array
    {
        return Experience::forCenter($centerId)
            ->withCount(['bookings as booking_count' => fn($q) => $q->whereIn('stage', ['confirmed','checked_in','completed'])])
            ->withSum(['bookings as total_revenue' => fn($q) => $q->whereIn('stage', ['confirmed','checked_in','completed'])], 'pay_amount')
            ->orderByDesc($orderBy === 'revenue' ? 'total_revenue' : 'booking_count')
            ->limit($limit)
            ->get()
            ->map(fn($e) => [
                'id'             => $e->id,
                'name'           => $e->name,
                'booking_count'  => $e->booking_count,
                'total_revenue'  => (float) $e->total_revenue,
                'occupancy_rate' => $e->occupancy_rate,
                'avg_rating'     => $e->computed_average_rating,
            ])
            ->toArray();
    }

    public function getOccupancyByMonth(int $centerId, int $months = 6): array
    {
        $results = [];
        for ($i = 0; $i < $months; $i++) {
            $month = now()->subMonths($i);
            $occupancy = \App\Models\Booking::forCenter($centerId)
                ->forMonth($month->year, $month->month)
                ->whereIn('stage', ['confirmed', 'checked_in', 'completed'])
                ->sum('guest_count');

            $capacity = Experience::forCenter($centerId)
                ->published()
                ->sum('batch_size');

            $results[] = [
                'period' => $month->format('Y-m'),
                'label'  => $month->format('M Y'),
                'booked' => $occupancy,
                'capacity' => $capacity,
                'rate'   => $capacity > 0 ? round($occupancy / $capacity * 100, 1) : 0,
            ];
        }

        return array_reverse($results);
    }

    protected function getCenterOccupancyRate(int $centerId): float
    {
        $capacity = Experience::forCenter($centerId)->published()->sum('batch_size');
        if (! $capacity) return 0;

        $booked = \App\Models\Booking::forCenter($centerId)
            ->whereIn('stage', ['confirmed', 'checked_in'])
            ->sum('guest_count');

        return round($booked / $capacity * 100, 1);
    }

    protected function changePct($prev, $current): float
    {
        if (! $prev) return $current > 0 ? 100 : 0;
        return round(($current - $prev) / $prev * 100, 1);
    }
}
