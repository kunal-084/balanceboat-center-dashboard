<?php

namespace App\Services;

use App\DTOs\{RetreatDTO, PricingDTO, MediaUploadDTO, AiContentDTO};
use App\Models\{
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{DB, Http, Log, Storage};
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AvailabilityService
{
    public function assertAvailable(int $experienceId, string $date, int $guestCount): void
    {
        $calendar = AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->first();

        if (! $calendar) {
            return; // No calendar record means open by default
        }

        if ($calendar->status === 'closed' || $calendar->status === 'blocked') {
            throw ValidationException::withMessages([
                'arrival_date' => 'This date is not available for booking.',
            ]);
        }

        if ($calendar->status === 'sold_out' || $calendar->available_units < $guestCount) {
            throw ValidationException::withMessages([
                'guest_count' => "Only {$calendar->available_units} spots remaining on this date.",
            ]);
        }
    }

    public function lockUnits(int $experienceId, string $date, int $units): void
    {
        AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->update([
                'booked_units'    => DB::raw("booked_units + {$units}"),
                'available_units' => DB::raw("GREATEST(0, available_units - {$units})"),
            ]);

        // Auto-update status if sold out
        $calendar = AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->first();

        if ($calendar && $calendar->available_units <= 0) {
            $calendar->update(['status' => 'sold_out']);
        }
    }

    public function releaseUnits(int $experienceId, string $date, int $units): void
    {
        AvailabilityCalendar::where('experience_id', $experienceId)
            ->where('calendar_date', $date)
            ->update([
                'booked_units'    => DB::raw("GREATEST(0, booked_units - {$units})"),
                'available_units' => DB::raw("available_units + {$units}"),
                'status'          => 'open',
            ]);
    }

    public function getCalendar(int $experienceId, Carbon $from, Carbon $to): array
    {
        $records = AvailabilityCalendar::where('experience_id', $experienceId)
            ->whereBetween('calendar_date', [$from->format('Y-m-d'), $to->format('Y-m-d')])
            ->orderBy('calendar_date')
            ->get()
            ->keyBy(fn($r) => $r->calendar_date->format('Y-m-d'));

        $experience = Experience::find($experienceId);
        $calendar   = [];
        $current    = $from->copy();

        while ($current->lte($to)) {
            $dateKey = $current->format('Y-m-d');
            $record  = $records[$dateKey] ?? null;

            $calendar[$dateKey] = [
                'date'            => $dateKey,
                'status'          => $record?->status ?? 'open',
                'available_units' => $record?->available_units ?? ($experience?->batch_size ?? 0),
                'booked_units'    => $record?->booked_units ?? 0,
                'override_price'  => $record?->override_price,
                'is_available'    => (! $record || $record->status === 'open') && ($record?->available_units ?? ($experience?->batch_size ?? 1)) > 0,
            ];

            $current->addDay();
        }

        return $calendar;
    }

    public function blockDates(int $experienceId, array $dates, string $reason = ''): void
    {
        $experience = Experience::findOrFail($experienceId);

        foreach ($dates as $date) {
            AvailabilityCalendar::updateOrCreate(
                ['experience_id' => $experienceId, 'calendar_date' => $date],
                [
                    'status'          => 'blocked',
                    'total_units'     => $experience->batch_size ?? 0,
                    'available_units' => 0,
                    'block_reason'    => $reason,
                ]
            );
        }
    }

    public function unblockDates(int $experienceId, array $dates): void
    {
        $experience = Experience::findOrFail($experienceId);

        AvailabilityCalendar::where('experience_id', $experienceId)
            ->whereIn('calendar_date', $dates)
            ->update([
                'status'          => 'open',
                'available_units' => DB::raw('total_units - booked_units'),
                'block_reason'    => null,
            ]);
    }

    public function refreshCalendarForExperience(Experience $experience, int $days = 90): void
    {
        $batchSize = $experience->batch_size ?? 0;
        $from      = today();
        $to        = today()->addDays($days);

        $existing = AvailabilityCalendar::where('experience_id', $experience->id)
            ->whereBetween('calendar_date', [$from, $to])
            ->pluck('calendar_date')
            ->map(fn($d) => $d->format('Y-m-d'))
            ->toArray();

        $current = $from->copy();

        while ($current->lte($to)) {
            $dateStr = $current->format('Y-m-d');

            if (! in_array($dateStr, $existing)) {
                AvailabilityCalendar::create([
                    'experience_id'  => $experience->id,
                    'calendar_date'  => $dateStr,
                    'total_units'    => $batchSize,
                    'available_units'=> $batchSize,
                    'booked_units'   => 0,
                    'blocked_units'  => 0,
                    'status'         => 'open',
                ]);
            }

            $current->addDay();
        }
    }
}
