<?php

namespace App\Services;

use App\DTOs\{RetreatDTO, PricingDTO, MediaUploadDTO, AiContentDTO};
use App\Models\{
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{DB, Http, Log, Storage};
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class MediaService
{
    public function upload(UploadedFile $file, MediaUploadDTO $dto): MediaAsset
    {
        $filename = Str::uuid() . '.' . $file->getClientOriginalExtension();
        $path     = "centers/{$dto->centerId}/{$dto->collection}/{$filename}";

        Storage::disk($dto->disk)->put($path, file_get_contents($file->getRealPath()));

        $url = Storage::disk($dto->disk)->url($path);

        [$width, $height] = $this->getImageDimensions($file);

        $asset = MediaAsset::create([
            'center_id'         => $dto->centerId,
            'folder_id'         => $dto->folderId,
            'uploaded_by'       => auth()->id(),
            'mediable_type'     => $dto->mediableType,
            'mediable_id'       => $dto->mediableId,
            'collection'        => $dto->collection,
            'filename'          => $filename,
            'original_filename' => $file->getClientOriginalName(),
            'disk'              => $dto->disk,
            'path'              => $path,
            'url'               => $url,
            'cdn_url'           => $this->toCdnUrl($url),
            'mime_type'         => $file->getMimeType(),
            'media_type'        => $this->classifyMimeType($file->getMimeType()),
            'size_bytes'        => $file->getSize(),
            'width'             => $width,
            'height'            => $height,
            'alt_text'          => $dto->altText,
            'caption'           => $dto->caption,
            'category'          => $dto->category,
        ]);

        if ($dto->generateThumbs && str_starts_with($file->getMimeType(), 'image/')) {
            dispatch(new \App\Jobs\GenerateThumbnailsJob($asset));
        }

        return $asset;
    }

    public function delete(MediaAsset $asset): void
    {
        Storage::disk($asset->disk)->delete($asset->path);

        if ($asset->thumbnails) {
            foreach ($asset->thumbnails as $thumbPath) {
                Storage::disk($asset->disk)->delete($thumbPath);
            }
        }

        $asset->delete();
    }

    public function reorder(array $ids): void
    {
        foreach ($ids as $order => $id) {
            MediaAsset::where('id', $id)->update(['sort_order' => $order]);
        }
    }

    protected function getImageDimensions(UploadedFile $file): array
    {
        if (! str_starts_with($file->getMimeType(), 'image/')) {
            return [null, null];
        }

        try {
            [$width, $height] = getimagesize($file->getRealPath());
            return [$width, $height];
        } catch (\Throwable) {
            return [null, null];
        }
    }

    protected function classifyMimeType(string $mime): string
    {
        if (str_starts_with($mime, 'image/')) return 'image';
        if (str_starts_with($mime, 'video/')) return 'video';
        if (str_starts_with($mime, 'audio/')) return 'audio';
        if (in_array($mime, ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])) return 'document';
        return 'other';
    }

    protected function toCdnUrl(string $url): ?string
    {
        $cdnBase = config('media.cdn_base_url');
        if (! $cdnBase) return null;

        $s3Base = rtrim(config('filesystems.disks.s3.url', ''), '/');
        return $s3Base ? str_replace($s3Base, rtrim($cdnBase, '/'), $url) : null;
    }
}
