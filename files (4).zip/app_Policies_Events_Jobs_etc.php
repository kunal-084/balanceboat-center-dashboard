<?php

// ============================================================================
// FILE: app/Policies/ExperiencePolicy.php
// ============================================================================

namespace App\Policies;

use App\Models\User;
use App\Models\Experience;

class ExperiencePolicy
{
    public function view(User $user, Experience $experience)
    {
        return $user->centers()->where('center_id', $experience->center_id)->exists();
    }

    public function create(User $user)
    {
        return $user->getPrimaryCenter() !== null;
    }

    public function update(User $user, Experience $experience)
    {
        return $user->centers()->where('center_id', $experience->center_id)->exists();
    }

    public function delete(User $user, Experience $experience)
    {
        return $user->centers()->where('center_id', $experience->center_id)->exists();
    }

    public function publish(User $user, Experience $experience)
    {
        return $this->update($user, $experience);
    }
}

// ============================================================================
// FILE: app/Policies/BookingPolicy.php
// ============================================================================

namespace App\Policies;

use App\Models\User;
use App\Models\Booking;

class BookingPolicy
{
    public function view(User $user, Booking $booking)
    {
        return $user->id === $booking->user_id ||
               $user->centers()->where('center_id', $booking->experience->center_id)->exists();
    }

    public function cancel(User $user, Booking $booking)
    {
        return $this->view($user, $booking);
    }
}

// ============================================================================
// FILE: app/Policies/CenterPolicy.php
// ============================================================================

namespace App\Policies;

use App\Models\User;
use App\Models\Center;

class CenterPolicy
{
    public function view(User $user, Center $center)
    {
        return $user->centers()->where('center_id', $center->id)->exists();
    }

    public function update(User $user, Center $center)
    {
        return $user->centers()->where('center_id', $center->id)->exists();
    }

    public function manageTeam(User $user, Center $center)
    {
        return $user->centers()->where('center_id', $center->id)->wherePivot('role', 'admin')->exists();
    }
}

// ============================================================================
// FILE: app/Events/BookingConfirmed.php
// ============================================================================

namespace App\Events;

use App\Models\Booking;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class BookingConfirmed implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public Booking $booking)
    {}

    public function broadcastOn()
    {
        return new PrivateChannel('booking.' . $this->booking->id);
    }

    public function broadcastAs()
    {
        return 'confirmed';
    }
}

// ============================================================================
// FILE: app/Events/RetreatPublished.php
// ============================================================================

namespace App\Events;

use App\Models\Experience;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RetreatPublished
{
    use Dispatchable, SerializesModels;

    public function __construct(public Experience $experience)
    {}
}

// ============================================================================
// FILE: app/Events/RetreatDrafted.php
// ============================================================================

namespace App\Events;

use App\Models\Experience;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RetreatDrafted
{
    use Dispatchable, SerializesModels;

    public function __construct(public Experience $experience)
    {}
}

// ============================================================================
// FILE: app/Jobs/GenerateRecurringRetreatDates.php
// ============================================================================

namespace App\Jobs;

use App\Models\Experience;
use App\Services\SchedulingEngine;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GenerateRecurringRetreatDates implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(SchedulingEngine $schedulingEngine)
    {
        $experiences = Experience::where('is_recurring', true)
            ->where('is_draft', false)
            ->get();

        foreach ($experiences as $experience) {
            $schedulingEngine->generateRecurringDates($experience, 50);
        }
    }
}

// ============================================================================
// FILE: app/Jobs/ProcessBookingPayment.php
// ============================================================================

namespace App\Jobs;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ProcessBookingPayment implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        // Process payment through payment gateway
        // Update booking transaction info
        // Confirm booking if successful
    }
}

// ============================================================================
// FILE: app/Jobs/CalculatePricingForRetreats.php
// ============================================================================

namespace App\Jobs;

use App\Models\Experience;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class CalculatePricingForRetreats implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        // Recalculate pricing for all experiences
        $experiences = Experience::all();

        foreach ($experiences as $experience) {
            // Update pricing rules based on occupancy
        }
    }
}

// ============================================================================
// FILE: app/Listeners/SendBookingConfirmationNotification.php
// ============================================================================

namespace App\Listeners;

use App\Events\BookingConfirmed;
use App\Notifications\BookingConfirmedNotification;

class SendBookingConfirmationNotification
{
    public function handle(BookingConfirmed $event)
    {
        $booking = $event->booking;

        // Notify guest
        $booking->user->notify(new BookingConfirmedNotification($booking));

        // Notify center admins
        foreach ($booking->experience->center->users as $user) {
            $user->notify(new BookingConfirmedNotification($booking));
        }
    }
}

// ============================================================================
// FILE: app/Notifications/BookingConfirmedNotification.php
// ============================================================================

namespace App\Notifications;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class BookingConfirmedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public Booking $booking)
    {}

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Your Retreat Booking is Confirmed!')
            ->greeting('Hello ' . $notifiable->first_name . '!')
            ->line('Your booking for ' . $this->booking->experience->name . ' has been confirmed.')
            ->line('Arrival Date: ' . $this->booking->arrival_date->format('M d, Y'))
            ->line('Departure Date: ' . $this->booking->end_date_time->format('M d, Y'))
            ->line('Total Amount: ₹' . number_format($this->booking->pay_amount, 0))
            ->action('View Booking', route('booking.show', $this->booking))
            ->line('Thank you for booking with us!');
    }

    public function toDatabase($notifiable)
    {
        return [
            'booking_id' => $this->booking->id,
            'message' => 'Your booking has been confirmed',
            'retreat_name' => $this->booking->experience->name,
        ];
    }
}

// ============================================================================
// FILE: app/Utilities/ResponseBuilder.php
// ============================================================================

namespace App\Utilities;

class ResponseBuilder
{
    public static function success($data = null, $message = 'Success', $statusCode = 200)
    {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
        ], $statusCode);
    }

    public static function error($message = 'Error', $statusCode = 400, $errors = null)
    {
        $response = [
            'success' => false,
            'message' => $message,
        ];

        if ($errors) {
            $response['errors'] = $errors;
        }

        return response()->json($response, $statusCode);
    }

    public static function paginated($items, $message = 'Data retrieved successfully')
    {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $items->items(),
            'pagination' => [
                'current_page' => $items->currentPage(),
                'per_page' => $items->perPage(),
                'total' => $items->total(),
                'last_page' => $items->lastPage(),
            ]
        ]);
    }
}

// ============================================================================
// FILE: app/Utilities/DateRange.php
// ============================================================================

namespace App\Utilities;

use Carbon\Carbon;

class DateRange
{
    public static function isWithinRange(Carbon $date, Carbon $start, Carbon $end): bool
    {
        return $date->between($start, $end);
    }

    public static function getDaysBetween(Carbon $start, Carbon $end): int
    {
        return $end->diffInDays($start) + 1;
    }

    public static function isInPeakSeason(Carbon $date): bool
    {
        $month = $date->month;
        return in_array($month, [1, 2, 3, 10, 11, 12]);
    }

    public static function isInMonsoon(Carbon $date): bool
    {
        $month = $date->month;
        return in_array($month, [6, 7, 8, 9]);
    }

    public static function getSeasonName(Carbon $date): string
    {
        $month = $date->month;

        return match($month) {
            1, 2, 3 => 'Winter',
            4, 5 => 'Summer',
            6, 7, 8, 9 => 'Monsoon',
            10, 11, 12 => 'Autumn',
            default => 'Unknown'
        };
    }
}

// ============================================================================
// FILE: app/Utilities/Formatters.php
// ============================================================================

namespace App\Utilities;

class Formatters
{
    public static function price($amount, $currency = 'INR'): string
    {
        if ($currency === 'INR') {
            return '₹' . number_format($amount, 2);
        }

        return $currency . ' ' . number_format($amount, 2);
    }

    public static function percentage($value, $decimals = 0): string
    {
        return round($value, $decimals) . '%';
    }

    public static function dateRange($startDate, $endDate, $format = 'M d'): string
    {
        return $startDate->format($format) . ' - ' . $endDate->format($format);
    }

    public static function shortName($firstName, $lastName): string
    {
        return substr($firstName, 0, 1) . substr($lastName, 0, 1);
    }

    public static function phoneNumber($phone): string
    {
        $cleaned = preg_replace('/\D/', '', $phone);

        if (strlen($cleaned) === 10) {
            return '+91 ' . substr($cleaned, 0, 5) . ' ' . substr($cleaned, 5);
        }

        return $phone;
    }
}

?>
