<?php

// ============================================================================
// FILE: app/Http/Requests/StoreRetreatRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreRetreatRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255|unique:experiences,name',
            'price_per_person' => 'required|numeric|min:100',
            'start_date_time' => 'required|date|after_or_equal:today',
            'end_date_time' => 'required|date|after:start_date_time',
            'experience_summary' => 'required|string|min:50',
            'accommodations' => 'required|array|min:1',
            'accommodations.*' => 'integer|exists:accomodations,id',
            'price_per_night' => 'required|numeric|min:0',
            'batch_size' => 'nullable|integer|min:1',
            'what_is_included' => 'nullable|string',
            'what_is_not_included' => 'nullable|string',
            'experience_highlights' => 'nullable|string',
            'cancellation_policy' => 'nullable|string',
            'early_bird_discount' => 'nullable|numeric|min:0|max:100',
            'early_bird_days' => 'nullable|integer|min:0',
        ];
    }

    public function messages(): array
    {
        return [
            'name.unique' => 'A retreat with this name already exists.',
            'start_date_time.after_or_equal' => 'Start date must be today or in the future.',
            'end_date_time.after' => 'End date must be after start date.',
            'accommodations.required' => 'Please select at least one accommodation.',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/UpdateRetreatRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateRetreatRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $retreatId = $this->route('retreat')->id;

        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('experiences', 'name')->ignore($retreatId),
            ],
            'price_per_person' => 'required|numeric|min:100',
            'start_date_time' => 'required|date|after_or_equal:today',
            'end_date_time' => 'required|date|after:start_date_time',
            'experience_summary' => 'required|string|min:50',
            'accommodations' => 'array|min:1',
            'accommodations.*' => 'integer|exists:accomodations,id',
            'price_per_night' => 'numeric|min:0',
            'batch_size' => 'nullable|integer|min:1',
            'what_is_included' => 'nullable|string',
            'what_is_not_included' => 'nullable|string',
            'experience_highlights' => 'nullable|string',
            'cancellation_policy' => 'nullable|string',
            'early_bird_discount' => 'nullable|numeric|min:0|max:100',
            'early_bird_days' => 'nullable|integer|min:0',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/StorePricingRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePricingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'pricing_type' => 'required|in:duration,seasonal,occupancy,promotional',
            'duration' => 'required_if:pricing_type,duration|integer|min:1',
            'price' => 'required|numeric|min:0',
            'promo_price' => 'nullable|numeric|min:0|lt:price',
            'start_date' => 'required_if:pricing_type,seasonal,occupancy|date',
            'end_date' => 'required_if:pricing_type,seasonal,occupancy|date|after:start_date',
            'accommodation_id' => 'nullable|integer|exists:accomodations,id',
            'min_occupancy' => 'nullable|integer|min:1',
            'max_occupancy' => 'nullable|integer|min:1|gt:min_occupancy',
        ];
    }

    public function messages(): array
    {
        return [
            'promo_price.lt' => 'Promotional price must be less than regular price.',
            'end_date.after' => 'End date must be after start date.',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/StoreBookingRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'email' => 'required|email',
            'phone' => 'required|regex:/^[0-9\s\+\-\(\)]+$/',
            'arrival_date' => 'required|date|after_or_equal:today',
            'departure_date' => 'required|date|after:arrival_date',
            'guest_count' => 'required|integer|min:1|max:20',
            'accommodation_id' => 'required|integer|exists:experience_accomodations,id',
            'message' => 'nullable|string|max:500',
            'billing_address' => 'nullable|string',
            'billing_city' => 'nullable|string',
            'billing_state' => 'nullable|string',
            'billing_zip' => 'nullable|string',
            'billing_country' => 'nullable|string',
            'agree_terms' => 'required|accepted',
        ];
    }

    public function messages(): array
    {
        return [
            'arrival_date.after_or_equal' => 'Arrival date must be today or in the future.',
            'departure_date.after' => 'Departure date must be after arrival date.',
            'guest_count.min' => 'At least 1 guest is required.',
            'phone.regex' => 'Please enter a valid phone number.',
            'agree_terms.required' => 'You must agree to the terms and conditions.',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/UpdateAccountRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAccountRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'nullable|string|max:255',
            'business_name' => 'nullable|string|max:255',
            'email_address' => 'nullable|email',
            'contact_number' => 'nullable|string|max:20',
            'whatsapp_number' => 'nullable|string|max:20',
            'website' => 'nullable|url',
            'facebook_url' => 'nullable|url',
            'instagram_url' => 'nullable|url',
            'gst_number' => 'nullable|regex:/^[0-9A-Z]{15}$/',
            'pan_number' => 'nullable|regex:/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/',
            'billing_address' => 'nullable|string',
            'account_holder_name' => 'nullable|string|max:100',
            'bank_name' => 'nullable|string|max:100',
            'account_number' => 'nullable|regex:/^[0-9]{8,17}$/',
            'ifsc_code' => 'nullable|regex:/^[A-Z]{4}0[A-Z0-9]{6}$/',
            'preferred_payout_cycle' => 'nullable|in:weekly,bi-weekly,monthly',
            'upi_id' => 'nullable|regex:/^[a-zA-Z0-9.-]{3,}@[a-zA-Z]{3,}$/',
        ];
    }

    public function messages(): array
    {
        return [
            'gst_number.regex' => 'GST number must be 15 alphanumeric characters.',
            'pan_number.regex' => 'PAN number format is invalid.',
            'account_number.regex' => 'Account number must be 8-17 digits.',
            'ifsc_code.regex' => 'IFSC code format is invalid.',
            'upi_id.regex' => 'UPI ID format is invalid.',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/StoreAccommodationRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreAccommodationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'accommodation_id' => 'required|integer|exists:accomodations,id',
            'title' => 'required|string|max:255',
            'about' => 'nullable|string',
            'price_per_night_per_guest' => 'required|numeric|min:0',
            'max_guest_in_room' => 'required|integer|min:1',
            'accommodation_default' => 'boolean',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/CreateScheduleRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateScheduleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'schedule_day' => 'required|integer|min:1',
            'schedule_start_time' => 'required|date_format:H:i',
            'schedule_end_time' => 'required|date_format:H:i|after:schedule_start_time',
            'activity_description' => 'required|string|min:10',
        ];
    }

    public function messages(): array
    {
        return [
            'schedule_end_time.after' => 'End time must be after start time.',
        ];
    }
}

// ============================================================================
// FILE: app/Http/Requests/CreateRecurringRequest.php
// ============================================================================

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateRecurringRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'recurring_type' => 'required|in:Daily,Weekly,Monthly,Yearly',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'separation_count' => 'nullable|integer|min:1',
            'max_num_of_occurrances' => 'nullable|integer|min:1',
            'day_of_week' => 'nullable|array',
            'day_of_week.*' => 'in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday',
            'week_of_month' => 'nullable|integer|min:1|max:5',
            'day_of_month' => 'nullable|integer|min:1|max:31',
            'month_of_year' => 'nullable|date_format:m-d',
        ];
    }

    public function messages(): array
    {
        return [
            'end_date.after' => 'End date must be after start date.',
        ];
    }
}

?>
