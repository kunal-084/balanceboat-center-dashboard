<?php

// ============================================================================
// FILE: app/Http/Controllers/Dashboard/OverviewController.php
// ============================================================================

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Center;
use App\Models\Booking;
use App\Models\Experience;
use Illuminate\Support\Facades\Auth;

class OverviewController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return view('dashboard.no-center');
        }

        $stats = [
            'total_retreats' => $center->experiences()->count(),
            'active_retreats' => $center->experiences()->where('is_draft', false)->count(),
            'total_bookings' => $center->experiences()->with('bookings')->get()
                ->sum(fn($e) => $e->bookings->where('order_status', 'confirmed')->count()),
            'total_revenue' => $center->experiences()->with('bookings')->get()
                ->sum(fn($e) => $e->bookings->where('payment_status', 'completed')->sum('pay_amount')),
            'pending_bookings' => $center->experiences()->with('bookings')->get()
                ->sum(fn($e) => $e->bookings->where('order_status', 'pending')->count()),
            'occupancy_percentage' => $this->calculateOccupancy($center),
        ];

        $upcomingRetreats = $center->experiences()
            ->where('is_draft', false)
            ->where('start_date_time', '>=', now())
            ->orderBy('start_date_time')
            ->take(5)
            ->get()
            ->map(fn($exp) => [
                'id' => $exp->id,
                'name' => $exp->name,
                'start_date' => $exp->start_date_time->format('M d, Y'),
                'booked' => $exp->occupied_spaces,
                'total' => $exp->total_spaces,
                'occupancy' => $exp->occupancy_percentage,
            ]);

        $recentBookings = $center->experiences()
            ->with('bookings')
            ->get()
            ->flatMap(fn($e) => $e->bookings)
            ->where('order_status', 'confirmed')
            ->sortByDesc('created_at')
            ->take(5)
            ->map(fn($booking) => [
                'id' => $booking->id,
                'guest_name' => $booking->userInfo->firstname . ' ' . $booking->userInfo->lastname,
                'retreat_name' => $booking->experience->name,
                'arrival_date' => $booking->arrival_date->format('M d'),
                'guests' => $booking->guest_count,
                'amount' => $booking->pay_amount,
            ]);

        return view('dashboard.index', [
            'center' => $center,
            'stats' => $stats,
            'upcoming_retreats' => $upcomingRetreats,
            'recent_bookings' => $recentBookings,
        ]);
    }

    private function calculateOccupancy(Center $center): float
    {
        $totalCapacity = $center->experiences()
            ->with('accommodations')
            ->get()
            ->sum(fn($exp) => $exp->total_spaces);

        $totalBooked = $center->experiences()
            ->with('bookings')
            ->get()
            ->sum(fn($exp) => $exp->occupied_spaces);

        if ($totalCapacity === 0) return 0;
        return round(($totalBooked / $totalCapacity) * 100, 2);
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Dashboard/AccountController.php
// ============================================================================

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateAccountRequest;
use App\Models\Center;
use App\Models\PayoutAccount;
use Illuminate\Support\Facades\Auth;

class AccountController extends Controller
{
    public function show()
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return view('dashboard.no-center');
        }

        $aiTrustScore = $this->calculateAITrustScore($center);
        $completionPercentage = $center->completion_percentage;
        $payoutAccount = $center->payoutAccounts()->first();

        return view('dashboard.account', [
            'center' => $center,
            'user' => $user,
            'ai_trust_score' => $aiTrustScore,
            'completion_percentage' => $completionPercentage,
            'payout_account' => $payoutAccount,
        ]);
    }

    public function update(UpdateAccountRequest $request)
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return redirect()->back()->with('error', 'Center not found');
        }

        // Update center
        $center->update($request->validated());

        // Update or create payout account
        if ($request->has('account_holder_name')) {
            PayoutAccount::updateOrCreate(
                ['center_id' => $center->id],
                [
                    'account_holder_name' => $request->input('account_holder_name'),
                    'bank_name' => $request->input('bank_name'),
                    'account_number' => $request->input('account_number'),
                    'ifsc_code' => $request->input('ifsc_code'),
                    'preferred_payout_cycle' => $request->input('preferred_payout_cycle'),
                    'upi_id' => $request->input('upi_id'),
                ]
            );
        }

        return redirect()->back()->with('success', 'Account information updated successfully!');
    }

    private function calculateAITrustScore(Center $center): array
    {
        $score = 0;
        $maxScore = 100;

        // Profile completeness (40 points)
        $profileFields = ['name', 'about_center', 'email_address', 'contact_number'];
        $filledFields = collect($profileFields)->filter(fn($field) => !empty($center->{$field}))->count();
        $score += ($filledFields / count($profileFields)) * 40;

        // Bookings & reviews (30 points)
        $totalBookings = $center->experiences()
            ->with('bookings')
            ->get()
            ->sum(fn($e) => $e->bookings->where('order_status', 'confirmed')->count());
        $averageRating = $center->reviews()->avg('rating') ?? 0;

        $score += min(($totalBookings / 10) * 15, 15);
        $score += ($averageRating / 5) * 15;

        // Security (20 points)
        $score += 10; // Email verified
        if (!empty($center->gst_number)) $score += 5;
        if ($center->payoutAccounts()->exists()) $score += 5;

        // Content (10 points)
        if (!empty($center->banner_image_url)) $score += 5;
        if ($center->galleries()->exists()) $score += 5;

        $finalScore = min(round($score), 100);
        $status = match(true) {
            $finalScore >= 80 => 'Very Good',
            $finalScore >= 60 => 'Good',
            $finalScore >= 40 => 'Fair',
            default => 'Poor'
        };

        return [
            'score' => $finalScore,
            'status' => $status,
            'out_of' => $maxScore,
        ];
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Retreat/RetreatController.php
// ============================================================================

namespace App\Http\Controllers\Retreat;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreRetreatRequest;
use App\Http\Requests\UpdateRetreatRequest;
use App\Models\Experience;
use App\Models\Center;
use App\Services\RetreatService;
use Illuminate\Support\Facades\Auth;

class RetreatController extends Controller
{
    public function __construct(private RetreatService $retreatService)
    {}

    public function index()
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return view('dashboard.no-center');
        }

        $retreats = $center->experiences()
            ->with('accommodations', 'bookings')
            ->orderByDesc('created_at')
            ->paginate(10);

        $retreats = $retreats->map(fn($r) => [
            'id' => $r->id,
            'name' => $r->name,
            'start_date' => $r->start_date_time?->format('M d, Y') ?? 'N/A',
            'end_date' => $r->end_date_time?->format('M d, Y') ?? 'N/A',
            'price' => $r->price_per_person,
            'status' => $r->is_draft ? 'Draft' : 'Published',
            'booked' => $r->occupied_spaces,
            'total' => $r->total_spaces,
            'occupancy_percent' => $r->occupancy_percentage,
            'bookings' => $r->bookings->where('order_status', 'confirmed')->count(),
            'revenue' => $r->bookings->where('payment_status', 'completed')->sum('pay_amount'),
            'rating' => $r->average_rating,
        ]);

        return view('retreat.index', [
            'center' => $center,
            'retreats' => $retreats,
        ]);
    }

    public function create()
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return redirect()->route('dashboard');
        }

        return view('retreat.create', [
            'center' => $center,
        ]);
    }

    public function store(StoreRetreatRequest $request)
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return redirect()->route('dashboard')->with('error', 'Center not found');
        }

        $retreat = $this->retreatService->createRetreat($center, $request->validated());

        // Handle accommodations
        if ($request->has('accommodations')) {
            foreach ($request->input('accommodations') as $accId) {
                $retreat->accommodations()->attach($accId, [
                    'price_per_night_per_guest' => $request->input('price_per_night'),
                ]);
            }
        }

        return redirect()->route('retreat.edit', $retreat)
            ->with('success', 'Retreat created successfully!');
    }

    public function edit(Experience $retreat)
    {
        $this->authorize('update', $retreat);

        return view('retreat.edit', [
            'retreat' => $retreat,
            'center' => $retreat->center,
        ]);
    }

    public function update(UpdateRetreatRequest $request, Experience $retreat)
    {
        $this->authorize('update', $retreat);

        $this->retreatService->updateRetreat($retreat, $request->validated());

        return redirect()->back()->with('success', 'Retreat updated successfully!');
    }

    public function show(Experience $retreat)
    {
        $this->authorize('view', $retreat);

        $summary = $this->retreatService->getRetreatSummary($retreat);

        return view('retreat.show', [
            'retreat' => $retreat,
            'summary' => $summary,
        ]);
    }

    public function publish(Experience $retreat)
    {
        $this->authorize('update', $retreat);

        try {
            $this->retreatService->publishRetreat($retreat);
            return redirect()->back()->with('success', 'Retreat published successfully!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function draft(Experience $retreat)
    {
        $this->authorize('update', $retreat);

        $this->retreatService->draftRetreat($retreat);

        return redirect()->back()->with('success', 'Retreat moved to draft.');
    }

    public function duplicate(Experience $retreat)
    {
        $this->authorize('create', Experience::class);

        $duplicate = $this->retreatService->duplicateRetreat($retreat);

        return redirect()->route('retreat.edit', $duplicate)
            ->with('success', 'Retreat duplicated successfully!');
    }

    public function destroy(Experience $retreat)
    {
        $this->authorize('delete', $retreat);

        $this->retreatService->deleteRetreat($retreat);

        return redirect()->route('retreat.index')
            ->with('success', 'Retreat deleted successfully!');
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Retreat/RetreatPricingController.php
// ============================================================================

namespace App\Http\Controllers\Retreat;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePricingRequest;
use App\Models\Experience;
use App\Models\ExperienceDurationPrice;

class RetreatPricingController extends Controller
{
    public function index(Experience $retreat)
    {
        $this->authorize('update', $retreat);

        $durationPrices = $retreat->durationPrices()->get();

        return view('retreat.pricing', [
            'retreat' => $retreat,
            'duration_prices' => $durationPrices,
        ]);
    }

    public function store(StorePricingRequest $request, Experience $retreat)
    {
        $this->authorize('update', $retreat);

        $data = $request->validated();
        $data['experience_id'] = $retreat->id;

        ExperienceDurationPrice::create($data);

        return redirect()->back()->with('success', 'Pricing rule added successfully!');
    }

    public function calculatePrice(Experience $retreat)
    {
        $arrivalDate = \Carbon\Carbon::parse(request('arrival_date'));
        $departureDate = \Carbon\Carbon::parse(request('departure_date'));
        $guestCount = request('guest_count', 1);
        $accommodationId = request('accommodation_id');

        $accommodation = $retreat->accommodations()
            ->where('experience_accomodation_id', $accommodationId)
            ->first();

        if (!$accommodation) {
            $accommodation = $retreat->accommodations()->first();
        }

        $pricing = app(\App\Services\PricingEngine::class)->calculateBookingPrice(
            $retreat,
            $accommodation,
            $arrivalDate,
            $departureDate,
            $guestCount
        );

        return response()->json($pricing);
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Booking/BookingController.php
// ============================================================================

namespace App\Http\Controllers\Booking;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreBookingRequest;
use App\Models\Booking;
use App\Models\Experience;
use App\Models\User;
use App\Services\BookingService;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function __construct(private BookingService $bookingService)
    {}

    public function index()
    {
        $user = Auth::user();
        $center = $user->getPrimaryCenter();

        if (!$center) {
            return view('dashboard.no-center');
        }

        $bookings = $center->experiences()
            ->with('bookings')
            ->get()
            ->flatMap(fn($e) => $e->bookings)
            ->where('order_status', 'confirmed')
            ->sortByDesc('created_at')
            ->paginate(15);

        return view('booking.index', [
            'center' => $center,
            'bookings' => $bookings,
        ]);
    }

    public function show(Booking $booking)
    {
        $this->authorize('view', $booking);

        return view('booking.show', [
            'booking' => $booking,
            'user_info' => $booking->userInfo,
            'transaction_info' => $booking->transactionInfo,
            'address_info' => $booking->addressInfo,
        ]);
    }

    public function preview(Experience $experience)
    {
        $accommodation = $experience->accommodations()->first();

        return view('booking.preview', [
            'experience' => $experience,
            'accommodation' => $accommodation,
        ]);
    }

    public function store(StoreBookingRequest $request, Experience $experience)
    {
        $accommodation = $experience->accommodations()
            ->where('id', $request->input('accommodation_id'))
            ->first() ?? $experience->accommodations()->first();

        $user = User::firstOrCreate(
            ['email' => $request->input('email')],
            [
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'phone_number' => $request->input('phone'),
                'password' => bcrypt('temporary-password'),
            ]
        );

        try {
            $booking = $this->bookingService->createBooking(
                $experience,
                $accommodation,
                $user,
                $request->validated()
            );

            return redirect()->route('booking.payment', $booking)
                ->with('success', 'Booking created! Please complete payment.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function confirm(Booking $booking)
    {
        if ($booking->order_status === 'confirmed') {
            return redirect()->back()->with('info', 'Booking already confirmed.');
        }

        $transactionId = request('transaction_id');

        try {
            $this->bookingService->confirmBooking($booking, $transactionId);
            return redirect()->route('booking.success', $booking)
                ->with('success', 'Booking confirmed successfully!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function cancel(Booking $booking)
    {
        $this->authorize('view', $booking);

        try {
            $this->bookingService->cancelBooking($booking, request('reason'));
            return redirect()->back()->with('success', 'Booking cancelled successfully!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Api/PricingController.php
// ============================================================================

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Experience;
use App\Services\PricingEngine;
use Carbon\Carbon;

class PricingController extends Controller
{
    public function __construct(private PricingEngine $pricingEngine)
    {}

    public function calculate()
    {
        $experience = Experience::findOrFail(request('experience_id'));
        $accommodation = $experience->accommodations()
            ->findOrFail(request('accommodation_id'));

        $arrivalDate = Carbon::parse(request('arrival_date'));
        $departureDate = Carbon::parse(request('departure_date'));
        $guestCount = request('guest_count', 1);

        $pricing = $this->pricingEngine->calculateBookingPrice(
            $experience,
            $accommodation,
            $arrivalDate,
            $departureDate,
            $guestCount,
            request('coupon_code')
        );

        return response()->json([
            'success' => true,
            'data' => $pricing,
        ]);
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Api/AvailabilityController.php
// ============================================================================

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Experience;
use App\Services\AvailabilityEngine;
use Carbon\Carbon;

class AvailabilityController extends Controller
{
    public function __construct(private AvailabilityEngine $availabilityEngine)
    {}

    public function calendar()
    {
        $experience = Experience::findOrFail(request('experience_id'));
        $accommodation = $experience->accommodations()
            ->find(request('accommodation_id'));

        $startDate = Carbon::parse(request('start_date', now()));
        $endDate = Carbon::parse(request('end_date', now()->addMonths(3)));

        $calendar = $this->availabilityEngine->getAvailabilityCalendar(
            $experience,
            $accommodation,
            $startDate,
            $endDate
        );

        return response()->json([
            'success' => true,
            'data' => $calendar,
        ]);
    }

    public function checkAvailability()
    {
        $experience = Experience::findOrFail(request('experience_id'));
        $accommodation = $experience->accommodations()
            ->findOrFail(request('accommodation_id'));

        $arrivalDate = Carbon::parse(request('arrival_date'));
        $departureDate = Carbon::parse(request('departure_date'));
        $guestCount = request('guest_count', 1);

        $isAvailable = $this->availabilityEngine->canBook(
            $experience,
            $accommodation,
            $arrivalDate,
            $departureDate,
            $guestCount
        );

        return response()->json([
            'success' => true,
            'available' => $isAvailable,
            'message' => $isAvailable ? 'Dates are available' : 'Dates are not available',
        ]);
    }
}

// ============================================================================
// FILE: app/Http/Controllers/Api/RetreatController.php
// ============================================================================

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Experience;
use App\Services\SchedulingEngine;

class RetreatController extends Controller
{
    public function __construct(private SchedulingEngine $schedulingEngine)
    {}

    public function summary(Experience $retreat)
    {
        $summary = [
            'id' => $retreat->id,
            'name' => $retreat->name,
            'slug' => $retreat->slug,
            'price' => $retreat->price_per_person,
            'currency' => $retreat->currency,
            'duration_days' => $retreat->duration_in_days,
            'start_date' => $retreat->start_date_time?->format('Y-m-d'),
            'end_date' => $retreat->end_date_time?->format('Y-m-d'),
            'about' => $retreat->experience_summary,
            'capacity' => $retreat->total_spaces,
            'available' => $retreat->available_spaces,
            'booked' => $retreat->occupied_spaces,
            'occupancy_percent' => $retreat->occupancy_percentage,
            'rating' => $retreat->average_rating,
            'accommodations' => $retreat->accommodations()->get()->map(fn($a) => [
                'id' => $a->id,
                'title' => $a->title,
                'price' => $a->price_per_night_per_guest,
                'max_guests' => $a->max_guest_in_room,
            ]),
            'teachers' => $retreat->teachers()->get()->map(fn($t) => [
                'id' => $t->id,
                'name' => $t->name,
                'bio' => $t->short_description,
            ]),
        ];

        return response()->json([
            'success' => true,
            'data' => $summary,
        ]);
    }

    public function availability(Experience $retreat)
    {
        $calendar = $this->schedulingEngine->generateRecurringDates($retreat);

        return response()->json([
            'success' => true,
            'data' => $calendar,
        ]);
    }
}

?>
