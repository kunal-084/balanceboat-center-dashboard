{{-- ======================================================================== --}}
{{-- FILE: resources/views/layouts/app.blade.php --}}
{{-- ======================================================================== --}}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - BalanceBoat</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        {{-- Sidebar --}}
        @include('components.sidebar')

        {{-- Main Content --}}
        <div class="flex-1 ml-72">
            {{-- Topbar --}}
            @include('components.topbar')

            {{-- Page Content --}}
            <main class="p-8">
                {{-- Alerts --}}
                @if ($errors->any())
                    <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                        <h3 class="text-red-800 font-semibold mb-2">Errors</h3>
                        <ul class="text-red-700 text-sm">
                            @foreach ($errors->all() as $error)
                                <li>• {{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg text-green-800">
                        <i class="fas fa-check-circle mr-2"></i>{{ session('success') }}
                    </div>
                @endif

                @if (session('error'))
                    <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-800">
                        <i class="fas fa-exclamation-circle mr-2"></i>{{ session('error') }}
                    </div>
                @endif

                {{-- Page Content --}}
                @yield('content')
            </main>
        </div>
    </div>
</body>
</html>

{{-- ======================================================================== --}}
{{-- FILE: resources/views/components/sidebar.blade.php --}}
{{-- ======================================================================== --}}

<aside class="fixed left-0 top-0 w-72 h-screen bg-gradient-to-b from-purple-100 to-pink-50 border-r border-purple-200 p-6">
    {{-- Logo --}}
    <div class="flex items-center gap-3 mb-8 pb-6 border-b border-purple-200">
        <div class="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center text-white text-xl">
            🧘
        </div>
        <span class="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            BalanceBoat
        </span>
    </div>

    {{-- Navigation --}}
    <nav class="space-y-2 flex-1">
        <a href="{{ route('dashboard.index') }}" class="block px-4 py-3 rounded-lg {{ request()->routeIs('dashboard.index') ? 'bg-white text-purple-600 font-semibold shadow' : 'text-gray-600 hover:bg-white/50' }}">
            <i class="fas fa-chart-line mr-3"></i>Dashboard
        </a>
        <a href="{{ route('retreat.index') }}" class="block px-4 py-3 rounded-lg {{ request()->routeIs('retreat.*') ? 'bg-white text-purple-600 font-semibold shadow' : 'text-gray-600 hover:bg-white/50' }}">
            <i class="fas fa-spa mr-3"></i>Retreats
        </a>
        <a href="{{ route('booking.index') }}" class="block px-4 py-3 rounded-lg {{ request()->routeIs('booking.*') ? 'bg-white text-purple-600 font-semibold shadow' : 'text-gray-600 hover:bg-white/50' }}">
            <i class="fas fa-calendar-check mr-3"></i>Bookings
        </a>
        <a href="{{ route('dashboard.account.show') }}" class="block px-4 py-3 rounded-lg {{ request()->routeIs('dashboard.account.*') ? 'bg-white text-purple-600 font-semibold shadow' : 'text-gray-600 hover:bg-white/50' }}">
            <i class="fas fa-user-cog mr-3"></i>Account
        </a>
    </nav>

    {{-- User Card --}}
    <div class="border-t border-purple-200 pt-4 mt-4">
        <div class="flex items-center gap-3 p-3 bg-white rounded-lg">
            <div class="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center text-white text-sm font-bold">
                {{ substr(Auth::user()->first_name, 0, 1) }}{{ substr(Auth::user()->last_name, 0, 1) }}
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-sm font-semibold text-gray-900 truncate">{{ Auth::user()->full_name }}</p>
                <p class="text-xs text-gray-500">Admin</p>
            </div>
        </div>
        <form method="POST" action="{{ route('logout') }}" class="mt-3">
            @csrf
            <button type="submit" class="w-full text-left px-4 py-2 text-gray-600 hover:bg-white/50 rounded-lg text-sm">
                <i class="fas fa-sign-out-alt mr-2"></i>Logout
            </button>
        </form>
    </div>
</aside>

{{-- ======================================================================== --}}
{{-- FILE: resources/views/components/topbar.blade.php --}}
{{-- ======================================================================== --}}

<header class="bg-white border-b border-gray-200 px-8 py-4 sticky top-0 z-40">
    <div class="flex items-center justify-between">
        <h1 class="text-2xl font-bold text-gray-900">@yield('page_title', 'Dashboard')</h1>
        <div class="flex items-center gap-4">
            <button class="p-2 hover:bg-gray-100 rounded-lg relative">
                <i class="fas fa-bell text-gray-600"></i>
                <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div class="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-400 rounded-lg flex items-center justify-center text-white">
                {{ substr(Auth::user()->first_name, 0, 1) }}
            </div>
        </div>
    </div>
</header>

{{-- ======================================================================== --}}
{{-- FILE: resources/views/dashboard/index.blade.php --}}
{{-- ======================================================================== --}}

@extends('layouts.app')

@section('title', 'Dashboard')
@section('page_title', 'Dashboard Overview')

@section('content')
    <div class="space-y-6">
        {{-- Stats Grid --}}
        <div class="grid grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-lg border border-gray-200">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-medium">Total Retreats</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">{{ $stats['total_retreats'] }}</p>
                    </div>
                    <div class="p-3 bg-blue-100 rounded-lg">
                        <i class="fas fa-spa text-blue-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg border border-gray-200">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-medium">Active Bookings</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">{{ $stats['total_bookings'] }}</p>
                    </div>
                    <div class="p-3 bg-green-100 rounded-lg">
                        <i class="fas fa-check-circle text-green-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg border border-gray-200">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-medium">Total Revenue</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">₹{{ number_format($stats['total_revenue'], 0) }}</p>
                    </div>
                    <div class="p-3 bg-purple-100 rounded-lg">
                        <i class="fas fa-rupee-sign text-purple-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg border border-gray-200">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-medium">Occupancy</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">{{ round($stats['occupancy_percentage']) }}%</p>
                    </div>
                    <div class="p-3 bg-orange-100 rounded-lg">
                        <i class="fas fa-chart-pie text-orange-600"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-6">
            {{-- Upcoming Retreats --}}
            <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">Upcoming Retreats</h2>
                <div class="space-y-3">
                    @foreach($upcoming_retreats as $retreat)
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-gray-900">{{ $retreat['name'] }}</p>
                                <p class="text-sm text-gray-600">{{ $retreat['start_date'] }} - {{ $retreat['end_date'] }}</p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-gray-900">{{ $retreat['booked'] }}/{{ $retreat['total'] }}</p>
                                <div class="w-16 h-2 bg-gray-200 rounded-full mt-1 overflow-hidden">
                                    <div class="h-full bg-green-500" style="width: {{ $retreat['occupancy'] }}%"></div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            {{-- Recent Bookings --}}
            <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">Recent Bookings</h2>
                <div class="space-y-3">
                    @foreach($recent_bookings as $booking)
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-gray-900">{{ $booking['guest_name'] }}</p>
                                <p class="text-sm text-gray-600">{{ $booking['retreat_name'] }} • {{ $booking['guests'] }} guests</p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-gray-900">₹{{ number_format($booking['amount'], 0) }}</p>
                                <p class="text-xs text-gray-500">{{ $booking['arrival_date'] }}</p>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection

{{-- ======================================================================== --}}
{{-- FILE: resources/views/retreat/index.blade.php --}}
{{-- ======================================================================== --}}

@extends('layouts.app')

@section('title', 'Retreats')
@section('page_title', 'Manage Retreats')

@section('content')
    <div class="mb-6 flex items-center justify-between">
        <h1 class="text-3xl font-bold text-gray-900">Your Retreats</h1>
        <a href="{{ route('retreat.create') }}" class="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg transition">
            <i class="fas fa-plus mr-2"></i>Create New Retreat
        </a>
    </div>

    <div class="grid gap-6">
        @forelse($retreats as $retreat)
            <div class="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition">
                <div class="flex items-start justify-between">
                    <div class="flex-1">
                        <div class="flex items-center gap-3 mb-2">
                            <h3 class="text-xl font-bold text-gray-900">{{ $retreat['name'] }}</h3>
                            <span class="px-2 py-1 bg-{{ $retreat['status'] === 'Draft' ? 'yellow-100 text-yellow-800' : 'green-100 text-green-800' }} rounded-full text-xs font-semibold">
                                {{ $retreat['status'] }}
                            </span>
                        </div>
                        <p class="text-gray-600 text-sm mb-3">{{ $retreat['start_date'] }} - {{ $retreat['end_date'] }}</p>

                        <div class="grid grid-cols-4 gap-4 mb-4">
                            <div>
                                <p class="text-xs text-gray-500 font-semibold">PRICE</p>
                                <p class="text-lg font-bold text-gray-900">₹{{ number_format($retreat['price'], 0) }}</p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500 font-semibold">CAPACITY</p>
                                <p class="text-lg font-bold text-gray-900">{{ $retreat['booked'] }}/{{ $retreat['total'] }}</p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500 font-semibold">BOOKINGS</p>
                                <p class="text-lg font-bold text-gray-900">{{ $retreat['bookings'] }}</p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500 font-semibold">REVENUE</p>
                                <p class="text-lg font-bold text-purple-600">₹{{ number_format($retreat['revenue'], 0) }}</p>
                            </div>
                        </div>

                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-green-500 h-2 rounded-full" style="width: {{ $retreat['occupancy_percent'] }}%"></div>
                        </div>
                        <p class="text-xs text-gray-500 mt-1">{{ round($retreat['occupancy_percent']) }}% Occupied</p>
                    </div>

                    <div class="flex flex-col gap-2 ml-6">
                        <a href="{{ route('retreat.edit', $retreat['id']) }}" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm">
                            <i class="fas fa-edit mr-1"></i>Edit
                        </a>
                        <a href="{{ route('retreat.show', $retreat['id']) }}" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm">
                            <i class="fas fa-eye mr-1"></i>View
                        </a>
                        <a href="#" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm">
                            <i class="fas fa-copy mr-1"></i>Duplicate
                        </a>
                    </div>
                </div>
            </div>
        @empty
            <div class="bg-white rounded-lg border border-gray-200 p-12 text-center">
                <i class="fas fa-spa text-6xl text-gray-300 mb-4"></i>
                <h3 class="text-xl font-bold text-gray-900 mb-2">No Retreats Yet</h3>
                <p class="text-gray-600 mb-6">Create your first retreat to get started</p>
                <a href="{{ route('retreat.create') }}" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                    Create Your First Retreat
                </a>
            </div>
        @endforelse
    </div>
@endsection

{{-- ======================================================================== --}}
{{-- FILE: resources/views/booking/index.blade.php --}}
{{-- ======================================================================== --}}

@extends('layouts.app')

@section('title', 'Bookings')
@section('page_title', 'Manage Bookings')

@section('content')
    <div class="space-y-6">
        <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <table class="w-full">
                <thead class="bg-gray-50 border-b border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Guest</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Retreat</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Dates</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Guests</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Amount</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @forelse($bookings as $booking)
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4">
                                <p class="font-semibold text-gray-900">{{ $booking->userInfo->firstname }} {{ $booking->userInfo->lastname }}</p>
                                <p class="text-sm text-gray-500">{{ $booking->userInfo->email }}</p>
                            </td>
                            <td class="px-6 py-4 text-gray-900 font-semibold">{{ $booking->experience->name }}</td>
                            <td class="px-6 py-4 text-gray-600">{{ $booking->arrival_date->format('M d') }} - {{ $booking->end_date_time->format('M d') }}</td>
                            <td class="px-6 py-4 text-gray-900 font-semibold">{{ $booking->guest_count }}</td>
                            <td class="px-6 py-4 text-gray-900 font-bold">₹{{ number_format($booking->pay_amount, 0) }}</td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                                    {{ ucfirst($booking->order_status) }}
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <a href="{{ route('booking.show', $booking) }}" class="text-purple-600 hover:text-purple-700 font-semibold text-sm">
                                    View
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                                No bookings yet
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        {{ $bookings->links() }}
    </div>
@endsection

{{-- ======================================================================== --}}
{{-- FILE: resources/views/dashboard/account.blade.php --}}
{{-- ======================================================================== --}}

@extends('layouts.app')

@section('title', 'Account Settings')
@section('page_title', 'Account Information')

@section('content')
    <div class="space-y-6">
        {{-- AI Trust Score --}}
        <div class="grid grid-cols-3 gap-6">
            <div class="bg-white rounded-lg border border-gray-200 p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm">AI Trust Score</p>
                        <p class="text-4xl font-bold text-gray-900 mt-2">{{ $ai_trust_score['score'] }}</p>
                        <p class="text-sm text-gray-500 mt-1">{{ $ai_trust_score['status'] }}</p>
                    </div>
                    <div class="text-6xl text-yellow-400">⭐</div>
                </div>
            </div>

            <div class="bg-white rounded-lg border border-gray-200 p-6 col-span-2">
                <p class="text-gray-600 text-sm font-semibold mb-4">Account Completion</p>
                <div class="mb-2 flex items-center justify-between">
                    <span class="text-sm font-semibold text-gray-900">{{ $completion_percentage }}%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-3">
                    <div class="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full" style="width: {{ $completion_percentage }}%"></div>
                </div>
                <p class="text-xs text-gray-500 mt-2">Complete your profile to reach 100%</p>
            </div>
        </div>

        {{-- Center Information Form --}}
        <form method="POST" action="{{ route('dashboard.account.update') }}" class="space-y-6">
            @csrf
            @method('PATCH')

            {{-- Basic Information --}}
            <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">Center Information</h2>
                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Center Name</label>
                        <input type="text" name="name" value="{{ $center->name }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Business Name</label>
                        <input type="text" name="business_name" value="{{ $center->business_name }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                        <input type="email" name="email_address" value="{{ $center->email_address }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Phone</label>
                        <input type="text" name="contact_number" value="{{ $center->contact_number }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                </div>
            </div>

            {{-- Tax & Billing --}}
            <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">Tax & Billing</h2>
                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">GST Number</label>
                        <input type="text" name="gst_number" placeholder="e.g. 22AAAAA0000A1Z5" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">PAN Number</label>
                        <input type="text" name="pan_number" placeholder="e.g. AAAAA0000A" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div class="col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Billing Address</label>
                        <input type="text" name="billing_address" value="{{ $center->address_of_center }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                </div>
            </div>

            {{-- Payout Account --}}
            <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">Payout Account</h2>
                <div class="grid grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Account Holder Name</label>
                        <input type="text" name="account_holder_name" value="{{ $payout_account?->account_holder_name }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Bank Name</label>
                        <input type="text" name="bank_name" value="{{ $payout_account?->bank_name }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Account Number</label>
                        <input type="text" name="account_number" value="{{ $payout_account?->account_number }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">IFSC Code</label>
                        <input type="text" name="ifsc_code" value="{{ $payout_account?->ifsc_code }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Payout Cycle</label>
                        <select name="preferred_payout_cycle" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                            <option value="weekly" {{ $payout_account?->preferred_payout_cycle === 'weekly' ? 'selected' : '' }}>Weekly</option>
                            <option value="bi-weekly" {{ $payout_account?->preferred_payout_cycle === 'bi-weekly' ? 'selected' : '' }}>Bi-weekly</option>
                            <option value="monthly" {{ $payout_account?->preferred_payout_cycle === 'monthly' ? 'selected' : '' }}>Monthly</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">UPI ID</label>
                        <input type="text" name="upi_id" value="{{ $payout_account?->upi_id }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>
                </div>
            </div>

            {{-- Submit Button --}}
            <div class="flex justify-end gap-4">
                <button type="button" onclick="window.history.back()" class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                    Cancel
                </button>
                <button type="submit" class="px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg transition">
                    <i class="fas fa-save mr-2"></i>Save Changes
                </button>
            </div>
        </form>
    </div>
@endsection

{{-- ======================================================================== --}}
{{-- FILE: resources/views/dashboard/no-center.blade.php --}}
{{-- ======================================================================== --}}

@extends('layouts.app')

@section('title', 'Welcome')

@section('content')
    <div class="flex items-center justify-center min-h-screen">
        <div class="text-center">
            <i class="fas fa-building text-6xl text-gray-300 mb-4"></i>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">No Center Found</h1>
            <p class="text-gray-600 mb-6">You need to be associated with a center to use the dashboard</p>
            <p class="text-sm text-gray-500">Please contact your administrator or create a new center</p>
        </div>
    </div>
@endsection
