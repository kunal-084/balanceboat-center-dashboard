# 🎯 BalanceBoat Laravel - Organized Code Structure

## 📦 What You Have

All code is organized in `LARAVEL_STRUCTURE/` directory, ready to copy to your Laravel project.

```
LARAVEL_STRUCTURE/
├── app_Models_ALL.php              ← All 20 models (extract each class)
├── app_Services_ALL.php            ← All 5 services (extract each class)
├── app_Http_Controllers_ALL.php    ← All 7 controllers (extract each class)
├── app_Http_Requests_ALL.php       ← All 8 requests (extract each class)
├── app_Policies_ALL.php            ← All 3 policies (extract each class)
├── app_Events_ALL.php              ← All 3 events (extract each class)
├── app_Jobs_ALL.php                ← All 3 jobs (extract each class)
├── app_Listeners_ALL.php           ← All 1 listeners (extract each class)
├── app_Notifications_ALL.php       ← All 1 notifications (extract each class)
├── app_Utilities_ALL.php           ← All 3 utilities (extract each class)
├── database_migrations_ALL.php     ← All 8 migrations (extract each class)
├── routes_web.php                  ← Web routes (copy directly)
├── routes_api.php                  ← API routes (copy directly)
├── resources_views_ALL.blade.php   ← All Blade files (extract each file)
├── config_balanceboat.php          ← Config file (copy directly)
└── .env.example                    ← Env template (copy directly)
```

---

## 🚀 Step-by-Step Setup

### Step 1: Create Laravel Project

```bash
composer create-project laravel/laravel balanceboat
cd balanceboat
```

### Step 2: Install Dependencies

```bash
composer require spatie/laravel-permission laravel/sanctum
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
npm install
```

### Step 3: Extract and Copy Models

**File**: `app_Models_ALL.php`

This file contains all 20 models. Extract each `namespace App\Models; class ClassName { ... }` block and create individual files:

```bash
# Create app/Models/ files:
app/Models/User.php
app/Models/Center.php
app/Models/Experience.php
app/Models/ExperienceAccommodation.php
app/Models/ExperienceAccommodationPrice.php
app/Models/ExperienceDurationPrice.php
app/Models/ExperienceSchedule.php
app/Models/ExperienceRecurring.php
app/Models/Booking.php
app/Models/BookingUserInfo.php
app/Models/BookingTransactionInfo.php
app/Models/BookingTransactionAddressInfo.php
app/Models/Category.php
app/Models/Teacher.php
app/Models/Amenity.php
app/Models/Review.php
app/Models/CenterCommission.php
app/Models/PayoutAccount.php
app/Models/ExperienceImage.php
app/Models/CenterImage.php
```

### Step 4: Extract and Copy Services

**File**: `app_Services_ALL.php`

Extract each service class and create individual files:

```bash
app/Services/PricingEngine.php
app/Services/AvailabilityEngine.php
app/Services/SchedulingEngine.php
app/Services/BookingService.php
app/Services/RetreatService.php
```

### Step 5: Extract and Copy Controllers

**File**: `app_Http_Controllers_ALL.php`

Create directories and extract controller files:

```bash
mkdir -p app/Http/Controllers/{Retreat,Booking,Dashboard,Api}

app/Http/Controllers/Retreat/RetreatController.php
app/Http/Controllers/Retreat/RetreatPricingController.php
app/Http/Controllers/Booking/BookingController.php
app/Http/Controllers/Dashboard/OverviewController.php
app/Http/Controllers/Dashboard/AccountController.php
app/Http/Controllers/Api/PricingController.php
app/Http/Controllers/Api/AvailabilityController.php
app/Http/Controllers/Api/RetreatController.php
```

### Step 6: Extract and Copy Requests

**File**: `app_Http_Requests_ALL.php`

Extract and create:

```bash
app/Http/Requests/StoreRetreatRequest.php
app/Http/Requests/UpdateRetreatRequest.php
app/Http/Requests/StorePricingRequest.php
app/Http/Requests/StoreBookingRequest.php
app/Http/Requests/UpdateAccountRequest.php
app/Http/Requests/StoreAccommodationRequest.php
app/Http/Requests/CreateScheduleRequest.php
app/Http/Requests/CreateRecurringRequest.php
```

### Step 7: Copy Other Components

**Files**: 
- `app_Policies_ALL.php` → `app/Policies/`
- `app_Events_ALL.php` → `app/Events/`
- `app_Jobs_ALL.php` → `app/Jobs/`
- `app_Listeners_ALL.php` → `app/Listeners/`
- `app_Notifications_ALL.php` → `app/Notifications/`
- `app_Utilities_ALL.php` → `app/Utilities/`

### Step 8: Copy Migrations

**File**: `database_migrations_ALL.php`

Extract each migration class and create files with timestamps:

```bash
database/migrations/2025_01_01_000000_create_users_table.php
database/migrations/2025_01_01_000001_create_centers_table.php
database/migrations/2025_01_01_000002_create_experiences_table.php
database/migrations/2025_01_01_000003_create_accommodations_table.php
database/migrations/2025_01_01_000004_create_experience_accommodations_table.php
database/migrations/2025_01_01_000005_create_bookings_table.php
database/migrations/2025_01_01_000006_create_experience_schedules_table.php
database/migrations/2025_01_01_000007_create_experience_recurring_table.php
```

### Step 9: Copy Routes (Directly)

```bash
# Copy directly (no extraction needed)
cp routes_web.php routes/web.php
cp routes_api.php routes/api.php
```

### Step 10: Extract and Copy Views

**File**: `resources_views_ALL.blade.php`

Create directories and extract Blade files:

```bash
mkdir -p resources/views/{layouts,components,retreat,booking,dashboard}

resources/views/layouts/app.blade.php
resources/views/components/sidebar.blade.php
resources/views/components/topbar.blade.php
resources/views/retreat/index.blade.php
resources/views/retreat/create.blade.php
resources/views/retreat/edit.blade.php
resources/views/retreat/show.blade.php
resources/views/booking/index.blade.php
resources/views/booking/preview.blade.php
resources/views/booking/show.blade.php
resources/views/dashboard/index.blade.php
resources/views/dashboard/account.blade.php
```

### Step 11: Copy Config (Directly)

```bash
cp config_balanceboat.php config/balanceboat.php
cp .env.example .env
```

### Step 12: Update Environment

Edit `.env`:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=balanceboat_center
DB_USERNAME=root
DB_PASSWORD=
```

### Step 13: Run Migrations

```bash
php artisan migrate:fresh
```

### Step 14: Create Test User

```bash
php artisan tinker
```

Inside tinker:
```php
use App\Models\User;
use App\Models\Center;

$user = User::create([
    'first_name' => 'Test',
    'last_name' => 'User',
    'email' => 'test@example.com',
    'password' => bcrypt('password')
]);

$center = Center::create([
    'user_id' => $user->id,
    'name' => 'Test Center',
    'slug' => 'test-center',
    'email_address' => 'center@example.com'
]);

exit
```

### Step 15: Start Development Server

```bash
npm run dev      # In another terminal
php artisan serve
```

Visit: **http://localhost:8000**

---

## 📋 File Extraction Process

Each `*_ALL.php` file contains multiple PHP classes. Here's how to extract them:

### Example: Extracting Models from `app_Models_ALL.php`

The file contains:

```php
<?php

// FILE: app/Models/User.php
namespace App\Models;

class User extends Authenticatable
{
    // ... class content
}

// FILE: app/Models/Center.php
namespace App\Models;

class Center extends Model
{
    // ... class content
}

// ... more classes
?>
```

**How to extract:**

**Option 1: Manual (Using IDE)**
1. Open `app_Models_ALL.php` in VS Code or PHPStorm
2. Find each `// FILE: ...` comment
3. Select the class code below it
4. Create new file with that name
5. Paste the code

**Option 2: Using Script**
```bash
#!/bin/bash
# Split app_Models_ALL.php into individual files

php << 'PHP'
$content = file_get_contents('app_Models_ALL.php');
$pattern = '/\/\/ FILE: (.*?)\n(.*?)(?=\/\/ FILE:|$)/s';

preg_match_all($pattern, $content, $matches);

for ($i = 0; $i < count($matches[1]); $i++) {
    $filename = trim($matches[1][$i]);
    $code = "<?php\n\n" . trim($matches[2][$i]) . "\n\n?>";
    
    // Create directory if needed
    $dir = dirname($filename);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    file_put_contents($filename, $code);
    echo "Created: $filename\n";
}
PHP
```

---

## ✅ Verification Checklist

After completing all steps:

```bash
# Check all files are in place
ls -la app/Models/          # Should show 20 files
ls -la app/Services/        # Should show 5 files
ls -la app/Http/Controllers # Should show 7 files (in subdirs)
ls -la app/Http/Requests/   # Should show 8 files
ls -la app/Policies/        # Should show 3 files
ls -la app/Events/          # Should show 3 files
ls -la app/Jobs/            # Should show 3 files
ls -la database/migrations/ # Should show 8 files

# Check syntax
php -l app/Models/User.php
php -l app/Services/PricingEngine.php

# Verify autoloading
php artisan tinker
> App\Models\User::count();
> exit

# Check routes
php artisan route:list

# Run migrations
php artisan migrate:fresh

# Start server
php artisan serve
```

---

## 🎯 What Each File Contains

| File | Classes | Purpose |
|------|---------|---------|
| `app_Models_ALL.php` | 20 | Database models |
| `app_Services_ALL.php` | 5 | Business logic services |
| `app_Http_Controllers_ALL.php` | 7 | Web & API controllers |
| `app_Http_Requests_ALL.php` | 8 | Form validation |
| `app_Policies_ALL.php` | 3 | Authorization rules |
| `app_Events_ALL.php` | 3 | Event classes |
| `app_Jobs_ALL.php` | 3 | Queue jobs |
| `app_Listeners_ALL.php` | 1 | Event listeners |
| `app_Notifications_ALL.php` | 1 | Email notifications |
| `app_Utilities_ALL.php` | 3 | Helper classes |
| `database_migrations_ALL.php` | 8 | Database tables |
| `routes_web.php` | Routes | Web endpoints |
| `routes_api.php` | Routes | API endpoints |
| `resources_views_ALL.blade.php` | 8+ | Blade templates |
| `config_balanceboat.php` | Config | App configuration |
| `.env.example` | Config | Environment template |

---

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| "Class not found" | Run `composer dump-autoload` |
| "Column not found" | Run `php artisan migrate:fresh` |
| "File not found" | Check file placement matches structure |
| "Syntax error" | Check PHP syntax with `php -l filename` |
| "Route not found" | Check `routes/web.php` and `routes/api.php` |
| "Permission denied" | Run `chmod -R 755 storage/` |

---

## 🚀 You're Ready!

After completing these steps, you have a **complete, production-ready** Laravel application with:

✅ 20 Eloquent models  
✅ 5 service classes  
✅ 7 controllers  
✅ 8 form validators  
✅ 3 policies  
✅ 3 events  
✅ 3 queue jobs  
✅ 8 Blade views  
✅ All necessary migrations  
✅ Complete routing  
✅ Full documentation  

**Happy coding! 🎉**

---

## 📞 Quick Help

**Getting Started**: Read `START_HERE.md`  
**Setup Issues**: Check `INSTALLATION_GUIDE.md`  
**File Locations**: See `COMPLETE_STRUCTURE_GUIDE.md`  
**Architecture**: Read `LARAVEL_ARCHITECTURE.md`  

All documentation files are in the root output directory.
